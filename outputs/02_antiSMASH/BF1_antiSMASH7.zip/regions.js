var recordData = [
 {
  "length": 262493,
  "seq_id": "NODE_1_length_262493_cov_27.458158",
  "regions": []
 },
 {
  "length": 236886,
  "seq_id": "NODE_2_length_236886_cov_27.478647",
  "regions": []
 },
 {
  "length": 182114,
  "seq_id": "NODE_3_length_182114_cov_26.914660",
  "regions": []
 },
 {
  "length": 179513,
  "seq_id": "NODE_4_length_179513_cov_27.340071",
  "regions": []
 },
 {
  "length": 170784,
  "seq_id": "NODE_5_length_170784_cov_30.371631",
  "regions": [
   {
    "start": 28687,
    "end": 56791,
    "idx": 1,
    "orfs": [
     {
      "start": 28748,
      "end": 29230,
      "strand": 1,
      "locus_tag": "ctg5_31",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_31</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_31</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,748 - 29,230,\n (total: 483 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_31\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGCGGGCGAGCGCTGGTGCTGGCGGTCGCGCTGCTGGCGGTGCCCGCCGCCGCGCGGCAGACGATCGGCGTCTACAAGAGCTGGGGCGCGTTTCGCGATCCCGACCGCTGCTATGCCATCGCCCAGCCCGTGCTCGCCAATGGCCGACCGGGCGGTTTCGCGACCGTGGGCACCTGGCCCGCCAAGCGGCTGCGCGCCTCCTTTCACCTGCATCTAAGCGCGCCGCGCGACCGCGCCGCGCCGGTGACGCTGGCGATCGGCGAGCGCCGCTTCCCGCTGATCGGGACCGACCGCGACATCTGGGCGCCCGATGGGGCTACCGACCATGCGCTGGTCATGGCGATGCGATCGGGGCGCAGCATGAGCGTGTCGGCGGTCGACACCCGCCACCGCCCCTTTGCCGACACCTATGCGCTGGCCGGTGCGGCTGCGGCGATCGACGCGGCGACGCTGGCCTGTGTGGCAGGGAATCCCGGCTGA",
      "translation": "MSGRALVLAVALLAVPAAARQTIGVYKSWGAFRDPDRCYAIAQPVLANGRPGGFATVGTWPAKRLRASFHLHLSAPRDRAAPVTLAIGERRFPLIGTDRDIWAPDGATDHALVMAMRSGRSMSVSAVDTRHRPFADTYALAGAAAAIDAATLACVAGNPG",
      "product": ""
     },
     {
      "start": 29257,
      "end": 30495,
      "strand": 1,
      "locus_tag": "ctg5_32",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_32</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_32</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,257 - 30,495,\n (total: 1239 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_32 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04055.24 (Radical SAM superfamily): [148:319](score: 60.8, e-value: 2.2e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_32 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04055.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF04055.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051536' target='_blank'>GO:0051536</a>: iron-sulfur cluster binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_32\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACACGATTTTGCGCTATGGCCGCGCGATGCAGACAGTTTCGGCCGCCCCCATGCCCATCCCCGGGCACATCGATCCCGTGCCCGTGCCGCGCGGCGTGCAACCGCGCCCGGATGGTCGCGTCGACCTGATCGGCCTGACCAAGGACCAGTTGCGCGAGGCGCTGCTGTCGGCGGGCATGGAATTGAAGCAGGCCAAGCTGCGCTCCAAGCAGATCTGGCACTGGCTCTACAATCGCGGCGCGGTGCGCTTTGCCGACATGACCGATATCGCCAAGGCGCAGCATCCCTGGCTGGAGGAACGCTTCGTCATCGGCCGTCCCGAGGTGGTCGAGGCGCAGGTGTCGAGCGACGGCACCCGCAAATGGCTGCTCCGCTCGCCCGACGGGCAGGATTACGAGATGGTGTTCATCCCCGACGCCGATCGGGGCACCCTGTGCGTGTCGAGCCAGGTCGGCTGCACGCTCAACTGCCGCTTCTGCCACACCGGCACGATGCGCCTGGTCCGTAACCTGACCGCGGGCGAGATCGTGGGACAGGTCATGCTGGCGCGCGACTCGCTCGGCGAATGGCCCAGCCAGCCCGAGGGCCGCATGCTGACCAACATCGTCATGATGGGCATGGGCGAGCCGCTCTATAATTTCGACGCGGTGCGCGATGCCTTGAAGCTGGTGATGGACGGCGACGGGCTGGCCCTGTCCAAGCGTCGCATCACGCTGTCGACCAGCGGCGTGGTGCCGATGATGGCGCGTGCGGGAGAGGAGATTGGCGTCAACTTGGCCGTCTCGCTCCACGCGGTGACCAAGGACGTGCGCGACGAGATCGTGCCGCTCAACAAGAAATACGGCATCGAGGAACTGCTTCAGGCCTGTGCCGATTATCCGGGGGCGAACAACGCGCGGCGTATCACCTTCGAATATGTGATGCTCAAGGACAAGAACGACTCGGACGCCGATGCGCACGAACTCGTCCGCCTGCTGCGCCACTATAAGCTGCCCGCCAAGGTGAACCTGATCCCGTTCAATCCCTGGCCGGGCGCGGCCTATGAATGTTCGGATCCAGAGCGCATCCGCCGGTTCTCCGACATCGTGTTCGAGGGCGGCATCTCCGCCCCCGTCCGCACTCCGCGCGGGCGCGACATCGACGCCGCCTGTGGCCAGCTCAAGACCGCCGCCGAGAAGAAGAGCCGCGCGCAGCTCGACCGCGAGGCGGAAGAAAAGTTCGCGGCGCTGGGGTGA",
      "translation": "MDTILRYGRAMQTVSAAPMPIPGHIDPVPVPRGVQPRPDGRVDLIGLTKDQLREALLSAGMELKQAKLRSKQIWHWLYNRGAVRFADMTDIAKAQHPWLEERFVIGRPEVVEAQVSSDGTRKWLLRSPDGQDYEMVFIPDADRGTLCVSSQVGCTLNCRFCHTGTMRLVRNLTAGEIVGQVMLARDSLGEWPSQPEGRMLTNIVMMGMGEPLYNFDAVRDALKLVMDGDGLALSKRRITLSTSGVVPMMARAGEEIGVNLAVSLHAVTKDVRDEIVPLNKKYGIEELLQACADYPGANNARRITFEYVMLKDKNDSDADAHELVRLLRHYKLPAKVNLIPFNPWPGAAYECSDPERIRRFSDIVFEGGISAPVRTPRGRDIDAACGQLKTAAEKKSRAQLDREAEEKFAALG",
      "product": ""
     },
     {
      "start": 30699,
      "end": 31460,
      "strand": 1,
      "locus_tag": "ctg5_33",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_33</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_33</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,699 - 31,460,\n (total: 762 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_33 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01925.22 (Sulfite exporter TauE/SafE): [10:244](score: 95.0, e-value: 5.8e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_33 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01925.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_33\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCGACTGGACCTTTCTCGCACTGGCGGCCGCCGGAGGTTTTGTCGGGGGTGCGATGAATGCGCTGGCGGGCGGGGGCAGTTTCTCGACCATGCCGACGCTGATCGCGCTGGGGCTGCCTTCCACCATCGCCAATGCGACCTCCAATGTCGCGCTTCAGCCCGCCGCGATGGCCAGCGTCTGGGCCTATCGCCATGGCCTGGAGCCGGTGATGGGCGTGTCGATGCGGCGCATGGCGGCGCTGACCTTCGTCTTCGCGCTGCTGGGCAGCATCCTGTTGTTCCTGACGCCGCCGCGCGCTTTCGACCTGATCGTGCCATGGCTGTTGCTGACCGCGACGCTGGCGATTGCGGGGGGACGCCATGCCTCGGACTGGCTGGCGCGGATTGCCCGACCGGGCCCGCGCGCATTGATGGGCGCGCAGGCGGTGCTGGGCATCTATGGCGGCTATTTCGGCGGCGGCATCGGCATGATGCTGACCGCCGCCTGGGGATTGCTGTCGGGACGCAATCCGGCGCAGCTCGCCGCCCCCCGTACGCTGATGCTGGCCACCGCCAATGCGGCGGCGACCTTGGTCTTCGTCGTCACCGGCATGGTCGCCTGGGCACAATGCGTGCCGATGCTGCTGGGCGGGATCGTCGGCGGATGGAGCGGGGCGATCATCGGCCGCAAGCTGCCCGCCGGCCTGATCCGGGTGTGGACCTTGTTGCTCACCAGCGTCACCACGCTGGTGTTCTTCTGGCGGGGCTATATCGTGTGA",
      "translation": "MIDWTFLALAAAGGFVGGAMNALAGGGSFSTMPTLIALGLPSTIANATSNVALQPAAMASVWAYRHGLEPVMGVSMRRMAALTFVFALLGSILLFLTPPRAFDLIVPWLLLTATLAIAGGRHASDWLARIARPGPRALMGAQAVLGIYGGYFGGGIGMMLTAAWGLLSGRNPAQLAAPRTLMLATANAAATLVFVVTGMVAWAQCVPMLLGGIVGGWSGAIIGRKLPAGLIRVWTLLLTSVTTLVFFWRGYIV",
      "product": ""
     },
     {
      "start": 31467,
      "end": 32219,
      "strand": -1,
      "locus_tag": "ctg5_34",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_34</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_34</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 31,467 - 32,219,\n (total: 753 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_34\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGCCGGCGGCATTGGCCGACGTACTGCTGGCATCCGGCCATCCGCCGATCGTCGAGGCCGATGTCGGCCCGGAGGGCATGATGCCGCCCGCGCCGCCAGGCGTTCCCGTCGTCAACGCGATTCGGCTGTACACGGCCGCGACCCCTGCGGATCATCCGGGCTTTTGCGAAAAGACGCGGATCGATGTATCGCTGGCGCCGCGCATGCGTCGGGGCGATGCGGTCCCCGCCGCTCCCGCCGATGCCGTCACCACGACGAAACTGTACCGCTGGGCGCGGCCGGCGAAGGATGGCACAGGATGTGAAGCGCCGGCGTGGAGCTTTTTCCGGCGTGATGACGTCTTGGGCGACCGCAGCTTCAGCGTCGTCCGCCGTTTTGCAACGCTCCGGCCCGCCCGGCTTCGCAAGCTGCGGATCACCATCGACGATCGCCTTACCCGCAACCTGGCGGACATGGTCAAGGCATATCCGCAGGACTTTCCCGGCATATCGAAAGATCGCCTGACCCCGATCACGGATGGCCGGGTCGCGCTGGCGCGGTTTCCGATCTCGTCCATCCGCTACGTCGCTCCCTATAACGCGAGCTGGCCCAACGATCTTCTGGACAAGGCCGACCTTCAGGATGCGGCAGGGCGCGAGTTTGATGCGGTCATGGTCGGAACCGGTGGCGAATGGCATGCCGGGATCGTGTTCGATGGCGACCAGATCGTCACGATCCGCTTTGTCCGGGCTATACCTCCGCCATCCTGA",
      "translation": "MTPAALADVLLASGHPPIVEADVGPEGMMPPAPPGVPVVNAIRLYTAATPADHPGFCEKTRIDVSLAPRMRRGDAVPAAPADAVTTTKLYRWARPAKDGTGCEAPAWSFFRRDDVLGDRSFSVVRRFATLRPARLRKLRITIDDRLTRNLADMVKAYPQDFPGISKDRLTPITDGRVALARFPISSIRYVAPYNASWPNDLLDKADLQDAAGREFDAVMVGTGGEWHAGIVFDGDQIVTIRFVRAIPPPS",
      "product": ""
     },
     {
      "start": 32320,
      "end": 32907,
      "strand": -1,
      "locus_tag": "ctg5_35",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_35</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_35</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,320 - 32,907,\n (total: 588 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_35 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03703.17 (Bacterial PH domain): [63:143](score: 56.9, e-value: 1.9e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_35\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGGATGTGGTCGAGCACCAGGGCGATGCGCCCGTGACGTTGTTGCAGGGGCGGTTCAGCAGCCAGCTGCGCCTCTATTTCCTGGCCTATTGGACGGCGGTGGTCATGCTGTCCGTGATCGGGATCATGCTTCTGCCCGTCTGGCTGGTGATCGGCCCGCCCTGGATCCGCCGTTACCACGCGGCGTTGCGCTGCGACCTGACGGAGCGCAGCGTGGTGATCGGCAAGGGGCTGATCTTCCGTCGCGAGTTGACGATCCCGCTGGACAAGATCCAGGACATCTCGATCCGCGAGGGGCCACTGCTCAAGAGGTTCGGTCTTTTGCAGCTGCGCGTGGAAACCGCCGGGCAAAGCCAGTCGGCGTCGGGAAAGTCCGATGCCGACCTGGTCGGCCTGGTCGATGCCCGCGCGGTGCGGGACCGCATCCTCGAACAGCGCGACCGACTGGCGATGGCCGACGGTTCGGGCACCGTACCGTCATCGGACCGACAGGTGCTGGTCGACATTCGCGATAGCCTGTTGCGGCTGGAGCAGGCGATCGCCGGACGCGTGACCGGTTCGCCCGCACCGCGCGATCCGCAATAG",
      "translation": "MADVVEHQGDAPVTLLQGRFSSQLRLYFLAYWTAVVMLSVIGIMLLPVWLVIGPPWIRRYHAALRCDLTERSVVIGKGLIFRRELTIPLDKIQDISIREGPLLKRFGLLQLRVETAGQSQSASGKSDADLVGLVDARAVRDRILEQRDRLAMADGSGTVPSSDRQVLVDIRDSLLRLEQAIAGRVTGSPAPRDPQ",
      "product": ""
     },
     {
      "start": 32998,
      "end": 33618,
      "strand": -1,
      "locus_tag": "ctg5_36",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_36</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_36</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,998 - 33,618,\n (total: 621 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_36 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01613.21 (Flavin reductase like domain): [26:174](score: 52.1, e-value: 8e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_36 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01613.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0010181' target='_blank'>GO:0010181</a>: FMN binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_36\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTCAGGACTGGCATTTCTACGAACCCGTCAACGGCCATGGCCTGGCACATGATCCGCTGAACGCGATCGTCGCCCCGCGCCCGATCGGCTGGATCGGCAGCCGGTCGAGCGCGGGCGTCAACAATCTGGCACCATACAGCTTTTTCAACCTGTTCAACTACCGCCCGCCGCTGATCGGCTTTTCGTCGCAAGGGTGGAAGGACTCGGTTGCCAACATCGCCGAGACGCAGGTCTTCACCTGGAATCTGGCGACCATGGCGCTGGCCGAGCCGATGAACGCCAGCGCCGCGATGGTCGGCGCCGAGGTGGACGAATTCGCGCTCGCCGGGCTGGCGGTGGAGGAAGGGCGGGTGGTCGCGGCACCGCGCGTGGCGGCCAGCCCGGTCTCGTTCGAATGCCGCCTGACCCAGCTCATCCGGCTGGAAACCAAGGAAGGGCGGGAGCTCGACCAGTGGCTGGTGATCGGCGAGGCGGTGGGCATCCATATCGCCACCGCAATGATCGAGAACGGCATCTATCAGACGGCACGCGCGCGTCCGATCCTGCGCGGCGGCGGGCCGGTCGATTATTTCGAAGTGACCGAAGGCGCGCGGTTCGAGATGCGGCGGCCGGACTGA",
      "translation": "MTQDWHFYEPVNGHGLAHDPLNAIVAPRPIGWIGSRSSAGVNNLAPYSFFNLFNYRPPLIGFSSQGWKDSVANIAETQVFTWNLATMALAEPMNASAAMVGAEVDEFALAGLAVEEGRVVAAPRVAASPVSFECRLTQLIRLETKEGRELDQWLVIGEAVGIHIATAMIENGIYQTARARPILRGGGPVDYFEVTEGARFEMRRPD",
      "product": ""
     },
     {
      "start": 33643,
      "end": 34371,
      "strand": 1,
      "locus_tag": "ctg5_37",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_37</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_37</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,643 - 34,371,\n (total: 729 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_37 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01292.23 (Prokaryotic cytochrome b561): [19:236](score: 129.6, e-value: 1e-37)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_37 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01292.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009055' target='_blank'>GO:0009055</a>: electron transfer activity<br>\n  \n   PF01292.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_37\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_37_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAAGCCCAAACGCCGCCCGATCCGCAAAGAGCCGATGGGCCGCGCGTCATCCGCCGTCATGGCTTGGTGACGCGGCTGTGGCACTGGGTCAATGCGGTGGCGGTGCTGATCCTGCTGGGATCGGGGCTGGGCATCTCCAACGCACATCCCCGGCTTTATTGGGGGCGCTATGGGGCGAATTTCGATCCCGCCTGGGCGACTCTGCCGCGTTTTCCCAGTTGGCTGACCATTCCCGCCCATTACAATCTGGCGATCTCGCGCCGCTGGCATCTCTTCTTCGCGCTGGTGCTGGGCTTCGGGCTGCTGGCCTATATGGTCGGCGGGCTGCTCACGCGGCATTTCCAGCGTGACCTGCGCATCCGGGGGCATGAGCTGCGCCCGCATGCGCTATGGGTCGATTTCAAGCGGCATCTGGCGTTCCGCTTTCACGACGAAAGGGACCCGCGCGCCTACAACCTCTTCCAGAAGTTCAGCTATGCGCTGGTGCTGTTCGTCGCCCTGCCGCTTGCCATCCTGACCGGGATCGCGCTGTCGCCGGGGATGAATGCGGCCTGGCCCTGGGTGCTGGAGATATTGGGCGGACGGCAATCGGCGCGCTCGATCCATTTCATCACCGCGAGCCTGTTGGCGCTGTTTACCATCGTCCATCTCGCGCTCGTCATCCTGGCGGGCGCGGGCAATGAGGTGCGGTCGATGATTACCGGCCGCTGGAGGGTTCCCGAATGA",
      "translation": "MEAQTPPDPQRADGPRVIRRHGLVTRLWHWVNAVAVLILLGSGLGISNAHPRLYWGRYGANFDPAWATLPRFPSWLTIPAHYNLAISRRWHLFFALVLGFGLLAYMVGGLLTRHFQRDLRIRGHELRPHALWVDFKRHLAFRFHDERDPRAYNLFQKFSYALVLFVALPLAILTGIALSPGMNAAWPWVLEILGGRQSARSIHFITASLLALFTIVHLALVILAGAGNEVRSMITGRWRVPE",
      "product": ""
     },
     {
      "start": 34368,
      "end": 35111,
      "strand": 1,
      "locus_tag": "ctg5_38",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_38</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_38</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,368 - 35,111,\n (total: 744 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_38 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00174.22 (Oxidoreductase molybdopterin binding domain): [85:223](score: 133.2, e-value: 7.3e-39)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_38\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_38_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCCGGCGTCGTACCATTCTGACCGGCGGTGCGGGGCTGCTCCTCGCAGGCTGCGACAAGGTCATCCAGCAGCCCACCGCACGGAAGATCCTCTTCGCGGGTGAGGATATGCAGAAGGGCTTGCAGCGTGCGCTGATGGATCGCGGGGCGCTGGCCCCCGAATATCGCCGTGACCAGATGTCGCCCTATTTCCGCACCAACGGCACCCGCGATCCGGGGACGCCGGAATATCGGGCGCTGGTGGAAAACCGCTTTGCCGATTGGCGGCTGAAGGTCGGCGGGCTGGTCGGCACGCCATTGTCGCTCTCACTACGCCAGATCGGCGAATTTCCGGCGCGTCGCCAGATCACCCGGCATGACTGTGTCGAGGGGTGGAGCGCGATCGGCGAGTGGATGGGGCCGATGCTGGGCAATGTGCTGAAGGCCGCGAACATCAGCGACCGCGCGCGCTATGTTGTCTTCACCTGCGCCGACCTATACGGGGGCCAGCCCTATTATGAATCGCTCGACCTGATCGACGCCTTCCATCCGCAGACGATCCTCGCCTGGGGCATGAACGGCCGGATGCTGGATGTCGGGCATGGCGCACCGTTGCGGCTGCGGGTCGAGCGGCAACTGGGATACAAGCACGCCAAATATGTGATGCGGATCGATGCGGTCGACAGTTTGTCCAACATAGGTTTGGGCAAGGGCGGATACTGGGAAGACCATGTCGATTATGACTGGTACGCCGGGATTTAA",
      "translation": "MIRRRTILTGGAGLLLAGCDKVIQQPTARKILFAGEDMQKGLQRALMDRGALAPEYRRDQMSPYFRTNGTRDPGTPEYRALVENRFADWRLKVGGLVGTPLSLSLRQIGEFPARRQITRHDCVEGWSAIGEWMGPMLGNVLKAANISDRARYVVFTCADLYGGQPYYESLDLIDAFHPQTILAWGMNGRMLDVGHGAPLRLRVERQLGYKHAKYVMRIDAVDSLSNIGLGKGGYWEDHVDYDWYAGI",
      "product": ""
     },
     {
      "start": 35130,
      "end": 36359,
      "strand": 1,
      "locus_tag": "ctg5_39",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_39</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_39</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,130 - 36,359,\n (total: 1230 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PCMT<br>\n \n  biosynthetic-additional (smcogs) SMCOG1089:methyltransferase (Score: 79.3; E-value: 5.4e-24)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_39 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02353.23 (Mycolic acid cyclopropane synthetase): [118:378](score: 293.8, e-value: 1.2e-87)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_39\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_39_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGCTGATCGATCTCTTTCTGTCGCGCGCGGTCCGCAAGGGCCGCCTGTCCCTCACCCATCATGACGGCACCGTCCGCGAGTTCGGCTCACCCGAACCTGGTTACCCGGATGTCGCAATCCGCTTCACGGACGCCCGCGTCGCCGGGCAGATCGTCCGCAACCCCGCGCTGGCGGCGGGCGAGTGCTTTATGGACGGCCGCCTGGTCGTCGAGAAGGGCGATGTCCGCGACCTGGTCGAACTGCTGACCGCCAATGACAAATGGGAAGCGGGAGCAGACCGGCTCAATCCGTCCTGGCTGGTCCGCGCGGGCGGCGCGGTGAAGCATCGCATCGACCGGATCAACATGGAGCGCCGCTCGAAAAAGAATGTCGCCCACCATTACGACCTGTCGGGCACGCTGTACGAACTCTTCCTCGACACCGACAAGCAGTATAGCTGCGCCTATTATACCGATCCCCAGAACGATCTGGAGCGGGCGCAACGCGATAAAAAGGCGCATATCGCCGCCAAGCTGGCGATCCAGCCGGGGATGAAGGTGCTCGACATCGGTTGCGGCTGGGGCGGGATGGCGCTCTATCTGCATCAGATGTGCGGCGCCGAGGTGCTGGGCGTCACCTTGTCCGAGGAACAGCTGAAGGTGGCGCGCCAGCGTGCCGAGGCGCTGGGCGTCGCGGACAAGGTGAAGTTCGAGCTGATCGACTATCGCCGGGTCGAGGGGAAGTTCGACCGCATCGTCTCGGTCGGGATGTTCGAGCATGTCGGCCCGCCGCAATATCGCACCTTCTTTCGCAAGTGCCGCGACCTGCTGACCGAGGATGGCGTGATGCTGCTCCACACGATCGGGCGGCTGGGCGGTCCGGGCGTGACCGACGACTGGACGACCAAGTACATCTTCCCCGGCGGCTACAATCCGGCCCTGTCGGAGATCGTCCGCGCGCAGGAGGGGCTGCGTATGTTCCTGACCGATGTCGAGGTGCTGCGCTGCCATTATGGCTGGACGCTCGACGAATGGTATGCGCGGACGGTGGCGGCGAAGGAGCGGATCGTCGAGCTGTATGACGAGCGCTTCTATCGCATGTGGCTATTCTATCTGGCGGGTGCGGGCGCGGCGTTCCGCAATGGCGGGCTTTGCAACTACCAGGTGCAGTTGACGCGCGGGCGCATGTCGGTGCCGGTGACGCGGGATTATATGTTCGAGGGGGAACGCGAACTGCGCGCGCGGTAG",
      "translation": "MALIDLFLSRAVRKGRLSLTHHDGTVREFGSPEPGYPDVAIRFTDARVAGQIVRNPALAAGECFMDGRLVVEKGDVRDLVELLTANDKWEAGADRLNPSWLVRAGGAVKHRIDRINMERRSKKNVAHHYDLSGTLYELFLDTDKQYSCAYYTDPQNDLERAQRDKKAHIAAKLAIQPGMKVLDIGCGWGGMALYLHQMCGAEVLGVTLSEEQLKVARQRAEALGVADKVKFELIDYRRVEGKFDRIVSVGMFEHVGPPQYRTFFRKCRDLLTEDGVMLLHTIGRLGGPGVTDDWTTKYIFPGGYNPALSEIVRAQEGLRMFLTDVEVLRCHYGWTLDEWYARTVAAKERIVELYDERFYRMWLFYLAGAGAAFRNGGLCNYQVQLTRGRMSVPVTRDYMFEGERELRAR",
      "product": ""
     },
     {
      "start": 36397,
      "end": 36798,
      "strand": -1,
      "locus_tag": "ctg5_40",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_40</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_40</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,397 - 36,798,\n (total: 402 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_40\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTCTGCCCCTGGCCGGGACCATGTCGGGCTGGGCGCTGGCGGGCGGAGCGGCGGGAACGCTGCTGAGCGGCGCCGGGATCGGCCTGCTGCTCCGGCGGCGGCGCGATCGCCGGGTCGGCTCGCCTGAAGAGGTGGCGGCGGCGGCCGAAGCAGCGCTGAGCGGTTTCATCGTATCGGGCGCGGTGGTCGGCGCGGACGGGCAGGGCGCGCTGGCGGTGGCGACCGATGGCCGGGTCGCGGCGATCAAACGGCAAGGGCGCATGCTCGCGGTGCGTGAAATCCCCTGGACCCGGGTGCGCTCGACCGCCGAGGGTATCATTGCCGAGGTCGAGGGGCGCTTCGGTTCGGTCACGCTGGCCGGAGTGGATGTGCTGGATATCCGGCGGCTCAAGGCCTGA",
      "translation": "MTLPLAGTMSGWALAGGAAGTLLSGAGIGLLLRRRRDRRVGSPEEVAAAAEAALSGFIVSGAVVGADGQGALAVATDGRVAAIKRQGRMLAVREIPWTRVRSTAEGIIAEVEGRFGSVTLAGVDVLDIRRLKA",
      "product": ""
     },
     {
      "start": 36795,
      "end": 37226,
      "strand": -1,
      "locus_tag": "ctg5_41",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_41</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_41</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,795 - 37,226,\n (total: 432 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_41 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04273.16 (Beta-lactamase hydrolase-like protein, phosphatase-like domain): [1:108](score: 128.5, e-value: 1.3e-37)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_41 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04273.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_41\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCCGTCCCCTGAACGAAAGCGTCGCCGTCGCCCCCCAGATCCGTCCCGAGGACGTCGCGGCGATCAAGGCAGCGGGCTATACCGCCATCGTCAACAACCGTCCCGATGGCGAGGAGCCGAACCAGCCGACGGGCGATTCGATTCGCGCCGCAGCCGAGGATCATGGGCTGGCCTATACCGCGATCCCGGTGACGCCGGGCGGGTTCAGCCACGAGATGGTCGATCAGATGACCCAGGCGCTGACCGAGGCCAAGGGGCCGGTCCTGGCCTATTGCCGCTCGGGCACGCGCAGCTGCAATTTATGGGCACTGGCGGCGGCCAAGGCCGGGCGCAACCCGACGCTGATCGTGATGCAGGCCGAGGGTGCGGGCTATGACCTGTCCGGCCTGCGCCCGACGCTGGACGCGCTCGCGGGCGCGCAGGGATGA",
      "translation": "MIRPLNESVAVAPQIRPEDVAAIKAAGYTAIVNNRPDGEEPNQPTGDSIRAAAEDHGLAYTAIPVTPGGFSHEMVDQMTQALTEAKGPVLAYCRSGTRSCNLWALAAAKAGRNPTLIVMQAEGAGYDLSGLRPTLDALAGAQG",
      "product": ""
     },
     {
      "start": 37614,
      "end": 38636,
      "strand": 1,
      "locus_tag": "ctg5_42",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_42</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_42</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 37,614 - 38,636,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_42\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCGCTGATCGATCGTCGCCAGGGTCTATGGGGTCTGGCCGCCCTGGGAATCGCGGCCACGCTGCCCATGGCTTGGCGCCGGGCGCAAGCCGCGCCATCGACCCGGGGTACGCTCGCGCTGGTCGAGAAGGGCGAAGGGCGCGTCGCCTTTTACGATGTCGGCGATGGTCGTCGGTTGGGCACCGTGCCGCTGGGCGTCCAGCCGCATGAGATGGTCGCCGACCCCACGGGGCGCTACGCCTATGTCGGGGGGTATGGCGTGAAGGGCTGGCAGGCCGCCGGTGAGGGCGGCCATCAGCTCTGGGTGATCGACCTCGCCGAGCGGCGGCTGGCGCGCACCATCGATCTGGCGCCACATCGCCGCTGGCACGGGATGCGGATGGATGCGCAAGGCCGCCTCTATGCGCTGTCTGAGACGGACAGCCTGCTCGCCCGCTTCGACCAGCCGGCCGCCGCCGAGACGCCGGACCGGATGATTCCCGTCGGCGGCGCGCGCAGCCATTATTTCGTCGTCCGCCGCGACGGGGCTCGCGCCTATATCGCCGACACGATGAGCGGCATGGTCATCATGGTGAACCCCGACGATGCGAGCTTCGCCCCCGTCAAGCAACATATCGGCCAAGCGCCCGAGGGACTCGCGCTCAGCCCCGACGAGCGGACGCTCTATGTGGTGGATCGCCCGGCCGGCATCCTTCACGCCCTCGACGCCACGACGCTTCAGCCCCGTGCCCGCACCCGCTTGCGCGGCGAGGCGGTGCGGGTGATCGTGCAGCCCGATGGCCGGCTGATCGTGTCGAACCAAGGGGACAAGAGCCTGACCCGCCACGCCGCCGCCACACTCGCCGAGGAAGCACGGCTCGCGCTGCCCGCCGCTGCGCCGGGGCTGAACCTGCCGGCGGGGGGCACGACGCTCTATGCCGCGCTCGACAACAATCGGCTGGCGATCGTCGATCTGGCGGCCTGGAAGATCGTCGGCGGCTTTGCGACCGGAGAGGCGCCCGATACGGCGGTGCTCGCATGA",
      "translation": "MSLIDRRQGLWGLAALGIAATLPMAWRRAQAAPSTRGTLALVEKGEGRVAFYDVGDGRRLGTVPLGVQPHEMVADPTGRYAYVGGYGVKGWQAAGEGGHQLWVIDLAERRLARTIDLAPHRRWHGMRMDAQGRLYALSETDSLLARFDQPAAAETPDRMIPVGGARSHYFVVRRDGARAYIADTMSGMVIMVNPDDASFAPVKQHIGQAPEGLALSPDERTLYVVDRPAGILHALDATTLQPRARTRLRGEAVRVIVQPDGRLIVSNQGDKSLTRHAAATLAEEARLALPAAAPGLNLPAGGTTLYAALDNNRLAIVDLAAWKIVGGFATGEAPDTAVLA",
      "product": ""
     },
     {
      "start": 38687,
      "end": 39859,
      "strand": 1,
      "locus_tag": "ctg5_43",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38,687 - 39,859,\n (total: 1173 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: Lycopene_cycl<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_43 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05834.15 (Lycopene cyclase protein): [7:378](score: 313.5, e-value: 2.1e-93)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_43\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_43_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAGCCACGATTTCCTGCGATGTCGCGATTGTTGGTGCGGGGCTGGCCGGTGGCCTGATCGCCCTGGCGCTCAAGGCACGACACCCCTCGCTCGACCTGCGTCTGATCGACGCGGGCGAGACGATCGGGGGCAATCACGTCTGGTCCTTTTTCGGCAGCGACGTGGCCAAGCGCGATCGCTGGATCGTCGAGCGGCTGGTCGCGCATGGCTGGCGGCAATATGACGTCGCCTTCCCCGCCCATTCGCGCACGCTCGACCAGACCTATTATTCGATCGAAAGCCACCGCCTCGATACCGAGGTGCGCCGCGCCCTGCCGCCGCAGGCGCTGATCCTGGGGCGCAAGGTGCTGGCGGTGTCGGCCACTGCCGCCGTCTTCGCCGATGGCGACCGGGTGGAGGCCAAGGGCGTGATCGACGCGCGCGGCGCGGGCGACCTGTCCGCTTTGTCGTGCGGGTGGCAGAAATTCGTCGGCCAGGAATTGCGCCTGTCGCGCCCGCATGGCTGCACCCGGCCGGTGGTGATGGACGCCACCGTCAAGCAGATCGACGGCTATCGCTTCGTCTATGTCCTGCCCTTCGCCGAGGATCGGATCTTCGTCGAGGACACTTATTACTCCACCTCGTCCGAGCTGAATCGCCGCGCCATCGTTCAGCGGATCGAGCGCTATGCCGAGGCGCGCGACTGGCTGACGGCGGAGGTGGTGCGCGAGGAAGCCGGCGTCCTGCCGGTGGCGATGGGCGGCGATTTCGACGCCTATTGGCGCAGCGGCGGGGCAAAGACGCCCAAGGCCGGAATGCGCGCCGGGCTATTCCATCCCACCACCGGCTATTCGCTGCCCGATGCGATCCGTCTGGCCGCGATGCTGGCCGAACGGACCGACTTCGCCGGCGCCGACCTGCACGACGCGACCTATCGCATGGCCCGCGCCGCCTGGGATGCGCGCGGCTTTTATCGTATGCTCGACACGATGTTGTTCAAGGCCGCCGAGCCCGATGAGCGATACCGCGTGCTCGAGCGTTTCTATCGACTTGCGCCCGACCTGATCGGGCGATTCTATGCGGGGCAATCGACCATGGCCGACAAGGCACGAATTTTGACCGGACGGCCGCCGGTGCCGATCCTGCGCGCCATCGCCGCGCTGAGAAGCCAGACGGGGGGTCGCGCGTGA",
      "translation": "MAATISCDVAIVGAGLAGGLIALALKARHPSLDLRLIDAGETIGGNHVWSFFGSDVAKRDRWIVERLVAHGWRQYDVAFPAHSRTLDQTYYSIESHRLDTEVRRALPPQALILGRKVLAVSATAAVFADGDRVEAKGVIDARGAGDLSALSCGWQKFVGQELRLSRPHGCTRPVVMDATVKQIDGYRFVYVLPFAEDRIFVEDTYYSTSSELNRRAIVQRIERYAEARDWLTAEVVREEAGVLPVAMGGDFDAYWRSGGAKTPKAGMRAGLFHPTTGYSLPDAIRLAAMLAERTDFAGADLHDATYRMARAAWDARGFYRMLDTMLFKAAEPDERYRVLERFYRLAPDLIGRFYAGQSTMADKARILTGRPPVPILRAIAALRSQTGGRA",
      "product": ""
     },
     {
      "start": 39856,
      "end": 41331,
      "strand": 1,
      "locus_tag": "ctg5_44",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 39,856 - 41,331,\n (total: 1476 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1222:dehydrogenase (Score: 405; E-value: 9.1e-123)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_44 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01593.27 (Flavin containing amine oxidoreductase): [11:488](score: 151.5, e-value: 5e-44)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_44 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01593.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_44\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_44_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAAGAGCGCGGTCGTCATCGGGTCGGGCTTTGGCGGCCTGGCGCTCGCCATTCGCCTGCAATCGGCGGGCGTGCAGACCACCATCGTCGAGGCGCGGGACAAGCCCGGCGGCCGGGCTTATTATTGGGAGCGCGACGGCTTCACCTTCGATGCCGGCCCCACCGTCATCACCGACCCGGCCTGTCTGGAGGAACTCTGGGCGCTGACCGGGCGCAGCATGTCGGAGGACGTCAAACTCGATCCGGTCAGCCCCTTCTACCGGCTCAATTGGGTCGACGGCACCAATTTCGATTACAGCAACGACGACACCCAGCTCCGCTCCGAGATCGCCAAGCTGAACCCCGACGATATCGCGGGCTATGGCCGGTTCCTCGACTATGCCGCCGGGGTCTACCGCGAAGGCTATGAGAAGCTGGGCCATGTCGCCTTTCTCGACTTCGCCTCGATGGTGAAGGCCGCGCCTGCGCTGGCGAAGTACCAGGCATGGAATTCGGTCTATGCCATGGTCTCGAAATTCGTGAAGTCGGAGAAGCTGCGCGAGGCCCTGTCCTTCCACACGCTGCTGGTCGGCGGCAATCCGATGACGACCAGCGCCATCTATGCGCTGATCCACAAGCTGGAGCGCGATGGCGGCGTCTGGTTCGCGCGCGGCGGTACCAATAGGCTGGTCGCCGGCATGGTCGCGCAGTTCGAGCGGATCGGCGGCGTGCTGCGTCTGGGTGATCCCGTCGCGCGGATCGAGACTTTGGGCGACCGCGCGACCGGCGTGGTGACGAAGAGCGGCCTGACGATCCAGGTGGATGCGGTCGCGACCAATGCCGATATCATGCACAGCTACCGCGATCTGCTGGCCGACAATCGCTCGGCCCGGCGGACGGTCAACCGGCTGGAGCGCAAGCGCTATTCGCCGTCGCTGTTCGTCGTCCATTTCGGCATCAAGGGCGCGTGGCCGGGCATCCCGCACCACATGATCCTGTTCGGGCCGCGCTATAAGGGCCTGCTGACAGACATCTACGACACCGGGGTGCTGTCGGAGGACTTCTCGCTCTACCTCCACCACCCGACCGTCACCGACCCTAGCTTGGCGCCCGAAGGCCATTCGACCTTCTATGCGCTGGCCCCGGTGCCGCACATGGGCAAGTTCCCGATGAACTGGGACGAAGTCGGGCCGATCCTGGAAAAGCGCATCCTCGACGAGGTCGGCCGCCGCCTGATCCCCGACATCCATGATCGGATCGTGACCAAATTCCATTATGCGCCATCGGACTTCGCCACCGACCTCAACGCGCATATGGGCTCGGCCTTCTCACTCGAGCCGATCCTGACGCAGAGCGCCTATTTCCGGGTGCACAACCGCGACGATTCGATCCCGAACCTGTATTTCGTCGGCGCCGGTACGCATCCGGGCGCGGGAATTCCGGGCGTGGTCGGCAGCGCCAAGGCGACGGCGGCGCTGATGCTGGAGCGTAAATAA",
      "translation": "MKSAVVIGSGFGGLALAIRLQSAGVQTTIVEARDKPGGRAYYWERDGFTFDAGPTVITDPACLEELWALTGRSMSEDVKLDPVSPFYRLNWVDGTNFDYSNDDTQLRSEIAKLNPDDIAGYGRFLDYAAGVYREGYEKLGHVAFLDFASMVKAAPALAKYQAWNSVYAMVSKFVKSEKLREALSFHTLLVGGNPMTTSAIYALIHKLERDGGVWFARGGTNRLVAGMVAQFERIGGVLRLGDPVARIETLGDRATGVVTKSGLTIQVDAVATNADIMHSYRDLLADNRSARRTVNRLERKRYSPSLFVVHFGIKGAWPGIPHHMILFGPRYKGLLTDIYDTGVLSEDFSLYLHHPTVTDPSLAPEGHSTFYALAPVPHMGKFPMNWDEVGPILEKRILDEVGRRLIPDIHDRIVTKFHYAPSDFATDLNAHMGSAFSLEPILTQSAYFRVHNRDDSIPNLYFVGAGTHPGAGIPGVVGSAKATAALMLERK",
      "product": ""
     },
     {
      "start": 41367,
      "end": 43193,
      "strand": -1,
      "locus_tag": "ctg5_45",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 41,367 - 43,193,\n (total: 1827 nt)<br>\n <br>\n \n  resistance (resist) ABC_efflux (Score: 245.2; E-value: 8.1e-75)<br>\n \n  transport (smcogs) SMCOG1288:ABC transporter related protein (Score: 326.7; E-value: 4.7e-99)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_45 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00664.26 (ABC transporter transmembrane region): [39:313](score: 123.1, e-value: 1.8e-35)<br>\n \n  PF00005.30 (ABC transporter): [374:524](score: 116.8, e-value: 1.1e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_45 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00005.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00664.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00664.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0140359' target='_blank'>GO:0140359</a>: ABC-type transporter activity<br>\n  \n   PF00664.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00664.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_45\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_45_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMPPLDPTAGAPDRPLIPTLRRFLPYLWPAGAPALRARIVAAMLLVILSKLLQVLGAAYTLKYAIDRMAGGDRGAVMLIVLLVIGYAAARFGTTLFDNLRNAVFEIVGQDATRRLSADVFRHLHRLSLRFHLERRTGAVTKVVERGTKSIDTMLYFLLFNIAPTVLELGLVLAIFGRSFGPVLVVTTLAMVVLYIGFTRKVTDWRNALRNRMNDLDTGAVAHAVDSLLNFETVKYFNAEEREAQRYENGVAAYARAATKSENSLAWLNVGQAAITSLMLGFAMAWVVREWSRGAASPGDVVFVSTLLSQLFRPLDLLGMVYRTIRQGVIDMGAMFDLIDTPAEVVDAPHALPLAVRGGHVRFDHVVFGYEPDRAILKGLTLDIPAGTTCAVVGPSGAGKSTLARLLYRFYDVTEGAITIDGQRVSDVTQDSLRAAIGIVPQDTVLFNDTIGYNIAYGREGADQSDVERAAKGAAIADFIERQPQGYATRVGERGLKLSGGEKQRVAIARTLLKDPPILILDEATSALDSRTEADILATLQAIERGRTTLVIAHRLSTIAHADQIVVLDGGHVVERGTHGELLAKGGLYAEMWARQAAEVEQAEEDAVLA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCGCCACTCGACCCCACCGCCGGTGCGCCTGACCGGCCGCTGATCCCGACGCTTCGCCGCTTCCTCCCCTATCTCTGGCCCGCCGGAGCGCCCGCCCTGCGCGCGCGGATCGTGGCGGCGATGCTGCTCGTCATCCTGTCCAAGCTCCTGCAGGTGCTGGGCGCGGCCTATACGCTGAAATATGCGATCGACCGGATGGCGGGCGGGGATCGCGGCGCGGTGATGCTGATCGTGCTGCTGGTCATCGGCTATGCGGCGGCGCGGTTCGGCACGACGCTGTTCGACAATCTGCGCAATGCGGTGTTCGAGATCGTCGGGCAGGACGCGACCCGGCGGCTGTCGGCCGATGTCTTTCGCCATCTCCACCGCCTGTCGCTGCGCTTCCATCTGGAGCGCCGCACCGGCGCGGTGACCAAGGTCGTCGAACGGGGGACCAAGAGCATCGATACAATGCTCTATTTTCTCCTCTTCAACATCGCGCCTACGGTGCTGGAACTGGGGCTGGTGCTGGCGATCTTCGGGCGCAGTTTCGGGCCGGTGCTGGTCGTCACCACCCTGGCGATGGTCGTCCTCTACATCGGCTTCACCCGCAAGGTGACCGACTGGCGCAATGCGCTGCGCAATCGGATGAACGATCTCGACACCGGCGCGGTGGCGCATGCGGTCGACTCGCTGCTGAATTTCGAGACGGTCAAATATTTCAATGCCGAGGAGCGCGAGGCGCAGCGCTACGAAAACGGCGTCGCCGCCTATGCCCGCGCGGCGACCAAGTCGGAAAATTCGCTCGCCTGGCTGAATGTCGGGCAGGCCGCGATCACCAGCCTGATGCTCGGTTTCGCCATGGCCTGGGTCGTGCGCGAATGGAGCCGGGGGGCGGCCTCGCCGGGCGATGTGGTGTTCGTCTCGACCCTGTTGTCGCAGCTCTTCCGCCCGCTCGATCTGCTCGGCATGGTCTATCGCACCATCCGCCAGGGGGTGATCGACATGGGCGCGATGTTCGACCTGATCGACACGCCCGCCGAAGTGGTCGACGCGCCCCATGCCTTGCCGCTGGCGGTGCGGGGCGGGCATGTCCGCTTCGACCATGTCGTCTTCGGCTACGAGCCGGATCGGGCAATCCTGAAGGGCCTGACGCTCGACATTCCGGCGGGCACGACCTGTGCGGTGGTGGGGCCGTCCGGCGCGGGCAAGTCGACGCTCGCGCGGCTGCTTTACCGGTTCTACGATGTCACCGAGGGCGCGATCACCATCGATGGGCAGCGGGTGTCAGACGTGACGCAGGATAGTTTGCGTGCGGCGATCGGGATCGTGCCGCAGGACACGGTGCTGTTCAACGATACGATCGGCTACAACATCGCTTATGGTCGTGAAGGCGCGGACCAGTCGGACGTCGAGCGCGCGGCCAAGGGCGCGGCGATCGCGGACTTCATCGAGCGCCAGCCGCAGGGCTATGCCACCCGCGTCGGCGAGCGTGGCCTGAAGCTGTCGGGTGGCGAGAAGCAGCGGGTGGCGATCGCCCGCACCTTGCTGAAGGATCCGCCCATCCTGATCCTCGACGAGGCGACCAGCGCGCTCGACAGCCGGACCGAGGCGGATATCCTCGCGACGCTCCAGGCGATCGAGCGCGGGCGCACCACGCTGGTCATCGCGCACCGCCTGTCGACCATCGCCCATGCCGATCAGATCGTGGTGCTCGATGGCGGCCATGTGGTCGAGCGGGGTACGCATGGCGAATTGCTGGCCAAGGGCGGGCTCTATGCCGAAATGTGGGCGCGCCAGGCCGCCGAGGTCGAGCAGGCGGAAGAGGATGCGGTGCTGGCGTGA",
      "translation": "MPPLDPTAGAPDRPLIPTLRRFLPYLWPAGAPALRARIVAAMLLVILSKLLQVLGAAYTLKYAIDRMAGGDRGAVMLIVLLVIGYAAARFGTTLFDNLRNAVFEIVGQDATRRLSADVFRHLHRLSLRFHLERRTGAVTKVVERGTKSIDTMLYFLLFNIAPTVLELGLVLAIFGRSFGPVLVVTTLAMVVLYIGFTRKVTDWRNALRNRMNDLDTGAVAHAVDSLLNFETVKYFNAEEREAQRYENGVAAYARAATKSENSLAWLNVGQAAITSLMLGFAMAWVVREWSRGAASPGDVVFVSTLLSQLFRPLDLLGMVYRTIRQGVIDMGAMFDLIDTPAEVVDAPHALPLAVRGGHVRFDHVVFGYEPDRAILKGLTLDIPAGTTCAVVGPSGAGKSTLARLLYRFYDVTEGAITIDGQRVSDVTQDSLRAAIGIVPQDTVLFNDTIGYNIAYGREGADQSDVERAAKGAAIADFIERQPQGYATRVGERGLKLSGGEKQRVAIARTLLKDPPILILDEATSALDSRTEADILATLQAIERGRTTLVIAHRLSTIAHADQIVVLDGGHVVERGTHGELLAKGGLYAEMWARQAAEVEQAEEDAVLA",
      "product": "",
      "resistance": true
     },
     {
      "start": 43407,
      "end": 45377,
      "strand": -1,
      "locus_tag": "ctg5_46",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_46</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_46</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 43,407 - 45,377,\n (total: 1971 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Abhydrolase_6<br>\n \n  biosynthetic-additional (rule-based-clusters) Peptidase_S9<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_46 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00326.24 (Prolyl oligopeptidase family): [416:628](score: 149.0, e-value: 1.4e-43)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_46 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00326.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008236' target='_blank'>GO:0008236</a>: serine-type peptidase activity<br>\n  \n   PF00326.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006508' target='_blank'>GO:0006508</a>: proteolysis<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_46\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_46_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTATTCAAGGCTTTGTTGGCGGCGGGAGCCGCGTTGATGGTGGCGCAATCGGCGATGGCGGCGGACGTCCCGCTGATCGAACGGGCCAAGCTGTTCGGCAATCCGACCAAGGTCGGTGGACAGCTGTCGCCCGATGGCAAGTGGATCAGTTTCATCGCGCCGCGCGACGGGGTGCTGAACGTCTGGGTCGCGCCGATCGCCACCCCCGATCAGGCCAAGCCGCTGACCGCCGAGAAGACCCGGCCGATCCGCCAAAGCTTCTGGTCGCCGGATTCCAAGTCGATTCTGTTCGTCAACGACAAGGGCGGCGACGAGAATTTCCTGCTCTACGGCGTCAACGTCGCGACCGGCGAGCAAAAGGCGCTGACCCCGTTCGAGAAGACCCGGGTTCAGATCGTCGGCACCAGCGAGACGATCAAGGACCGTATCCTGGTCGGCGTCAACAATCGCGACCCGCGCTGGCATGACGTGTACGAACTGAACCTGACCACCGGCGCGCTGACCAAGGTGATGCAGAATGACGGCTATGCCGGGTTCCTCGCCGACGATCAGTTGAAGCTGCGCATGGCAGCCAAGGCGCGGCCCGATGGCGGCTCCGACTATTACCGCGTCAACGGCACCAATGTGGAGGCGACGCCGGTCGTGCAGTTCGGGCTGGACGATTCGTTGACCACCTCGCCGCTGGGCTTCACGGTTGATGGCAAGACGCTCTACTGGATGGACAGCCGGGGCCGGAACACCGCCGCGCTGATGGCGCAGGACATGGGCAGCGGCAAGATGGCCGTGATCGGCGAAAGCCCCAAGGCCGATGTCGGCGGCGGTCTGTTCAACCCCAAGACCGGCCGGGTCGAGGCCTATTCGGTCAATTACCTGAAGCGCGACTATGTGCCGGTCGGCGATGCGGTGAAGGCCGATCTCGCCTTTCTGAAGGCACAGAACAAGGGCGAATTCGCGATCGGGTCGCGCACCGATGCCGATGACAAATGGCTCGTCACTTTCGATCCGGTGACCGCGCCGGCCTCGACCTGGCTATACGACCGCAAGGCGAAGAAGCTGACCCAGCTTTACGTCAGCCGCCCCGAACTGGCCGATGCGCCGCTGGTGCCGATGGAGGCGGTGGAAATCCCCGCGCGCGACGGGCTGACGCTGGTGTCGTACCTGACCAAGCCCAAGGGCGTGACCGGGCCGGTGCCGATGGTGTTGTTCGTCCATGGCGGACCCTGGGCGCGCGACGGCTATGGCTTTAACGGCTATCATCAGTGGCTCGCCAATCGCGGCTATGCGGTGCTGTCGGTCAATTATCGCGGCTCGACCGGCTTTGGGAAGAATTTCATCTCGGCGGGCGACCTGCAATGGGGCCGCAAGATGCATGACGACCTGATCGACGCGGTCGACTGGGCGGTCAAACAGGGCGTCACCACCCCCGACAAGGTGGCGATCATGGGCGGCTCTTATGGCGGCTATGCGACGCTGGCGGGCCTGACCTTCACGCCGGAGAAATTCGCGTGCGGCGTCGATATCGTCGGGCCGTCGAACCTGTTCACGCTTCTGAAGACGATCCCGCCCTATTGGGAAGCGGGCAAGCAACAATTCTACAAGCGGATGGGCGACCCGACGACCGAAGAGGGGCGCGCCCTTCTCAAGGAACGCTCACCGCTGACCTTTGTCGACCAGATCAAGAAGCCGCTGCTGATCGGGCAGGGCGCCAACGACCCGCGCGTCAACGTCGCGGAGAGTGACCAGATCGTGGCGGCGATGGCGACGAAGAACATCCCCGTCACCTATGTCCTGTTCCCCGACGAGGGCCATGGCTTCGCGCGGCCGGCCAACAACATCGCCTTCAACGCGGTGGCCGAGAATTTCCTCGCCCCTTGCCTGGGCGGTCGCGCCGAGCCGATCGGCGACACGCTCAAGGCCTCGACCGCGCAGGTGAAGCATGGCGCGGAGTTCGTGACCGGGTTGAAGTAG",
      "translation": "MVFKALLAAGAALMVAQSAMAADVPLIERAKLFGNPTKVGGQLSPDGKWISFIAPRDGVLNVWVAPIATPDQAKPLTAEKTRPIRQSFWSPDSKSILFVNDKGGDENFLLYGVNVATGEQKALTPFEKTRVQIVGTSETIKDRILVGVNNRDPRWHDVYELNLTTGALTKVMQNDGYAGFLADDQLKLRMAAKARPDGGSDYYRVNGTNVEATPVVQFGLDDSLTTSPLGFTVDGKTLYWMDSRGRNTAALMAQDMGSGKMAVIGESPKADVGGGLFNPKTGRVEAYSVNYLKRDYVPVGDAVKADLAFLKAQNKGEFAIGSRTDADDKWLVTFDPVTAPASTWLYDRKAKKLTQLYVSRPELADAPLVPMEAVEIPARDGLTLVSYLTKPKGVTGPVPMVLFVHGGPWARDGYGFNGYHQWLANRGYAVLSVNYRGSTGFGKNFISAGDLQWGRKMHDDLIDAVDWAVKQGVTTPDKVAIMGGSYGGYATLAGLTFTPEKFACGVDIVGPSNLFTLLKTIPPYWEAGKQQFYKRMGDPTTEEGRALLKERSPLTFVDQIKKPLLIGQGANDPRVNVAESDQIVAAMATKNIPVTYVLFPDEGHGFARPANNIAFNAVAENFLAPCLGGRAEPIGDTLKASTAQVKHGAEFVTGLK",
      "product": ""
     },
     {
      "start": 45498,
      "end": 45728,
      "strand": 1,
      "locus_tag": "ctg5_47",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_47</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_47</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,498 - 45,728,\n (total: 231 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_47\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAACCGATTTTCTATGTGATGGCGATCCTGGGCTGCGGAGATGGCAGCGTCGATTGCACCGAGGCGCGGATGGTCCCCGCCCGCTACGAAACCATGGCCCAGTGCCGCGCCGATCTCGCCAACCGGATCGCCGCCAATACCGATGTGCCCTATCCCGTGATCGGTGCCGACTGTCGCCGCATCGGCGCGCAGGTTGCGAAGGCCGAGCGCAAGCCTTCGCAGGGCTGA",
      "translation": "MQPIFYVMAILGCGDGSVDCTEARMVPARYETMAQCRADLANRIAANTDVPYPVIGADCRRIGAQVAKAERKPSQG",
      "product": ""
     },
     {
      "start": 45841,
      "end": 46791,
      "strand": -1,
      "locus_tag": "ctg5_48",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_48</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_48</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,841 - 46,791,\n (total: 951 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_48 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [21:277](score: 214.0, e-value: 2.9e-63)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_48 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_48\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_48_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACCCGGCCCGCCGCCCCGACCGAACGGGCGGCGCTGGTGGCGGCGGCCAAGGACTCGATCGCACGCGGCTCGAAGAGTTTCGCGGCGGCCAGCCTGTTGTTCGATCCCGAAACGCGCGAGCGCGCCTGGCTGCTCTATGCCTGGTGCCGGCGGTGCGACGATATCGCCGATGGGCAGGATCATGGCCATGGCATGACCCGCGTGGCCGATGCGCCCGCGCGGCTGGCCGAGCTGACCGACAAGACCGAGGCGGCGCTGGCGGGGCAGGTGGTGGGTGATCCTGCCTTCGACGCGCTGCGCGTGGTGGTGGCGGAGACGGGGATGCCGCATCGCTGGCCCCGTGACCTGATCGCCGGCTTCGCGCTGGATGCCGAGGATTGGCGGCCGCAGAGCGAGGCGGACCTCTATCGCTATTGCTATCACGTCGCGGGCGTCGTCGGCTGCATGATGGCGGTGACGATGGGGGTGCGGCCGGATGACGAGGCGACGCTCGACCGAGCTTGTGATTTGGGAATGGCGTTTCAACTGGCCAATATCGCGCGCGACATTGCCGAAGATGCCGGCGCCGGGCGGCATTATCTGCCGCGCGAGTGGCTCGCCTATAAGAGCATCGCGCCCGATGCGATCATGGCCCCCTCGCACCGGCCGGGGCTGACCGCGCTGGCCCGGCGGCTGACCGATCAGGCTGCCCGGTTCGAGGCGAGCGCACGGATGGGGACGCCGGCGCTTTCCTATCGCTCGGCCTGGGCGGTGCTATCGGCGGCGGCGATCTATGGCGCGATCGGCCGCAAGGTTGCCAAGCGGGGGCGGCGCGCCTGGGACAGCAGGGTCGGAACCGGCAAGGCGGAGAAGCTGCGCTTCATGACGGTCGCCGGCGTTCAGGCGGCGCGGAGGGACAAAATGAAAATCCTCCCACGTGATCCAACCCTTTGGACGCGGCCCCGGTAG",
      "translation": "MTRPAAPTERAALVAAAKDSIARGSKSFAAASLLFDPETRERAWLLYAWCRRCDDIADGQDHGHGMTRVADAPARLAELTDKTEAALAGQVVGDPAFDALRVVVAETGMPHRWPRDLIAGFALDAEDWRPQSEADLYRYCYHVAGVVGCMMAVTMGVRPDDEATLDRACDLGMAFQLANIARDIAEDAGAGRHYLPREWLAYKSIAPDAIMAPSHRPGLTALARRLTDQAARFEASARMGTPALSYRSAWAVLSAAAIYGAIGRKVAKRGRRAWDSRVGTGKAEKLRFMTVAGVQAARRDKMKILPRDPTLWTRPR",
      "product": ""
     },
     {
      "start": 46788,
      "end": 47369,
      "strand": -1,
      "locus_tag": "ctg5_49",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_49</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_49</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 46,788 - 47,369,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_49 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03641.17 (Possible lysine decarboxylase): [45:176](score: 129.3, e-value: 1.1e-37)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_49\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_49_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGCGATTGGCCATTTACTGCGGGTCGGCGACCCCCTCGGACCCTCAATATATCGAGACGGCGCGTGCTGTCGGGCGCGGACTGGCGGAGCGGGGGATCGGCGTCGTCTATGGCGGCGGTCGGCTGGGCCTGATGGGCGCGGTCGCCGATGCGGCGCTGGCGGCCGGCGGCGAGGTGATCGGCATCATCCCGCAGGCGCTGGTCGATGCCGAGGTCGCGCATCGCGGCCTGACCGAACTGCACGTCGTGCCCGGCATGCACGAGCGGAAGAAGGCGTTCACTGATCTGTCCGACGGTTTCGTCACCATCGCCGGCGGCACCGGCACGATGGACGAATTGTGGGAAGCATTGAGCTGGGCGCAGCTCGGCTATCATGCCGATCCGGTCGGGCTGCTCAACACGGGCGGCTATTACGACCATCTCGTCGCCTTCTGGGACAAGATGGGCGAGGTCGGCTTCCTGCGGCCGCAGCACCGCGAATTGCTGATCGTCGATGAAACGCTGGACGGGCTGCTGGAGCGGATGGCGGTGCATGTTCCCACCCAGCCGATCGTTCGCATGAACGCGGGCGACCTGTGA",
      "translation": "MKRLAIYCGSATPSDPQYIETARAVGRGLAERGIGVVYGGGRLGLMGAVADAALAAGGEVIGIIPQALVDAEVAHRGLTELHVVPGMHERKKAFTDLSDGFVTIAGGTGTMDELWEALSWAQLGYHADPVGLLNTGGYYDHLVAFWDKMGEVGFLRPQHRELLIVDETLDGLLERMAVHVPTQPIVRMNAGDL",
      "product": ""
     },
     {
      "start": 47447,
      "end": 47707,
      "strand": -1,
      "locus_tag": "ctg5_50",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 47,447 - 47,707,\n (total: 261 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_50\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTATTCGACGGGGCTTCGGCCGTATGGTGAGCCTCTATGAACGCGCACCGCTGCGCCAGTTGCTCGATCTCGATCCGATCGGCGCTGTGGACTGGATCGTGGTGGCGCTCGCCCGGCGCATGGTACGGTTTCTGGATGGCGCGCATGCTACCGAGTATCTCGACGGTCCAGCGGTATCGTCGGGCTGGCGCGGCAATTTCGTCTTTCTGCTGTTCTGGGTGACGCTGATCGTGGGCACAGTGGCCGTCTTCGCCTGA",
      "translation": "MTIRRGFGRMVSLYERAPLRQLLDLDPIGAVDWIVVALARRMVRFLDGAHATEYLDGPAVSSGWRGNFVFLLFWVTLIVGTVAVFA",
      "product": ""
     },
     {
      "start": 48039,
      "end": 48737,
      "strand": -1,
      "locus_tag": "ctg5_51",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 48,039 - 48,737,\n (total: 699 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_51\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAAACCATACCGTGATCCGGATCGGCAATGAAAATTTTCGACTGATCGCAACAGTCGATGAAGGGCAGACTCTGTATTTTACGGCCGGCAAAGCCATAGCCGTAGAAAAATACGACATGCGGATCGGCAAGAGTGAGTTCGACTTTCAAGTCAATTCACGGCCGGTACGTGGCGGGCGTCCCGAGGCCATTGCGGCCCGACAGCAAAGCTTAGACCGCGAATTTATGGAAAGTCGGGTAAAATCCAATCTTTTTGGTTTGCCGGTCAGTCTGGGCAACGCCGCCGCCATGGTAAAAGATCGAAGGGTCGCGCTAAGCTATGGCGAGTTGCGACCTCAGATATTTCGAAGTTCCGTCAGTACTAGGCCGGTCGCATGGCGAATCTGGTTTCGTCGTACGAGGTACTCCGGCCAAGCGAGTGGGAAGGGGATACGAAACGCTCCTAAGCCTGCCGCTTCCGCCAAGGCGCAAGCCTCAGCAATGGGTAGTGCTGCAATCGGAGCTATGTCCAAGGCACCCCAGAGAGGACGGGCGACGGCAATCGGACCCTTGGCCAACGGTGCGGGCATCCTCCGCGTGTACGTTCTAGCCGATGACAAGAGCGAAATCGTTGCGCCCTTCGATCGGAGAGACGTGACGTTTCGCGATCCAAGTTTGTGGGAACGAGCGGTCAATTTGGTGCGAGGGGGGAGTTAA",
      "translation": "MANHTVIRIGNENFRLIATVDEGQTLYFTAGKAIAVEKYDMRIGKSEFDFQVNSRPVRGGRPEAIAARQQSLDREFMESRVKSNLFGLPVSLGNAAAMVKDRRVALSYGELRPQIFRSSVSTRPVAWRIWFRRTRYSGQASGKGIRNAPKPAASAKAQASAMGSAAIGAMSKAPQRGRATAIGPLANGAGILRVYVLADDKSEIVAPFDRRDVTFRDPSLWERAVNLVRGGS",
      "product": ""
     },
     {
      "start": 48847,
      "end": 50616,
      "strand": 1,
      "locus_tag": "ctg5_52",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 48,847 - 50,616,\n (total: 1770 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 280.4; E-value: 4.5e-85)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_52 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00270.32 (DEAD/DEAH box helicase): [20:175](score: 59.5, e-value: 3.8e-16)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [227:319](score: 43.3, e-value: 4.1e-11)<br>\n \n  PF16124.8 (RecQ zinc-binding): [331:392](score: 50.3, e-value: 3.2e-13)<br>\n \n  PF09382.13 (RQC domain): [394:504](score: 69.1, e-value: 3e-19)<br>\n \n  PF00570.26 (HRDC domain): [519:585](score: 75.7, e-value: 2.2e-21)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_52 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding<br>\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00570.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding<br>\n  \n   PF09382.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043138' target='_blank'>GO:0043138</a>: 3'-5' DNA helicase activity<br>\n  \n   PF09382.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006260' target='_blank'>GO:0006260</a>: DNA replication<br>\n  \n   PF09382.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006281' target='_blank'>GO:0006281</a>: DNA repair<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_52\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_52_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTCGCCGACCCCCTTGCCAAGCTCCATGAAGTCTTCGGGTACAGCCAGTTCCGGGGTGTCCAGGAACAGGTGGTCGACCGCGTGCTCGGCAAACAGCGGACTTTGGCGGTCATGCCGACCGGCGCGGGCAAGTCGCTGTGTTACCAGCTGCCCGCGGTGATGATGAACGGATGTTGCGTCGTGGTCAGCCCGCTGATCGCGCTGATGCACGACCAGTTGCGCGCCGCCGAAGCAGTCGGCATCCGCGCCGCCACGCTGACCAGCGTCGACCAGAACCGCGCCGAGACGGTCGCGCGCTTCCGCGACGGCCAGCTCGACCTTCTGTATGTCGCGCCCGAGCGCGCTTCGTCGGGGCATTTCCGCGAGCTGCTGGCCTCCGCGCCGCTCAGCCTGTTCGCGATCGACGAGGCGCACTGCGTCAGCGAATGGGGGCATGACTTCCGCCCCGATTACCGGCTGCTCGAACCGTTGATGGATGCCTTTCCGGAGGTGCCCCGGCTGGCGCTGACCGCGACCGCCGATGCGCATACCCGCGCCGACATCGCCAAGCAGCTGGGCATTCCGGTCGAGGGGATGATCGTCTCGGGCTTCGATCGGCCCAATATCCGCTATGCGATCAGCCCCAAGGCCAATGTGAACCTGCAGATCGCGCGGGTGGTCGCCGACACGCCGGGCCCCGGCATCGTCTATGCCCAGACGCGCGCCGCGACCGAGAAACTGGCGGAAGCGCTGGCGCGGACGGGGCGGCCGGTGCGCGCCTATCATGCGGGACTCGACCCAGCGATCCGCGCCAAGAACCAGGCCGATTTCGTCGCGAGCGAGGACATGGTGATCTGCGCGACCGTCGCCTTCGGCATGGGGATCGACAAGCCCGATGTGCGCTTCGTCGCCCATGCCGGGCTGCCCAAGTCGATCGAGGCCTATTATCAGGAGACGGGGCGCGCCGGGCGCGACGGCGACCCTTCCGTCGCGCATCTCTTCTGGGGCGCCGACGATTTTGCGCGGGCCCGCCAACGCATCGCCGAGGTCGAACCCGAACGCCAGCCCGGCGAGCGTGCACGCCTGTCCGCTCTCGGTGCGCTGGTCGAGACGGGCGGGTGCCGCCGCCGCATCCTGCTACGCCATTTTGGCGAGGAGCTGGCGGAGGATTGCGGCAATTGCGACAATTGCCTGGGGTCGCCCGATGCGGTCGATGCGACGACCACCGCGCAGAAATTCCTCTCTGCCGTGTTCCGCACCGGCCAGATGTTCGGCGCGGGCTATATCGAGCAGGTGCTGACTGGCCAGTCGAGCGAGCGCAGCCTGATGAACGGGCATGAGGCGCTGTCGGTGTGGAACATCGTCGACGGCGACGAGGTGGCGTTGCTCAAGCCGGTGCACCGCGCGCTGTTGCTGCGCGATGCGTTGCGCACCAATCCCCATGGCGGGCTGGAGTTCGGCCCCGCCGCGCGTGCGCTGATCAAGGGCGAGGCGCGGCTGTCGCTGGTCGTGCCGCCCAAGCGGGAGCGTAAAGGCCGCCGCGCCGCGCCCGTGGCCGCCAATCCGGCCGACAATCCGCTGTTCGAGGCGCTGCGCGCCAAGCGTCGCGAGCTGGCGCAGGAGGCGGGCGTGCCGCCTTACGTCATCTTCCACGACTCGGTGCTGCGCGACATGGCGGCGCAGCGGCCGAACAGCCGCGCGGCGCTGTCGCTCCTGTCCGGGATCGGCGCGCGCAAGCTGGATGCTTATGGCGAGGCCTTTCTGGCGGTGATCCGCGACGCCGGCTAA",
      "translation": "MVADPLAKLHEVFGYSQFRGVQEQVVDRVLGKQRTLAVMPTGAGKSLCYQLPAVMMNGCCVVVSPLIALMHDQLRAAEAVGIRAATLTSVDQNRAETVARFRDGQLDLLYVAPERASSGHFRELLASAPLSLFAIDEAHCVSEWGHDFRPDYRLLEPLMDAFPEVPRLALTATADAHTRADIAKQLGIPVEGMIVSGFDRPNIRYAISPKANVNLQIARVVADTPGPGIVYAQTRAATEKLAEALARTGRPVRAYHAGLDPAIRAKNQADFVASEDMVICATVAFGMGIDKPDVRFVAHAGLPKSIEAYYQETGRAGRDGDPSVAHLFWGADDFARARQRIAEVEPERQPGERARLSALGALVETGGCRRRILLRHFGEELAEDCGNCDNCLGSPDAVDATTTAQKFLSAVFRTGQMFGAGYIEQVLTGQSSERSLMNGHEALSVWNIVDGDEVALLKPVHRALLLRDALRTNPHGGLEFGPAARALIKGEARLSLVVPPKRERKGRRAAPVAANPADNPLFEALRAKRRELAQEAGVPPYVIFHDSVLRDMAAQRPNSRAALSLLSGIGARKLDAYGEAFLAVIRDAG",
      "product": ""
     },
     {
      "start": 50630,
      "end": 51154,
      "strand": 1,
      "locus_tag": "ctg5_53",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_53</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_53</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 50,630 - 51,154,\n (total: 525 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1111:GCN5-related N-acetyltransferase (Score: 111.3; E-value: 7.9e-34)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_53 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13302.10 (Acetyltransferase (GNAT) domain): [13:155](score: 93.6, e-value: 1.8e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_53 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF13302.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016747' target='_blank'>GO:0016747</a>: acyltransferase activity, transferring groups other than amino-acyl groups<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_53\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCTTTGCGAGCCCCACCCCGACCCTGACGACCGAGCGGCTGAGCTTGCGCGGCCACCATCCCGACGATCTCGACGCGCTGGCGGCGATGTGGGCCGATCCCGCCGTATACGGGATGATCGGCGGCAAGCCCCGTTCGCGCGAAGAGGTGTGGATTCGGCTGCTCCGCTCGATCGGTTGCTGGACGGTGTTCGGCTATGGCGCCTGGGTGGTGTGCGACCGGGCGACGGGTGCGGTGCTGGGCGATATCGGGCTGCTCGAGTCGCGGCGGGCGATTATACCGGAGTTGACGGTGCCGGAGGTGGGCTGGACCTTGGTTCCAGCGGCGCATGGCCAGGGCTATGCGGGTGAGGCGATGCGCGCGGTGCTGGACTGGGCGGATGCGAACGGCATCGACCGGACCTGCTGCATCATCGATCCGGGCAATGCCGCGTCGATCCGGCTGGCCGAGAAGCTGGGCTACCGCGCGCCGGTGGAGGGGGTTTATTACGAGCGGCCGATCCTGATCTTCCACCGGGTATAA",
      "translation": "MTFASPTPTLTTERLSLRGHHPDDLDALAAMWADPAVYGMIGGKPRSREEVWIRLLRSIGCWTVFGYGAWVVCDRATGAVLGDIGLLESRRAIIPELTVPEVGWTLVPAAHGQGYAGEAMRAVLDWADANGIDRTCCIIDPGNAASIRLAEKLGYRAPVEGVYYERPILIFHRV",
      "product": ""
     },
     {
      "start": 51507,
      "end": 52322,
      "strand": 1,
      "locus_tag": "ctg5_54",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_54</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_54</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 51,507 - 52,322,\n (total: 816 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_54 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04116.16 (Fatty acid hydroxylase): [94:230](score: 104.0, e-value: 8e-30)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_54 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04116.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF04116.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n   PF04116.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008610' target='_blank'>GO:0008610</a>: lipid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_54\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_54_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACGCTTGCCCTGATCCTGTCCGCCATCGCCATGACGCTGATCGTCGGTGTCCGCTATCTACTCGCCTCGGGCGCGTTCGCGCTGGCGACCCGGGCGCGGCATCCCGATCTCTATGCCGGTCTCGATCCGCAGATCCGGCGCGAGATCGGCTGGAGCCTGGCCTCGGCCGCGATCTATGGCGTGCCGGCCGGCATCGTCGCTTGGGGGTGGCAGAATCGCGGCTGGACGCAGATTTACGCCGACGTCCATGCCTATCCGCTCTGGTATCTGCCCGTCTCGGTCCTGCTCTATCTGATCGCGCACGATAGTTGGTTCTACTGGACGCATCGCTGGATGCACCGGCCCGCCATCTTCAAGCGCGCGCATGCCGTCCATCACGCCAGCCGACCGCCGACCGCCTGGGCGGCGATGGCGTTCCACCCGATCGAAGCGGTAACCGGCGCTGTGGCCATTCCGCTACTGGTCTTCGTGATTCCGATCCATGTCGGCGCACTCGGCTTGGTGCTGACGATCATGACGGTTATGGGCGTGACCAACCACATGGGCTGGGAAATCTTTCCCCGTTTCCTGTGGCAGGGGCACCTGGGGGGGTGGCTCATCACTGCGAGCCACCATCAACGGCATCACGAGCAATATGGGTGCAATTATGGACTCTACTTCCGTTTCTGGGATCGACTGTGCGGGACGGACCGGGGACTGGGAGATTTCGCGCGCGCCCATGCGCAGGCGGCGCGGCGCGTCGGTGCTGCTGGCGCTGGCCAGCCTGCCGCTGATCGGCGCGGCGCCGGTCAGCCGGCTGGACATCGGGATTGA",
      "translation": "MTLALILSAIAMTLIVGVRYLLASGAFALATRARHPDLYAGLDPQIRREIGWSLASAAIYGVPAGIVAWGWQNRGWTQIYADVHAYPLWYLPVSVLLYLIAHDSWFYWTHRWMHRPAIFKRAHAVHHASRPPTAWAAMAFHPIEAVTGAVAIPLLVFVIPIHVGALGLVLTIMTVMGVTNHMGWEIFPRFLWQGHLGGWLITASHHQRHHEQYGCNYGLYFRFWDRLCGTDRGLGDFARAHAQAARRVGAAGAGQPAADRRGAGQPAGHRD",
      "product": ""
     },
     {
      "start": 52345,
      "end": 52665,
      "strand": 1,
      "locus_tag": "ctg5_55",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_55</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_55</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 52,345 - 52,665,\n (total: 321 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_55 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF09912.12 (Uncharacterized protein conserved in bacteria (DUF2141)): [1:94](score: 83.7, e-value: 9.1e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_55\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCCGGCTGTGCTTGACCGCCGATCCGGACAATTTTCCCGCCTGCGTCGATGACGCGCGCGCGCTGACCCGCTCGGTGCCGGCGGGGCAGCGCGCCATCCATCTCGACGGCCTGCCCCATGGCCAGTACGCCGCCGCCGTCATCCATGACGAGAACAACAACGCCAAGCTGGACACGCTGGCCGGCATTCCCCGCGAGGGCTTTGGCTTCTCCCGCAATCCGGCGATCCATTTCGGCCCGCCCCGTTTTACGGCCGCACGCTTCGCGCTCGATTCTGTTGCCGAAACACAACAGATTCGGATGCGATACATATTCTGA",
      "translation": "MIRLCLTADPDNFPACVDDARALTRSVPAGQRAIHLDGLPHGQYAAAVIHDENNNAKLDTLAGIPREGFGFSRNPAIHFGPPRFTAARFALDSVAETQQIRMRYIF",
      "product": ""
     },
     {
      "start": 52738,
      "end": 53622,
      "strand": 1,
      "locus_tag": "ctg5_56",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_56</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_56</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 52,738 - 53,622,\n (total: 885 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_56 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06629.15 (MltA-interacting protein MipA): [49:294](score: 117.3, e-value: 1.2e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_56\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGCGCCTTTTTCCGCGCGTTGCCGCCCCGCTCATCGCTTCGGCGGCTCTATCCCTGTCCCTGCCCGCCCATGCGCAGGACCTCCCCGCGGCCGATGCTTCCGATGCCGCCGCTGTTGGCGCTCAGATGGGCAAGAATACCATCACGCTCGGCTTGGGCGCGGCCTATCTGCCCGATTATCAGGGGTCGAACGATTATCAGTTCACGCCCGCACCCGCCGGCTTGGCCTATATTGATGGGCATACGATCACCTGGATCGGCAATCGCCTGTCGGTCGACCTGATCGGCGACCGGAGCAATCCGGGTTGGGATTTTCAGGCCGGGCCGGTCGGCGTCGTCAATCTGGACCGTACCGCGCCGTCGCGCATTGATGATCCCCGCGTCCGCGCGCTGGGCAAGATCGGCGCGGCGGTCGAACTGGGCGGCTATGTCGGCATCGGCAAGGTGGGCGTGGTCACCAGCCCCTATGACCGCCTGTCCGTCGCGCTCAGCTATCGCCACGACGTCACCGGCGTGCATGACAGCGGCATCTGGCAGCCCAGCATCAACTATTTCACGCCGCTGTCGACCAAGGCGGCCGCCGGCCTGTTCGCGACCGCCGAACATGCCGGCGCGGGCTATGCCCGTCGCTATTATTCGATCACGCCGGGCCAGAGCGTGGCGAGCGGCCTGCCCATCTATGACGCGCGGTCGGGGTGGAAGAACTGGACCGCCGGTGCGCTGGGCACCTATTCGCTGACCGGCAATCTCCTTCAGGGTTGGAAGCTGGTCGGCAGCGTCGCCTATAGCCGCATGCTCAACGATTTCGGCGACAGCCCGATCGTGTCGCAGGCGGGTTCGCGCAGCCAGTGGCTGGGTGCGCTGGGCGTCGCCTATACCTTCTGA",
      "translation": "MRLFPRVAAPLIASAALSLSLPAHAQDLPAADASDAAAVGAQMGKNTITLGLGAAYLPDYQGSNDYQFTPAPAGLAYIDGHTITWIGNRLSVDLIGDRSNPGWDFQAGPVGVVNLDRTAPSRIDDPRVRALGKIGAAVELGGYVGIGKVGVVTSPYDRLSVALSYRHDVTGVHDSGIWQPSINYFTPLSTKAAAGLFATAEHAGAGYARRYYSITPGQSVASGLPIYDARSGWKNWTAGALGTYSLTGNLLQGWKLVGSVAYSRMLNDFGDSPIVSQAGSRSQWLGALGVAYTF",
      "product": ""
     },
     {
      "start": 53666,
      "end": 54178,
      "strand": -1,
      "locus_tag": "ctg5_57",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_57</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_57</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 53,666 - 54,178,\n (total: 513 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_57\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGCCGTTTCGCTTGTCTTGCCCCCTTGGCCCTGCTGGCACTGGCCGCCTGCGGCTCCAAGGACGGGGATACCGATTCGGATGTCGCGCCGGGCAATTTCACCCCGCCGGGAACCGCGCGCCCGACGCCGCTGGCGGGGGTGGCGCAGGTGACGCCGCTCAAGGCCTATATCGGCCAATATCCCAATGATGCGGTCGATGGAGTCACCTTCTTCGACCGGACCGAGGTGGCGGGTGCGCTGCACGATGCGGTGGGCGATCAGAAACTGGTGCAGCGGATCATATCACGTGGCGCGGTGACAGTGCCGATCTTCGCCATGGGGGCCACGGGGCTGGCCGCGCATGGCTGCACCCCGCATGACTGCGCCGACAACAATTGGACGATGCAGATGGATATGAAGACCGGCAAGGCGCAGGTCTGCTATCATGATCGCGATACGATGGGCGACCGAAGCCAATGGTATATGGGCGGCGCGCCCGTCACCCGCCCCGGGGAATGCCCGCAGGAATAA",
      "translation": "MRRFACLAPLALLALAACGSKDGDTDSDVAPGNFTPPGTARPTPLAGVAQVTPLKAYIGQYPNDAVDGVTFFDRTEVAGALHDAVGDQKLVQRIISRGAVTVPIFAMGATGLAAHGCTPHDCADNNWTMQMDMKTGKAQVCYHDRDTMGDRSQWYMGGAPVTRPGECPQE",
      "product": ""
     },
     {
      "start": 54234,
      "end": 54698,
      "strand": 1,
      "locus_tag": "ctg5_58",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_58</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_58</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 54,234 - 54,698,\n (total: 465 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_58 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08837.14 (Protein of unknown function (DUF1810)): [17:148](score: 175.4, e-value: 5.3e-52)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_58\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTTTGCCGGGCGGTTGCCGGGATATGCCCCATCCCTCTCCCGATCCGCTGACGCGCTTCGTCGAAGCCCAGGCGCAAGACCTTGCCACCGCTCTGGCCGAGTTGCGCGACGGGCGAAAGCGCAGCCATTGGATGTGGTATGTCTTTCCCCAGATCGCCGGGCTGGGGCGCAGCGAGACCGCGCGCTACTATGCGATCGCCGATGTCGTGGAAGCCCGCGCCTATCTGGCGCATCCGCTGCTCGGGCCCCGTCTGCACGAGGCGGTGCGCACCGCCTGCGCCGCGTCGGGATCGGCCGAGGCGGTGTTCGGTCCGGTCGATGCGATGAAGCTGCGTTCCTCGCTGACGCTGTTCGCGGCGGTGGCCGAGGACCCTGCGCCGTTCCAGGCGGGGCTCGACCGATTCTTCGACGGGCAGGGCGATCCGGCGACGCTTCGCCTGATCGGCCATGCGACCTCCTGA",
      "translation": "MALPGGCRDMPHPSPDPLTRFVEAQAQDLATALAELRDGRKRSHWMWYVFPQIAGLGRSETARYYAIADVVEARAYLAHPLLGPRLHEAVRTACAASGSAEAVFGPVDAMKLRSSLTLFAAVAEDPAPFQAGLDRFFDGQGDPATLRLIGHATS",
      "product": ""
     },
     {
      "start": 54749,
      "end": 55129,
      "strand": -1,
      "locus_tag": "ctg5_59",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_59</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_59</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 54,749 - 55,129,\n (total: 381 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_59\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGCGTACGATCATCACCGCCATTCTGGCCGCCGCCCTGCCGCTGGCGGCCTGTGGCTCCTCGACCGAAGCCACCGGCAACACCGCGACGGCGGCGGCTCCGTCCAACACCAGCGGGATGAGCGCGCAGGACCTGGGCGCCAAGGTCCGCAACCTGCCCGAGGGGCAGCGGCGCGGTGTGCTGTTCCGCGCGATCCGCGATGCCGGCACGAGCGGCGCGACCTGTCAGTCGGTGACCAGCATGACCGAGATCGCCCCGGTCAACGGCAACCCGACCTGGACGGCGGTGTGCGACAATGTCGCGCAGTGGACGATCGTACTGACCGCCGATGGCTCGGCCAGCGTGACGGGCCCCGGGCCGGTGAAGACCAAGGGATGA",
      "translation": "MKRTIITAILAAALPLAACGSSTEATGNTATAAAPSNTSGMSAQDLGAKVRNLPEGQRRGVLFRAIRDAGTSGATCQSVTSMTEIAPVNGNPTWTAVCDNVAQWTIVLTADGSASVTGPGPVKTKG",
      "product": ""
     },
     {
      "start": 55245,
      "end": 55940,
      "strand": 1,
      "locus_tag": "ctg5_60",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_60</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_60</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 55,245 - 55,940,\n (total: 696 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_60 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03167.22 (Uracil DNA glycosylase superfamily): [56:214](score: 84.3, e-value: 9.7e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_60\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_60_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGATATTCGTCTTCACGAAAGCTGGCTGGCCCCGTTACGGCCCGAGTTTGACGAGCCCTATATGAAGGCGCTCAAGACTTTTCTGGCGCAGGAGCGCGCCGCCGGGCAGCGCATCTTCCCCCGCCCGACCGAATGGTTCCGCGCACTCGACCTGACCCCGCTCGACCAGGTGCGCGTCGTCATCCTGGGGCAGGACCCCTATCATGGCGAGGGGCAGGCGCATGGCCTGGCCTTCTCCGTCCAGCCCGGCGTCCGGCCGCCGCCCAGCCTGGTCAATATCTACAAGGAGATGGCCGACGATCTGGGCATCGCCCCGCCCGGCCACGGCCTGCTCGACCATTGGGCGCGGCAGGGGGTGCTGCTGCTCAACTCGGTGCTGACCGTGCGCATGGGGCAGGCCGCTTCGCATCAGGGGCGCGGGTGGGAACGCTTCACCGACGCCGTCATCCGCGCCGTCGCCGCCAAGCCCGAGCCGGTCGTCTTTATCCTCTGGGGCGCCTATGCCCAGAAAAAGGCGGGCTTCGTGCGCGAGATGGGCGGCGGGCGGCACGGCGTGATCACGTCGGTCCATCCCTCCCCCTTGTCGGCGAGGGGCGGCTTTTTCGGCTCCAAGCCCTTTTCGCGCGCCAACGCCTTTCTGGTCGAGCATGGCCAAAAACCGATCGACTGGGCGCTGCCGCCGCTGCTCTGA",
      "translation": "MSDIRLHESWLAPLRPEFDEPYMKALKTFLAQERAAGQRIFPRPTEWFRALDLTPLDQVRVVILGQDPYHGEGQAHGLAFSVQPGVRPPPSLVNIYKEMADDLGIAPPGHGLLDHWARQGVLLLNSVLTVRMGQAASHQGRGWERFTDAVIRAVAAKPEPVVFILWGAYAQKKAGFVREMGGGRHGVITSVHPSPLSARGGFFGSKPFSRANAFLVEHGQKPIDWALPPLL",
      "product": ""
     },
     {
      "start": 56017,
      "end": 56328,
      "strand": 1,
      "locus_tag": "ctg5_61",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_61</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_61</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,017 - 56,328,\n (total: 312 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_61 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03831.17 (PhnA domain): [35:102](score: 100.2, e-value: 4.8e-29)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_61\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCCGACGAAGACTATGTCTATGACGAAGCGACCGGAGAATGGATCAGCGCGGCGGACGCCGCCGCCAAGGCCGGCACGGTCGGCGAGGATGATGCGGTGGTGGTGCGGGACTCGGTCGGCAATGTGCTGAGCGATGGGGATCAGGTGACGCTGATCAAGGACCTGACCGTCAAGGGCGCGGGCCAGACGCTGAAGCGCGGCACGCTCATCAAGTCGATCCGCCTGACCGGCGACGCGCAGGAAATCGACTGCAAGTTCGACGGGATCAAGGGACTCGTGCTGCGCGCGGAGTTTGTGCGTAAGCGGTAA",
      "translation": "MADEDYVYDEATGEWISAADAAAKAGTVGEDDAVVVRDSVGNVLSDGDQVTLIKDLTVKGAGQTLKRGTLIKSIRLTGDAQEIDCKFDGIKGLVLRAEFVRKR",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 38686,
      "end": 46791,
      "tool": "rule-based-clusters",
      "neighbouring_start": 28686,
      "neighbouring_end": 56791,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [
      {
       "start": 36921,
       "end": 36923,
       "strand": -1,
       "containedBy": [
        "ctg5_41"
       ]
      },
      {
       "start": 48522,
       "end": 48524,
       "strand": -1,
       "containedBy": [
        "ctg5_51"
       ]
      },
      {
       "start": 55284,
       "end": 55286,
       "strand": 1,
       "containedBy": [
        "ctg5_60"
       ]
      }
     ],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r5c1"
   }
  ]
 },
 {
  "length": 169754,
  "seq_id": "NODE_6_length_169754_cov_27.671387",
  "regions": []
 },
 {
  "length": 164556,
  "seq_id": "NODE_7_length_164556_cov_28.026544",
  "regions": []
 },
 {
  "length": 153914,
  "seq_id": "NODE_8_length_153914_cov_29.652236",
  "regions": []
 },
 {
  "length": 145203,
  "seq_id": "NODE_9_length_145203_cov_27.967394",
  "regions": []
 },
 {
  "length": 127093,
  "seq_id": "NODE_10_length_127093_cov_31.067598",
  "regions": []
 },
 {
  "length": 126821,
  "seq_id": "NODE_11_length_126821_cov_30.706818",
  "regions": [
   {
    "start": 51426,
    "end": 93954,
    "idx": 1,
    "orfs": [
     {
      "start": 52039,
      "end": 52986,
      "strand": 1,
      "locus_tag": "ctg11_43",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 52,039 - 52,986,\n (total: 948 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_43 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13668.9 (Ferritin-like domain): [66:231](score: 54.8, e-value: 1.2e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_43\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAGAACCCGACCTTTTCCCATGCCCCCCACCCCTATGATCGGCGCCACTATGATCGTCGCAACGTCCTTCGCCTGATCGCCACCTTTTCGACCGGCGCGCTGCTCGCCGGATGCGGCAGCGGCGGCGGAGACGATTCGATCGTCACACCGCCCGCCGCCACCACCCCCGTGCCCGTCGCCTCACCAGGGCACCCACTGAATCTGGCCCTGACGCTTGCCTATCTCGGCGGGCAATATTTCTCCTATGTCGCGCGCGGTGCACCGCTGCCGAGCGTGCTGACCGGAAACGGTGCGGGGGCGGTGACCGGCGCCCGGCAGATGCGTTTCAACGATTCCTCGATCGCCTGGCTGGCGGCGGATCTGGCGGATGACAAGGCAGCCCACGTCACCGCGCTGCGCGGACAGATAGGCGCGTCCGCGCCGGCGCAGCCCGCCATCGACCTGTCGCCGGGCGCATCGGGTGCGTTTTCGCTCGCCGCCCAGCGCGCCGGGATCGTCGGGTTGGGCCAGGCCTTCGATCCCTATGCCGACGACACTCATTTCCTGATCGGCGCGCTGCTGATCGAAAATGCCGTGGCGGCAAGCTATCGCCGATTGTTGCTGGTCGAACCGGATTCGGCGAACGGTGCGATGGCGGCGGCGCATCTGGCCGATTCCATCTATCATGGCGGGGTGATCCGGGCGCTGCTCGACGACCGTGCCGCCACGACGCCCGCGGTCGATGCGATGCTCGGCCGCATCGGCACGATGCTCGCCACGCTCGACGGCACGCAAGGCAGCGACCAGATCCTGCCCGGCGGCGATACGAACAGCTCCAACCTGCTCGACGCGGAAGGACGCCCCATCCCCTTTACCCGCACCGATCGGCAGGTGCTGAACGCGCTTTACCTCTCCGCCACCGGGCCGGGCGGGTTCCTGCCCCAAGGCGCGGTCGGCATCGCATGA",
      "translation": "MQNPTFSHAPHPYDRRHYDRRNVLRLIATFSTGALLAGCGSGGGDDSIVTPPAATTPVPVASPGHPLNLALTLAYLGGQYFSYVARGAPLPSVLTGNGAGAVTGARQMRFNDSSIAWLAADLADDKAAHVTALRGQIGASAPAQPAIDLSPGASGAFSLAAQRAGIVGLGQAFDPYADDTHFLIGALLIENAVAASYRRLLLVEPDSANGAMAAAHLADSIYHGGVIRALLDDRAATTPAVDAMLGRIGTMLATLDGTQGSDQILPGGDTNSSNLLDAEGRPIPFTRTDRQVLNALYLSATGPGGFLPQGAVGIA",
      "product": ""
     },
     {
      "start": 52926,
      "end": 53486,
      "strand": -1,
      "locus_tag": "ctg11_44",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 52,926 - 53,486,\n (total: 561 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_44 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01648.23 (4&#39;-phosphopantetheinyl transferase superfamily): [65:132](score: 26.1, e-value: 8e-06)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_44 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01648.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000287' target='_blank'>GO:0000287</a>: magnesium ion binding<br>\n  \n   PF01648.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008897' target='_blank'>GO:0008897</a>: holo-[acyl-carrier-protein] synthase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_44\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_44_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGTGCCTGCGCGACCTGATGACGGTGCCCTGCGGCGAGGCGATGGCGGCTGATCTGGGCAAGGGGCGGACTCTGCTCCTCGCGCCATCCGCCGCAGATCGGGATGCGGCGGCCGTGCGGATGGCGGGGCGCGCGACCGTGGTCAGCCGGAGCAGCACCTCGGCTTGCCATGCCGTCGCCTGGGCCAGAGGCGGGCGGATCGGCCTGGACGTGGAGACGGTGTCGCGTGTCGCACTGAACGCGAACGTCGACGATCCCTGGCTGGCCGATAGCGAGCGTCATTCCGTCATCGCGGCGGCGGACCCGGTAATCGAACTGGCCTGTCGGTGGGTCCTGCGGGAGGCCTATGGCAAGGCGCTAGGCGTCGGCCTTGCCCTGCCGCTCGATCGCCTTGTCTTTCACGGACGGGGCGGGCGGATCGTGCTGAAGACGCCCTGGCCCAGCGATGGATGGGATTTTGCCCTGTACCGCCGGGGTGAGACGCTGTGTGCCGTTGCCCATCATGCGATGCCGACCGCGCCTTGGGGCAGGAACCCGCCCGGCCCGGTGGCGGAGAGGTAA",
      "translation": "MCLRDLMTVPCGEAMAADLGKGRTLLLAPSAADRDAAAVRMAGRATVVSRSSTSACHAVAWARGGRIGLDVETVSRVALNANVDDPWLADSERHSVIAAADPVIELACRWVLREAYGKALGVGLALPLDRLVFHGRGGRIVLKTPWPSDGWDFALYRRGETLCAVAHHAMPTAPWGRNPPGPVAER",
      "product": ""
     },
     {
      "start": 53518,
      "end": 54291,
      "strand": -1,
      "locus_tag": "ctg11_45",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 53,518 - 54,291,\n (total: 774 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1133:Transcription regulator, crp (Score: 75.4; E-value: 6.3e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_45 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13545.9 (Crp-like helix-turn-helix domain): [168:242](score: 44.5, e-value: 1.2e-11)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_45 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF13545.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF13545.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_45\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCAGTCTTGCTTTGAGCAGCCATCGGCCCGCGCCCGCCCCGCGTGCGATCACCAGCGAATTGTTGCTGCATCGCCTGCGCAGTTTCGCCACCCTTGCCGCCCATGAGGTGGAACTGGTTCTGTCACTGGCCGAACCGCCCAAGAGCCATGCGGCGGGAACCAGCATCTGTCCCCGCGAGGACGGTAGCCCACACCCCCGCCTGATCGTCGGCGGCTGGGCTTGTCGTCCGCGCATCCTACCCGACGGCCGCCGCCAGATGCTGGGAGTGCTCCTGCCCGGCGACATGATGGGTGATCGGGGCGAGCGGCGGCCATTGGCCATGAACCCTGTCATCGCGCTGACCCCCGTGCGCACGATCGGCATCGCCCGGCTAGTGCAGGCGGTACGGATGGAGCCGCAGGACCATCCCGGCATCGTGCGTGCGCTCGCGGCGATCGATCGGTGCGAGGAGATGGCGCTGCTCGACCATATCGTCCGCCTGGGGTGCCAAAGCGCGTTGCAGCGGACCGCGCATCTGCTGCTCGAACTGCATCACCGGCTGTCGGTGATCGGCTTCGTGCACGGTGGCACCTTTCCGATGCCGCTGACCCAGGACACGCTGGGCGAGCTGTTGGGGTTGAGCCTGGTCCATATCAACCGGATCGTGTCGCAGATGCGGCGCGAGGAACTGGCCCTGATCCGCGGCGGGGTGGTGACGATCCAGGATTTTCCCCGGCTGGCGCTGCTCGCCGATCGGATCGACCCGACGAGCCATGCTGGCTCGGCCTGA",
      "translation": "MGSLALSSHRPAPAPRAITSELLLHRLRSFATLAAHEVELVLSLAEPPKSHAAGTSICPREDGSPHPRLIVGGWACRPRILPDGRRQMLGVLLPGDMMGDRGERRPLAMNPVIALTPVRTIGIARLVQAVRMEPQDHPGIVRALAAIDRCEEMALLDHIVRLGCQSALQRTAHLLLELHHRLSVIGFVHGGTFPMPLTQDTLGELLGLSLVHINRIVSQMRREELALIRGGVVTIQDFPRLALLADRIDPTSHAGSA",
      "product": ""
     },
     {
      "start": 54294,
      "end": 56516,
      "strand": -1,
      "locus_tag": "ctg11_46",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_46</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_46</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 54,294 - 56,516,\n (total: 2223 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1216:exopolysaccharide biosynthesis domain protein (Score: 388.8; E-value: 6.8e-118)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_46 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02706.18 (Chain length determinant protein): [34:119](score: 29.3, e-value: 8.7e-07)<br>\n \n  PF13807.9 (G-rich domain on putative tyrosine kinase): [404:471](score: 31.2, e-value: 1.7e-07)<br>\n \n  PF01656.26 (CobQ/CobB/MinD/ParA nucleotide binding domain): [552:715](score: 27.2, e-value: 3.5e-06)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_46 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02706.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009103' target='_blank'>GO:0009103</a>: lipopolysaccharide biosynthetic process<br>\n  \n   PF02706.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_46\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_46_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCCAGCCTGCCGATTCGTTACGATAGCGCTACTTTCGAAGGCGCTCGTTCATCACCCGCCTATGTCGAACGGGGCCCGCTGCCTCAAAACGGGGTCATGGACCTGATCAAGGCCTATCGCCGCCATCTCACGCTGTTCCTGGCGGTCGCGGGCGGCATCCTGGCGCTGGTCGCGGCCTATAGCTGGCTGCAGACCCCGCGCTATACGGCGACCGCCACGCTGGTCATCGCGCCCCAGCCCGCGCAGATCGGGGCGGAGCGAACCAGTGCCCTCAGTGATCCGGCCGCCGATTCCAGTGTCGATACGCAGGTCGAATTGCTGAAGAGCCGGACGCTCGCGGGGCTGGTCGTCGACCGGCTGGGATTGGCCGAGGAAGCGCGGTTCCAGGCGCTGGTCCACAACCCCTCGATCCTCGAGCGGATTCCTGGATTGGAGCGCCCACCCACGCCCCTGCCGGCCTCGGCCCGGCGTGATGCGGCGATCGATCGGCTGGCAAGTGGCATCGAGGTGCATCGCAATGCGCAGACCTTCATGCTCAGCCTGTCCTTCGAGCATCCCGACCGCGAGCTCGCGACCGCGATCGTCAACAGCTATGCGCAGGAATTCGTCGCTCAATCGGGCGCGGTGAAGCGCGAAGGCGCGGACGCCGCCGCCGCGTTGCTGCGCGGCCAGCTCGACGAGGCGCGCCGCGAGGTCGAGGAGGCGGACGGCGATCTGGGCCGCTACAAGGTCGCGCACAATCTGATGAGCGTGCAGGGGGGCACCATCGCCGAGCAGCAGCTATCCTCGCTCGACGGCCAGGTCGCACTCGCCCGCGCCGGAGAGGCGGAAGCGACCGCCCGCCTTCAGACCGCCCGCCAGCAGCTCGCCCGCGGTTCCAAGGGCGACGATCTGGGCGAGGCGCTGGGCTCGCCGGTGATCCAGCAACTGCGCAGCCAGCGCGCGACGGTCAGCGCGCAGGTCGCCGATCTGGGCGGCAAGTACGGACCCAAATATCCCCCGCTTGCGGCCGCACAGCGCCAGGTCGCCGATATCGACGCGCAGATCGAAGGCGAGATCAAGCGCACCATCTCCAATCTGGAGGCGCAGCGCGATGTCGCCGCTCGGCGGACCGCCTCGCTGGCGGGCAGCGCGTCGGGTGCGCGATCGCAGGTGGTGAACAACAATGTCGCTTCAATCGCGCTGGGCGGGCTTCAACTCCGTTCGGACACCGCGCATCAAAGCTATGCACTGTTGCTGACCCGACTGAACGAGATCGGCGCGCAGGCCGCCTCCACCCGGTCGGACGCACGCATCGCCAGTCTCGCCGCGTTGCCCACGCATCCCAGTTCGCCCAACCGGCCGATCAACATGCTCGTCGGCGCGCTGCTGGCGATCGCAATCGGGCTGGGCGTGGTCTTCATGCGGCAGGGGACCGATCGCGGCATCCGTACGCTGGAAGATGTCGAGGGACGGTTGCAGCTTCCCTATCTGGCGGGGCTGCCGACGCTGAACTCGGCGGTGCGCCATATCGGCGGCAGCGACCCGATCAGTGCGCTGGTCGACCATAGCGGCTCGGCCTATGCGGAGGGGTATCGCAACCTGGCCGCCTCGGTCCTGCAATCGGCGGCGGCCGGAACGGTGCGGACGATCGCGCTGACCTCTGCGCTACCCAATGAGGGCAAGACCACCGCCGCGATCGGGCTGGCGCGGATCGTCGCGATGAGCGGGGTCAGCGTGGTGCTGGTCGATGCCGATATGCGCCGGCCGAGCATCGCCAATGCCCTGGGCCTGCGTCCGGCGGTCGGCTTGCAACAGGTGCTGGAGGGCGAGGCGCGGCTGGATGAGGCACTGCTCCGCGATCTCGATTCGCCGCTGACCATCCTGCCCATGGTTCGCGCCGGACTGGGCGGTGCGGCGGCGTTGGGCGGCGCGGGCTTCGACGCGCTGATCGAGGATTTGAAGGCGCGGTTCGATGTCGTGATCTTCGACGCCTCGCCGGTGCTGCCGGTGGTCGACGGGCGGCTGGTCGCCAAGAAGGCGGATTCGACCGTGCTACTGGTCCGCTGGCGCAAGACCCCCGACGCGGCGGTCGAGATGGCGATCCACCTGCTCCAGACACTGGGCGTCAAGATGACCGGCGTGGCGCTCAGCCGGGTCGATCTTCATGCGCTCGCCCGTTCCGGCTATGGCGATCCGGCGCAGTTCATGGGGTCCTACAACACCTATTATGCGAATTGA",
      "translation": "MASLPIRYDSATFEGARSSPAYVERGPLPQNGVMDLIKAYRRHLTLFLAVAGGILALVAAYSWLQTPRYTATATLVIAPQPAQIGAERTSALSDPAADSSVDTQVELLKSRTLAGLVVDRLGLAEEARFQALVHNPSILERIPGLERPPTPLPASARRDAAIDRLASGIEVHRNAQTFMLSLSFEHPDRELATAIVNSYAQEFVAQSGAVKREGADAAAALLRGQLDEARREVEEADGDLGRYKVAHNLMSVQGGTIAEQQLSSLDGQVALARAGEAEATARLQTARQQLARGSKGDDLGEALGSPVIQQLRSQRATVSAQVADLGGKYGPKYPPLAAAQRQVADIDAQIEGEIKRTISNLEAQRDVAARRTASLAGSASGARSQVVNNNVASIALGGLQLRSDTAHQSYALLLTRLNEIGAQAASTRSDARIASLAALPTHPSSPNRPINMLVGALLAIAIGLGVVFMRQGTDRGIRTLEDVEGRLQLPYLAGLPTLNSAVRHIGGSDPISALVDHSGSAYAEGYRNLAASVLQSAAAGTVRTIALTSALPNEGKTTAAIGLARIVAMSGVSVVLVDADMRRPSIANALGLRPAVGLQQVLEGEARLDEALLRDLDSPLTILPMVRAGLGGAAALGGAGFDALIEDLKARFDVVIFDASPVLPVVDGRLVAKKADSTVLLVRWRKTPDAAVEMAIHLLQTLGVKMTGVALSRVDLHALARSGYGDPAQFMGSYNTYYAN",
      "product": ""
     },
     {
      "start": 56534,
      "end": 57862,
      "strand": -1,
      "locus_tag": "ctg11_47",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_47</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_47</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,534 - 57,862,\n (total: 1329 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_47 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF10082.12 (Putative beta-barrel porin 2): [65:442](score: 248.3, e-value: 1.2e-73)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_47\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGATCCTGTGCGGCGCGCCTCGGCGGCTGTCGCGCCTGGCGTCGCTGATGATCGCCGGCGCCTGTACCGCGCCGCTGGGCGCTCAGCTGTTGCAGGATGTACCGACCGTCCAGGTGCCGCCCGAGCCGCCGCTGACCGATGCACGCTCGGTCTTCGCTCGCGAACGCGACACGGGTGTCGCCGACCGGACATTGCCGGCCTTCACCGCGCAAGGGGTCACGGTCGGTGCGTTCGATGTGTTTCCGGCGGTGTCGGTCGGGGGGCTGTTTACCTCCAACCTGTTCGCCAACAATGAGGACCGGCGCAGCGATGTCGCTCTGGTTGTCCGGCCGGAGGTGACGGTGCGCACCAGCGGCGGCCCCTATCGCCTGACCGCCTATGGCCGCGCCGACCTACGCCGCTTCGCCACCTATGCCAGTGAAAATACCGAGGAGGGCATGGCGGGGCTGGAAGGCAGCATTGCGGTCGGCGCGCTCAGCAGCCTCGCGGCGGGGGCCAGCTATGGCAGCTTCGTCAATCCGCGTTTCGCGCCGGACTCGCCGATCGAGGCGGCCAAGCCGCTCGAATATAATGCGCTCAACGGCTATGCGGGTGCGACGATCGAGCAGGCGAACACCCGCATCATTTTGCGCGCCGATGTCATCGACCTGCGCTTTCGCGATACGCCTGCGCGGGACGGCGGCACGCTGTTCACCCGCGACCGCGACCGGACCCGCTATCAGGCACTGGTGCGGGTCGAGCGCGCACTGAGTCCCGCCGTTTCGATTTATGGCGCCGCCAGCCTGAACAAGGTCGATTTCCGCCTCGCACCTGGTGGTACGCGCGATTCCAAGGGCTATGGCGTCTATCTCGGGTCGAGCTTCCAGGTTACCGATCTGATGCGCGGCGATGTCCGCGTCGGCTATATTCGCCAGGACTTCGATCGGGCCGGTATTCGTCCGCTTTCAGGTCTCGGGGCGCTGGGCAAGCTCGTCTATTTCCCGACCCGGTTGTGGACGCTAACCGCGACCGCCGAGAGCAGTATTCAGGACAGCGGCGTGCCGGGAACCGGCGGCTTCTTGCATCGCGGCGGATCGTTGCGCTCGGATCACGAGCTTCGCCGTTACCTCATCGCCTCGGTCGAGGGGGGCTATTACCGCGACACCTATCGCGGCATCCCTCGGCGGGATTCGCTTCCCTATGCCGATGCGGGCCTGACCTATCTGTCGCGCAACCATTGGAATGCGCGGCTCGGCTATCGCTATCTCGCGCGGGATTGCACCTGCGGGTCCGGCGTCACCAATTTCGACGATCATCGCGTCTCACTGACGCTGACCCTTCAACGATAG",
      "translation": "MILCGAPRRLSRLASLMIAGACTAPLGAQLLQDVPTVQVPPEPPLTDARSVFARERDTGVADRTLPAFTAQGVTVGAFDVFPAVSVGGLFTSNLFANNEDRRSDVALVVRPEVTVRTSGGPYRLTAYGRADLRRFATYASENTEEGMAGLEGSIAVGALSSLAAGASYGSFVNPRFAPDSPIEAAKPLEYNALNGYAGATIEQANTRIILRADVIDLRFRDTPARDGGTLFTRDRDRTRYQALVRVERALSPAVSIYGAASLNKVDFRLAPGGTRDSKGYGVYLGSSFQVTDLMRGDVRVGYIRQDFDRAGIRPLSGLGALGKLVYFPTRLWTLTATAESSIQDSGVPGTGGFLHRGGSLRSDHELRRYLIASVEGGYYRDTYRGIPRRDSLPYADAGLTYLSRNHWNARLGYRYLARDCTCGSGVTNFDDHRVSLTLTLQR",
      "product": ""
     },
     {
      "start": 57859,
      "end": 58449,
      "strand": -1,
      "locus_tag": "ctg11_48",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_48</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_48</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 57,859 - 58,449,\n (total: 591 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Poly_export<br>\n \n  transport (smcogs) SMCOG1186:polysaccharide export protein (Score: 116.6; E-value: 1.7e-35)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_48 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02563.19 (Polysaccharide biosynthesis/export protein): [44:117](score: 63.7, e-value: 1.5e-17)<br>\n \n  PF10531.12 (SLBB domain): [122:167](score: 39.7, e-value: 3.4e-10)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_48 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02563.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015159' target='_blank'>GO:0015159</a>: polysaccharide transmembrane transporter activity<br>\n  \n   PF02563.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015774' target='_blank'>GO:0015774</a>: polysaccharide transport<br>\n  \n   PF02563.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_48\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_48_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMPSGVSRNSATRLMTLFLATALPAVAPGQEVATTTNGASAQLPIYNYVLSGGDRVRVVVFGDPALGGEFTIAGSGMIAMPLIGEVDVRGLTSTQLQDRIVARLADGYIKDPRVAVEVLSTRPFYILGEVNKPGQYPFANGLTVLGAVAQAGGYTYRAKTKQVFIKHAGQDAEVAEPVTATTLVAPGDTIRIKERWF\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCCAGTGGCGTATCGCGAAATTCTGCGACCCGTCTGATGACGCTGTTCCTGGCCACCGCACTGCCGGCGGTAGCTCCGGGGCAGGAGGTCGCCACGACCACGAACGGCGCTTCGGCGCAGCTTCCCATCTATAATTATGTGCTGTCGGGCGGCGACCGGGTGCGGGTCGTGGTGTTCGGCGATCCGGCGCTGGGTGGCGAGTTCACCATCGCCGGGTCGGGGATGATCGCGATGCCGCTGATCGGCGAGGTCGATGTGCGCGGCCTGACCTCCACCCAGTTGCAGGACCGCATCGTTGCACGGCTGGCCGATGGTTATATCAAGGACCCGCGCGTCGCGGTCGAAGTATTGTCGACCCGCCCTTTCTACATCTTGGGCGAGGTCAACAAACCCGGCCAATATCCCTTTGCCAACGGATTGACCGTGCTGGGCGCTGTGGCGCAGGCGGGCGGCTATACCTATCGCGCCAAGACCAAGCAGGTCTTCATCAAACATGCCGGCCAGGATGCGGAGGTCGCGGAACCCGTCACCGCGACGACGCTGGTGGCGCCGGGCGACACCATCCGGATCAAGGAACGCTGGTTTTGA",
      "translation": "MPSGVSRNSATRLMTLFLATALPAVAPGQEVATTTNGASAQLPIYNYVLSGGDRVRVVVFGDPALGGEFTIAGSGMIAMPLIGEVDVRGLTSTQLQDRIVARLADGYIKDPRVAVEVLSTRPFYILGEVNKPGQYPFANGLTVLGAVAQAGGYTYRAKTKQVFIKHAGQDAEVAEPVTATTLVAPGDTIRIKERWF",
      "product": ""
     },
     {
      "start": 58792,
      "end": 59445,
      "strand": 1,
      "locus_tag": "ctg11_49",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_49</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_49</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 58,792 - 59,445,\n (total: 654 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Bac_transf<br>\n \n  biosynthetic-additional (smcogs) SMCOG1146:sugar transferase (Score: 265.7; E-value: 1.4e-80)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_49 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02397.19 (Bacterial sugar transferase): [20:211](score: 188.1, e-value: 1.2e-55)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_49\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_49_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGTTTCCTATATATCCCCCGCGCCCCCATCCCTCTCACGCCCCGGGCTGTTGCAGACGGCGGACGTGATTCTGGCGCTTATCCTGTTGGTCCTGCTGTCCCCGCTGATGCTGGCCGTGGCGGCGCTGATCGCGCTGGAGAGCGGCGGCGGCACACCCATCTATGGCCATCGCCGTTACGGCAAAGATGGGCGGACCTTCCTATGCTACAAATTCCGCTCGATGGCGCTGGATGCCGATGCGCGGCTGGCCCGGCTGGTGGCGCATGATCCTGCCGCACGCGCCGAATGGGCGCGCGACCACAAGCTGCGTCATGATCCGCGCGTCACCCGGATCGGCCGCTTCATCCGCCGCACCAGCCTCGACGAACTGCCGCAGCTGTTCAATATCCTGCGCGGCGAAATGAGCCTGGTCGGCCCGCGCCCGATCGTGGCGGCCGAAGTGCGGCGCTATGGCCGCCATTTCGTCGATTATTGCTCGGTGCGGCCCGGGATGACCGGCATCTGGCAGATCAGCGGGCGCAACGACATCGGCTATCGGCGGCGGGTCGCGATGGACTGCCTGATGGCGCGGCGCATGTCGCCCCGACTCTATGCCGAGGTGCTGATCGGCACTGCGCGCTGCGTTGTGACCCGCCAAGGTGCCTATTGA",
      "translation": "MTVSYISPAPPSLSRPGLLQTADVILALILLVLLSPLMLAVAALIALESGGGTPIYGHRRYGKDGRTFLCYKFRSMALDADARLARLVAHDPAARAEWARDHKLRHDPRVTRIGRFIRRTSLDELPQLFNILRGEMSLVGPRPIVAAEVRRYGRHFVDYCSVRPGMTGIWQISGRNDIGYRRRVAMDCLMARRMSPRLYAEVLIGTARCVVTRQGAY",
      "product": ""
     },
     {
      "start": 59455,
      "end": 60642,
      "strand": -1,
      "locus_tag": "ctg11_50",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 59,455 - 60,642,\n (total: 1188 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1045:glycosyl transferase group 1 (Score: 115.4; E-value: 5.9e-35)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_50 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13579.9 (Glycosyl transferase 4-like domain): [17:209](score: 56.4, e-value: 4.6e-15)<br>\n \n  PF00534.23 (Glycosyl transferases group 1): [225:362](score: 84.6, e-value: 6e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_50 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00534.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016757' target='_blank'>GO:0016757</a>: glycosyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_50\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_50_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAAGCCCCGCATCCTGCATCTCTCCAGCCTCTATCCGCCACATATCGTCGGCGGCGCGGAGCGATCGGTGTCGATGCTGGCGGAGGCGCAGGCGGCCGAGGGTTGGAATGTCGCCGCCGCCTGCCTGACTCCCAGCGAAGCGGTGGAAGAGGAGCGGCACGGCGTCACCGTCTTCCGCATGCCGCACGGCAACGACTTCTGGCTGGAGGACTGGGCGGCGCATAGCCAGCGCCAGCGTGAATGGGCCAAGTTCAAGCAACAGGCCAATTTCGCGATCGAACGCCGCTTTGGCGAGGTGCTCGACCGATTTCGCCCTAATGTCGTCCACACCCATTCGATGGTCGATATCTCGACCCGGGTCTGGCACGCGGCGCGCGCGCGCGGGATTCCGATCGTCCACACGTTGCGCGACTTCGACCTGCTGTGCGCCGCCAGTTCCATGTACCGGGAGACGGGACCTTGTGTGGGACGGCATCTGAAATGCCGGGTGCTGACCTTCGCCAAGCAGCTCGACCAGCGTCTCGTCGCGTCGGTGACGGCGGTGGGGGAGGAAGTGCTTTCGCGGCATTTGCGCTATGGCTTTTTTGGTCATGTGCCGGCCGACCGGCGACGCGTCATCTGGAACACGGCGGCGGTCGAGGGGGTGGAGGCGGACTATACCAAGCCCGTGCTCACCGGTCCCATCACCTTCGGCTATCTGGGGCGGATCAGCCCGGAAAAGGGGGTCGATACGCTGCTCAAGGCCGCACGGCTGTTGCCGCCTAACGGCTGGCGGTTGCTGATCGCCGGCGCGGCGCTGGGCGATCCGGCGCCCTATCACGCGCTTGCCGAAGGGCTTCCGGTCGAATTCATCGGCTTTCAGCGTCCCAAGGTGCTATTCGACCAGATCGACTGCCTCGTCGCGCCGTCCTTGTGGGCCGAGCCGCTCGGGCGGACCGTGCTCGAGGCCTATCAGGCGCAGGTACCCGTCATCGGCGCGCGCAGCGGCGGGATTGCCGAGATCATCGCCGATGACGCTTGGCTGGTGCCGCCGGGCGATGAGGCGGCGCTGGCGGCCCGGATGCGCGCGCTGCTGGAGATAGGGCGCCCCGGCCCGCCCAAGGGCCGGGCGCGGGTAGTCGCCCGCACCACGCCCGAGGCGGTGGCGCGGGCCTTCGCGCAAGTTTACGCTCAGCTTCTTCAATAG",
      "translation": "MKPRILHLSSLYPPHIVGGAERSVSMLAEAQAAEGWNVAAACLTPSEAVEEERHGVTVFRMPHGNDFWLEDWAAHSQRQREWAKFKQQANFAIERRFGEVLDRFRPNVVHTHSMVDISTRVWHAARARGIPIVHTLRDFDLLCAASSMYRETGPCVGRHLKCRVLTFAKQLDQRLVASVTAVGEEVLSRHLRYGFFGHVPADRRRVIWNTAAVEGVEADYTKPVLTGPITFGYLGRISPEKGVDTLLKAARLLPPNGWRLLIAGAALGDPAPYHALAEGLPVEFIGFQRPKVLFDQIDCLVAPSLWAEPLGRTVLEAYQAQVPVIGARSGGIAEIIADDAWLVPPGDEAALAARMRALLEIGRPGPPKGRARVVARTTPEAVARAFAQVYAQLLQ",
      "product": ""
     },
     {
      "start": 60639,
      "end": 61823,
      "strand": -1,
      "locus_tag": "ctg11_51",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 60,639 - 61,823,\n (total: 1185 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1045:glycosyl transferase group 1 (Score: 156.9; E-value: 1.4e-47)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_51 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13439.9 (Glycosyltransferase Family 4): [17:210](score: 74.7, e-value: 9.4e-21)<br>\n \n  PF13692.9 (Glycosyl transferases group 1): [224:358](score: 86.8, e-value: 1.8e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_51\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_51_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGAGCGGGATGCGCATCCTTCATGTCAGCTCGGTCTATCCCCCGCACGTCGTCGGTGGCGCGGAGAAGGTCGTCGCCATGCTCGCCGAGGCGCAGGTGCAGCGCGGACATCAGGTGGGCGCGGCCTATCTGTCGCGCAAGGCGCAAGAGGCGGGCGAGCGACACGGCGTCACCGTCCTGCCGCAGCGCAGCCGCAACCTAGTCTGGATGGAGGAGGTGTTCGCCGCCCCGCGCGCGATGCGGACCGCCAACAAATTGGGGCAGATGGTCAATTATCGCGGGGCCGCCGATGTCGCGCGTGCGGTCGCGCAGTTCCGCCCCGACATCGTCCACACCCATTCGATGGTCGAGCTGCCGCCGATGATCTGGTCGGCGATCGCCGACAGCGGCGCGCGCAGCGTCCATACGCTGCACGATTACGACTTGATCTGCTCGCGCGCGTCGATGTTCCGCGACGGGCGCTCCTGTGTCGAGCGCCACGCGTCCTGCCGGATCACCGGTGCGTGGAAGGCACGCTTCGCCAAGCGGATCGATGCAGTCGCGGCGGTGTCGCAGCCGGTGCTCGACGAACATCGCCGCTTCGGCCTGTTTCAGGACACGCGCGCGAAGGTGATCTGGAACGGGGTGGAGGTGCCGCCAGCGCGGCAGCGCTCCGACCGGACAGGGGACTTTATCTTCGGCTTTCTCGGACGGCTTGTCCCCGAAAAGGGAATTGAGACACTGCTCGCCGCCTGTCGTCTCCTACCCGAGACCGGCTGGCAGTTGCAGGTAGCGGGCCGTGCACAAGAAGGCGATGCCGCGTACCGTGCCTTGGCCGAGGGGATGCCGGTCGAATTTCTGGGCTTCACCGATCCGCAGGCGTTTCTGCGCGGCATAGACCTGCTCGTCGTGCCGTCCATCTGGCGTGAGCCGTTCGGGCTGACCGTCGTCGAGGCCTTTGCCCAAGGCGTGCCCGTGATCGGGTCACGGCTTGGCGCGATCGGCGATCTGGTCGGTGCGGTGGGCGAGGAATGGCTGGTGCCACCGGGCGACCCGGCGGCGTTGGCCGCGCGGATGCTGGCGGCGATACACGACGGGCGGTCGGCCTTGCCCGCGCCCCCCGCCTTTGACGGTGTGCTGTCGGTGGTGACGCCGCAGCGGATGCTCGACGCCTATGACGTCCTCTATGCGGAGGTGCTGGCGTGA",
      "translation": "MSGMRILHVSSVYPPHVVGGAEKVVAMLAEAQVQRGHQVGAAYLSRKAQEAGERHGVTVLPQRSRNLVWMEEVFAAPRAMRTANKLGQMVNYRGAADVARAVAQFRPDIVHTHSMVELPPMIWSAIADSGARSVHTLHDYDLICSRASMFRDGRSCVERHASCRITGAWKARFAKRIDAVAAVSQPVLDEHRRFGLFQDTRAKVIWNGVEVPPARQRSDRTGDFIFGFLGRLVPEKGIETLLAACRLLPETGWQLQVAGRAQEGDAAYRALAEGMPVEFLGFTDPQAFLRGIDLLVVPSIWREPFGLTVVEAFAQGVPVIGSRLGAIGDLVGAVGEEWLVPPGDPAALAARMLAAIHDGRSALPAPPAFDGVLSVVTPQRMLDAYDVLYAEVLA",
      "product": ""
     },
     {
      "start": 61820,
      "end": 62818,
      "strand": -1,
      "locus_tag": "ctg11_52",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 61,820 - 62,818,\n (total: 999 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_52 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF16317.8 (Glycosyl hydrolase family 99): [30:312](score: 132.6, e-value: 1.9e-38)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_52 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF16317.8: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016798' target='_blank'>GO:0016798</a>: hydrolase activity, acting on glycosyl bonds<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_52\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGCTGGTCGCGGCGCAGCGTCGTCGGTGCCGGGTTGGCGCTGGCGGCAGCACCGATCTCGGCGGGCCCCCGGCGTTACCCGCGTCAGGTGCTGGCCTTCTATTATCCCTGGTATGGCAATCCGACGACCAGCGGGCGTTGGCTTCATTGGCAGGGTCCGCATGGCGAAGCCCCCCGGCAGAGCCCGACGCTCAACTATCCGGTGCTCGGTCTCTACGACAGCCATGATGCGGGCGTGATCCGCACCCATGTCGCCCAGGCCAAGGCGGCGGGGATCACGGCGCTCATCGTCAGCTGGTGGGGACCGAATTCGTTTGAGGACAAGGCGCTGCCGATGATCCTTGAGGCCGCACGGGCGGCGGGCCTACATGTCACCGTCTATCTCGAACAGCAGAAGGACGGGGCGGCGGGCGCGGCGCGCGATATCGCCTATCTCACCCGGACCTATGGCGCGCATCCCGCCTGGCTGGGGGTGGACAAGCGTCCGGTGCTGTTCCTCTATCTGCAAGCCTTGCGCGATCTGCCCGCACGCGACTGGCGCAAAGCGGCGGAGGGAGCGTTCATGGTGGGTGACGTTTCCCCGCGCGAGACGCGCGATTTCGCCGCCTGGGCGCCGTTCATGGACGGCATCCATGTCTATGTGCTCGCCCCCTATCTGAAGGGCATGACGCCGCCCCAGATGAAGGCCTGGGCGGACCGCACCTACCCGGTCTGGCGGCGCATGGCGGGGAGCAAGCTGTTCTGCGCCACCGTCATCCCCGGCTTCGACGACAGCAAAGTCCCCGGCCGCCCGGCGCCGCGCCCGACGGTCGCGCGCTATGACGGCGCGACCTATCGCACGCTGTGGGACGCCGCGATCCGCCACGACGCCGATTGGGTGCTCGTGACCAGTTTCAACGAATGGCATGAGGGGTCCGAGATCGAACCGTCCACCGAACAGGGCGACCGCTATCTGACCCTGACGGCGCAAGCCGCACGCCGGTTCATGGGGCATTGA",
      "translation": "MSWSRRSVVGAGLALAAAPISAGPRRYPRQVLAFYYPWYGNPTTSGRWLHWQGPHGEAPRQSPTLNYPVLGLYDSHDAGVIRTHVAQAKAAGITALIVSWWGPNSFEDKALPMILEAARAAGLHVTVYLEQQKDGAAGAARDIAYLTRTYGAHPAWLGVDKRPVLFLYLQALRDLPARDWRKAAEGAFMVGDVSPRETRDFAAWAPFMDGIHVYVLAPYLKGMTPPQMKAWADRTYPVWRRMAGSKLFCATVIPGFDDSKVPGRPAPRPTVARYDGATYRTLWDAAIRHDADWVLVTSFNEWHEGSEIEPSTEQGDRYLTLTAQAARRFMGH",
      "product": ""
     },
     {
      "start": 62815,
      "end": 64329,
      "strand": -1,
      "locus_tag": "ctg11_53",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_53</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_53</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 62,815 - 64,329,\n (total: 1515 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_53 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF19982.2 (Family of unknown function (DUF6418)): [364:460](score: 51.0, e-value: 1.4e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_53\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCATCTCGATACACAGGGGCGCGGATGGGCCGACCGATCGCGATGGGCCGGCGGCGCGCCGGTTGCCGCGACCATTGCCTTGGGGGGCGATCATCGCGCTGACCGCCGCGCTTGCGCTCCACTGGGCGTTGGCGGCGGCATGGCCCAGCACGGCCTTCTCCCTATCCTCGCTCCTCCTGTTCGGTGCCTTGCTGTTGCTGGTCGGGCGGATCAGTGCGGCGGGGCTGATCCTGCTGCTCCCGCTGGTCATCACGCGCGGCGCTACATTGGTGTCGCTGCTGGTGATCGAGGCCGGGGCCTATATGCCCGAGGTCAATCAGCAGGGTGTGCCGGGCGATGCGAGCGCGTCCTTTGTCGCCTTCACCGCGATCTTCTTCCTCATCTTCGCGCTGGTCTTTCGCCGATGCGAGCGCTGGTTCCTCGCCTATGCCCGCTCGCCCCTGCTCGATCAGGTCGTGGCGTGGCTCGGCTGGCCGGTGGTGGGCCTGTGCACGGCGTTGGGGGCACTTGCCTTTCTGCATGGGATGCAGAGCGGGTTTCCGCTGCTCGCGGGTGTCGACCGGTTCCTCTATCGGCGGGAATATAGCAGCGGCTTGGTCCTGATCCTGCTCGACAACAAGTTCCTGTTCGCCGCGATGCTGGGGGCCATCGCCTTCGCACCGCGGTACCAGCCGCTGCTCAAGACGGCGGCGATCCTGACCTTCCTTGCCCTCACCGCACTCTATTTCCTGTTCGGCGACAAGTTCTTCACCATCCTGGCCGAAGTCGCCTTCTTCGCCATGCCCTTGCTGCTCGTGCGGCAGGGGCGGCTGGCGGGGACGATGCTGCGGCTCGCGGTGCCGGTCGCGGCGTTGCTGTGCGCGGCGCTGGGGGCCACCCTCTATATCTATTCGGGCTATGGACGGTTACCGCTCGACCGCACCGTGACCCTGGTCGGAGAGCGGATCGCCGGGCAGGGCGAATTGTGGTTCGTCGCCAGCCGCGATGCGCGCCGGGTCACGCATTGGGACGCGCATCTGGTTGCGCGCAACCTCGACACGCTGGGCGACAAGTCGCCGCCCGCCACCGCCTTCGCCAACGGGGTCGAGACCTATTATTTCATCCAGCGCTACGCCCCTGCCGCGCTGGCGGACAGTTTCCGCAAGAATGGCGGCTGGGTGCAGCTGACCATGGGCACCGAGGCGATGGCGCTCGTCATGTTCGGCTATGTCGGCGTGGCCGTCGTCATGGTGGTGCTGGGGGTATTGGTCGCCTTTGCCGCGCTCTATCTGCGTCGCGCCTTCGAATCCGCCTTCCCGTTGAGCCTGTTCTTCGCGGTGTGGACCTTCCTTCAGGTCTATTTCTCGGCACAGCAGGCTTCGCTCTGGAGCATCGCCGCGCCGGGGCAGATCAACCGCCTGCTGTTGTTCGTCACGATCGAGATCATCCTGCTGGCGATCAACCGCGCGCAGATCCGGGTCGGCTGGGACCGCGCCCGCGCGGCGATCTTCGCCGCGAGGCGTACCGCGTGA",
      "translation": "MGISIHRGADGPTDRDGPAARRLPRPLPWGAIIALTAALALHWALAAAWPSTAFSLSSLLLFGALLLLVGRISAAGLILLLPLVITRGATLVSLLVIEAGAYMPEVNQQGVPGDASASFVAFTAIFFLIFALVFRRCERWFLAYARSPLLDQVVAWLGWPVVGLCTALGALAFLHGMQSGFPLLAGVDRFLYRREYSSGLVLILLDNKFLFAAMLGAIAFAPRYQPLLKTAAILTFLALTALYFLFGDKFFTILAEVAFFAMPLLLVRQGRLAGTMLRLAVPVAALLCAALGATLYIYSGYGRLPLDRTVTLVGERIAGQGELWFVASRDARRVTHWDAHLVARNLDTLGDKSPPATAFANGVETYYFIQRYAPAALADSFRKNGGWVQLTMGTEAMALVMFGYVGVAVVMVVLGVLVAFAALYLRRAFESAFPLSLFFAVWTFLQVYFSAQQASLWSIAAPGQINRLLLFVTIEIILLAINRAQIRVGWDRARAAIFAARRTA",
      "product": ""
     },
     {
      "start": 64428,
      "end": 65867,
      "strand": 1,
      "locus_tag": "ctg11_54",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_54</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_54</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 64,428 - 65,867,\n (total: 1440 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Polysacc_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_54 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13440.9 (Polysaccharide biosynthesis protein): [27:315](score: 157.3, e-value: 5.1e-46)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_54\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTTGCCAGGAACATGCTCTCGATGTCGGGGCTCAGCCTCTATCGCAACGCCGTCCAGTTCGGGATGAACGTCGCCATCGCCGCCTTTGTGCTGCCCGGCGATTATGGGCTGATCGTCTTCACCACGCCCTTTCTGGTGTTGATCGCGATGCTGACCGATTTGGGCATGACCAGCGCGATCACCCGTGCGCCGACCCTGTCGCGCGACGAGGCGGGGGCGGCGATGGGGGCGATGATGATCGGAGGCGCGGTCTGCGCCGTGCTGCTGGTCGCAGGCGCCTGGCCCCTGGAGCGCGCGATCGGCATGGCGGGGCTGGCCCCCGTGATGGCGGCGATGGCGGGGGTCGTGCTGTTGTCGATCGCCGCCGCCACCCCGCGCGCCTTGATGGAGCGCGAATTGCGCTATGCCGGGATCGCCCGGATCGAGGCGATCGCCATCGCCCTGGCCGCGATCGCGGGGCTCGCGGCTGCGTGGAGCGGGGCCGGGGTCTGGTCGCTCGTCCTCTACAATATCCTGGTCCAGGCGATGCGGCTCGGCGCGTTCGGCTGGACGATGCGCGGCGTGCTGCGGCCCAATGCCCGGTTCGGCCAGTTGAAAGGCTTGCTCTCCTTCGGTGGCTGGGTGCTGGCGAACAACATCCTCAACTTTCTGGCGCGCAACAGCGACAATCTGCTGATCGGCGCCTGGCTGGGTGCGGCGGCGGTCGGGGTGTACGGCCTGGCCTATCAGTTCATGCTCGCCCCATTGATGGCGATCACCTGGCCGACCAGCGGCATATTGCTGTCCACATTGCGCGGCGAAGACCCGCATGGGCCGCGCGCGCAGGCGACGGTGGAGGGCGTGCTGTCCGCCACCGCGCTGATCGTCACGCCCGCGATGATCTACCTCACCTTCGGCCTCGCCTTTCCGGTGGACAGCCTGTTGTCGGGGCATTGGGCGGCGGTGCCCGCAATCGTCGCCTGGCTGGCCCCGGCGGGCGCGCTTCAAGCGATCGCCTCCTATAATGGCGCGCTGCTGATGGTCGCGGGGCGTGTGAAGGCGCAGTTCCTGCTCAGCGTCGCCAATACGGCCGTGCTGGTCGCGACCTTTGTGCTGGCGCTACCGCATGGGCTGATGGCGTTGGTCCAGGCCTATACGGCGGCGATTTCGGTGATGAGCCTCGCCTTTCTGGCGATGACGGTCATGCTGACGGGCTTGCGCGTCGAGCGGCTCGCCCGCGCGCTGGCCCCCGCGCTGCTCGCCACCGGGGCAGGCGTCGTGGGGGTGGCCGTCACCACGGGCCTGCATCCGGCAAGCTGGACGGGGTGGATCGCCGCGACGGCCATGTACGGCGCGGGGGTGCTGGCCTGCTACGCCGCGCTGCACCTGCATGTCCGGCGCACGCTGGCGGCACTTCTCACACGCGGGGCACCGGATGCGGCGATTACAGGAAGGTAG",
      "translation": "MLARNMLSMSGLSLYRNAVQFGMNVAIAAFVLPGDYGLIVFTTPFLVLIAMLTDLGMTSAITRAPTLSRDEAGAAMGAMMIGGAVCAVLLVAGAWPLERAIGMAGLAPVMAAMAGVVLLSIAAATPRALMERELRYAGIARIEAIAIALAAIAGLAAAWSGAGVWSLVLYNILVQAMRLGAFGWTMRGVLRPNARFGQLKGLLSFGGWVLANNILNFLARNSDNLLIGAWLGAAAVGVYGLAYQFMLAPLMAITWPTSGILLSTLRGEDPHGPRAQATVEGVLSATALIVTPAMIYLTFGLAFPVDSLLSGHWAAVPAIVAWLAPAGALQAIASYNGALLMVAGRVKAQFLLSVANTAVLVATFVLALPHGLMALVQAYTAAISVMSLAFLAMTVMLTGLRVERLARALAPALLATGAGVVGVAVTTGLHPASWTGWIAATAMYGAGVLACYAALHLHVRRTLAALLTRGAPDAAITGR",
      "product": ""
     },
     {
      "start": 65854,
      "end": 66552,
      "strand": -1,
      "locus_tag": "ctg11_55",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_55</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_55</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 65,854 - 66,552,\n (total: 699 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_55\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATGCACAGCCTGCGCCACCGTTTGCGGCATTGGACCGGACGGGCCGACGCCTTCGCCCCCGAACCGGGGCTGGAGGCGATCTATCGCGACCTGTTCCTGCGCGAGTTAAAGCTGCTCGGAGAGGAAGACCGGTTCTTCCCCACAGGCGGCGCGGCCAATTACAGCCTGCTCTATCTGATCCTGCGCATCGGGGTGGAGTTCGGCCCAGCCTCCGTGCTCGATATCGGGGCAGGACAGAGCAGCCTGTTATGGGCGATGCTGCAACGGCGCGGGCTGGTCGGCGAAGTGCTGACGCTGGAGAACGACCCCGAATGGGGCGAGCGGATCGCGGCGCAGGTGATGCATGAGGTGCTGGTAACGCCGCTGGCGGTCCGCCAAGTGGGCAAGCGTGCGGTGACGACCTATGACTGGGCGGCGGTGCGGGCCGGGCGGCGCTTCGACGTGATCCTGTGCGACGGGCCGCGCGGCACGCCTTTCCATTCGCGGGGCGGGGTGCTGGCGATGCTCGAGGATTTGCCGCGCGACTTCGCGCTGATCCTCGACGATGCCGAGCGCGATGGCGAACAGGATACGGTGGGGGCGATCCATGCGCGGCTTCAGGCCGACGGGGTCGATTACGGCGTCGGCGTGGTGCGCGCGGCCAAGACCCAGGTGGTGTTTGCGGGCGGCCGCTTCCTGCCCGCTACCTTCCTGTAA",
      "translation": "MMHSLRHRLRHWTGRADAFAPEPGLEAIYRDLFLRELKLLGEEDRFFPTGGAANYSLLYLILRIGVEFGPASVLDIGAGQSSLLWAMLQRRGLVGEVLTLENDPEWGERIAAQVMHEVLVTPLAVRQVGKRAVTTYDWAAVRAGRRFDVILCDGPRGTPFHSRGGVLAMLEDLPRDFALILDDAERDGEQDTVGAIHARLQADGVDYGVGVVRAAKTQVVFAGGRFLPATFL",
      "product": ""
     },
     {
      "start": 66553,
      "end": 67719,
      "strand": -1,
      "locus_tag": "ctg11_56",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_56</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_56</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 66,553 - 67,719,\n (total: 1167 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1088:acyltransferase 3 (Score: 154; E-value: 9.3e-47)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_56 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01757.25 (Acyltransferase family): [29:360](score: 70.5, e-value: 1.4e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_56 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01757.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016747' target='_blank'>GO:0016747</a>: acyltransferase activity, transferring groups other than amino-acyl groups<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_56\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_56_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGAAAAGGGCGGTGGAGAAGCAGGGGAGACCATAGTCCACCCCGTTGGCATGGCCCCGTCGACGCGTACGCTTTGGACGGTCCAGGCCTTGCGCGGTGCGGCCGCGCTGATGGTCGTGATCGGTCACAGCCAGAGCGCGGCGGCGGGAATCGTAACCGCGCGGGGCGACCATTTCGCGCGCTCGACACTGATGCCATGGGGGGCGGGGGTGGACCTGTTCTTCGTCCTGTCGGGCTTCATCATGGTCCATGCCTCCACCCGCTTGTTCGGGCAGGGGAATGCGCACGAGGAGTTCCTGCGGCGGCGGCTGGTGCGGATCGTGCCGCTCTACTGGCTGGTCACGACCCTCTTTCTCGCACTGCTCGCGGCGGCGACGCTGAAGGGGGGCGATCCCTTTCCCGACGCTCGGGCGATCCTCGCTTCCTATACCTTCGTCCCGGCGAACACATGGGGCGACGGGCGGTTCTTTCCGGTCTTCGATCTGGGCTGGACGCTGAATTACGAGATGTTCTTCTATGCGCTGTTCGCCTTCGTCGTGGCGCTGCCGCGCGGGCGGGCGCTGGTGGCGATCGGCGTGATGCTGGTCGCGGCGACGGGGATTGGCGCTGTGGTGCCGGGGCCGTCTGGGCTGTGGTTCTGGACGCGGCCGATCATCTTGGATTTCGGGCTGGGGCTGGCGGTCGGGGCACTGCTGGGGCGGGGCGTCGTCCTGCCACCGATGGTGCGGCTCGCGCTGGCGGCCGCCGGGGCCGCGCTGCTGCTCGCCGATCCCTTCCATATCTTTGACGGCGCGGTCGGTGTGACCGTCGCTAATGACTGGCCGCGCGTGGTCTGTGCCGGGCTGCCGATCGCGATGCTGCTGGCGGCGGCGGTGCTGGGGCCCGAGCCGGTGATGCCGCGTATCCTGTTGCCCGCCGCGCTTGTGGGGGATGCGTCCTATTCACTCTATCTCTTCCACCCCTTCGCGCTGATCCTGACGGAGAAGCTGGCACAGAAGCTGCCCGTGATGCGGGCGGCCGAGGGATGGCAGCTCGTGGCCGTCATGGTCGGTGTCGCGCTGATCCTCGCCTTCGCGGTCCATCGCTGGATCGAGCGACCCCTGACCGCGCAACTCGCGACCCCAACCCAGCCGCGTGCCGTCGCGGCGCATTCTGGAGAGTGA",
      "translation": "MTEKGGGEAGETIVHPVGMAPSTRTLWTVQALRGAAALMVVIGHSQSAAAGIVTARGDHFARSTLMPWGAGVDLFFVLSGFIMVHASTRLFGQGNAHEEFLRRRLVRIVPLYWLVTTLFLALLAAATLKGGDPFPDARAILASYTFVPANTWGDGRFFPVFDLGWTLNYEMFFYALFAFVVALPRGRALVAIGVMLVAATGIGAVVPGPSGLWFWTRPIILDFGLGLAVGALLGRGVVLPPMVRLALAAAGAALLLADPFHIFDGAVGVTVANDWPRVVCAGLPIAMLLAAAVLGPEPVMPRILLPAALVGDASYSLYLFHPFALILTEKLAQKLPVMRAAEGWQLVAVMVGVALILAFAVHRWIERPLTAQLATPTQPRAVAAHSGE",
      "product": ""
     },
     {
      "start": 67826,
      "end": 68950,
      "strand": 1,
      "locus_tag": "ctg11_57",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_57</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_57</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 67,826 - 68,950,\n (total: 1125 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1045:glycosyl transferase group 1 (Score: 182.5; E-value: 2.5e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_57 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13579.9 (Glycosyl transferase 4-like domain): [11:173](score: 61.0, e-value: 1.9e-16)<br>\n \n  PF00534.23 (Glycosyl transferases group 1): [183:319](score: 99.7, e-value: 1.4e-28)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_57 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00534.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016757' target='_blank'>GO:0016757</a>: glycosyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_57\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_57_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGGATTCTTCACATCGCCGAATCCGCGCAGGGCGGCGTCGGCACCTATCTGACCGAGATATTGTCCGATCAGGCACGCCGCTATGGCGGCGACCGGGTCCGCGCGCTGGTCCCAGCACAACATGCCGCACATCTGAGCGGGGTCGATCGCCGGCTGTTGATCCCGTGGCGACGGCAGCACCGCTCGGTCCGCGGCATGATGTCGCTGGCCGGCGCGATCGCGAGCGCGGTAGAGCAGGTAAGGCCGACGATCGTCCATGCCCATTCCAGCTTTGCGGGTGCGGTGCTGCGGCTGTTGTACGGATCATGGCGGCGCGCGCCGTTCCGTATCGTCTATTGCCCGCATGGCTGGGCCTTCGACCGCCGTTCCTCGGCGTGGAAGCGCCGCGTGGTCGAGGGGGTCGAGCGCATCCTGGCGCCGGCCGCCGACCGCATCGTCCTGATCTCCGACCATGAACGGCGCGAGGGCGTGCGGATCGGCATCGATCCGGCCGCGCTGACCCTGGTGCTGAACGGCATCGCCGACCTGCACAGCGAACGCCCCGCGCGATGGCAGGACGATCGGGTGCGGGTGCTGTTCGTCGGGCGGCTCGACACGCAAAAGGGGTTCGACACGCTGCTCGACGCGGTCGAGCCCATTCAGGACCATGTCGCGGTGCGCGTCATCGGCAAGGCGGTGGCCGGCCCCGCCACCACCCCGCGCAAACGCAGCCCGCAGATCGAATATCTCGGCTGGCGATCGCTGTCCGAAGTCGCGACCGAGATCGCCGCCGCCGATGTCGTCGTCGTCCCCTCGCGCTGGGAAGGCTTCGGCCTCGTCGCGCTGGAGGCGATGTGCGGCGGCTGCGCGGTCGTCGCCTCCGATGTGGGGGGCCTGCGCGAGATCGTCGCCGATGGCGAGACGGGCTATCTCGTCCCCCCCGATCATCCGGAGCGGCTGATGCGCACGCTCGCCCGGCATGACCGCGCCACCTGGCAGGCGATGGGTGCCGCCGGACGCGCGCGCTACGAGGCGCGGTTCACCGCGCAGCGGATGAATGCCGAACTCGCCGCGCTCTATGCCGAATTGTCGCCGGTCGTGCGGGAAGAGCATGTGGCCACGCCGCTGGTCGCCCATGCGTAA",
      "translation": "MRILHIAESAQGGVGTYLTEILSDQARRYGGDRVRALVPAQHAAHLSGVDRRLLIPWRRQHRSVRGMMSLAGAIASAVEQVRPTIVHAHSSFAGAVLRLLYGSWRRAPFRIVYCPHGWAFDRRSSAWKRRVVEGVERILAPAADRIVLISDHERREGVRIGIDPAALTLVLNGIADLHSERPARWQDDRVRVLFVGRLDTQKGFDTLLDAVEPIQDHVAVRVIGKAVAGPATTPRKRSPQIEYLGWRSLSEVATEIAAADVVVVPSRWEGFGLVALEAMCGGCAVVASDVGGLREIVADGETGYLVPPDHPERLMRTLARHDRATWQAMGAAGRARYEARFTAQRMNAELAALYAELSPVVREEHVATPLVAHA",
      "product": ""
     },
     {
      "start": 68919,
      "end": 70205,
      "strand": 1,
      "locus_tag": "ctg11_58",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_58</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_58</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 68,919 - 70,205,\n (total: 1287 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1045:glycosyl transferase group 1 (Score: 94.2; E-value: 1.6e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_58 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13692.9 (Glycosyl transferases group 1): [243:371](score: 54.0, e-value: 2.2e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_58\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTGGCCACGCCGCTGGTCGCCCATGCGTAACGGGCGCATCGTCCTGCTCTCCGATTATATCGGTGGCGAGGGGCCGGGTAGCGGCGGGGCCGGCCATGCCGCGCTCGACAGCTACCGCGCGCTCAGGGCCGCGGGCGCGGATGTCCATGTCATGGCAGGGTTCGGTGAGCCGCCCGCGATCGAGCCCGAGCGGTTCCGAGGACTGGGCGGCGCGGACCTGCGCGGCGGGGGCGCCGGCGCCATGCTGCGCGCCATCTACAACCCTGACGCCGGAGCAATGCTGTCTCGCGAAGTGGCGGGGCTTGATCCCGACACCACATTGATCGTGCTTCACCAATGGACCCGGTATCTGTCCCCGGCCGCCTTGCGAATCGCCAGCCGCTTTCCGATCATGATCTATATGCACGACTATTTCTGGGTCTGTCCCAACGGCATTTATTATGATTTCGCGGCCGGCCGCCCATGCGATCGGCGGCCGATGCGGCGCCATTGCCTGACCAGCGATTGCGACCGCCAGGGCCGCCTGCCCAAGCTCGGCCGGCTGGCCAGGCACGCGATGCGCCACATGGCGACCGCGACCCGGCCGAGCCGCCGCCTGTTCCTGCATTTGTCCGAACATGCGCAACGGACCATCATGCCGCTGCTCCCCGAACAGCGCCATGCGGTGCTCCACAATCCCCTATCGCTCTCCGATATCGAGCCACCCCCCGCTCCGCCACCGACCTATGACGTGGGCTATTTCGGACGACTGGAGCAAGACAAGGGTGTCGAACTTCTGGTCGAGGCACTGCGCGAGACGGGACGTACCGGCCTGTTCGTTGGCCAGGGTTCGCTGGAACCGCTGCTGCACGCCACGCCCGGCATCACCCACCGATCCTGGCAACCGCGCGAGACGATGGCGGCGGCGATGCGATCCTGCCGCGTCGTCGTCCTGCCCTCGCTCTGGAACGAGACCTGGGGGCTGATCATCGCCGAGGCGATGGCCGCGGGCGTAACGGTGCTGGTGTCGTCGCGCGCCGGTTCGTCCGAACTGGTCCGTCGCTTTGGCGGGGGACAGATGTTCGATCCCGGGCAGACCGGCAGCTTGGCGGCGAGCCTGCGCCAGATGCTGGGGGCGCCCCCCTCGCCCACCCGGCAACATGGCGCGCTTCGCCGCTTCCTGTCTCCCGAACGCCATGCCGCGCGCATCATGGGGCTGGCGGAGAGTCACTTCGGGCTGAGCCTGCGGAGTGACGACCGCCGTGTCAGGACGTCAGCACCTCACTCAGTATCCCGGCCAGCCTGA",
      "translation": "MWPRRWSPMRNGRIVLLSDYIGGEGPGSGGAGHAALDSYRALRAAGADVHVMAGFGEPPAIEPERFRGLGGADLRGGGAGAMLRAIYNPDAGAMLSREVAGLDPDTTLIVLHQWTRYLSPAALRIASRFPIMIYMHDYFWVCPNGIYYDFAAGRPCDRRPMRRHCLTSDCDRQGRLPKLGRLARHAMRHMATATRPSRRLFLHLSEHAQRTIMPLLPEQRHAVLHNPLSLSDIEPPPAPPPTYDVGYFGRLEQDKGVELLVEALRETGRTGLFVGQGSLEPLLHATPGITHRSWQPRETMAAAMRSCRVVVLPSLWNETWGLIIAEAMAAGVTVLVSSRAGSSELVRRFGGGQMFDPGQTGSLAASLRQMLGAPPSPTRQHGALRRFLSPERHAARIMGLAESHFGLSLRSDDRRVRTSAPHSVSRPA",
      "product": ""
     },
     {
      "start": 70165,
      "end": 71304,
      "strand": -1,
      "locus_tag": "ctg11_59",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_59</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_59</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 70,165 - 71,304,\n (total: 1140 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1045:glycosyl transferase group 1 (Score: 117.3; E-value: 1.6e-35)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_59 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00534.23 (Glycosyl transferases group 1): [215:322](score: 62.7, e-value: 3.2e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_59 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00534.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016757' target='_blank'>GO:0016757</a>: glycosyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_59\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_59_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTTTGCAATCCCTTCCCCGCGATGCGCTCTTCCGAAACGGTACGCGATCCGACCGGCCGTGCCTGTTCTTCAACGGCAAATTCTATTCGGGGAAGACCAACGGGGTTCATCGGGTCGCGGATCGGCTGTTGCGCGAACTGGACGCGCTGGCGGTGGCGGGGGCCGCGCCGGCGGGATGGGACATGCGGTTGCTGCTGCCCAGACGCGCCAACTGGGCGCCGCGCTTCGCCGCGATCACACCGATGCCGCAGCGTTATGGCGCTAGCCAATTCTGGGAGCAGATGATCCTGCCCGTTGCGGCGCGGCGCGGGGCGCTGGCCAGCTTCGCCAATCTCGCCCCAGGCTGGCATGGGCGCAAGGTGACGATGGTACATGATGCACAATTCCTGCTGTCGCCCGAAAGCTATTCGCCCAAATTGCGGTGGGGCTATCGCCTGCTCGTGCCGTGGGGCGCGCGGTCGAGCCGGGTGGTCCTGACCGTGTCCGATTATGCGCGCGACAGCCTGGCGACGTTCGGCATCGCGTCGCCCGCGCAGACGCAGGTGCTGCATAATGGCGCGGACCATATTCTGGACGTGCCCGCCGACCGAAGCGTGCTGGACAGGCATGGCCTGGCGCCCGGCTCCTATGGCCTGATCTTCGGCTCGACCTCGGCGTACAAGAATGTCGCGGCCGTCTTCACCGCCTTTGCCGATCCGCGTCTGGCCGCGATGCCACTGGTCGTGGTCGGGCCGTCGCGGGCGGTGCTCGAGGCGGCAGGACTGCGGCCGCCGCCGGGCGTGGTGTTCGTCGGCGGGGTCGATGATAGCGGCCTGCGTGCCCTGTACGAAGGGGCGCATTGCCTGCTCTACCCTTCACGGACAGAGGGTTTCGGTCTGCCGCCGGTCGAGGCGATGCTGTGCGGCTGCCCGGTCGTCGCGGCCCCGGCGGGGGCCATTCCGGAAGTATGCCGCGACGCCGTCGTCTATGCCGGGATGGACGATATCGGCGAATGGATCGGCGGCGTCCTGGTGCTGGGTAATCGTGAGGTACGTGCCGCCAAAGTCGCCGCCGGTCGCGCGCGTGCCGGCCATTTCACCTGGGCGGCGGCGGGCGTCAGGCTGGCCGGGATACTGAGTGAGGTGCTGACGTCCTGA",
      "translation": "MALQSLPRDALFRNGTRSDRPCLFFNGKFYSGKTNGVHRVADRLLRELDALAVAGAAPAGWDMRLLLPRRANWAPRFAAITPMPQRYGASQFWEQMILPVAARRGALASFANLAPGWHGRKVTMVHDAQFLLSPESYSPKLRWGYRLLVPWGARSSRVVLTVSDYARDSLATFGIASPAQTQVLHNGADHILDVPADRSVLDRHGLAPGSYGLIFGSTSAYKNVAAVFTAFADPRLAAMPLVVVGPSRAVLEAAGLRPPPGVVFVGGVDDSGLRALYEGAHCLLYPSRTEGFGLPPVEAMLCGCPVVAAPAGAIPEVCRDAVVYAGMDDIGEWIGGVLVLGNREVRAAKVAAGRARAGHFTWAAAGVRLAGILSEVLTS",
      "product": ""
     },
     {
      "start": 71426,
      "end": 73954,
      "strand": 1,
      "locus_tag": "ctg11_60",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_60</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_60</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 71,426 - 73,954,\n (total: 2529 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 344.6; E-value: 1.3e-104)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-ctg11_60 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>Thioesterase</strong> (645..801)</dt>\n   <dd>\n   \n    active site serine inconclusive<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_60 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [23:409](score: 301.3, e-value: 9.8e-90)<br>\n \n  PF13193.9 (AMP-binding enzyme C-terminal domain): [416:491](score: 44.2, e-value: 3.1e-11)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [517:582](score: 55.1, e-value: 7.6e-15)<br>\n \n  PF00975.23 (Thioesterase domain): [645:740](score: 46.7, e-value: 4.5e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_60 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00975.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_60\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_60_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCTGCGCCAGGAAGAGACGACCGCCTATGTCCCCAAACGGGGGTGGCACGCGCTTCCCGATATCTTCGCCCGTCACGCCTGGTGCGATCCCGACGCCCCGGCGGTCGAAGCACGCGGGCAGCGGCGCAGCTATGGCGAACTGGCGGCGCGTGTCGACCAGTTGGCGGCGCGGCTGGCCTATCTGGTGGCCGACGATCATCCCTTGATCGGTCTGTGCCTGTCGCGCGATGTCGATCTGCCCGCCTGGCTGCTCGCGGTGCTGAAGATCGGTGCGGCCTATCTACCGATCGATCCCGCGACCCCGCCCAACCGTCTGGCGCATATCATGGAGGATGCGCGCCCCGCCCTGATCATCGCCAATCGCTGCTATGGCGATATCATCGCCGATCTGGGGATACCGGTGATGATCGCCGAGGAGGAAGGCGATCCCGTCATGATGGTCCCGACCCCAGCGATCACCTCCTCGACGCTCGCCTATGTCATCTTCACCTCCGGTTCGACCGGCCGGCCTAAGGGCGTGGAGATCGAACATGGCGCGCTCGTCGCACTGCTGGCGACCATGGCGGCGAGCCCGGGCTTTCGCGCGAATGAGAAGATGCTGGGGATCACCCGGCTCAGCTTCGATCTGTCCGTGCCGGACCTGTTCCTGCCCTTCTATGTCGGCGGATCGCTGGCGCTGATCGATCTCGAGGAGGCTGCCGATCCCACACGGCTCGCCGCTGCGCTCGATCGGCATCGCCCCGACCTGGTGCAGGCGACACCCTCCACCTGGCGGGCACTGGTCGAACAGGGTTGGAGCGGGCTGCCAGGCTTGCGCATCCTGGCGGGCGGGGAAACGCTGACCCGTTCGCTCGCCGACCGATTGCTGCTACGCTGCGACGAGTTGTGGAATATCTATGGGCCGACCGAAACGACCGTGTGGTCGACCGCCTGCCGCGTGACCCCTAGCCATGACGCGATCCCGATCGGCTGGCCGATGAGCGGCATCACCGTGTACGTCACCGACGTCGATCTGAAACCCGTGCCGCCCGGCCAGGTGGGTGAGATCGTCATCGGCGGGCCGGGTGTCGCGCGCGGCTATCGCAATCGCCCCGACCTCACCACCGAGCGCTTCGTGCGCCTAGCCGACGGGGCGCGGGTCTATCGCACCGGCGATCTTGGCCGGTTTGACGAACGCGGCGCGCTTTATTGCCTGGGGCGGATCGACGATCAGGTGAAGGTGCGCGGCTTTCGCATCGAACTGGGCGATGTCGAGGCGGCACTGTCGCTCCACCCCGGCGTCGTCTGGAGCGCGGTGCGGCTCTGGACCGATCCTTCGGGCGAGGCGCTGCTGGTTGGCTATGTCGTACCGCGCGACAGATCGCTCGGCCCCCGCGAGATCAAGGCGTTCCTGGCCGGTCACCTGCCCGCCTATATGATCCCCGACCGGATCGTGACGCTGTCGGCCATGCCGCTGACGCCCAATGGCAAGATCGACCGCGCCGCGCTGCCCGACCCTGCTGCGGAAGGACGCCCAACCATCGCACAGCATGCGGCCGACGCAATCGATCGGCGGCTGGCGGCGATCTGGAGCGATCTGCTCAATATCGGCGCGATCGCCGCGGAGGATGATTTCTTCGACCTGGGGGGCTATTCGCTGATGACCGTGCGGCTGGCCCGCCGGATCGAGGCGGCGTTCGGCGTCCGTCTCGCACTGATCGACCTGATGCGACATTCCACGCTGTCCGACATGGCGGCGCGCATCGCGCTGGGCGAGCAGCCCGCCGATCGGACGATGACGCTGTTCAATCCCGAGGGGCGGCGGACGCCGCTCTTCTGGCTCGATACCGGGCCGCTGATGCGCAACATCCTGCGCGACCTATCCGCCGACCAGCCGGTGCTGGCGCTCAATATCGATCCGCACGACGAAGACGCGCTCGGCTCAGGCACGCTGTCGATCACGGCAGTCGCGGCGCGGCTCAAGGAGCATCTGCTGGCGGCCTATCCCATCGGCGCGCTGAATCTGGGCGGATGGTGCCGCTGGGGAATCGTCGCCTATGAATTGGCGCAACAACTGGCCGCACAAGGGCGCGAGGTTCGCCTGCTTGCCCTTCTCGACGCCGAATGTCCCCGGCAGGGCGTGGGGCAGCGGCTCCGGAGGCAGATGCGCCAAATGCTCCACCGCATCGGGACCGTCCAACACGAGAAGGCCAGTTTCAGCCAGCGGGTCGAACATGCGACCCACAGCTATGCAGCCGCTCTTTACGCCGGTGACGTGCTGTTGCTGCAGCCCACCGCCCGGCGCACGAATGCCGGCTGGAATGCCGTCGTGCGCGGCGCGTTGACGGTCGAGCTCATCCCCGGCGACCATGAGACGATGATGCGGGGCAGCGCCGCGCCCATGCTCGCCTCCGCGCTGAACACCGCGCTTGCATCCACGCAGCACCGCCCGGCCATACTCCCGGAGGTCAGGTCGCCTGTCCCCGTCCCGCTCCTACAGCCCCGTGCGATCCCGGCCGCCGGGGAACGCCGGTGCCAGTCCAGTTAA",
      "translation": "MLRQEETTAYVPKRGWHALPDIFARHAWCDPDAPAVEARGQRRSYGELAARVDQLAARLAYLVADDHPLIGLCLSRDVDLPAWLLAVLKIGAAYLPIDPATPPNRLAHIMEDARPALIIANRCYGDIIADLGIPVMIAEEEGDPVMMVPTPAITSSTLAYVIFTSGSTGRPKGVEIEHGALVALLATMAASPGFRANEKMLGITRLSFDLSVPDLFLPFYVGGSLALIDLEEAADPTRLAAALDRHRPDLVQATPSTWRALVEQGWSGLPGLRILAGGETLTRSLADRLLLRCDELWNIYGPTETTVWSTACRVTPSHDAIPIGWPMSGITVYVTDVDLKPVPPGQVGEIVIGGPGVARGYRNRPDLTTERFVRLADGARVYRTGDLGRFDERGALYCLGRIDDQVKVRGFRIELGDVEAALSLHPGVVWSAVRLWTDPSGEALLVGYVVPRDRSLGPREIKAFLAGHLPAYMIPDRIVTLSAMPLTPNGKIDRAALPDPAAEGRPTIAQHAADAIDRRLAAIWSDLLNIGAIAAEDDFFDLGGYSLMTVRLARRIEAAFGVRLALIDLMRHSTLSDMAARIALGEQPADRTMTLFNPEGRRTPLFWLDTGPLMRNILRDLSADQPVLALNIDPHDEDALGSGTLSITAVAARLKEHLLAAYPIGALNLGGWCRWGIVAYELAQQLAAQGREVRLLALLDAECPRQGVGQRLRRQMRQMLHRIGTVQHEKASFSQRVEHATHSYAAALYAGDVLLLQPTARRTNAGWNAVVRGALTVELIPGDHETMMRGSAAPMLASALNTALASTQHRPAILPEVRSPVPVPLLQPRAIPAAGERRCQSS",
      "product": ""
     },
     {
      "start": 73971,
      "end": 75401,
      "strand": -1,
      "locus_tag": "ctg11_61",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_61</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_61</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 73,971 - 75,401,\n (total: 1431 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1076:RND efflux system, outer membrane lipoprotein, (Score: 407.5; E-value: 1e-123)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_61 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02321.21 (Outer membrane efflux protein): [70:262](score: 64.3, e-value: 1.3e-17)<br>\n \n  PF02321.21 (Outer membrane efflux protein): [287:469](score: 88.7, e-value: 4.4e-25)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_61 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02321.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015562' target='_blank'>GO:0015562</a>: efflux transmembrane transporter activity<br>\n  \n   PF02321.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_61\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_61_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMAKHLCRWLAGAALGLLGGCSMAPAYHPPAMPTPPAFKEAFSASASIWKPAGALTTAPRGDWWTGFGDPTLNQLEARIDADSPTLAAALARYDLARATLAGARSGLFPHVELTPGLIRNRQSGERPLRGGNQPDFYTAATLGGDISYEADLWGRVRNSVASGRALAEASRDDLAAVKLALQGQLATDFVQLRGQDQQLALLTQTIMAFAKADALTHNRFRGGIATGMDVGRAGALLGEARAQYAETEAARAITEHAIASLVGQPASTFSIPHRDGVMTLPAIPIGLPSTLLARRPDVAAAERRMAAANARIGVAKAAFFPQITLGGAGGFQSTALAGLVAAPNLFWAIGPGAILNLFDGGKRRAEVAAARADWNGAMADYRTHALGAFQDVEDALATLHHLGEAQAAQDQAVASATRTEQIALDRYIKGAATYLDVATAQESALHDRQAALALENRRLMAGVALIRALGGGWSAAI\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTAAGCACCTGTGCCGCTGGCTGGCGGGGGCGGCGCTGGGGCTGCTCGGTGGCTGCTCCATGGCACCCGCCTATCACCCGCCCGCCATGCCCACGCCGCCCGCGTTCAAGGAAGCGTTCTCGGCCAGCGCCTCCATCTGGAAACCGGCTGGGGCGCTGACCACCGCGCCGCGCGGCGATTGGTGGACCGGCTTCGGCGATCCGACGCTCAATCAATTGGAAGCGCGGATCGATGCCGACAGTCCGACGCTGGCGGCCGCCTTGGCACGCTATGACCTAGCCCGAGCGACGCTGGCAGGGGCACGGTCCGGACTGTTCCCGCATGTCGAACTGACCCCCGGTTTGATCCGCAACCGTCAGTCGGGCGAGCGACCGCTGCGCGGTGGCAACCAGCCCGATTTCTATACCGCCGCGACGCTGGGCGGCGATATTTCCTATGAGGCGGACCTATGGGGCCGGGTGCGCAACTCGGTCGCCTCGGGCCGTGCGCTGGCCGAGGCGAGCCGCGACGATCTGGCGGCGGTGAAGCTGGCACTGCAAGGGCAACTGGCCACCGATTTCGTGCAGTTGCGCGGACAGGACCAGCAATTGGCGTTGCTGACCCAGACGATCATGGCCTTTGCCAAGGCCGATGCGCTGACCCACAACCGCTTCCGGGGCGGGATCGCGACCGGCATGGATGTCGGCCGCGCCGGCGCGTTGCTGGGCGAGGCGCGGGCGCAATATGCCGAGACGGAGGCTGCGCGCGCGATCACCGAACATGCCATCGCCAGCCTGGTCGGACAGCCCGCCTCGACCTTCTCGATCCCGCACCGCGACGGTGTAATGACCTTGCCCGCCATTCCTATCGGCCTGCCCTCGACCCTGCTTGCCCGCCGTCCCGATGTCGCGGCGGCGGAGCGGCGGATGGCGGCAGCCAATGCGCGCATCGGCGTCGCCAAGGCGGCGTTCTTCCCGCAGATTACGCTGGGCGGGGCGGGGGGCTTTCAAAGCACCGCGCTCGCCGGACTGGTCGCAGCGCCCAACCTGTTCTGGGCGATCGGGCCGGGGGCGATCCTGAACCTGTTCGATGGCGGCAAGCGTCGTGCCGAGGTCGCCGCCGCGCGCGCCGACTGGAACGGCGCGATGGCCGATTACCGCACCCATGCGCTGGGCGCATTCCAGGATGTCGAGGACGCGCTCGCCACGCTGCACCATCTGGGCGAGGCGCAAGCGGCGCAGGACCAGGCGGTCGCCTCCGCTACCCGCACCGAACAGATCGCGCTCGATCGTTATATCAAGGGGGCGGCCACCTATCTCGACGTCGCGACCGCGCAAGAGAGCGCCTTGCACGACCGGCAGGCGGCGCTGGCGCTCGAGAACCGGCGGCTGATGGCGGGCGTCGCATTGATCCGGGCGTTGGGCGGAGGGTGGTCGGCCGCCATCTAG",
      "translation": "MAKHLCRWLAGAALGLLGGCSMAPAYHPPAMPTPPAFKEAFSASASIWKPAGALTTAPRGDWWTGFGDPTLNQLEARIDADSPTLAAALARYDLARATLAGARSGLFPHVELTPGLIRNRQSGERPLRGGNQPDFYTAATLGGDISYEADLWGRVRNSVASGRALAEASRDDLAAVKLALQGQLATDFVQLRGQDQQLALLTQTIMAFAKADALTHNRFRGGIATGMDVGRAGALLGEARAQYAETEAARAITEHAIASLVGQPASTFSIPHRDGVMTLPAIPIGLPSTLLARRPDVAAAERRMAAANARIGVAKAAFFPQITLGGAGGFQSTALAGLVAAPNLFWAIGPGAILNLFDGGKRRAEVAAARADWNGAMADYRTHALGAFQDVEDALATLHHLGEAQAAQDQAVASATRTEQIALDRYIKGAATYLDVATAQESALHDRQAALALENRRLMAGVALIRALGGGWSAAI",
      "product": ""
     },
     {
      "start": 75394,
      "end": 76569,
      "strand": -1,
      "locus_tag": "ctg11_62",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_62</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_62</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 75,394 - 76,569,\n (total: 1176 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1029:RND family efflux transporter MFP subunit (Score: 182.1; E-value: 2.5e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_62 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF16576.8 (Barrel-sandwich domain of CusB or HlyD membrane-fusion): [85:304](score: 92.3, e-value: 2.7e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_62\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_62\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_62_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMHDAAPTPAVSADTPAPKGLKIAGLTAAMLAIGVVGLGALARSHDVAAAANWSNANAIPTVHLVPVKGGAASDALDLPATLEAWEAARLFPRVSGYVRSWSQDIGAHVGAGQALGVVDTPELDEQIGQARAALASAIAHEKLARSTAARWNDLLTSSSVSKQEVDEKNGDLAVKAAGVAEARAALSRLEAMKRYAVIRAPFAGVVTARNAEVGDLVGPGAAAQSPMFGVDDTHRIRVYVSVPQSLSATIKPGMTASLTVPAFPGRQFTATVAGLSSAVDPQSGAFRVQLYADNPDGALKPGGYAEARFDLPGQAGAAQVPSSAILFGAGGAQVATVDPHGRIMMHKVHIGQDNGPTVQILSGIKPGAQIVDNPPDSLAQGELVRVGASNHG\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_62\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_62\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCATGATGCAGCCCCGACCCCCGCTGTGTCGGCCGACACCCCCGCGCCCAAGGGCCTGAAGATCGCCGGGCTGACCGCCGCCATGCTCGCGATCGGCGTGGTCGGCCTCGGTGCCCTGGCCCGGTCCCATGATGTCGCGGCGGCGGCGAACTGGTCCAACGCCAATGCGATCCCGACCGTGCATCTCGTCCCCGTTAAGGGCGGCGCGGCAAGCGATGCGCTCGACCTGCCCGCCACGCTGGAGGCATGGGAAGCGGCACGGCTCTTCCCCCGCGTGTCCGGCTATGTGCGTAGCTGGTCGCAGGATATCGGCGCGCATGTCGGTGCCGGCCAGGCACTGGGCGTCGTCGACACGCCCGAACTGGACGAGCAGATCGGCCAGGCGCGCGCCGCGCTCGCCAGTGCCATTGCGCATGAAAAACTGGCGCGCAGTACGGCGGCGCGCTGGAACGACCTGCTCACCAGTTCCTCGGTGTCGAAACAGGAAGTCGACGAGAAGAATGGCGATCTCGCGGTCAAGGCGGCCGGGGTGGCGGAGGCGCGCGCGGCCCTGTCGCGGCTGGAGGCGATGAAGCGCTATGCCGTCATCCGCGCGCCCTTTGCGGGCGTGGTCACCGCGCGCAATGCCGAGGTCGGCGATCTGGTCGGCCCCGGTGCCGCGGCGCAATCGCCGATGTTTGGTGTCGACGATACCCATCGCATCCGCGTTTATGTCAGCGTGCCGCAATCGCTGTCCGCGACGATCAAGCCGGGTATGACCGCGTCCCTGACCGTGCCGGCCTTTCCCGGACGTCAGTTCACCGCGACGGTGGCGGGGCTGTCGAGCGCGGTCGATCCGCAGTCGGGCGCCTTCCGCGTCCAGCTCTATGCCGACAATCCCGACGGTGCGCTCAAGCCCGGCGGCTATGCCGAGGCGCGCTTCGATCTGCCCGGACAGGCGGGGGCGGCGCAGGTGCCGTCGAGTGCGATCCTGTTCGGCGCGGGCGGCGCGCAGGTGGCGACCGTCGATCCACATGGCCGCATCATGATGCACAAGGTCCATATCGGGCAGGACAATGGGCCAACCGTGCAGATCCTGTCGGGGATCAAGCCGGGCGCGCAGATCGTCGACAATCCGCCCGACTCGCTCGCGCAGGGCGAACTGGTGCGCGTGGGGGCGAGCAACCATGGCTAA",
      "translation": "MHDAAPTPAVSADTPAPKGLKIAGLTAAMLAIGVVGLGALARSHDVAAAANWSNANAIPTVHLVPVKGGAASDALDLPATLEAWEAARLFPRVSGYVRSWSQDIGAHVGAGQALGVVDTPELDEQIGQARAALASAIAHEKLARSTAARWNDLLTSSSVSKQEVDEKNGDLAVKAAGVAEARAALSRLEAMKRYAVIRAPFAGVVTARNAEVGDLVGPGAAAQSPMFGVDDTHRIRVYVSVPQSLSATIKPGMTASLTVPAFPGRQFTATVAGLSSAVDPQSGAFRVQLYADNPDGALKPGGYAEARFDLPGQAGAAQVPSSAILFGAGGAQVATVDPHGRIMMHKVHIGQDNGPTVQILSGIKPGAQIVDNPPDSLAQGELVRVGASNHG",
      "product": ""
     },
     {
      "start": 76562,
      "end": 79789,
      "strand": -1,
      "locus_tag": "ctg11_63",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_63</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_63</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 76,562 - 79,789,\n (total: 3228 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1049:AcrB/AcrD/AcrF family protein (Score: 893.8; E-value: 2.4e-270)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_63 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00873.22 (AcrB/AcrD/AcrF family): [4:1052](score: 685.9, e-value: 9e-206)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_63 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00873.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity<br>\n  \n   PF00873.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00873.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_63\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_63\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_63_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMLQLVKLALSKPYTFVVLAILIVLGGGIAAVETPTDIFPDIRIPVIAAVWTYRGLPPRDMSGRVIYYYERSLSATVGDIDHIESQSLSGVGIVKIFFRPGVDIRTATAQVTAASQTVLKQMPPGITPPLILNYNASTVPILQLALSGKGLSEQKIYDLGQNMIRPALASVQGSAIPSPYGGKERQVQIDLDPAALQAHRLSATDVANALAQQNQIIPSGTAKIGQYEYNLRLNNSPSVIDDLNDLPIKTVDGATVLMHDVAHVRDGSPPQRNEVRVDGARSVLMTVLKSGSASTIAIVDSVKALMPKLEATLPPGLNVTLLSDQSVFVKAAVSGVMREGVIAAALTSLMILLFLGSWRSTVIIAASIPLAILAAIAGLSVAGQTLNIMTLGGLALAVGILVDDATVTIENINWHLEQGKPVREAILDGAKQIVGPAFVSLLCICIAFLPMFFLPGVAGFLFAPMAMAVVFAMIASFILSRTLVPTMGNYLLRDHAGPHTAEVMVAHDAQAGRPQSRNPFRRFQHGFEQRFEAVRGYYTGLLAFALARRRPFVIGFMVVVLISFALVPMLGRNFFPAVDAGQISIHVRAPVGTRIEETAALFDHIENRIRAVVPADQLDTIVDNIGLPVSGINRAYSNTGGVGPQDGDILVTLKEGHAPTAGYVKALREQLPRDFPGSSFAFLPADIVSQILNFGSPAPIDVQVAGPDTKGGEAYARMLVDRLSRIPGLADVRLQQASNYPEYAVDVDRAQASRLGITENDVTRSLTVNLAGSSQVAPTFWLNPKNGVSYPIVVQTPQYRASTVEQIDNLPITGSAGGNVQTLQALGTLHREPSPALVSHYAVQPVFDVYATTQGRDLGAVAADIDKVLAATKGQLPKGATVAMRGQVETMNTAFTGLILGLAGAIILIYLLIVVNFQSWIDPLVIVSALPAALAGIVWMLFATHTPLSVPALTGAIMCMGVATANSVLVVSFARERLAACGNAIQAAMEAGATRFRPVLMTALSMMIGMAPMALGLGEGGEQNAPLGRAVIGGLLCATLATLVFVPVVFAIAHRRDKAAAPSTSNDLSLGEAIHA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_63\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_63\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTTCAGCTCGTCAAGCTCGCCCTCAGCAAACCTTATACCTTCGTCGTTCTCGCGATCCTGATCGTGCTGGGCGGCGGCATCGCGGCGGTCGAGACGCCGACCGACATTTTCCCCGACATCCGCATCCCGGTGATCGCGGCGGTGTGGACCTATCGCGGTCTGCCGCCACGCGACATGTCGGGCCGCGTCATCTATTATTACGAACGTTCGCTGTCGGCGACGGTCGGCGATATCGACCATATCGAAAGCCAGTCGCTGTCGGGCGTCGGCATCGTGAAGATCTTCTTCCGCCCCGGCGTCGACATCCGCACCGCCACCGCGCAGGTGACCGCCGCCTCGCAGACCGTGCTGAAGCAGATGCCGCCGGGCATCACCCCGCCGCTGATCCTGAACTACAACGCCTCGACCGTGCCGATCCTGCAACTCGCGCTCTCCGGCAAGGGGCTGTCCGAGCAGAAGATCTACGACCTGGGGCAGAACATGATCCGCCCGGCGCTGGCGTCGGTGCAGGGTTCGGCCATCCCGTCGCCCTATGGCGGCAAGGAGCGACAGGTCCAGATCGACCTCGATCCCGCCGCCCTTCAGGCGCATCGCCTGTCCGCGACCGATGTCGCCAATGCGCTGGCGCAGCAGAACCAGATCATCCCGTCGGGCACGGCCAAGATCGGCCAGTATGAATATAACCTCCGGCTCAACAACAGCCCGAGCGTCATCGACGATCTGAACGACCTGCCGATCAAGACGGTCGACGGAGCGACCGTGCTGATGCACGACGTGGCGCATGTCCGCGACGGTTCGCCGCCGCAGCGCAACGAGGTGCGGGTCGATGGCGCGCGATCGGTGCTGATGACCGTGCTGAAGAGCGGTTCGGCCTCGACCATCGCCATCGTCGACTCGGTCAAGGCGCTGATGCCCAAGCTGGAGGCGACCCTGCCGCCGGGGCTGAACGTCACGCTGCTGTCCGACCAGTCGGTCTTCGTGAAGGCGGCGGTGTCGGGGGTGATGCGCGAAGGCGTGATCGCCGCCGCGCTCACCAGCCTGATGATCCTGCTGTTCCTGGGTTCGTGGCGCTCGACCGTCATCATCGCCGCGTCGATCCCGCTCGCCATCCTGGCGGCGATCGCCGGGTTGTCGGTGGCGGGGCAGACGCTCAATATCATGACGCTGGGCGGCCTGGCCCTGGCGGTCGGCATCCTGGTCGACGATGCGACCGTCACCATCGAGAATATCAACTGGCATCTGGAACAGGGCAAGCCGGTGCGCGAGGCGATCCTGGACGGCGCCAAGCAGATCGTCGGCCCGGCCTTCGTCTCGTTGCTGTGCATCTGCATCGCCTTCCTGCCGATGTTCTTCCTGCCGGGCGTCGCGGGCTTCCTGTTCGCGCCGATGGCGATGGCGGTGGTCTTCGCGATGATCGCCTCGTTCATCCTGTCGCGCACGCTGGTGCCGACCATGGGCAATTACCTGCTGCGCGATCATGCCGGGCCGCACACCGCCGAGGTGATGGTGGCCCATGACGCGCAGGCGGGCCGCCCACAGAGCCGCAACCCGTTCCGCCGTTTCCAGCATGGCTTCGAGCAGCGGTTCGAGGCAGTGCGCGGCTATTATACCGGCCTCCTCGCCTTTGCGCTGGCCCGGCGGCGGCCGTTCGTCATCGGCTTCATGGTCGTGGTGCTGATCTCGTTCGCACTGGTGCCGATGCTGGGGCGGAATTTCTTCCCTGCGGTCGATGCCGGACAGATCAGCATCCATGTCCGCGCGCCGGTCGGCACCCGCATCGAGGAGACGGCGGCGCTGTTCGACCATATCGAAAACCGTATCCGCGCCGTGGTGCCCGCCGACCAGCTCGACACCATCGTCGACAATATCGGCCTGCCGGTCAGCGGCATCAACCGCGCCTATTCCAACACCGGCGGCGTCGGTCCGCAGGACGGCGACATCCTCGTCACGCTGAAGGAAGGCCATGCGCCCACCGCCGGCTATGTGAAGGCGTTGCGCGAGCAACTGCCGCGTGACTTCCCCGGCTCGTCCTTCGCCTTCCTGCCCGCCGATATCGTCAGCCAGATCCTGAACTTCGGCTCGCCCGCGCCGATCGACGTGCAGGTCGCCGGGCCCGATACCAAGGGCGGCGAGGCCTATGCGCGGATGCTGGTCGACAGGCTGTCGCGCATTCCCGGGCTGGCCGATGTGCGCCTGCAACAGGCGTCCAACTATCCCGAATATGCGGTCGATGTGGACCGCGCCCAGGCCAGCCGCCTCGGCATCACCGAGAATGACGTGACGCGCAGCCTGACCGTCAATCTGGCCGGCAGTTCGCAGGTCGCCCCGACCTTCTGGTTGAATCCGAAGAACGGCGTCTCCTATCCGATCGTCGTCCAGACCCCGCAATATCGCGCCAGCACCGTCGAGCAGATCGACAATCTGCCGATCACGGGCAGCGCGGGGGGCAATGTCCAGACGCTTCAGGCGCTGGGCACGCTCCACCGCGAACCCAGCCCCGCGCTCGTCTCGCATTATGCGGTGCAGCCGGTGTTCGACGTCTATGCGACGACGCAAGGTCGCGATCTGGGCGCGGTCGCGGCGGACATCGACAAGGTGCTGGCCGCCACCAAGGGCCAGTTGCCCAAGGGCGCGACCGTCGCGATGCGGGGACAGGTGGAGACGATGAACACCGCCTTCACCGGCCTGATCCTGGGTCTCGCGGGTGCGATCATCCTGATCTACCTGCTGATCGTCGTGAACTTCCAGAGCTGGATCGATCCGCTGGTGATCGTCTCGGCCCTGCCCGCCGCGCTTGCCGGGATCGTATGGATGCTGTTCGCGACGCATACGCCGCTCAGCGTGCCCGCGCTGACCGGGGCCATCATGTGCATGGGCGTGGCCACCGCCAACAGCGTGCTGGTGGTCAGCTTCGCCCGCGAAAGGCTGGCGGCGTGCGGCAACGCGATCCAGGCGGCGATGGAGGCGGGCGCCACCCGCTTCCGCCCGGTGCTGATGACCGCGCTGTCGATGATGATCGGCATGGCCCCCATGGCGCTGGGTCTGGGCGAGGGCGGCGAACAGAATGCGCCACTCGGCCGTGCGGTCATCGGCGGGCTGCTCTGCGCCACGCTCGCCACCTTGGTCTTCGTTCCCGTCGTCTTCGCCATCGCGCACCGCCGCGACAAGGCGGCCGCTCCTTCCACTTCCAACGACCTGTCCCTCGGAGAAGCCATCCATGCATGA",
      "translation": "MLQLVKLALSKPYTFVVLAILIVLGGGIAAVETPTDIFPDIRIPVIAAVWTYRGLPPRDMSGRVIYYYERSLSATVGDIDHIESQSLSGVGIVKIFFRPGVDIRTATAQVTAASQTVLKQMPPGITPPLILNYNASTVPILQLALSGKGLSEQKIYDLGQNMIRPALASVQGSAIPSPYGGKERQVQIDLDPAALQAHRLSATDVANALAQQNQIIPSGTAKIGQYEYNLRLNNSPSVIDDLNDLPIKTVDGATVLMHDVAHVRDGSPPQRNEVRVDGARSVLMTVLKSGSASTIAIVDSVKALMPKLEATLPPGLNVTLLSDQSVFVKAAVSGVMREGVIAAALTSLMILLFLGSWRSTVIIAASIPLAILAAIAGLSVAGQTLNIMTLGGLALAVGILVDDATVTIENINWHLEQGKPVREAILDGAKQIVGPAFVSLLCICIAFLPMFFLPGVAGFLFAPMAMAVVFAMIASFILSRTLVPTMGNYLLRDHAGPHTAEVMVAHDAQAGRPQSRNPFRRFQHGFEQRFEAVRGYYTGLLAFALARRRPFVIGFMVVVLISFALVPMLGRNFFPAVDAGQISIHVRAPVGTRIEETAALFDHIENRIRAVVPADQLDTIVDNIGLPVSGINRAYSNTGGVGPQDGDILVTLKEGHAPTAGYVKALREQLPRDFPGSSFAFLPADIVSQILNFGSPAPIDVQVAGPDTKGGEAYARMLVDRLSRIPGLADVRLQQASNYPEYAVDVDRAQASRLGITENDVTRSLTVNLAGSSQVAPTFWLNPKNGVSYPIVVQTPQYRASTVEQIDNLPITGSAGGNVQTLQALGTLHREPSPALVSHYAVQPVFDVYATTQGRDLGAVAADIDKVLAATKGQLPKGATVAMRGQVETMNTAFTGLILGLAGAIILIYLLIVVNFQSWIDPLVIVSALPAALAGIVWMLFATHTPLSVPALTGAIMCMGVATANSVLVVSFARERLAACGNAIQAAMEAGATRFRPVLMTALSMMIGMAPMALGLGEGGEQNAPLGRAVIGGLLCATLATLVFVPVVFAIAHRRDKAAAPSTSNDLSLGEAIHA",
      "product": ""
     },
     {
      "start": 79937,
      "end": 81310,
      "strand": -1,
      "locus_tag": "ctg11_64",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_64</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_64</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 79,937 - 81,310,\n (total: 1374 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1003:sensor histidine kinase (Score: 139; E-value: 4.4e-42)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_64 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02518.29 (Histidine kinase-, DNA gyrase B-, and HSP90-like ATPase): [346:450](score: 62.5, e-value: 5.2e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_64\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_64\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_64_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_64\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_64\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGGCTGAGCCGTTCCGCTGGCGTGACGTCGTCCGGATCAGCACCTTCCGCCTGTCGGCCATGCTGGGCGCGGTGTTCGTCACCGCCGTGATCGCCATGCTGGGCGTGGTCTATATCGCGACCGCGCGCGATCTGACCGTCCGCAGCGACCGCATCCTCCACGCCGCCGCCGGGCAATTGCTGCAGGTCCCGGCCGACGAACTGCCCGACCGCATCCGCGCCGAGTTGAAGCGTGATCGGTCCGGCTTCAACTATCTGGCGCTGATCGCGGCGGACGGCACCCTGATCGTCGGCAATGTCCGCCCTTTGCGTCCGCTAATCCCCGGCCATCCGGTCGATGTCGAGAGCGGATCACGCGGGCCCTTTCGCCTGGTCGCCCTGCGCACCCGTGAGAAGGAGACGCTGCTGGTCGGGCGTGACATCAGCCTGCTGCGCGATCTGCGGAACACGGTTCTGGAGACGCTGGTGGTCAGCGGGTTGATGACCCTGATCTGCATCGGGACTGCGGCGATCGGATTCAGCCGGGCGCCGCTGCACCGCGTCCGGGCGCTCCAGCGGGCCAGCCGGGAGATTGCGGCGGGGGATTTTTCGGTGCGGATGCCGATCGCGGGGCGGCATGACGAACTCGATCAGTTCGCCGCGACCGTGAACGTCACCGTCGAGGAGGTCGGCCGCGTCGTTGCGCAGGTGAAGGGCGTGACCGACGCCATCGCGCACGATTTGCGCACACCGCTGACCCGCGTCCGCGCCACGTTGAATGCGGTCGGCCACCGGCCCGACGATCCGGCGGGCGTCGTCGCCGGGATCGCGCAGGCGACCGCCGACCTGGACCTGGTGCTCGAGCGTTTCGCCGCGCTGCTCCGGATATCGGAATTGGAGGCGGGGCGGCGGCGGGCCGGGTTCCGCCGCGTCGATCTGGGCGCTCTCGTCGCGCAGGTGGCCGAGCTGTACGAGCCTCTGGCCGAAGACCGCGCCATCACCCTGTCGGTCGCCGCCAGGCCCCTGTCGGTCGCCGCCAGGCCCCTGTCGGTCGAGGGCGACGACAAGCTGTTGTTCGAGGCGCTGAGCAATCTGGTCGACAATGCGATCAAGTTCGGGCGGCCCGGTGGGCAAGTGCATATCGCGCTGTTCGACGATGAGGCGGCCCGCGCGATCGAGGTCCGCGACGACGGCCCCGGCATCCCGTCCGAAGAGCGCGACGCGGTGCTCCATCGTTTCCATCGGGGCACACACGCCGCCGGTGTGCCGGGCAGCGGTTTGGGCTTGAGCGTCGTGGCGGCGATCCTGCACCTCCACGGTTTTCGCCTGCGCCTGTCCGATGCCGACCCGGGGCTTTGCGTGCGGATCGAGGTCGGGCCGGCGGTGGCCTGA",
      "translation": "MAAEPFRWRDVVRISTFRLSAMLGAVFVTAVIAMLGVVYIATARDLTVRSDRILHAAAGQLLQVPADELPDRIRAELKRDRSGFNYLALIAADGTLIVGNVRPLRPLIPGHPVDVESGSRGPFRLVALRTREKETLLVGRDISLLRDLRNTVLETLVVSGLMTLICIGTAAIGFSRAPLHRVRALQRASREIAAGDFSVRMPIAGRHDELDQFAATVNVTVEEVGRVVAQVKGVTDAIAHDLRTPLTRVRATLNAVGHRPDDPAGVVAGIAQATADLDLVLERFAALLRISELEAGRRRAGFRRVDLGALVAQVAELYEPLAEDRAITLSVAARPLSVAARPLSVEGDDKLLFEALSNLVDNAIKFGRPGGQVHIALFDDEAARAIEVRDDGPGIPSEERDAVLHRFHRGTHAAGVPGSGLGLSVVAAILHLHGFRLRLSDADPGLCVRIEVGPAVA",
      "product": ""
     },
     {
      "start": 81300,
      "end": 82001,
      "strand": -1,
      "locus_tag": "ctg11_65",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_65</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_65</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 81,300 - 82,001,\n (total: 702 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1008:response regulator (Score: 194.5; E-value: 3.1e-59)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_65 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00072.27 (Response regulator receiver domain): [12:122](score: 84.2, e-value: 7.4e-24)<br>\n \n  PF00486.31 (Transcriptional regulatory protein, C terminal): [154:230](score: 80.3, e-value: 9.3e-23)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_65 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00072.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_65\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_65\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_65_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_65\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_65\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGGGCGGGCGGCTATGCCGATGGCATGGCGGCTATCCTGGTCATCGAAGACGACGGCGCGACCGCTGCGGCGATCATCGCCGAGCTGAAGCAGCATGGGCATGAGGTGACACATGCTAGCGATGGCGATGCCGGCCTGGAGCTCGCGACCCGCGAGGCGTTCGATGCGATCACGCTAGACCGGATGTTGCCGAGGCTGGACGGCCTGTCGCTCGTGGCCCGGCTGCGCGAACGGCATATCACCATTCCCGTGCTGATGCTGAGCGCGTTGAGCGATGTCGATGAGCGGATTGCGGGGCTGCGCGCAGGGGGCGACGATTATCTGACCAAGCCCTTCGACTTTGCCGAAATGGCGATGCGGGTCGAGGTGCTGCTGCGCCGCCGCGAGCAGGCCGAGGCCGTGGTGCTGCGCGGCGGAGGCATCGAGTGCGACCTCGTCCGCCGGACCGTGAAGGTCGATGGCGAGCCGGTGCGGCTGCTGCATATGGAATTCCGCCTGCTCGAATTCCTGATGCGCAACCAGGGCGAGGTGATGACCCGGCGGATCATCTTCGAACGGGTCTGGGGCTATTATTTCGATCCCGGCGCCAATCTGATCAGCGTGCATATCGCGCGGCTGCGCAAGAAGATCGACCGGCCGGATCGTTCCTCGCCCATCCAGACGGTGAAGGGCGAGGGATATCTGTTCGATGGCGGCTGA",
      "translation": "MGAGGYADGMAAILVIEDDGATAAAIIAELKQHGHEVTHASDGDAGLELATREAFDAITLDRMLPRLDGLSLVARLRERHITIPVLMLSALSDVDERIAGLRAGGDDYLTKPFDFAEMAMRVEVLLRRREQAEAVVLRGGGIECDLVRRTVKVDGEPVRLLHMEFRLLEFLMRNQGEVMTRRIIFERVWGYYFDPGANLISVHIARLRKKIDRPDRSSPIQTVKGEGYLFDGG",
      "product": ""
     },
     {
      "start": 82107,
      "end": 82364,
      "strand": 1,
      "locus_tag": "ctg11_66",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_66</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_66</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 82,107 - 82,364,\n (total: 258 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_66\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_66\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_66\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_66\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTCCACACCCGCTTATGGATCATCATCCTCTCGACCGCCCTCCTCGCCACCCCCGCTGTCGCCGCCGGGGACCAGGCCGATACAGGGGACGACTGCTTCGCCGTCGCCGCGCCGATGGCCGACGCGACGCCCTGCTTTGTGCCCGGGCGTCACAAGAAACATCATAAACCCCGACCCAAGCACGCAAGCCATGCCGCCGGGGAACGGGTTTTGCAAACCGGGGACTCGACCAAGAGAACGACGCAAGGATCATAG",
      "translation": "MLHTRLWIIILSTALLATPAVAAGDQADTGDDCFAVAAPMADATPCFVPGRHKKHHKPRPKHASHAAGERVLQTGDSTKRTTQGS",
      "product": ""
     },
     {
      "start": 83004,
      "end": 83417,
      "strand": -1,
      "locus_tag": "ctg11_67",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_67</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_67</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 83,004 - 83,417,\n (total: 414 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_67\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_67\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_67\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_67\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGTTGGTGCCGTTTGTGATCGGCGGCGCGGTATGGGCGCACGGCGCGATGTTCCCGGCCAGGCACAGGATCGTGATCGAGCCCGTGAGGGGGCTATGCGAATATGTGCTTTTCCCACACTTCAACGCGGGACTCCGCGAGAGCTTCGTGGCCGAGGTGAGCCACAGGCTTCCTGCCCACTATTCCGTGGCCGCCAATGGTGAAAAAGCCGATCTCCATGCGAGTGTCAGTGTCCGGCAGACGTCGCAACGAACGACCGTGGTTGTGACGCTGGCCGAGGATGGTTCCGATCGCGTGTTGTGGTCCAGTCAGTTTTCCGCTCCAACCGACATGCAGGATTACGTGCCGCTTCAAGAGAAGCTGGCGAGAAGCATGGCGACCGGTCTTGCGCGGACAGTTGCTCGGATGAGTTGA",
      "translation": "MLVPFVIGGAVWAHGAMFPARHRIVIEPVRGLCEYVLFPHFNAGLRESFVAEVSHRLPAHYSVAANGEKADLHASVSVRQTSQRTTVVVTLAEDGSDRVLWSSQFSAPTDMQDYVPLQEKLARSMATGLARTVARMS",
      "product": ""
     },
     {
      "start": 83857,
      "end": 85404,
      "strand": 1,
      "locus_tag": "ctg11_68",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_68</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_68</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 83,857 - 85,404,\n (total: 1548 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1053:beta-lactamase (Score: 140.6; E-value: 1e-42)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_68 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00144.27 (Beta-lactamase): [64:388](score: 159.2, e-value: 1.6e-46)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_68\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_68\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_68\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_68\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGGCCTGAGCGCCGGGGGAGGATAACCGATCCGAACACCGTCTGCATCCTTCCGAAAGGCCTATCCTTGCGACAGACATTCCATCTTCCGGATACCGACCGGCGACGTGTTCTTGCCCTTGGCCTGTCCGGCCTGATGACATCGATAGGGTGGGCGACGACCGTCCATGCGACCGAGCCTTCTGCGGCGATCGACGACCTGCTCGACCGCTCCGCAGATGCTTATGGCACGGTGGGCCACTCCGTCGCCGTTCTACGACGCGGCAGGCTCGTCTATTCGCGTCATGCCGGGCTGTCCGATCGCGAGACGGGCGCTCCTATCACCGACGCCTCCGTCTATCCGCTCTTTTCGATCTCCAAGCTGTTCGTGATCGTGGAGTTGCTCAAGGCGCGTCAGGCCGGACTGATCAACCTTGATGCATCACTAGCCACGATACGCGCTGGTCTTCCATCAGCATGGGCCGGGATCACCTTGTTACAGGCCTTGGCCCATGTTTCGGGCCTACCCGACTATATTCCCGATCATGTCGAGCCGACCGACGAGCAGGCCTTCGCCAGCATCGCGACGCTTCCGCTCCGTTTCGCACCAGGCTCGCGTAACGAGTATAATCAGACAAACTTCCTGTTCGCCAAAAAAGCGCTAGAACAGGCGACGCGAACGCCGCTGACGAACTTGACGGGGCGTCAGTTCGCTCGCGCCGGAATGACGCGGACCAGCTACCATGTGGAGGGGCAACCCCGGTTGCCGGACCTGGTGTCGAGCTACCGCCCGGCTCCCAAGCGCGATCGACCGCCGCTGCCCTATGTCTCTCCCTCGTGGCCGGCCTATACCTTCGGCTCGCGGGGCGTCTTCACGACGCTGCCCGATCTGGTCCGATGGTCACAGGCGCTGCTTTATGGTGCGCTCGTGCCGCTCGCGGCGCTTCGGGAATCATGGTCGCCCTTTGCCATGCCGTCCCGGAATGCGGCGTGGCACACCCATGGGTGGGAATATTATCGGCACGACGACGTGACGATCGTCGGCCATGGCGGCGAAGCGCGGCTCGTCTGGCGGCATTTCTTCCGTCAGGCCGACCCGGACGACAGCGCGACGGTGATCTATCTCGACAATGGCGGCCGTACGACGTTCGACCGCCATCGGCTTGCCACGCTGGTCGCCGATCGCGTCATGCCGGGGGTCGCCCGCAAGGACGAAGAGCAGGAGGAGGCACTTTACCGGGGCATGGCGTCAGGCCGGTGGGAGCAGGCCAGCGCGACCGTCGCGGCGGCGATATCCACGGACCGGCTGGAAGCGATCGTCAACCGTGTCGGCTACGACGCCATGAACATCCTCGATGCCGAAGCCGCCCTGCCGGTGTTCCGATGGAACGCCGAGCGCTTTCCCCGCTCTGCCAATGCCCATGACAGTTTGGGCGAAGCCTATCGGGCCGCTGGCCAATGCGACCGGGCCAAGGAGAGCTATGCCCGCGCATTGGCGCTCGATCCGGCAAACGATCGCCTCAAGGCGACGATCGACGAACTGAACCAGGCGGCGTGCTGCCGATAA",
      "translation": "MRPERRGRITDPNTVCILPKGLSLRQTFHLPDTDRRRVLALGLSGLMTSIGWATTVHATEPSAAIDDLLDRSADAYGTVGHSVAVLRRGRLVYSRHAGLSDRETGAPITDASVYPLFSISKLFVIVELLKARQAGLINLDASLATIRAGLPSAWAGITLLQALAHVSGLPDYIPDHVEPTDEQAFASIATLPLRFAPGSRNEYNQTNFLFAKKALEQATRTPLTNLTGRQFARAGMTRTSYHVEGQPRLPDLVSSYRPAPKRDRPPLPYVSPSWPAYTFGSRGVFTTLPDLVRWSQALLYGALVPLAALRESWSPFAMPSRNAAWHTHGWEYYRHDDVTIVGHGGEARLVWRHFFRQADPDDSATVIYLDNGGRTTFDRHRLATLVADRVMPGVARKDEEQEEALYRGMASGRWEQASATVAAAISTDRLEAIVNRVGYDAMNILDAEAALPVFRWNAERFPRSANAHDSLGEAYRAAGQCDRAKESYARALALDPANDRLKATIDELNQAACCR",
      "product": ""
     },
     {
      "start": 85620,
      "end": 87422,
      "strand": -1,
      "locus_tag": "ctg11_69",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_69</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_69</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 85,620 - 87,422,\n (total: 1803 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_69 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03600.19 (Citrate transporter): [23:546](score: 158.4, e-value: 2.4e-46)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_69 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03600.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF03600.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_69\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_69\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_69_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_69\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_69\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGAAATCCTCGCCGGCATCGAGGCCCATCGTGCGGCGCTGGGGCTGATATTCATAACTGGTTTGTTCGTTGCGTTCGCGCTCGAACGCTTTCCCCCCGTCACGATCGCGGTCGCCGGTGCGGCGATCATGATGGCGCTGGGCTGGCTCACGCCACCGCTCGTCACCGCCGCGTTCGCGAATCCGGCGCCGATTACGATCGCGGCCTTCTTCATCCTGTCAGGCGCGCTGGTGCGGACCGGTACGATAGAGGCGCTCGCCAGTCTGATCGTTCGGCGGGCGGGAAATGCGCCACGGCGCACGGTCGCCGAAATGCTGACCGGCGCGGCTATCGCACCCGCGTTCATCAATAACACGCCGGTCGTCATGGTCTTGATCCCGCTCGTACGCAGACTGGCGCGGACGGTCGGCATACCGGCGACCCGCCTGCTGATCCCACTGTCCTATCTTTCGATTTTGGGCGGTACGCTGACATTGGTCGGCACCTCGACAAACCTGCTGGTCGACGGCGTGGCACGCGCGAACGGGCAGCCGGGTTTCGGCATCTTCGATATCACGGCCATCGGTCTGGTGACGATGGCGGCGGGGGCGGTGGCCATGCTGGTTCTTGGTCCCCGTCTGCTGCCGTCTCGGCCCGACAATACCATAGCCGATCGGCACCAGCTGTCCTATCTCACCGAGATCGCGCTGATGCCTGACGTATCAGCGAAGAATATATGCGTGGCAGATATCGCATTCCTGCGCCGCGATGCGATCAGGCTGATCGCGGTCCGCCGCGGGTCGCGGATTGAGCGTAACCCCCCGGCGGATATGATTCTTCAAACGGCCGATCGCTTGGTCGTCAGCGCAACCGCTGACGAACTCGATGATCTGGCGCGCAGCGAGGAGTATCTGGTTGGCCTTCAAAATGTGGGGCGCCCCATTCGCCTGTCCGACAGCGCACGGTCGGACGATGTAAAGCTCATTGGCTTGACGATCGGCCCCGCGCATCCGGCGCTGGGTCGCGAGCTACGCGACATTCCTTTCCTGTCGAATCTTCCGGCACGCATTCTGGGGATTGGCCGGGCGCGACACCTTCCAGGCCCCGATCTGGCAAGCGTGCGTTTGCGCGCGGCGGACAATTTACTGGTGGCGGCAGATGGCACGGCCCTTGCCGAATTGCGCGCCAACACGAACCTGATTGCTGAAGACACCAGCCATATTCGCCGCTTCCGCCGCGCGCGTGCCCCGATCGCGATCGGGGTACTGGCTGGCGTGATTGCGCTGGCCGCCTTGGGGGTGGCGTCGGCCACGTCGCTCGCCATCGTCGGAGTCGGCATGGTTCTGATCACGCGGTGCGTGGATGCGGAAGAAGCCTGGCGATCGATCGATGGCAGCGTCCTGGTGTTGATCTTCGCCATGCTGGGCATCGGCGGTGCCTTGGAGAATATGGGGACCATCGACCTGATCGTCGGCGCGATATCGCCATGGTTGGCCACGTTGTCACCACTTGGGGTGCTTCTGATCCTGTATTTCCTGACCTCGGCTTTGACGGAAACGGTGACCAACAGTGCGGTAGCCGTCATCATGACCCCGGTGGCCATCGGTTTGGCCCAATCCACCAGCCAAGACCCGCGCGCGCTTATCATCGCGGTGATGTTCGCGGCCTCCGCGAGCTTCGCGACGCCTGTCGGGTATCAGACCAACACGATGGTCTACGCTGCGGCCGATTACCGTTTCTCCGATTTTGTCCGGATCGGCCTGCCTATGAATGTCATCGTTGGCTTGGCCACTTGCTTCGCTATCAATTGGCTGGCGTAG",
      "translation": "MSEILAGIEAHRAALGLIFITGLFVAFALERFPPVTIAVAGAAIMMALGWLTPPLVTAAFANPAPITIAAFFILSGALVRTGTIEALASLIVRRAGNAPRRTVAEMLTGAAIAPAFINNTPVVMVLIPLVRRLARTVGIPATRLLIPLSYLSILGGTLTLVGTSTNLLVDGVARANGQPGFGIFDITAIGLVTMAAGAVAMLVLGPRLLPSRPDNTIADRHQLSYLTEIALMPDVSAKNICVADIAFLRRDAIRLIAVRRGSRIERNPPADMILQTADRLVVSATADELDDLARSEEYLVGLQNVGRPIRLSDSARSDDVKLIGLTIGPAHPALGRELRDIPFLSNLPARILGIGRARHLPGPDLASVRLRAADNLLVAADGTALAELRANTNLIAEDTSHIRRFRRARAPIAIGVLAGVIALAALGVASATSLAIVGVGMVLITRCVDAEEAWRSIDGSVLVLIFAMLGIGGALENMGTIDLIVGAISPWLATLSPLGVLLILYFLTSALTETVTNSAVAVIMTPVAIGLAQSTSQDPRALIIAVMFAASASFATPVGYQTNTMVYAAADYRFSDFVRIGLPMNVIVGLATCFAINWLA",
      "product": ""
     },
     {
      "start": 87419,
      "end": 88462,
      "strand": -1,
      "locus_tag": "ctg11_70",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_70</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_70</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 87,419 - 88,462,\n (total: 1044 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_70 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07885.19 (Ion channel): [34:112](score: 51.7, e-value: 7e-14)<br>\n \n  PF02254.21 (TrkA-N domain): [132:251](score: 82.0, e-value: 4.1e-23)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_70 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02254.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006813' target='_blank'>GO:0006813</a>: potassium ion transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_70\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_70\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_70\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_70\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGACATCGCTGGCCGGAAACCCGATTATCACCTGTACCGCCGTAGCCGGACGCCGATCTGGCTGGCCCTGTCCTGGCGGGCCTTGCTGGCGCTGGGCCTGATCGGTATCGCGCTGGCCGTCCACTGGTTCGACCGCGATGGCCTGCGCCAGTCATCGGGCGAGCCGGTCACCTTCACCGACATCCTCTACTTCACGATGATCACGGTCACGACCGTCGGCTATGGCGACATCGTGCCCGTCACTCAGCAGTCGCGGCTGTTCGACACCTTCGTCGTCACCCCGATCCGGCTGTTCGTGTGGCTCATTTTCCTGGGAACCGCCTATGACTTTCTTCTCAAGCGCGTGTGGGAGCGATGGCGCATGTCGGTGATCCAGCGGCAGCTGCGCGACCATGTCGTCATCGCGGGCTTCGGCAATAGCGGATCGGAAGCCGCCAGCGAATTGATCCGCCGCGGCGCGCATCCCGACATGATCGTCGTGATCGATGAAAGCCCTGCTGCACTCCGTAACGCCGAAGCGCTGGACGTCGCCGTCATGGAGGGCAACGCCACGCGCGATGCCGCCTTGCGGGCGGTGCGTGTGGGTACGGCCAGGGCGTTGATCGTGGCCGCTGGGCGCGACGATACCTCCATCCTGATCGTCCTGACCGCCCGCCGCATCGCGCCGACGCTGCCGATCAGCGTCATCATCCGCTCGCTCGACAATGAAGCGATCGCGCGGCAGGCGGGGGCCAATACCGTCATCAATCCGGCGAGCTTCGCCGGCCTGCTTCTCGCCGGGTCCACGCACGGCACACATTTGGCCGACTATATGGCGGATCTGGCGGCAACGGATGGCCGGGTCGCGCTGCGTGAACGGCGCGTCGCGGCGGACGAAATCGGTGTGCCGCTGCGGGCTATCACCACCGGCCTTGGCCATCGCATTTATCGTAAGGGCTCAATGATCGGTTTTTGGGAAGCGGCGGCAAACCGCCTGGAAGCGGGGGACGTCATTCTGGAGGTCGTACCAGCCCTCGGCCAGGATACAGACGGGCCGGCATGA",
      "translation": "MDIAGRKPDYHLYRRSRTPIWLALSWRALLALGLIGIALAVHWFDRDGLRQSSGEPVTFTDILYFTMITVTTVGYGDIVPVTQQSRLFDTFVVTPIRLFVWLIFLGTAYDFLLKRVWERWRMSVIQRQLRDHVVIAGFGNSGSEAASELIRRGAHPDMIVVIDESPAALRNAEALDVAVMEGNATRDAALRAVRVGTARALIVAAGRDDTSILIVLTARRIAPTLPISVIIRSLDNEAIARQAGANTVINPASFAGLLLAGSTHGTHLADYMADLAATDGRVALRERRVAADEIGVPLRAITTGLGHRIYRKGSMIGFWEAAANRLEAGDVILEVVPALGQDTDGPA",
      "product": ""
     },
     {
      "start": 88472,
      "end": 88885,
      "strand": -1,
      "locus_tag": "ctg11_71",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_71</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_71</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 88,472 - 88,885,\n (total: 414 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_71 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03334.17 (Na+/H+ antiporter subunit): [11:91](score: 82.3, e-value: 2.4e-23)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_71 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03334.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015297' target='_blank'>GO:0015297</a>: antiporter activity<br>\n  \n   PF03334.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0098662' target='_blank'>GO:0098662</a>: inorganic cation transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_71\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_71\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_71\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_71\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGTCATCGCCGACATCGCCATCACCGTCCTGCTGATCCTCGGGGGCGGCTTCGCGCTCATCGGCAGCTGGGGGCTGGTGCGCCTGCCATCGACCATGGAGCGGCTTCACGGACCGACCAAGGCGACGACCCTGGGGCTGGGGGCGCTGCTCCTCGCCTCCGTCGTCTATTTTCAGACGCGGCTCGGCATCTGGACCGCGCATGAGCTGCTGATCTCGCTGTTCTTGTTCATCACCGCGCCGATCTCGGCCAATATGATCGCCAAGGTCCATCTCCACCGCGCGCGCCTCGGCAAAGCCCATGAGGATGACGGCATCGCCGGTCCGCCGCCCCGCCCCGGCGGGGACGGCGATTGGGCCACGTTCGAGGCGCCCAAGCGCAAGACGCCCGCCTCGACGGCCAGCGACTGA",
      "translation": "MSVIADIAITVLLILGGGFALIGSWGLVRLPSTMERLHGPTKATTLGLGALLLASVVYFQTRLGIWTAHELLISLFLFITAPISANMIAKVHLHRARLGKAHEDDGIAGPPPRPGGDGDWATFEAPKRKTPASTASD",
      "product": ""
     },
     {
      "start": 88882,
      "end": 89151,
      "strand": -1,
      "locus_tag": "ctg11_72",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_72</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_72</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 88,882 - 89,151,\n (total: 270 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_72 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04066.16 (Multiple resistance and pH regulation protein F (MrpF / PhaF)): [31:82](score: 72.9, e-value: 2.2e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_72 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04066.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015075' target='_blank'>GO:0015075</a>: monoatomic ion transmembrane transporter activity<br>\n  \n   PF04066.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0034220' target='_blank'>GO:0034220</a>: monoatomic ion transmembrane transport<br>\n  \n   PF04066.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_72\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_72\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_72\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_72\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCGAGGTCGCCCTTCACATCGCGTCGGGCTGCATCGCGCTCGCCCTGGCGCTGAACGTATGGCGGTTGTTGCGCGGGCCGACGCTGGGCGACCGCATCGTCGCGCTCGACACCATGGTCATCAACGCCATCGCGCTGATCATCCTGATCGGCATGATCGGCGGCAACGACACCTATTTCGAGGCCGCGCTGCTGCTGGCGATGGTCGGGTTCGTGAGCACCATCGCCTATTGCAAGTTCATCCTGCGCGGGGACATCGTCGAATGA",
      "translation": "MIEVALHIASGCIALALALNVWRLLRGPTLGDRIVALDTMVINAIALIILIGMIGGNDTYFEAALLLAMVGFVSTIAYCKFILRGDIVE",
      "product": ""
     },
     {
      "start": 89148,
      "end": 89636,
      "strand": -1,
      "locus_tag": "ctg11_73",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_73</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_73</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 89,148 - 89,636,\n (total: 489 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_73 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01899.19 (Na+/H+ ion antiporter subunit): [11:160](score: 134.8, e-value: 2e-39)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_73 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01899.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008324' target='_blank'>GO:0008324</a>: monoatomic cation transmembrane transporter activity<br>\n  \n   PF01899.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006812' target='_blank'>GO:0006812</a>: monoatomic cation transport<br>\n  \n   PF01899.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_73\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_73\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_73\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_73\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGCGCGTCCTGCCCCATCCGGCGCTGTCGGCGATGCTGCTGATCGTCTGGCTGTTGATGGCGAACCACATCACGGTCGGCGGCATCGTGCTGGGCGGCATCTTCGCTCTGATCCTGCCCAAATTCACCCAGCCCTTCTGGCCCGATCGCCCGCGCATGCGCTTCCGCCGCGCATTTCTAGGATATCTGGCGATCGTGCTGGTCGACATCGTCGTCGCCAATTTCGAGGTCGCCAGGCTGATCCTGTTCCGGCGCAACCGCGACCTGCGCGCGCGCTGGCTGGTCGTGCCGATCGCGCTGACGACCCCGGAAGCGATCACCATGCTGGCGGGCACGATCAGCCTGACGCCGGGCACCGTCTCGTCCGACGTCTCGGCGGATGGCCGTTTTCTCCTCGTCCACGCGCTCGACGTCGCGGACGAGGCGGCGGAGATCGCCCGCATCAAGTCGCGCTACGAAGCCCGCCTGCAACGGATTTTCGCATGA",
      "translation": "MKRVLPHPALSAMLLIVWLLMANHITVGGIVLGGIFALILPKFTQPFWPDRPRMRFRRAFLGYLAIVLVDIVVANFEVARLILFRRNRDLRARWLVVPIALTTPEAITMLAGTISLTPGTVSSDVSADGRFLLVHALDVADEAAEIARIKSRYEARLQRIFA",
      "product": ""
     },
     {
      "start": 89633,
      "end": 91156,
      "strand": -1,
      "locus_tag": "ctg11_74",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_74</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_74</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 89,633 - 91,156,\n (total: 1524 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_74 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00361.23 (Proton-conducting membrane transporter): [129:427](score: 120.2, e-value: 1.1e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_74\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_74\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_74\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_74\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGCTTCCCGACCACCTCGTCATCGCGCCGATCATCATACCCGCGGTGATCGCGCCCGTGACGATGTTGCTGATGCGACGCCATCGCCCCGTGGCGCTGGGGCTGTCGCTGGGTGGCGGCATCGCGATGCTGGCGGCGGCCGTCGCGCTGTTCGTCCGTGCGCAGGACGATGCGATCCGCAGCTATGCGCTGGGCGCGTGGCGCGCGCCGTTCGGCATCGTCCTGATGCTCGACCGGCTGGCGGCGACGATGCTGGTGCTGGCGGCGGTGCTGGCCGTCACCGTGCTGCTCCACGCCGTCATCACCGGGGCGGACAAGCGCGGCTGGCATTTCCATCCGCTGTTCCATTTCCAGCTCATGGGCCTGAACGGCGCGTTCCTGACCGGCGACCTGTTCAACCTGTTCGTGTTCTTTGAGGTGCTGCTGATCGCCTCCTACGGCCTGATGCTGCACGGGCAGGGCGCGCTGCGACTGAAGGCGGGCGTGGCCTATGTCGTGGTCAATATCGTCGGATCGGCGCTGTTCCTGATGTCGCTCGGGCTGCTCTATGGGCTGACGGGTACGCTCAACATGGCGGACCTGGCCGTCAGGGTCGCGGCGCTGGCGCGGGAGGATCAAGGGCTGCTGCGCATCGCCGGGCTGCTGCTGATGGCGGTGTTCGCGCTGAAGGCGGCGGTGGTGCCGATCCATCTCTGGCTGCCGCGCACCTACGGCGCCACCATGCCCGTCGTCGCCGCCTTGTTCGCGATCATGACCAAGGTCGGCGTCTATGCGATGATCCGCACCGTGCCGCTGATCTTCGGTGCGCAGGCGGGGGCCGCGGCCTGGGTACCGGCACCCTATTTGCTGCCCGCCGCGATCCTGGGGGCGGTGATCGGCTTTGTCGGCGTGCTGACCACGCGCGGGATGCGCGAACAGGCGGCCTTTGCGGTGCTGGCGTCCACCGGCACGCTGCTGATGGCGGTGTCGCTATGGCGCGAGGCGACGCTGGCGGCCGCGCTCTATTACATGGTGCAGGCGACCTTGGCGGGCGCGGCGCTGTTCCTGGTCGCCGATGTGACGATGCGGCGTCGCGGCCCCTATGCCGACAGCATCGTACCCAGCCCGCGCTTCGCCGGGCAGGATGTCGCCGGGCTGCTCTATCTCACCGCCGCGATCGCCGCTGTCGGGTTGCCGCCGCTGGCGGGCTTCGTCGGCAAGCTGCTGATCCTGGACGCCAGCTTCGCGCTGCCGGGGTGGCAGGCGATCTGGGCGACGATCCTCGTCACCACACTGATCGGCGTGGTCGGCTTTTCGCGCAGCGGCTCCTCGCTGTTCTGGAAGGCCGCGCCTCCGGAGACCGTCGCGATCACCGGCACGGCCCGGTCGCGCGCCGAGTTCGTCGCGCCGATCATGCTCCTGGCGATGCTCGCCCTGCTGACCATCGGCGCCGGTTGGGTCACGGAGCAGACCCGCGCCACCGCCGCGCAGGTCATGGACCCCGGCCGCTATGTCAGCGCGATCCTGGGGGGCGGGCGATGA",
      "translation": "MTLPDHLVIAPIIIPAVIAPVTMLLMRRHRPVALGLSLGGGIAMLAAAVALFVRAQDDAIRSYALGAWRAPFGIVLMLDRLAATMLVLAAVLAVTVLLHAVITGADKRGWHFHPLFHFQLMGLNGAFLTGDLFNLFVFFEVLLIASYGLMLHGQGALRLKAGVAYVVVNIVGSALFLMSLGLLYGLTGTLNMADLAVRVAALAREDQGLLRIAGLLLMAVFALKAAVVPIHLWLPRTYGATMPVVAALFAIMTKVGVYAMIRTVPLIFGAQAGAAAWVPAPYLLPAAILGAVIGFVGVLTTRGMREQAAFAVLASTGTLLMAVSLWREATLAAALYYMVQATLAGAALFLVADVTMRRRGPYADSIVPSPRFAGQDVAGLLYLTAAIAAVGLPPLAGFVGKLLILDASFALPGWQAIWATILVTTLIGVVGFSRSGSSLFWKAAPPETVAITGTARSRAEFVAPIMLLAMLALLTIGAGWVTEQTRATAAQVMDPGRYVSAILGGGR",
      "product": ""
     },
     {
      "start": 91153,
      "end": 91506,
      "strand": -1,
      "locus_tag": "ctg11_75",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_75</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_75</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 91,153 - 91,506,\n (total: 354 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_75 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00420.27 (NADH-ubiquinone/plastoquinone oxidoreductase chain 4L): [9:106](score: 71.5, e-value: 4e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_75\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_75\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_75\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_75\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCCTGGAATTCCTGGTCGCCTCCGCTATCGCCATGCTGGTTGCCGGCGGCATCTATCTGGCCCTGCGCGGACGGACCTTTCAGGTTGTGCTGGGGCTCACCCTCTTGTCCTATGCGGTCAATCTGTTCCTGTTCGCGATCGGCCGGTTGGTGGTCGATCGCCCGCCGCTTTACGCCAAGGGCGTGGCGCTGCATGCCGATCCGCTACCCCAGGCGCTGGTGCTGACCGCGATCGTCATCACCTTCGGCATGACCGCGATGACCGTGATCCTGAGCTTGCGCAGCTTCCTCGAAACCGGATCGGATCAGGTCGATGGCCGCGTTGCGCCGGACGAGGAGGACGCGGCATGA",
      "translation": "MSLEFLVASAIAMLVAGGIYLALRGRTFQVVLGLTLLSYAVNLFLFAIGRLVVDRPPLYAKGVALHADPLPQALVLTAIVITFGMTAMTVILSLRSFLETGSDQVDGRVAPDEEDAA",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 71425,
      "end": 73954,
      "tool": "rule-based-clusters",
      "neighbouring_start": 51425,
      "neighbouring_end": 93954,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [
      {
       "start": 63418,
       "end": 63420,
       "strand": -1,
       "containedBy": [
        "ctg11_53"
       ]
      },
      {
       "start": 66442,
       "end": 66444,
       "strand": -1,
       "containedBy": [
        "ctg11_55"
       ]
      },
      {
       "start": 66301,
       "end": 66303,
       "strand": -1,
       "containedBy": [
        "ctg11_55"
       ]
      },
      {
       "start": 82122,
       "end": 82124,
       "strand": 1,
       "containedBy": [
        "ctg11_66"
       ]
      },
      {
       "start": 84334,
       "end": 84336,
       "strand": 1,
       "containedBy": [
        "ctg11_68"
       ]
      },
      {
       "start": 86295,
       "end": 86297,
       "strand": -1,
       "containedBy": [
        "ctg11_69"
       ]
      }
     ],
     "bindingSites": []
    },
    "type": "NRPS-like",
    "products": [
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS-like",
    "anchor": "r11c1"
   }
  ]
 },
 {
  "length": 123973,
  "seq_id": "NODE_12_length_123973_cov_27.565967",
  "regions": []
 },
 {
  "length": 115497,
  "seq_id": "NODE_13_length_115497_cov_27.978453",
  "regions": []
 },
 {
  "length": 102722,
  "seq_id": "NODE_14_length_102722_cov_27.582970",
  "regions": []
 },
 {
  "length": 100720,
  "seq_id": "NODE_15_length_100720_cov_27.458462",
  "regions": []
 },
 {
  "length": 89110,
  "seq_id": "NODE_16_length_89110_cov_27.199746",
  "regions": []
 },
 {
  "length": 83143,
  "seq_id": "NODE_17_length_83143_cov_28.235199",
  "regions": []
 },
 {
  "length": 80697,
  "seq_id": "NODE_18_length_80697_cov_26.072253",
  "regions": []
 },
 {
  "length": 76103,
  "seq_id": "NODE_19_length_76103_cov_28.788191",
  "regions": []
 },
 {
  "length": 69974,
  "seq_id": "NODE_20_length_69974_cov_27.265619",
  "regions": []
 },
 {
  "length": 69746,
  "seq_id": "NODE_21_length_69746_cov_27.233935",
  "regions": []
 },
 {
  "length": 68069,
  "seq_id": "NODE_22_length_68069_cov_30.479130",
  "regions": []
 },
 {
  "length": 67292,
  "seq_id": "NODE_23_length_67292_cov_30.899546",
  "regions": []
 },
 {
  "length": 66325,
  "seq_id": "NODE_24_length_66325_cov_28.626902",
  "regions": []
 },
 {
  "length": 65647,
  "seq_id": "NODE_25_length_65647_cov_26.710325",
  "regions": []
 },
 {
  "length": 61450,
  "seq_id": "NODE_26_length_61450_cov_30.520343",
  "regions": []
 },
 {
  "length": 50225,
  "seq_id": "NODE_27_length_50225_cov_28.811498",
  "regions": []
 },
 {
  "length": 47030,
  "seq_id": "NODE_28_length_47030_cov_30.757076",
  "regions": []
 },
 {
  "length": 46151,
  "seq_id": "NODE_29_length_46151_cov_28.776056",
  "regions": []
 },
 {
  "length": 46039,
  "seq_id": "NODE_30_length_46039_cov_28.726905",
  "regions": []
 },
 {
  "length": 45644,
  "seq_id": "NODE_31_length_45644_cov_31.556806",
  "regions": []
 },
 {
  "length": 43843,
  "seq_id": "NODE_32_length_43843_cov_32.960586",
  "regions": []
 },
 {
  "length": 42486,
  "seq_id": "NODE_33_length_42486_cov_27.089863",
  "regions": []
 },
 {
  "length": 41572,
  "seq_id": "NODE_34_length_41572_cov_28.156645",
  "regions": []
 },
 {
  "length": 41354,
  "seq_id": "NODE_35_length_41354_cov_31.051191",
  "regions": []
 },
 {
  "length": 39569,
  "seq_id": "NODE_36_length_39569_cov_33.980325",
  "regions": []
 },
 {
  "length": 39030,
  "seq_id": "NODE_37_length_39030_cov_28.988679",
  "regions": []
 },
 {
  "length": 37240,
  "seq_id": "NODE_38_length_37240_cov_26.653096",
  "regions": []
 },
 {
  "length": 35210,
  "seq_id": "NODE_39_length_35210_cov_28.417613",
  "regions": []
 },
 {
  "length": 33825,
  "seq_id": "NODE_40_length_33825_cov_31.281261",
  "regions": []
 },
 {
  "length": 33529,
  "seq_id": "NODE_41_length_33529_cov_29.690273",
  "regions": []
 },
 {
  "length": 31555,
  "seq_id": "NODE_42_length_31555_cov_25.914035",
  "regions": []
 },
 {
  "length": 30588,
  "seq_id": "NODE_43_length_30588_cov_29.071122",
  "regions": []
 },
 {
  "length": 30400,
  "seq_id": "NODE_44_length_30400_cov_30.516308",
  "regions": []
 },
 {
  "length": 28542,
  "seq_id": "NODE_45_length_28542_cov_29.613771",
  "regions": []
 },
 {
  "length": 28392,
  "seq_id": "NODE_46_length_28392_cov_26.890482",
  "regions": []
 },
 {
  "length": 27869,
  "seq_id": "NODE_47_length_27869_cov_24.186996",
  "regions": []
 },
 {
  "length": 27077,
  "seq_id": "NODE_48_length_27077_cov_27.301815",
  "regions": []
 },
 {
  "length": 25150,
  "seq_id": "NODE_49_length_25150_cov_27.032744",
  "regions": []
 },
 {
  "length": 24461,
  "seq_id": "NODE_50_length_24461_cov_46.059424",
  "regions": []
 },
 {
  "length": 24411,
  "seq_id": "NODE_51_length_24411_cov_27.112559",
  "regions": []
 },
 {
  "length": 24372,
  "seq_id": "NODE_52_length_24372_cov_33.735830",
  "regions": []
 },
 {
  "length": 23647,
  "seq_id": "NODE_53_length_23647_cov_30.631396",
  "regions": []
 },
 {
  "length": 22346,
  "seq_id": "NODE_54_length_22346_cov_73.255916",
  "regions": []
 },
 {
  "length": 22335,
  "seq_id": "NODE_55_length_22335_cov_29.949232",
  "regions": []
 },
 {
  "length": 21361,
  "seq_id": "NODE_56_length_21361_cov_29.903684",
  "regions": []
 },
 {
  "length": 20214,
  "seq_id": "NODE_57_length_20214_cov_24.537617",
  "regions": []
 },
 {
  "length": 19326,
  "seq_id": "NODE_58_length_19326_cov_30.532547",
  "regions": []
 },
 {
  "length": 19025,
  "seq_id": "NODE_59_length_19025_cov_30.186035",
  "regions": []
 },
 {
  "length": 17886,
  "seq_id": "NODE_60_length_17886_cov_57.515301",
  "regions": []
 },
 {
  "length": 17285,
  "seq_id": "NODE_61_length_17285_cov_30.505172",
  "regions": []
 },
 {
  "length": 17188,
  "seq_id": "NODE_62_length_17188_cov_47.800947",
  "regions": []
 },
 {
  "length": 16763,
  "seq_id": "NODE_63_length_16763_cov_28.781793",
  "regions": []
 },
 {
  "length": 16652,
  "seq_id": "NODE_64_length_16652_cov_35.635053",
  "regions": []
 },
 {
  "length": 16052,
  "seq_id": "NODE_65_length_16052_cov_32.950986",
  "regions": []
 },
 {
  "length": 15129,
  "seq_id": "NODE_66_length_15129_cov_24.399017",
  "regions": []
 },
 {
  "length": 14919,
  "seq_id": "NODE_67_length_14919_cov_26.249966",
  "regions": []
 },
 {
  "length": 14780,
  "seq_id": "NODE_68_length_14780_cov_30.309189",
  "regions": []
 },
 {
  "length": 14674,
  "seq_id": "NODE_69_length_14674_cov_58.378160",
  "regions": []
 },
 {
  "length": 14669,
  "seq_id": "NODE_70_length_14669_cov_26.930578",
  "regions": []
 },
 {
  "length": 14374,
  "seq_id": "NODE_71_length_14374_cov_33.073302",
  "regions": []
 },
 {
  "length": 14300,
  "seq_id": "NODE_72_length_14300_cov_31.477255",
  "regions": []
 },
 {
  "length": 14166,
  "seq_id": "NODE_73_length_14166_cov_33.012350",
  "regions": []
 },
 {
  "length": 13607,
  "seq_id": "NODE_74_length_13607_cov_51.607908",
  "regions": []
 },
 {
  "length": 12634,
  "seq_id": "NODE_75_length_12634_cov_29.684638",
  "regions": []
 },
 {
  "length": 12247,
  "seq_id": "NODE_76_length_12247_cov_27.387264",
  "regions": []
 },
 {
  "length": 11136,
  "seq_id": "NODE_77_length_11136_cov_28.320192",
  "regions": []
 },
 {
  "length": 10018,
  "seq_id": "NODE_78_length_10018_cov_35.622271",
  "regions": []
 },
 {
  "length": 9742,
  "seq_id": "NODE_79_length_9742_cov_26.368546",
  "regions": []
 },
 {
  "length": 9712,
  "seq_id": "NODE_80_length_9712_cov_31.983913",
  "regions": []
 },
 {
  "length": 9071,
  "seq_id": "NODE_81_length_9071_cov_31.481432",
  "regions": []
 },
 {
  "length": 9014,
  "seq_id": "NODE_82_length_9014_cov_29.035247",
  "regions": []
 },
 {
  "length": 8915,
  "seq_id": "NODE_83_length_8915_cov_27.384137",
  "regions": []
 },
 {
  "length": 8740,
  "seq_id": "NODE_84_length_8740_cov_29.455154",
  "regions": []
 },
 {
  "length": 8680,
  "seq_id": "NODE_85_length_8680_cov_27.953853",
  "regions": []
 },
 {
  "length": 8671,
  "seq_id": "NODE_86_length_8671_cov_28.496858",
  "regions": []
 },
 {
  "length": 7688,
  "seq_id": "NODE_87_length_7688_cov_31.673367",
  "regions": []
 },
 {
  "length": 7465,
  "seq_id": "NODE_88_length_7465_cov_29.603952",
  "regions": []
 },
 {
  "length": 7324,
  "seq_id": "NODE_89_length_7324_cov_62.324272",
  "regions": []
 },
 {
  "length": 7276,
  "seq_id": "NODE_90_length_7276_cov_28.331991",
  "regions": []
 },
 {
  "length": 7131,
  "seq_id": "NODE_91_length_7131_cov_25.555004",
  "regions": []
 },
 {
  "length": 6931,
  "seq_id": "NODE_92_length_6931_cov_32.688649",
  "regions": []
 },
 {
  "length": 6913,
  "seq_id": "NODE_93_length_6913_cov_35.779988",
  "regions": []
 },
 {
  "length": 6735,
  "seq_id": "NODE_94_length_6735_cov_24.188195",
  "regions": []
 },
 {
  "length": 6520,
  "seq_id": "NODE_95_length_6520_cov_188.114388",
  "regions": []
 },
 {
  "length": 6475,
  "seq_id": "NODE_96_length_6475_cov_30.673804",
  "regions": []
 },
 {
  "length": 6462,
  "seq_id": "NODE_97_length_6462_cov_133.968207",
  "regions": []
 },
 {
  "length": 5972,
  "seq_id": "NODE_98_length_5972_cov_71.283291",
  "regions": []
 },
 {
  "length": 5709,
  "seq_id": "NODE_99_length_5709_cov_115.444957",
  "regions": []
 },
 {
  "length": 5670,
  "seq_id": "NODE_100_length_5670_cov_26.212408",
  "regions": []
 },
 {
  "length": 5367,
  "seq_id": "NODE_101_length_5367_cov_76.181096",
  "regions": []
 },
 {
  "length": 5130,
  "seq_id": "NODE_102_length_5130_cov_399.559272",
  "regions": []
 },
 {
  "length": 5083,
  "seq_id": "NODE_103_length_5083_cov_3.388134",
  "regions": []
 },
 {
  "length": 4806,
  "seq_id": "NODE_104_length_4806_cov_42.129414",
  "regions": []
 },
 {
  "length": 4598,
  "seq_id": "NODE_105_length_4598_cov_106.033621",
  "regions": []
 },
 {
  "length": 4544,
  "seq_id": "NODE_106_length_4544_cov_32.395120",
  "regions": []
 },
 {
  "length": 4512,
  "seq_id": "NODE_107_length_4512_cov_31.402029",
  "regions": []
 },
 {
  "length": 4166,
  "seq_id": "NODE_108_length_4166_cov_50.079726",
  "regions": []
 },
 {
  "length": 4074,
  "seq_id": "NODE_109_length_4074_cov_23.006755",
  "regions": []
 },
 {
  "length": 3919,
  "seq_id": "NODE_110_length_3919_cov_28.332639",
  "regions": []
 },
 {
  "length": 3842,
  "seq_id": "NODE_111_length_3842_cov_92.297742",
  "regions": []
 },
 {
  "length": 3824,
  "seq_id": "NODE_112_length_3824_cov_90.561516",
  "regions": []
 },
 {
  "length": 3616,
  "seq_id": "NODE_113_length_3616_cov_57.990393",
  "regions": []
 },
 {
  "length": 3512,
  "seq_id": "NODE_114_length_3512_cov_185.710044",
  "regions": []
 },
 {
  "length": 3505,
  "seq_id": "NODE_115_length_3505_cov_19.419487",
  "regions": []
 },
 {
  "length": 3337,
  "seq_id": "NODE_116_length_3337_cov_33.152147",
  "regions": []
 },
 {
  "length": 3096,
  "seq_id": "NODE_117_length_3096_cov_88.443193",
  "regions": []
 },
 {
  "length": 3058,
  "seq_id": "NODE_118_length_3058_cov_56.565247",
  "regions": []
 },
 {
  "length": 2588,
  "seq_id": "NODE_119_length_2588_cov_31.115890",
  "regions": []
 },
 {
  "length": 2525,
  "seq_id": "NODE_120_length_2525_cov_24.837010",
  "regions": []
 },
 {
  "length": 2481,
  "seq_id": "NODE_121_length_2481_cov_62.259567",
  "regions": []
 },
 {
  "length": 2427,
  "seq_id": "NODE_122_length_2427_cov_30.527234",
  "regions": []
 },
 {
  "length": 2378,
  "seq_id": "NODE_123_length_2378_cov_61.776619",
  "regions": []
 },
 {
  "length": 2377,
  "seq_id": "NODE_124_length_2377_cov_196.026522",
  "regions": []
 },
 {
  "length": 2228,
  "seq_id": "NODE_125_length_2228_cov_32.887029",
  "regions": []
 },
 {
  "length": 2052,
  "seq_id": "NODE_126_length_2052_cov_30.494177",
  "regions": []
 },
 {
  "length": 1825,
  "seq_id": "NODE_127_length_1825_cov_66.000000",
  "regions": []
 },
 {
  "length": 1779,
  "seq_id": "NODE_128_length_1779_cov_52.906580",
  "regions": []
 },
 {
  "length": 1670,
  "seq_id": "NODE_129_length_1670_cov_223.125549",
  "regions": []
 },
 {
  "length": 1667,
  "seq_id": "NODE_130_length_1667_cov_65.848428",
  "regions": []
 },
 {
  "length": 1623,
  "seq_id": "NODE_131_length_1623_cov_202.977361",
  "regions": []
 },
 {
  "length": 1566,
  "seq_id": "NODE_132_length_1566_cov_101.365346",
  "regions": []
 },
 {
  "length": 1561,
  "seq_id": "NODE_133_length_1561_cov_47.159030",
  "regions": []
 },
 {
  "length": 1515,
  "seq_id": "NODE_134_length_1515_cov_216.217663",
  "regions": []
 },
 {
  "length": 1515,
  "seq_id": "NODE_135_length_1515_cov_43.748957",
  "regions": []
 },
 {
  "length": 1362,
  "seq_id": "NODE_136_length_1362_cov_200.427237",
  "regions": []
 },
 {
  "length": 1310,
  "seq_id": "NODE_137_length_1310_cov_99.743715",
  "regions": []
 },
 {
  "length": 1175,
  "seq_id": "NODE_138_length_1175_cov_36.280510",
  "regions": []
 },
 {
  "length": 1160,
  "seq_id": "NODE_139_length_1160_cov_22.756233",
  "regions": []
 },
 {
  "length": 1142,
  "seq_id": "NODE_140_length_1142_cov_28.229108",
  "regions": []
 },
 {
  "length": 1059,
  "seq_id": "NODE_141_length_1059_cov_368.466395",
  "regions": []
 },
 {
  "length": 1058,
  "seq_id": "NODE_142_length_1058_cov_63.196738",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r5c1",
  "r11c1"
 ],
 "r5c1": {
  "start": 28687,
  "end": 56791,
  "idx": 1,
  "orfs": [
   {
    "start": 28748,
    "end": 29230,
    "strand": 1,
    "locus_tag": "ctg5_31",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_31</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_31</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,748 - 29,230,\n (total: 483 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_31\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGCGGGCGAGCGCTGGTGCTGGCGGTCGCGCTGCTGGCGGTGCCCGCCGCCGCGCGGCAGACGATCGGCGTCTACAAGAGCTGGGGCGCGTTTCGCGATCCCGACCGCTGCTATGCCATCGCCCAGCCCGTGCTCGCCAATGGCCGACCGGGCGGTTTCGCGACCGTGGGCACCTGGCCCGCCAAGCGGCTGCGCGCCTCCTTTCACCTGCATCTAAGCGCGCCGCGCGACCGCGCCGCGCCGGTGACGCTGGCGATCGGCGAGCGCCGCTTCCCGCTGATCGGGACCGACCGCGACATCTGGGCGCCCGATGGGGCTACCGACCATGCGCTGGTCATGGCGATGCGATCGGGGCGCAGCATGAGCGTGTCGGCGGTCGACACCCGCCACCGCCCCTTTGCCGACACCTATGCGCTGGCCGGTGCGGCTGCGGCGATCGACGCGGCGACGCTGGCCTGTGTGGCAGGGAATCCCGGCTGA",
    "translation": "MSGRALVLAVALLAVPAAARQTIGVYKSWGAFRDPDRCYAIAQPVLANGRPGGFATVGTWPAKRLRASFHLHLSAPRDRAAPVTLAIGERRFPLIGTDRDIWAPDGATDHALVMAMRSGRSMSVSAVDTRHRPFADTYALAGAAAAIDAATLACVAGNPG",
    "product": ""
   },
   {
    "start": 29257,
    "end": 30495,
    "strand": 1,
    "locus_tag": "ctg5_32",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_32</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_32</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,257 - 30,495,\n (total: 1239 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF04055<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_32 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04055.24 (Radical SAM superfamily): [148:319](score: 60.8, e-value: 2.2e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_32 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04055.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF04055.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051536' target='_blank'>GO:0051536</a>: iron-sulfur cluster binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_32\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACACGATTTTGCGCTATGGCCGCGCGATGCAGACAGTTTCGGCCGCCCCCATGCCCATCCCCGGGCACATCGATCCCGTGCCCGTGCCGCGCGGCGTGCAACCGCGCCCGGATGGTCGCGTCGACCTGATCGGCCTGACCAAGGACCAGTTGCGCGAGGCGCTGCTGTCGGCGGGCATGGAATTGAAGCAGGCCAAGCTGCGCTCCAAGCAGATCTGGCACTGGCTCTACAATCGCGGCGCGGTGCGCTTTGCCGACATGACCGATATCGCCAAGGCGCAGCATCCCTGGCTGGAGGAACGCTTCGTCATCGGCCGTCCCGAGGTGGTCGAGGCGCAGGTGTCGAGCGACGGCACCCGCAAATGGCTGCTCCGCTCGCCCGACGGGCAGGATTACGAGATGGTGTTCATCCCCGACGCCGATCGGGGCACCCTGTGCGTGTCGAGCCAGGTCGGCTGCACGCTCAACTGCCGCTTCTGCCACACCGGCACGATGCGCCTGGTCCGTAACCTGACCGCGGGCGAGATCGTGGGACAGGTCATGCTGGCGCGCGACTCGCTCGGCGAATGGCCCAGCCAGCCCGAGGGCCGCATGCTGACCAACATCGTCATGATGGGCATGGGCGAGCCGCTCTATAATTTCGACGCGGTGCGCGATGCCTTGAAGCTGGTGATGGACGGCGACGGGCTGGCCCTGTCCAAGCGTCGCATCACGCTGTCGACCAGCGGCGTGGTGCCGATGATGGCGCGTGCGGGAGAGGAGATTGGCGTCAACTTGGCCGTCTCGCTCCACGCGGTGACCAAGGACGTGCGCGACGAGATCGTGCCGCTCAACAAGAAATACGGCATCGAGGAACTGCTTCAGGCCTGTGCCGATTATCCGGGGGCGAACAACGCGCGGCGTATCACCTTCGAATATGTGATGCTCAAGGACAAGAACGACTCGGACGCCGATGCGCACGAACTCGTCCGCCTGCTGCGCCACTATAAGCTGCCCGCCAAGGTGAACCTGATCCCGTTCAATCCCTGGCCGGGCGCGGCCTATGAATGTTCGGATCCAGAGCGCATCCGCCGGTTCTCCGACATCGTGTTCGAGGGCGGCATCTCCGCCCCCGTCCGCACTCCGCGCGGGCGCGACATCGACGCCGCCTGTGGCCAGCTCAAGACCGCCGCCGAGAAGAAGAGCCGCGCGCAGCTCGACCGCGAGGCGGAAGAAAAGTTCGCGGCGCTGGGGTGA",
    "translation": "MDTILRYGRAMQTVSAAPMPIPGHIDPVPVPRGVQPRPDGRVDLIGLTKDQLREALLSAGMELKQAKLRSKQIWHWLYNRGAVRFADMTDIAKAQHPWLEERFVIGRPEVVEAQVSSDGTRKWLLRSPDGQDYEMVFIPDADRGTLCVSSQVGCTLNCRFCHTGTMRLVRNLTAGEIVGQVMLARDSLGEWPSQPEGRMLTNIVMMGMGEPLYNFDAVRDALKLVMDGDGLALSKRRITLSTSGVVPMMARAGEEIGVNLAVSLHAVTKDVRDEIVPLNKKYGIEELLQACADYPGANNARRITFEYVMLKDKNDSDADAHELVRLLRHYKLPAKVNLIPFNPWPGAAYECSDPERIRRFSDIVFEGGISAPVRTPRGRDIDAACGQLKTAAEKKSRAQLDREAEEKFAALG",
    "product": ""
   },
   {
    "start": 30699,
    "end": 31460,
    "strand": 1,
    "locus_tag": "ctg5_33",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_33</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_33</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,699 - 31,460,\n (total: 762 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_33 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01925.22 (Sulfite exporter TauE/SafE): [10:244](score: 95.0, e-value: 5.8e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_33 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01925.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_33\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCGACTGGACCTTTCTCGCACTGGCGGCCGCCGGAGGTTTTGTCGGGGGTGCGATGAATGCGCTGGCGGGCGGGGGCAGTTTCTCGACCATGCCGACGCTGATCGCGCTGGGGCTGCCTTCCACCATCGCCAATGCGACCTCCAATGTCGCGCTTCAGCCCGCCGCGATGGCCAGCGTCTGGGCCTATCGCCATGGCCTGGAGCCGGTGATGGGCGTGTCGATGCGGCGCATGGCGGCGCTGACCTTCGTCTTCGCGCTGCTGGGCAGCATCCTGTTGTTCCTGACGCCGCCGCGCGCTTTCGACCTGATCGTGCCATGGCTGTTGCTGACCGCGACGCTGGCGATTGCGGGGGGACGCCATGCCTCGGACTGGCTGGCGCGGATTGCCCGACCGGGCCCGCGCGCATTGATGGGCGCGCAGGCGGTGCTGGGCATCTATGGCGGCTATTTCGGCGGCGGCATCGGCATGATGCTGACCGCCGCCTGGGGATTGCTGTCGGGACGCAATCCGGCGCAGCTCGCCGCCCCCCGTACGCTGATGCTGGCCACCGCCAATGCGGCGGCGACCTTGGTCTTCGTCGTCACCGGCATGGTCGCCTGGGCACAATGCGTGCCGATGCTGCTGGGCGGGATCGTCGGCGGATGGAGCGGGGCGATCATCGGCCGCAAGCTGCCCGCCGGCCTGATCCGGGTGTGGACCTTGTTGCTCACCAGCGTCACCACGCTGGTGTTCTTCTGGCGGGGCTATATCGTGTGA",
    "translation": "MIDWTFLALAAAGGFVGGAMNALAGGGSFSTMPTLIALGLPSTIANATSNVALQPAAMASVWAYRHGLEPVMGVSMRRMAALTFVFALLGSILLFLTPPRAFDLIVPWLLLTATLAIAGGRHASDWLARIARPGPRALMGAQAVLGIYGGYFGGGIGMMLTAAWGLLSGRNPAQLAAPRTLMLATANAAATLVFVVTGMVAWAQCVPMLLGGIVGGWSGAIIGRKLPAGLIRVWTLLLTSVTTLVFFWRGYIV",
    "product": ""
   },
   {
    "start": 31467,
    "end": 32219,
    "strand": -1,
    "locus_tag": "ctg5_34",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_34</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_34</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 31,467 - 32,219,\n (total: 753 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_34\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGCCGGCGGCATTGGCCGACGTACTGCTGGCATCCGGCCATCCGCCGATCGTCGAGGCCGATGTCGGCCCGGAGGGCATGATGCCGCCCGCGCCGCCAGGCGTTCCCGTCGTCAACGCGATTCGGCTGTACACGGCCGCGACCCCTGCGGATCATCCGGGCTTTTGCGAAAAGACGCGGATCGATGTATCGCTGGCGCCGCGCATGCGTCGGGGCGATGCGGTCCCCGCCGCTCCCGCCGATGCCGTCACCACGACGAAACTGTACCGCTGGGCGCGGCCGGCGAAGGATGGCACAGGATGTGAAGCGCCGGCGTGGAGCTTTTTCCGGCGTGATGACGTCTTGGGCGACCGCAGCTTCAGCGTCGTCCGCCGTTTTGCAACGCTCCGGCCCGCCCGGCTTCGCAAGCTGCGGATCACCATCGACGATCGCCTTACCCGCAACCTGGCGGACATGGTCAAGGCATATCCGCAGGACTTTCCCGGCATATCGAAAGATCGCCTGACCCCGATCACGGATGGCCGGGTCGCGCTGGCGCGGTTTCCGATCTCGTCCATCCGCTACGTCGCTCCCTATAACGCGAGCTGGCCCAACGATCTTCTGGACAAGGCCGACCTTCAGGATGCGGCAGGGCGCGAGTTTGATGCGGTCATGGTCGGAACCGGTGGCGAATGGCATGCCGGGATCGTGTTCGATGGCGACCAGATCGTCACGATCCGCTTTGTCCGGGCTATACCTCCGCCATCCTGA",
    "translation": "MTPAALADVLLASGHPPIVEADVGPEGMMPPAPPGVPVVNAIRLYTAATPADHPGFCEKTRIDVSLAPRMRRGDAVPAAPADAVTTTKLYRWARPAKDGTGCEAPAWSFFRRDDVLGDRSFSVVRRFATLRPARLRKLRITIDDRLTRNLADMVKAYPQDFPGISKDRLTPITDGRVALARFPISSIRYVAPYNASWPNDLLDKADLQDAAGREFDAVMVGTGGEWHAGIVFDGDQIVTIRFVRAIPPPS",
    "product": ""
   },
   {
    "start": 32320,
    "end": 32907,
    "strand": -1,
    "locus_tag": "ctg5_35",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_35</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_35</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,320 - 32,907,\n (total: 588 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_35 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03703.17 (Bacterial PH domain): [63:143](score: 56.9, e-value: 1.9e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_35\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGGATGTGGTCGAGCACCAGGGCGATGCGCCCGTGACGTTGTTGCAGGGGCGGTTCAGCAGCCAGCTGCGCCTCTATTTCCTGGCCTATTGGACGGCGGTGGTCATGCTGTCCGTGATCGGGATCATGCTTCTGCCCGTCTGGCTGGTGATCGGCCCGCCCTGGATCCGCCGTTACCACGCGGCGTTGCGCTGCGACCTGACGGAGCGCAGCGTGGTGATCGGCAAGGGGCTGATCTTCCGTCGCGAGTTGACGATCCCGCTGGACAAGATCCAGGACATCTCGATCCGCGAGGGGCCACTGCTCAAGAGGTTCGGTCTTTTGCAGCTGCGCGTGGAAACCGCCGGGCAAAGCCAGTCGGCGTCGGGAAAGTCCGATGCCGACCTGGTCGGCCTGGTCGATGCCCGCGCGGTGCGGGACCGCATCCTCGAACAGCGCGACCGACTGGCGATGGCCGACGGTTCGGGCACCGTACCGTCATCGGACCGACAGGTGCTGGTCGACATTCGCGATAGCCTGTTGCGGCTGGAGCAGGCGATCGCCGGACGCGTGACCGGTTCGCCCGCACCGCGCGATCCGCAATAG",
    "translation": "MADVVEHQGDAPVTLLQGRFSSQLRLYFLAYWTAVVMLSVIGIMLLPVWLVIGPPWIRRYHAALRCDLTERSVVIGKGLIFRRELTIPLDKIQDISIREGPLLKRFGLLQLRVETAGQSQSASGKSDADLVGLVDARAVRDRILEQRDRLAMADGSGTVPSSDRQVLVDIRDSLLRLEQAIAGRVTGSPAPRDPQ",
    "product": ""
   },
   {
    "start": 32998,
    "end": 33618,
    "strand": -1,
    "locus_tag": "ctg5_36",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_36</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_36</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,998 - 33,618,\n (total: 621 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_36 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01613.21 (Flavin reductase like domain): [26:174](score: 52.1, e-value: 8e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_36 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01613.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0010181' target='_blank'>GO:0010181</a>: FMN binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_36\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTCAGGACTGGCATTTCTACGAACCCGTCAACGGCCATGGCCTGGCACATGATCCGCTGAACGCGATCGTCGCCCCGCGCCCGATCGGCTGGATCGGCAGCCGGTCGAGCGCGGGCGTCAACAATCTGGCACCATACAGCTTTTTCAACCTGTTCAACTACCGCCCGCCGCTGATCGGCTTTTCGTCGCAAGGGTGGAAGGACTCGGTTGCCAACATCGCCGAGACGCAGGTCTTCACCTGGAATCTGGCGACCATGGCGCTGGCCGAGCCGATGAACGCCAGCGCCGCGATGGTCGGCGCCGAGGTGGACGAATTCGCGCTCGCCGGGCTGGCGGTGGAGGAAGGGCGGGTGGTCGCGGCACCGCGCGTGGCGGCCAGCCCGGTCTCGTTCGAATGCCGCCTGACCCAGCTCATCCGGCTGGAAACCAAGGAAGGGCGGGAGCTCGACCAGTGGCTGGTGATCGGCGAGGCGGTGGGCATCCATATCGCCACCGCAATGATCGAGAACGGCATCTATCAGACGGCACGCGCGCGTCCGATCCTGCGCGGCGGCGGGCCGGTCGATTATTTCGAAGTGACCGAAGGCGCGCGGTTCGAGATGCGGCGGCCGGACTGA",
    "translation": "MTQDWHFYEPVNGHGLAHDPLNAIVAPRPIGWIGSRSSAGVNNLAPYSFFNLFNYRPPLIGFSSQGWKDSVANIAETQVFTWNLATMALAEPMNASAAMVGAEVDEFALAGLAVEEGRVVAAPRVAASPVSFECRLTQLIRLETKEGRELDQWLVIGEAVGIHIATAMIENGIYQTARARPILRGGGPVDYFEVTEGARFEMRRPD",
    "product": ""
   },
   {
    "start": 33643,
    "end": 34371,
    "strand": 1,
    "locus_tag": "ctg5_37",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_37</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_37</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,643 - 34,371,\n (total: 729 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_37 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01292.23 (Prokaryotic cytochrome b561): [19:236](score: 129.6, e-value: 1e-37)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_37 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01292.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009055' target='_blank'>GO:0009055</a>: electron transfer activity<br>\n  \n   PF01292.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_37\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_37_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAAGCCCAAACGCCGCCCGATCCGCAAAGAGCCGATGGGCCGCGCGTCATCCGCCGTCATGGCTTGGTGACGCGGCTGTGGCACTGGGTCAATGCGGTGGCGGTGCTGATCCTGCTGGGATCGGGGCTGGGCATCTCCAACGCACATCCCCGGCTTTATTGGGGGCGCTATGGGGCGAATTTCGATCCCGCCTGGGCGACTCTGCCGCGTTTTCCCAGTTGGCTGACCATTCCCGCCCATTACAATCTGGCGATCTCGCGCCGCTGGCATCTCTTCTTCGCGCTGGTGCTGGGCTTCGGGCTGCTGGCCTATATGGTCGGCGGGCTGCTCACGCGGCATTTCCAGCGTGACCTGCGCATCCGGGGGCATGAGCTGCGCCCGCATGCGCTATGGGTCGATTTCAAGCGGCATCTGGCGTTCCGCTTTCACGACGAAAGGGACCCGCGCGCCTACAACCTCTTCCAGAAGTTCAGCTATGCGCTGGTGCTGTTCGTCGCCCTGCCGCTTGCCATCCTGACCGGGATCGCGCTGTCGCCGGGGATGAATGCGGCCTGGCCCTGGGTGCTGGAGATATTGGGCGGACGGCAATCGGCGCGCTCGATCCATTTCATCACCGCGAGCCTGTTGGCGCTGTTTACCATCGTCCATCTCGCGCTCGTCATCCTGGCGGGCGCGGGCAATGAGGTGCGGTCGATGATTACCGGCCGCTGGAGGGTTCCCGAATGA",
    "translation": "MEAQTPPDPQRADGPRVIRRHGLVTRLWHWVNAVAVLILLGSGLGISNAHPRLYWGRYGANFDPAWATLPRFPSWLTIPAHYNLAISRRWHLFFALVLGFGLLAYMVGGLLTRHFQRDLRIRGHELRPHALWVDFKRHLAFRFHDERDPRAYNLFQKFSYALVLFVALPLAILTGIALSPGMNAAWPWVLEILGGRQSARSIHFITASLLALFTIVHLALVILAGAGNEVRSMITGRWRVPE",
    "product": ""
   },
   {
    "start": 34368,
    "end": 35111,
    "strand": 1,
    "locus_tag": "ctg5_38",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_38</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_38</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,368 - 35,111,\n (total: 744 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_38 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00174.22 (Oxidoreductase molybdopterin binding domain): [85:223](score: 133.2, e-value: 7.3e-39)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_38\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_38_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCCGGCGTCGTACCATTCTGACCGGCGGTGCGGGGCTGCTCCTCGCAGGCTGCGACAAGGTCATCCAGCAGCCCACCGCACGGAAGATCCTCTTCGCGGGTGAGGATATGCAGAAGGGCTTGCAGCGTGCGCTGATGGATCGCGGGGCGCTGGCCCCCGAATATCGCCGTGACCAGATGTCGCCCTATTTCCGCACCAACGGCACCCGCGATCCGGGGACGCCGGAATATCGGGCGCTGGTGGAAAACCGCTTTGCCGATTGGCGGCTGAAGGTCGGCGGGCTGGTCGGCACGCCATTGTCGCTCTCACTACGCCAGATCGGCGAATTTCCGGCGCGTCGCCAGATCACCCGGCATGACTGTGTCGAGGGGTGGAGCGCGATCGGCGAGTGGATGGGGCCGATGCTGGGCAATGTGCTGAAGGCCGCGAACATCAGCGACCGCGCGCGCTATGTTGTCTTCACCTGCGCCGACCTATACGGGGGCCAGCCCTATTATGAATCGCTCGACCTGATCGACGCCTTCCATCCGCAGACGATCCTCGCCTGGGGCATGAACGGCCGGATGCTGGATGTCGGGCATGGCGCACCGTTGCGGCTGCGGGTCGAGCGGCAACTGGGATACAAGCACGCCAAATATGTGATGCGGATCGATGCGGTCGACAGTTTGTCCAACATAGGTTTGGGCAAGGGCGGATACTGGGAAGACCATGTCGATTATGACTGGTACGCCGGGATTTAA",
    "translation": "MIRRRTILTGGAGLLLAGCDKVIQQPTARKILFAGEDMQKGLQRALMDRGALAPEYRRDQMSPYFRTNGTRDPGTPEYRALVENRFADWRLKVGGLVGTPLSLSLRQIGEFPARRQITRHDCVEGWSAIGEWMGPMLGNVLKAANISDRARYVVFTCADLYGGQPYYESLDLIDAFHPQTILAWGMNGRMLDVGHGAPLRLRVERQLGYKHAKYVMRIDAVDSLSNIGLGKGGYWEDHVDYDWYAGI",
    "product": ""
   },
   {
    "start": 35130,
    "end": 36359,
    "strand": 1,
    "locus_tag": "ctg5_39",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_39</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_39</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,130 - 36,359,\n (total: 1230 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PCMT<br>\n \n  biosynthetic-additional (smcogs) SMCOG1089:methyltransferase (Score: 79.3; E-value: 5.4e-24)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_39 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02353.23 (Mycolic acid cyclopropane synthetase): [118:378](score: 293.8, e-value: 1.2e-87)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_39\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_39_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGCTGATCGATCTCTTTCTGTCGCGCGCGGTCCGCAAGGGCCGCCTGTCCCTCACCCATCATGACGGCACCGTCCGCGAGTTCGGCTCACCCGAACCTGGTTACCCGGATGTCGCAATCCGCTTCACGGACGCCCGCGTCGCCGGGCAGATCGTCCGCAACCCCGCGCTGGCGGCGGGCGAGTGCTTTATGGACGGCCGCCTGGTCGTCGAGAAGGGCGATGTCCGCGACCTGGTCGAACTGCTGACCGCCAATGACAAATGGGAAGCGGGAGCAGACCGGCTCAATCCGTCCTGGCTGGTCCGCGCGGGCGGCGCGGTGAAGCATCGCATCGACCGGATCAACATGGAGCGCCGCTCGAAAAAGAATGTCGCCCACCATTACGACCTGTCGGGCACGCTGTACGAACTCTTCCTCGACACCGACAAGCAGTATAGCTGCGCCTATTATACCGATCCCCAGAACGATCTGGAGCGGGCGCAACGCGATAAAAAGGCGCATATCGCCGCCAAGCTGGCGATCCAGCCGGGGATGAAGGTGCTCGACATCGGTTGCGGCTGGGGCGGGATGGCGCTCTATCTGCATCAGATGTGCGGCGCCGAGGTGCTGGGCGTCACCTTGTCCGAGGAACAGCTGAAGGTGGCGCGCCAGCGTGCCGAGGCGCTGGGCGTCGCGGACAAGGTGAAGTTCGAGCTGATCGACTATCGCCGGGTCGAGGGGAAGTTCGACCGCATCGTCTCGGTCGGGATGTTCGAGCATGTCGGCCCGCCGCAATATCGCACCTTCTTTCGCAAGTGCCGCGACCTGCTGACCGAGGATGGCGTGATGCTGCTCCACACGATCGGGCGGCTGGGCGGTCCGGGCGTGACCGACGACTGGACGACCAAGTACATCTTCCCCGGCGGCTACAATCCGGCCCTGTCGGAGATCGTCCGCGCGCAGGAGGGGCTGCGTATGTTCCTGACCGATGTCGAGGTGCTGCGCTGCCATTATGGCTGGACGCTCGACGAATGGTATGCGCGGACGGTGGCGGCGAAGGAGCGGATCGTCGAGCTGTATGACGAGCGCTTCTATCGCATGTGGCTATTCTATCTGGCGGGTGCGGGCGCGGCGTTCCGCAATGGCGGGCTTTGCAACTACCAGGTGCAGTTGACGCGCGGGCGCATGTCGGTGCCGGTGACGCGGGATTATATGTTCGAGGGGGAACGCGAACTGCGCGCGCGGTAG",
    "translation": "MALIDLFLSRAVRKGRLSLTHHDGTVREFGSPEPGYPDVAIRFTDARVAGQIVRNPALAAGECFMDGRLVVEKGDVRDLVELLTANDKWEAGADRLNPSWLVRAGGAVKHRIDRINMERRSKKNVAHHYDLSGTLYELFLDTDKQYSCAYYTDPQNDLERAQRDKKAHIAAKLAIQPGMKVLDIGCGWGGMALYLHQMCGAEVLGVTLSEEQLKVARQRAEALGVADKVKFELIDYRRVEGKFDRIVSVGMFEHVGPPQYRTFFRKCRDLLTEDGVMLLHTIGRLGGPGVTDDWTTKYIFPGGYNPALSEIVRAQEGLRMFLTDVEVLRCHYGWTLDEWYARTVAAKERIVELYDERFYRMWLFYLAGAGAAFRNGGLCNYQVQLTRGRMSVPVTRDYMFEGERELRAR",
    "product": ""
   },
   {
    "start": 36397,
    "end": 36798,
    "strand": -1,
    "locus_tag": "ctg5_40",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_40</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_40</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,397 - 36,798,\n (total: 402 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_40\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTCTGCCCCTGGCCGGGACCATGTCGGGCTGGGCGCTGGCGGGCGGAGCGGCGGGAACGCTGCTGAGCGGCGCCGGGATCGGCCTGCTGCTCCGGCGGCGGCGCGATCGCCGGGTCGGCTCGCCTGAAGAGGTGGCGGCGGCGGCCGAAGCAGCGCTGAGCGGTTTCATCGTATCGGGCGCGGTGGTCGGCGCGGACGGGCAGGGCGCGCTGGCGGTGGCGACCGATGGCCGGGTCGCGGCGATCAAACGGCAAGGGCGCATGCTCGCGGTGCGTGAAATCCCCTGGACCCGGGTGCGCTCGACCGCCGAGGGTATCATTGCCGAGGTCGAGGGGCGCTTCGGTTCGGTCACGCTGGCCGGAGTGGATGTGCTGGATATCCGGCGGCTCAAGGCCTGA",
    "translation": "MTLPLAGTMSGWALAGGAAGTLLSGAGIGLLLRRRRDRRVGSPEEVAAAAEAALSGFIVSGAVVGADGQGALAVATDGRVAAIKRQGRMLAVREIPWTRVRSTAEGIIAEVEGRFGSVTLAGVDVLDIRRLKA",
    "product": ""
   },
   {
    "start": 36795,
    "end": 37226,
    "strand": -1,
    "locus_tag": "ctg5_41",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_41</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_41</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,795 - 37,226,\n (total: 432 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_41 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04273.16 (Beta-lactamase hydrolase-like protein, phosphatase-like domain): [1:108](score: 128.5, e-value: 1.3e-37)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_41 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04273.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_41\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCCGTCCCCTGAACGAAAGCGTCGCCGTCGCCCCCCAGATCCGTCCCGAGGACGTCGCGGCGATCAAGGCAGCGGGCTATACCGCCATCGTCAACAACCGTCCCGATGGCGAGGAGCCGAACCAGCCGACGGGCGATTCGATTCGCGCCGCAGCCGAGGATCATGGGCTGGCCTATACCGCGATCCCGGTGACGCCGGGCGGGTTCAGCCACGAGATGGTCGATCAGATGACCCAGGCGCTGACCGAGGCCAAGGGGCCGGTCCTGGCCTATTGCCGCTCGGGCACGCGCAGCTGCAATTTATGGGCACTGGCGGCGGCCAAGGCCGGGCGCAACCCGACGCTGATCGTGATGCAGGCCGAGGGTGCGGGCTATGACCTGTCCGGCCTGCGCCCGACGCTGGACGCGCTCGCGGGCGCGCAGGGATGA",
    "translation": "MIRPLNESVAVAPQIRPEDVAAIKAAGYTAIVNNRPDGEEPNQPTGDSIRAAAEDHGLAYTAIPVTPGGFSHEMVDQMTQALTEAKGPVLAYCRSGTRSCNLWALAAAKAGRNPTLIVMQAEGAGYDLSGLRPTLDALAGAQG",
    "product": ""
   },
   {
    "start": 37614,
    "end": 38636,
    "strand": 1,
    "locus_tag": "ctg5_42",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_42</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_42</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 37,614 - 38,636,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_42\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCGCTGATCGATCGTCGCCAGGGTCTATGGGGTCTGGCCGCCCTGGGAATCGCGGCCACGCTGCCCATGGCTTGGCGCCGGGCGCAAGCCGCGCCATCGACCCGGGGTACGCTCGCGCTGGTCGAGAAGGGCGAAGGGCGCGTCGCCTTTTACGATGTCGGCGATGGTCGTCGGTTGGGCACCGTGCCGCTGGGCGTCCAGCCGCATGAGATGGTCGCCGACCCCACGGGGCGCTACGCCTATGTCGGGGGGTATGGCGTGAAGGGCTGGCAGGCCGCCGGTGAGGGCGGCCATCAGCTCTGGGTGATCGACCTCGCCGAGCGGCGGCTGGCGCGCACCATCGATCTGGCGCCACATCGCCGCTGGCACGGGATGCGGATGGATGCGCAAGGCCGCCTCTATGCGCTGTCTGAGACGGACAGCCTGCTCGCCCGCTTCGACCAGCCGGCCGCCGCCGAGACGCCGGACCGGATGATTCCCGTCGGCGGCGCGCGCAGCCATTATTTCGTCGTCCGCCGCGACGGGGCTCGCGCCTATATCGCCGACACGATGAGCGGCATGGTCATCATGGTGAACCCCGACGATGCGAGCTTCGCCCCCGTCAAGCAACATATCGGCCAAGCGCCCGAGGGACTCGCGCTCAGCCCCGACGAGCGGACGCTCTATGTGGTGGATCGCCCGGCCGGCATCCTTCACGCCCTCGACGCCACGACGCTTCAGCCCCGTGCCCGCACCCGCTTGCGCGGCGAGGCGGTGCGGGTGATCGTGCAGCCCGATGGCCGGCTGATCGTGTCGAACCAAGGGGACAAGAGCCTGACCCGCCACGCCGCCGCCACACTCGCCGAGGAAGCACGGCTCGCGCTGCCCGCCGCTGCGCCGGGGCTGAACCTGCCGGCGGGGGGCACGACGCTCTATGCCGCGCTCGACAACAATCGGCTGGCGATCGTCGATCTGGCGGCCTGGAAGATCGTCGGCGGCTTTGCGACCGGAGAGGCGCCCGATACGGCGGTGCTCGCATGA",
    "translation": "MSLIDRRQGLWGLAALGIAATLPMAWRRAQAAPSTRGTLALVEKGEGRVAFYDVGDGRRLGTVPLGVQPHEMVADPTGRYAYVGGYGVKGWQAAGEGGHQLWVIDLAERRLARTIDLAPHRRWHGMRMDAQGRLYALSETDSLLARFDQPAAAETPDRMIPVGGARSHYFVVRRDGARAYIADTMSGMVIMVNPDDASFAPVKQHIGQAPEGLALSPDERTLYVVDRPAGILHALDATTLQPRARTRLRGEAVRVIVQPDGRLIVSNQGDKSLTRHAAATLAEEARLALPAAAPGLNLPAGGTTLYAALDNNRLAIVDLAAWKIVGGFATGEAPDTAVLA",
    "product": ""
   },
   {
    "start": 38687,
    "end": 39859,
    "strand": 1,
    "locus_tag": "ctg5_43",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38,687 - 39,859,\n (total: 1173 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: Lycopene_cycl<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_43 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05834.15 (Lycopene cyclase protein): [7:378](score: 313.5, e-value: 2.1e-93)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_43\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_43_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAGCCACGATTTCCTGCGATGTCGCGATTGTTGGTGCGGGGCTGGCCGGTGGCCTGATCGCCCTGGCGCTCAAGGCACGACACCCCTCGCTCGACCTGCGTCTGATCGACGCGGGCGAGACGATCGGGGGCAATCACGTCTGGTCCTTTTTCGGCAGCGACGTGGCCAAGCGCGATCGCTGGATCGTCGAGCGGCTGGTCGCGCATGGCTGGCGGCAATATGACGTCGCCTTCCCCGCCCATTCGCGCACGCTCGACCAGACCTATTATTCGATCGAAAGCCACCGCCTCGATACCGAGGTGCGCCGCGCCCTGCCGCCGCAGGCGCTGATCCTGGGGCGCAAGGTGCTGGCGGTGTCGGCCACTGCCGCCGTCTTCGCCGATGGCGACCGGGTGGAGGCCAAGGGCGTGATCGACGCGCGCGGCGCGGGCGACCTGTCCGCTTTGTCGTGCGGGTGGCAGAAATTCGTCGGCCAGGAATTGCGCCTGTCGCGCCCGCATGGCTGCACCCGGCCGGTGGTGATGGACGCCACCGTCAAGCAGATCGACGGCTATCGCTTCGTCTATGTCCTGCCCTTCGCCGAGGATCGGATCTTCGTCGAGGACACTTATTACTCCACCTCGTCCGAGCTGAATCGCCGCGCCATCGTTCAGCGGATCGAGCGCTATGCCGAGGCGCGCGACTGGCTGACGGCGGAGGTGGTGCGCGAGGAAGCCGGCGTCCTGCCGGTGGCGATGGGCGGCGATTTCGACGCCTATTGGCGCAGCGGCGGGGCAAAGACGCCCAAGGCCGGAATGCGCGCCGGGCTATTCCATCCCACCACCGGCTATTCGCTGCCCGATGCGATCCGTCTGGCCGCGATGCTGGCCGAACGGACCGACTTCGCCGGCGCCGACCTGCACGACGCGACCTATCGCATGGCCCGCGCCGCCTGGGATGCGCGCGGCTTTTATCGTATGCTCGACACGATGTTGTTCAAGGCCGCCGAGCCCGATGAGCGATACCGCGTGCTCGAGCGTTTCTATCGACTTGCGCCCGACCTGATCGGGCGATTCTATGCGGGGCAATCGACCATGGCCGACAAGGCACGAATTTTGACCGGACGGCCGCCGGTGCCGATCCTGCGCGCCATCGCCGCGCTGAGAAGCCAGACGGGGGGTCGCGCGTGA",
    "translation": "MAATISCDVAIVGAGLAGGLIALALKARHPSLDLRLIDAGETIGGNHVWSFFGSDVAKRDRWIVERLVAHGWRQYDVAFPAHSRTLDQTYYSIESHRLDTEVRRALPPQALILGRKVLAVSATAAVFADGDRVEAKGVIDARGAGDLSALSCGWQKFVGQELRLSRPHGCTRPVVMDATVKQIDGYRFVYVLPFAEDRIFVEDTYYSTSSELNRRAIVQRIERYAEARDWLTAEVVREEAGVLPVAMGGDFDAYWRSGGAKTPKAGMRAGLFHPTTGYSLPDAIRLAAMLAERTDFAGADLHDATYRMARAAWDARGFYRMLDTMLFKAAEPDERYRVLERFYRLAPDLIGRFYAGQSTMADKARILTGRPPVPILRAIAALRSQTGGRA",
    "product": ""
   },
   {
    "start": 39856,
    "end": 41331,
    "strand": 1,
    "locus_tag": "ctg5_44",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 39,856 - 41,331,\n (total: 1476 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1222:dehydrogenase (Score: 405; E-value: 9.1e-123)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_44 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01593.27 (Flavin containing amine oxidoreductase): [11:488](score: 151.5, e-value: 5e-44)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_44 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01593.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_44\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_44_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAAGAGCGCGGTCGTCATCGGGTCGGGCTTTGGCGGCCTGGCGCTCGCCATTCGCCTGCAATCGGCGGGCGTGCAGACCACCATCGTCGAGGCGCGGGACAAGCCCGGCGGCCGGGCTTATTATTGGGAGCGCGACGGCTTCACCTTCGATGCCGGCCCCACCGTCATCACCGACCCGGCCTGTCTGGAGGAACTCTGGGCGCTGACCGGGCGCAGCATGTCGGAGGACGTCAAACTCGATCCGGTCAGCCCCTTCTACCGGCTCAATTGGGTCGACGGCACCAATTTCGATTACAGCAACGACGACACCCAGCTCCGCTCCGAGATCGCCAAGCTGAACCCCGACGATATCGCGGGCTATGGCCGGTTCCTCGACTATGCCGCCGGGGTCTACCGCGAAGGCTATGAGAAGCTGGGCCATGTCGCCTTTCTCGACTTCGCCTCGATGGTGAAGGCCGCGCCTGCGCTGGCGAAGTACCAGGCATGGAATTCGGTCTATGCCATGGTCTCGAAATTCGTGAAGTCGGAGAAGCTGCGCGAGGCCCTGTCCTTCCACACGCTGCTGGTCGGCGGCAATCCGATGACGACCAGCGCCATCTATGCGCTGATCCACAAGCTGGAGCGCGATGGCGGCGTCTGGTTCGCGCGCGGCGGTACCAATAGGCTGGTCGCCGGCATGGTCGCGCAGTTCGAGCGGATCGGCGGCGTGCTGCGTCTGGGTGATCCCGTCGCGCGGATCGAGACTTTGGGCGACCGCGCGACCGGCGTGGTGACGAAGAGCGGCCTGACGATCCAGGTGGATGCGGTCGCGACCAATGCCGATATCATGCACAGCTACCGCGATCTGCTGGCCGACAATCGCTCGGCCCGGCGGACGGTCAACCGGCTGGAGCGCAAGCGCTATTCGCCGTCGCTGTTCGTCGTCCATTTCGGCATCAAGGGCGCGTGGCCGGGCATCCCGCACCACATGATCCTGTTCGGGCCGCGCTATAAGGGCCTGCTGACAGACATCTACGACACCGGGGTGCTGTCGGAGGACTTCTCGCTCTACCTCCACCACCCGACCGTCACCGACCCTAGCTTGGCGCCCGAAGGCCATTCGACCTTCTATGCGCTGGCCCCGGTGCCGCACATGGGCAAGTTCCCGATGAACTGGGACGAAGTCGGGCCGATCCTGGAAAAGCGCATCCTCGACGAGGTCGGCCGCCGCCTGATCCCCGACATCCATGATCGGATCGTGACCAAATTCCATTATGCGCCATCGGACTTCGCCACCGACCTCAACGCGCATATGGGCTCGGCCTTCTCACTCGAGCCGATCCTGACGCAGAGCGCCTATTTCCGGGTGCACAACCGCGACGATTCGATCCCGAACCTGTATTTCGTCGGCGCCGGTACGCATCCGGGCGCGGGAATTCCGGGCGTGGTCGGCAGCGCCAAGGCGACGGCGGCGCTGATGCTGGAGCGTAAATAA",
    "translation": "MKSAVVIGSGFGGLALAIRLQSAGVQTTIVEARDKPGGRAYYWERDGFTFDAGPTVITDPACLEELWALTGRSMSEDVKLDPVSPFYRLNWVDGTNFDYSNDDTQLRSEIAKLNPDDIAGYGRFLDYAAGVYREGYEKLGHVAFLDFASMVKAAPALAKYQAWNSVYAMVSKFVKSEKLREALSFHTLLVGGNPMTTSAIYALIHKLERDGGVWFARGGTNRLVAGMVAQFERIGGVLRLGDPVARIETLGDRATGVVTKSGLTIQVDAVATNADIMHSYRDLLADNRSARRTVNRLERKRYSPSLFVVHFGIKGAWPGIPHHMILFGPRYKGLLTDIYDTGVLSEDFSLYLHHPTVTDPSLAPEGHSTFYALAPVPHMGKFPMNWDEVGPILEKRILDEVGRRLIPDIHDRIVTKFHYAPSDFATDLNAHMGSAFSLEPILTQSAYFRVHNRDDSIPNLYFVGAGTHPGAGIPGVVGSAKATAALMLERK",
    "product": ""
   },
   {
    "start": 41367,
    "end": 43193,
    "strand": -1,
    "locus_tag": "ctg5_45",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 41,367 - 43,193,\n (total: 1827 nt)<br>\n <br>\n \n  resistance (resist) ABC_efflux (Score: 245.2; E-value: 8.1e-75)<br>\n \n  transport (smcogs) SMCOG1288:ABC transporter related protein (Score: 326.7; E-value: 4.7e-99)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_45 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00664.26 (ABC transporter transmembrane region): [39:313](score: 123.1, e-value: 1.8e-35)<br>\n \n  PF00005.30 (ABC transporter): [374:524](score: 116.8, e-value: 1.1e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_45 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00005.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00664.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00664.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0140359' target='_blank'>GO:0140359</a>: ABC-type transporter activity<br>\n  \n   PF00664.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00664.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_45\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_45_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMPPLDPTAGAPDRPLIPTLRRFLPYLWPAGAPALRARIVAAMLLVILSKLLQVLGAAYTLKYAIDRMAGGDRGAVMLIVLLVIGYAAARFGTTLFDNLRNAVFEIVGQDATRRLSADVFRHLHRLSLRFHLERRTGAVTKVVERGTKSIDTMLYFLLFNIAPTVLELGLVLAIFGRSFGPVLVVTTLAMVVLYIGFTRKVTDWRNALRNRMNDLDTGAVAHAVDSLLNFETVKYFNAEEREAQRYENGVAAYARAATKSENSLAWLNVGQAAITSLMLGFAMAWVVREWSRGAASPGDVVFVSTLLSQLFRPLDLLGMVYRTIRQGVIDMGAMFDLIDTPAEVVDAPHALPLAVRGGHVRFDHVVFGYEPDRAILKGLTLDIPAGTTCAVVGPSGAGKSTLARLLYRFYDVTEGAITIDGQRVSDVTQDSLRAAIGIVPQDTVLFNDTIGYNIAYGREGADQSDVERAAKGAAIADFIERQPQGYATRVGERGLKLSGGEKQRVAIARTLLKDPPILILDEATSALDSRTEADILATLQAIERGRTTLVIAHRLSTIAHADQIVVLDGGHVVERGTHGELLAKGGLYAEMWARQAAEVEQAEEDAVLA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCGCCACTCGACCCCACCGCCGGTGCGCCTGACCGGCCGCTGATCCCGACGCTTCGCCGCTTCCTCCCCTATCTCTGGCCCGCCGGAGCGCCCGCCCTGCGCGCGCGGATCGTGGCGGCGATGCTGCTCGTCATCCTGTCCAAGCTCCTGCAGGTGCTGGGCGCGGCCTATACGCTGAAATATGCGATCGACCGGATGGCGGGCGGGGATCGCGGCGCGGTGATGCTGATCGTGCTGCTGGTCATCGGCTATGCGGCGGCGCGGTTCGGCACGACGCTGTTCGACAATCTGCGCAATGCGGTGTTCGAGATCGTCGGGCAGGACGCGACCCGGCGGCTGTCGGCCGATGTCTTTCGCCATCTCCACCGCCTGTCGCTGCGCTTCCATCTGGAGCGCCGCACCGGCGCGGTGACCAAGGTCGTCGAACGGGGGACCAAGAGCATCGATACAATGCTCTATTTTCTCCTCTTCAACATCGCGCCTACGGTGCTGGAACTGGGGCTGGTGCTGGCGATCTTCGGGCGCAGTTTCGGGCCGGTGCTGGTCGTCACCACCCTGGCGATGGTCGTCCTCTACATCGGCTTCACCCGCAAGGTGACCGACTGGCGCAATGCGCTGCGCAATCGGATGAACGATCTCGACACCGGCGCGGTGGCGCATGCGGTCGACTCGCTGCTGAATTTCGAGACGGTCAAATATTTCAATGCCGAGGAGCGCGAGGCGCAGCGCTACGAAAACGGCGTCGCCGCCTATGCCCGCGCGGCGACCAAGTCGGAAAATTCGCTCGCCTGGCTGAATGTCGGGCAGGCCGCGATCACCAGCCTGATGCTCGGTTTCGCCATGGCCTGGGTCGTGCGCGAATGGAGCCGGGGGGCGGCCTCGCCGGGCGATGTGGTGTTCGTCTCGACCCTGTTGTCGCAGCTCTTCCGCCCGCTCGATCTGCTCGGCATGGTCTATCGCACCATCCGCCAGGGGGTGATCGACATGGGCGCGATGTTCGACCTGATCGACACGCCCGCCGAAGTGGTCGACGCGCCCCATGCCTTGCCGCTGGCGGTGCGGGGCGGGCATGTCCGCTTCGACCATGTCGTCTTCGGCTACGAGCCGGATCGGGCAATCCTGAAGGGCCTGACGCTCGACATTCCGGCGGGCACGACCTGTGCGGTGGTGGGGCCGTCCGGCGCGGGCAAGTCGACGCTCGCGCGGCTGCTTTACCGGTTCTACGATGTCACCGAGGGCGCGATCACCATCGATGGGCAGCGGGTGTCAGACGTGACGCAGGATAGTTTGCGTGCGGCGATCGGGATCGTGCCGCAGGACACGGTGCTGTTCAACGATACGATCGGCTACAACATCGCTTATGGTCGTGAAGGCGCGGACCAGTCGGACGTCGAGCGCGCGGCCAAGGGCGCGGCGATCGCGGACTTCATCGAGCGCCAGCCGCAGGGCTATGCCACCCGCGTCGGCGAGCGTGGCCTGAAGCTGTCGGGTGGCGAGAAGCAGCGGGTGGCGATCGCCCGCACCTTGCTGAAGGATCCGCCCATCCTGATCCTCGACGAGGCGACCAGCGCGCTCGACAGCCGGACCGAGGCGGATATCCTCGCGACGCTCCAGGCGATCGAGCGCGGGCGCACCACGCTGGTCATCGCGCACCGCCTGTCGACCATCGCCCATGCCGATCAGATCGTGGTGCTCGATGGCGGCCATGTGGTCGAGCGGGGTACGCATGGCGAATTGCTGGCCAAGGGCGGGCTCTATGCCGAAATGTGGGCGCGCCAGGCCGCCGAGGTCGAGCAGGCGGAAGAGGATGCGGTGCTGGCGTGA",
    "translation": "MPPLDPTAGAPDRPLIPTLRRFLPYLWPAGAPALRARIVAAMLLVILSKLLQVLGAAYTLKYAIDRMAGGDRGAVMLIVLLVIGYAAARFGTTLFDNLRNAVFEIVGQDATRRLSADVFRHLHRLSLRFHLERRTGAVTKVVERGTKSIDTMLYFLLFNIAPTVLELGLVLAIFGRSFGPVLVVTTLAMVVLYIGFTRKVTDWRNALRNRMNDLDTGAVAHAVDSLLNFETVKYFNAEEREAQRYENGVAAYARAATKSENSLAWLNVGQAAITSLMLGFAMAWVVREWSRGAASPGDVVFVSTLLSQLFRPLDLLGMVYRTIRQGVIDMGAMFDLIDTPAEVVDAPHALPLAVRGGHVRFDHVVFGYEPDRAILKGLTLDIPAGTTCAVVGPSGAGKSTLARLLYRFYDVTEGAITIDGQRVSDVTQDSLRAAIGIVPQDTVLFNDTIGYNIAYGREGADQSDVERAAKGAAIADFIERQPQGYATRVGERGLKLSGGEKQRVAIARTLLKDPPILILDEATSALDSRTEADILATLQAIERGRTTLVIAHRLSTIAHADQIVVLDGGHVVERGTHGELLAKGGLYAEMWARQAAEVEQAEEDAVLA",
    "product": "",
    "resistance": true
   },
   {
    "start": 43407,
    "end": 45377,
    "strand": -1,
    "locus_tag": "ctg5_46",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_46</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_46</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 43,407 - 45,377,\n (total: 1971 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Abhydrolase_6<br>\n \n  biosynthetic-additional (rule-based-clusters) Peptidase_S9<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_46 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00326.24 (Prolyl oligopeptidase family): [416:628](score: 149.0, e-value: 1.4e-43)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_46 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00326.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008236' target='_blank'>GO:0008236</a>: serine-type peptidase activity<br>\n  \n   PF00326.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006508' target='_blank'>GO:0006508</a>: proteolysis<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_46\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_46_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTATTCAAGGCTTTGTTGGCGGCGGGAGCCGCGTTGATGGTGGCGCAATCGGCGATGGCGGCGGACGTCCCGCTGATCGAACGGGCCAAGCTGTTCGGCAATCCGACCAAGGTCGGTGGACAGCTGTCGCCCGATGGCAAGTGGATCAGTTTCATCGCGCCGCGCGACGGGGTGCTGAACGTCTGGGTCGCGCCGATCGCCACCCCCGATCAGGCCAAGCCGCTGACCGCCGAGAAGACCCGGCCGATCCGCCAAAGCTTCTGGTCGCCGGATTCCAAGTCGATTCTGTTCGTCAACGACAAGGGCGGCGACGAGAATTTCCTGCTCTACGGCGTCAACGTCGCGACCGGCGAGCAAAAGGCGCTGACCCCGTTCGAGAAGACCCGGGTTCAGATCGTCGGCACCAGCGAGACGATCAAGGACCGTATCCTGGTCGGCGTCAACAATCGCGACCCGCGCTGGCATGACGTGTACGAACTGAACCTGACCACCGGCGCGCTGACCAAGGTGATGCAGAATGACGGCTATGCCGGGTTCCTCGCCGACGATCAGTTGAAGCTGCGCATGGCAGCCAAGGCGCGGCCCGATGGCGGCTCCGACTATTACCGCGTCAACGGCACCAATGTGGAGGCGACGCCGGTCGTGCAGTTCGGGCTGGACGATTCGTTGACCACCTCGCCGCTGGGCTTCACGGTTGATGGCAAGACGCTCTACTGGATGGACAGCCGGGGCCGGAACACCGCCGCGCTGATGGCGCAGGACATGGGCAGCGGCAAGATGGCCGTGATCGGCGAAAGCCCCAAGGCCGATGTCGGCGGCGGTCTGTTCAACCCCAAGACCGGCCGGGTCGAGGCCTATTCGGTCAATTACCTGAAGCGCGACTATGTGCCGGTCGGCGATGCGGTGAAGGCCGATCTCGCCTTTCTGAAGGCACAGAACAAGGGCGAATTCGCGATCGGGTCGCGCACCGATGCCGATGACAAATGGCTCGTCACTTTCGATCCGGTGACCGCGCCGGCCTCGACCTGGCTATACGACCGCAAGGCGAAGAAGCTGACCCAGCTTTACGTCAGCCGCCCCGAACTGGCCGATGCGCCGCTGGTGCCGATGGAGGCGGTGGAAATCCCCGCGCGCGACGGGCTGACGCTGGTGTCGTACCTGACCAAGCCCAAGGGCGTGACCGGGCCGGTGCCGATGGTGTTGTTCGTCCATGGCGGACCCTGGGCGCGCGACGGCTATGGCTTTAACGGCTATCATCAGTGGCTCGCCAATCGCGGCTATGCGGTGCTGTCGGTCAATTATCGCGGCTCGACCGGCTTTGGGAAGAATTTCATCTCGGCGGGCGACCTGCAATGGGGCCGCAAGATGCATGACGACCTGATCGACGCGGTCGACTGGGCGGTCAAACAGGGCGTCACCACCCCCGACAAGGTGGCGATCATGGGCGGCTCTTATGGCGGCTATGCGACGCTGGCGGGCCTGACCTTCACGCCGGAGAAATTCGCGTGCGGCGTCGATATCGTCGGGCCGTCGAACCTGTTCACGCTTCTGAAGACGATCCCGCCCTATTGGGAAGCGGGCAAGCAACAATTCTACAAGCGGATGGGCGACCCGACGACCGAAGAGGGGCGCGCCCTTCTCAAGGAACGCTCACCGCTGACCTTTGTCGACCAGATCAAGAAGCCGCTGCTGATCGGGCAGGGCGCCAACGACCCGCGCGTCAACGTCGCGGAGAGTGACCAGATCGTGGCGGCGATGGCGACGAAGAACATCCCCGTCACCTATGTCCTGTTCCCCGACGAGGGCCATGGCTTCGCGCGGCCGGCCAACAACATCGCCTTCAACGCGGTGGCCGAGAATTTCCTCGCCCCTTGCCTGGGCGGTCGCGCCGAGCCGATCGGCGACACGCTCAAGGCCTCGACCGCGCAGGTGAAGCATGGCGCGGAGTTCGTGACCGGGTTGAAGTAG",
    "translation": "MVFKALLAAGAALMVAQSAMAADVPLIERAKLFGNPTKVGGQLSPDGKWISFIAPRDGVLNVWVAPIATPDQAKPLTAEKTRPIRQSFWSPDSKSILFVNDKGGDENFLLYGVNVATGEQKALTPFEKTRVQIVGTSETIKDRILVGVNNRDPRWHDVYELNLTTGALTKVMQNDGYAGFLADDQLKLRMAAKARPDGGSDYYRVNGTNVEATPVVQFGLDDSLTTSPLGFTVDGKTLYWMDSRGRNTAALMAQDMGSGKMAVIGESPKADVGGGLFNPKTGRVEAYSVNYLKRDYVPVGDAVKADLAFLKAQNKGEFAIGSRTDADDKWLVTFDPVTAPASTWLYDRKAKKLTQLYVSRPELADAPLVPMEAVEIPARDGLTLVSYLTKPKGVTGPVPMVLFVHGGPWARDGYGFNGYHQWLANRGYAVLSVNYRGSTGFGKNFISAGDLQWGRKMHDDLIDAVDWAVKQGVTTPDKVAIMGGSYGGYATLAGLTFTPEKFACGVDIVGPSNLFTLLKTIPPYWEAGKQQFYKRMGDPTTEEGRALLKERSPLTFVDQIKKPLLIGQGANDPRVNVAESDQIVAAMATKNIPVTYVLFPDEGHGFARPANNIAFNAVAENFLAPCLGGRAEPIGDTLKASTAQVKHGAEFVTGLK",
    "product": ""
   },
   {
    "start": 45498,
    "end": 45728,
    "strand": 1,
    "locus_tag": "ctg5_47",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_47</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_47</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,498 - 45,728,\n (total: 231 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_47\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAACCGATTTTCTATGTGATGGCGATCCTGGGCTGCGGAGATGGCAGCGTCGATTGCACCGAGGCGCGGATGGTCCCCGCCCGCTACGAAACCATGGCCCAGTGCCGCGCCGATCTCGCCAACCGGATCGCCGCCAATACCGATGTGCCCTATCCCGTGATCGGTGCCGACTGTCGCCGCATCGGCGCGCAGGTTGCGAAGGCCGAGCGCAAGCCTTCGCAGGGCTGA",
    "translation": "MQPIFYVMAILGCGDGSVDCTEARMVPARYETMAQCRADLANRIAANTDVPYPVIGADCRRIGAQVAKAERKPSQG",
    "product": ""
   },
   {
    "start": 45841,
    "end": 46791,
    "strand": -1,
    "locus_tag": "ctg5_48",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_48</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_48</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,841 - 46,791,\n (total: 951 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_48 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [21:277](score: 214.0, e-value: 2.9e-63)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_48 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_48\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_48_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACCCGGCCCGCCGCCCCGACCGAACGGGCGGCGCTGGTGGCGGCGGCCAAGGACTCGATCGCACGCGGCTCGAAGAGTTTCGCGGCGGCCAGCCTGTTGTTCGATCCCGAAACGCGCGAGCGCGCCTGGCTGCTCTATGCCTGGTGCCGGCGGTGCGACGATATCGCCGATGGGCAGGATCATGGCCATGGCATGACCCGCGTGGCCGATGCGCCCGCGCGGCTGGCCGAGCTGACCGACAAGACCGAGGCGGCGCTGGCGGGGCAGGTGGTGGGTGATCCTGCCTTCGACGCGCTGCGCGTGGTGGTGGCGGAGACGGGGATGCCGCATCGCTGGCCCCGTGACCTGATCGCCGGCTTCGCGCTGGATGCCGAGGATTGGCGGCCGCAGAGCGAGGCGGACCTCTATCGCTATTGCTATCACGTCGCGGGCGTCGTCGGCTGCATGATGGCGGTGACGATGGGGGTGCGGCCGGATGACGAGGCGACGCTCGACCGAGCTTGTGATTTGGGAATGGCGTTTCAACTGGCCAATATCGCGCGCGACATTGCCGAAGATGCCGGCGCCGGGCGGCATTATCTGCCGCGCGAGTGGCTCGCCTATAAGAGCATCGCGCCCGATGCGATCATGGCCCCCTCGCACCGGCCGGGGCTGACCGCGCTGGCCCGGCGGCTGACCGATCAGGCTGCCCGGTTCGAGGCGAGCGCACGGATGGGGACGCCGGCGCTTTCCTATCGCTCGGCCTGGGCGGTGCTATCGGCGGCGGCGATCTATGGCGCGATCGGCCGCAAGGTTGCCAAGCGGGGGCGGCGCGCCTGGGACAGCAGGGTCGGAACCGGCAAGGCGGAGAAGCTGCGCTTCATGACGGTCGCCGGCGTTCAGGCGGCGCGGAGGGACAAAATGAAAATCCTCCCACGTGATCCAACCCTTTGGACGCGGCCCCGGTAG",
    "translation": "MTRPAAPTERAALVAAAKDSIARGSKSFAAASLLFDPETRERAWLLYAWCRRCDDIADGQDHGHGMTRVADAPARLAELTDKTEAALAGQVVGDPAFDALRVVVAETGMPHRWPRDLIAGFALDAEDWRPQSEADLYRYCYHVAGVVGCMMAVTMGVRPDDEATLDRACDLGMAFQLANIARDIAEDAGAGRHYLPREWLAYKSIAPDAIMAPSHRPGLTALARRLTDQAARFEASARMGTPALSYRSAWAVLSAAAIYGAIGRKVAKRGRRAWDSRVGTGKAEKLRFMTVAGVQAARRDKMKILPRDPTLWTRPR",
    "product": ""
   },
   {
    "start": 46788,
    "end": 47369,
    "strand": -1,
    "locus_tag": "ctg5_49",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_49</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_49</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 46,788 - 47,369,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_49 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03641.17 (Possible lysine decarboxylase): [45:176](score: 129.3, e-value: 1.1e-37)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_49\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_49_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGCGATTGGCCATTTACTGCGGGTCGGCGACCCCCTCGGACCCTCAATATATCGAGACGGCGCGTGCTGTCGGGCGCGGACTGGCGGAGCGGGGGATCGGCGTCGTCTATGGCGGCGGTCGGCTGGGCCTGATGGGCGCGGTCGCCGATGCGGCGCTGGCGGCCGGCGGCGAGGTGATCGGCATCATCCCGCAGGCGCTGGTCGATGCCGAGGTCGCGCATCGCGGCCTGACCGAACTGCACGTCGTGCCCGGCATGCACGAGCGGAAGAAGGCGTTCACTGATCTGTCCGACGGTTTCGTCACCATCGCCGGCGGCACCGGCACGATGGACGAATTGTGGGAAGCATTGAGCTGGGCGCAGCTCGGCTATCATGCCGATCCGGTCGGGCTGCTCAACACGGGCGGCTATTACGACCATCTCGTCGCCTTCTGGGACAAGATGGGCGAGGTCGGCTTCCTGCGGCCGCAGCACCGCGAATTGCTGATCGTCGATGAAACGCTGGACGGGCTGCTGGAGCGGATGGCGGTGCATGTTCCCACCCAGCCGATCGTTCGCATGAACGCGGGCGACCTGTGA",
    "translation": "MKRLAIYCGSATPSDPQYIETARAVGRGLAERGIGVVYGGGRLGLMGAVADAALAAGGEVIGIIPQALVDAEVAHRGLTELHVVPGMHERKKAFTDLSDGFVTIAGGTGTMDELWEALSWAQLGYHADPVGLLNTGGYYDHLVAFWDKMGEVGFLRPQHRELLIVDETLDGLLERMAVHVPTQPIVRMNAGDL",
    "product": ""
   },
   {
    "start": 47447,
    "end": 47707,
    "strand": -1,
    "locus_tag": "ctg5_50",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 47,447 - 47,707,\n (total: 261 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_50\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTATTCGACGGGGCTTCGGCCGTATGGTGAGCCTCTATGAACGCGCACCGCTGCGCCAGTTGCTCGATCTCGATCCGATCGGCGCTGTGGACTGGATCGTGGTGGCGCTCGCCCGGCGCATGGTACGGTTTCTGGATGGCGCGCATGCTACCGAGTATCTCGACGGTCCAGCGGTATCGTCGGGCTGGCGCGGCAATTTCGTCTTTCTGCTGTTCTGGGTGACGCTGATCGTGGGCACAGTGGCCGTCTTCGCCTGA",
    "translation": "MTIRRGFGRMVSLYERAPLRQLLDLDPIGAVDWIVVALARRMVRFLDGAHATEYLDGPAVSSGWRGNFVFLLFWVTLIVGTVAVFA",
    "product": ""
   },
   {
    "start": 48039,
    "end": 48737,
    "strand": -1,
    "locus_tag": "ctg5_51",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 48,039 - 48,737,\n (total: 699 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_51\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAAACCATACCGTGATCCGGATCGGCAATGAAAATTTTCGACTGATCGCAACAGTCGATGAAGGGCAGACTCTGTATTTTACGGCCGGCAAAGCCATAGCCGTAGAAAAATACGACATGCGGATCGGCAAGAGTGAGTTCGACTTTCAAGTCAATTCACGGCCGGTACGTGGCGGGCGTCCCGAGGCCATTGCGGCCCGACAGCAAAGCTTAGACCGCGAATTTATGGAAAGTCGGGTAAAATCCAATCTTTTTGGTTTGCCGGTCAGTCTGGGCAACGCCGCCGCCATGGTAAAAGATCGAAGGGTCGCGCTAAGCTATGGCGAGTTGCGACCTCAGATATTTCGAAGTTCCGTCAGTACTAGGCCGGTCGCATGGCGAATCTGGTTTCGTCGTACGAGGTACTCCGGCCAAGCGAGTGGGAAGGGGATACGAAACGCTCCTAAGCCTGCCGCTTCCGCCAAGGCGCAAGCCTCAGCAATGGGTAGTGCTGCAATCGGAGCTATGTCCAAGGCACCCCAGAGAGGACGGGCGACGGCAATCGGACCCTTGGCCAACGGTGCGGGCATCCTCCGCGTGTACGTTCTAGCCGATGACAAGAGCGAAATCGTTGCGCCCTTCGATCGGAGAGACGTGACGTTTCGCGATCCAAGTTTGTGGGAACGAGCGGTCAATTTGGTGCGAGGGGGGAGTTAA",
    "translation": "MANHTVIRIGNENFRLIATVDEGQTLYFTAGKAIAVEKYDMRIGKSEFDFQVNSRPVRGGRPEAIAARQQSLDREFMESRVKSNLFGLPVSLGNAAAMVKDRRVALSYGELRPQIFRSSVSTRPVAWRIWFRRTRYSGQASGKGIRNAPKPAASAKAQASAMGSAAIGAMSKAPQRGRATAIGPLANGAGILRVYVLADDKSEIVAPFDRRDVTFRDPSLWERAVNLVRGGS",
    "product": ""
   },
   {
    "start": 48847,
    "end": 50616,
    "strand": 1,
    "locus_tag": "ctg5_52",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 48,847 - 50,616,\n (total: 1770 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 280.4; E-value: 4.5e-85)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_52 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00270.32 (DEAD/DEAH box helicase): [20:175](score: 59.5, e-value: 3.8e-16)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [227:319](score: 43.3, e-value: 4.1e-11)<br>\n \n  PF16124.8 (RecQ zinc-binding): [331:392](score: 50.3, e-value: 3.2e-13)<br>\n \n  PF09382.13 (RQC domain): [394:504](score: 69.1, e-value: 3e-19)<br>\n \n  PF00570.26 (HRDC domain): [519:585](score: 75.7, e-value: 2.2e-21)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_52 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding<br>\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00570.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding<br>\n  \n   PF09382.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043138' target='_blank'>GO:0043138</a>: 3'-5' DNA helicase activity<br>\n  \n   PF09382.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006260' target='_blank'>GO:0006260</a>: DNA replication<br>\n  \n   PF09382.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006281' target='_blank'>GO:0006281</a>: DNA repair<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_52\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_52_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTCGCCGACCCCCTTGCCAAGCTCCATGAAGTCTTCGGGTACAGCCAGTTCCGGGGTGTCCAGGAACAGGTGGTCGACCGCGTGCTCGGCAAACAGCGGACTTTGGCGGTCATGCCGACCGGCGCGGGCAAGTCGCTGTGTTACCAGCTGCCCGCGGTGATGATGAACGGATGTTGCGTCGTGGTCAGCCCGCTGATCGCGCTGATGCACGACCAGTTGCGCGCCGCCGAAGCAGTCGGCATCCGCGCCGCCACGCTGACCAGCGTCGACCAGAACCGCGCCGAGACGGTCGCGCGCTTCCGCGACGGCCAGCTCGACCTTCTGTATGTCGCGCCCGAGCGCGCTTCGTCGGGGCATTTCCGCGAGCTGCTGGCCTCCGCGCCGCTCAGCCTGTTCGCGATCGACGAGGCGCACTGCGTCAGCGAATGGGGGCATGACTTCCGCCCCGATTACCGGCTGCTCGAACCGTTGATGGATGCCTTTCCGGAGGTGCCCCGGCTGGCGCTGACCGCGACCGCCGATGCGCATACCCGCGCCGACATCGCCAAGCAGCTGGGCATTCCGGTCGAGGGGATGATCGTCTCGGGCTTCGATCGGCCCAATATCCGCTATGCGATCAGCCCCAAGGCCAATGTGAACCTGCAGATCGCGCGGGTGGTCGCCGACACGCCGGGCCCCGGCATCGTCTATGCCCAGACGCGCGCCGCGACCGAGAAACTGGCGGAAGCGCTGGCGCGGACGGGGCGGCCGGTGCGCGCCTATCATGCGGGACTCGACCCAGCGATCCGCGCCAAGAACCAGGCCGATTTCGTCGCGAGCGAGGACATGGTGATCTGCGCGACCGTCGCCTTCGGCATGGGGATCGACAAGCCCGATGTGCGCTTCGTCGCCCATGCCGGGCTGCCCAAGTCGATCGAGGCCTATTATCAGGAGACGGGGCGCGCCGGGCGCGACGGCGACCCTTCCGTCGCGCATCTCTTCTGGGGCGCCGACGATTTTGCGCGGGCCCGCCAACGCATCGCCGAGGTCGAACCCGAACGCCAGCCCGGCGAGCGTGCACGCCTGTCCGCTCTCGGTGCGCTGGTCGAGACGGGCGGGTGCCGCCGCCGCATCCTGCTACGCCATTTTGGCGAGGAGCTGGCGGAGGATTGCGGCAATTGCGACAATTGCCTGGGGTCGCCCGATGCGGTCGATGCGACGACCACCGCGCAGAAATTCCTCTCTGCCGTGTTCCGCACCGGCCAGATGTTCGGCGCGGGCTATATCGAGCAGGTGCTGACTGGCCAGTCGAGCGAGCGCAGCCTGATGAACGGGCATGAGGCGCTGTCGGTGTGGAACATCGTCGACGGCGACGAGGTGGCGTTGCTCAAGCCGGTGCACCGCGCGCTGTTGCTGCGCGATGCGTTGCGCACCAATCCCCATGGCGGGCTGGAGTTCGGCCCCGCCGCGCGTGCGCTGATCAAGGGCGAGGCGCGGCTGTCGCTGGTCGTGCCGCCCAAGCGGGAGCGTAAAGGCCGCCGCGCCGCGCCCGTGGCCGCCAATCCGGCCGACAATCCGCTGTTCGAGGCGCTGCGCGCCAAGCGTCGCGAGCTGGCGCAGGAGGCGGGCGTGCCGCCTTACGTCATCTTCCACGACTCGGTGCTGCGCGACATGGCGGCGCAGCGGCCGAACAGCCGCGCGGCGCTGTCGCTCCTGTCCGGGATCGGCGCGCGCAAGCTGGATGCTTATGGCGAGGCCTTTCTGGCGGTGATCCGCGACGCCGGCTAA",
    "translation": "MVADPLAKLHEVFGYSQFRGVQEQVVDRVLGKQRTLAVMPTGAGKSLCYQLPAVMMNGCCVVVSPLIALMHDQLRAAEAVGIRAATLTSVDQNRAETVARFRDGQLDLLYVAPERASSGHFRELLASAPLSLFAIDEAHCVSEWGHDFRPDYRLLEPLMDAFPEVPRLALTATADAHTRADIAKQLGIPVEGMIVSGFDRPNIRYAISPKANVNLQIARVVADTPGPGIVYAQTRAATEKLAEALARTGRPVRAYHAGLDPAIRAKNQADFVASEDMVICATVAFGMGIDKPDVRFVAHAGLPKSIEAYYQETGRAGRDGDPSVAHLFWGADDFARARQRIAEVEPERQPGERARLSALGALVETGGCRRRILLRHFGEELAEDCGNCDNCLGSPDAVDATTTAQKFLSAVFRTGQMFGAGYIEQVLTGQSSERSLMNGHEALSVWNIVDGDEVALLKPVHRALLLRDALRTNPHGGLEFGPAARALIKGEARLSLVVPPKRERKGRRAAPVAANPADNPLFEALRAKRRELAQEAGVPPYVIFHDSVLRDMAAQRPNSRAALSLLSGIGARKLDAYGEAFLAVIRDAG",
    "product": ""
   },
   {
    "start": 50630,
    "end": 51154,
    "strand": 1,
    "locus_tag": "ctg5_53",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_53</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_53</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 50,630 - 51,154,\n (total: 525 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1111:GCN5-related N-acetyltransferase (Score: 111.3; E-value: 7.9e-34)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_53 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13302.10 (Acetyltransferase (GNAT) domain): [13:155](score: 93.6, e-value: 1.8e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_53 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF13302.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016747' target='_blank'>GO:0016747</a>: acyltransferase activity, transferring groups other than amino-acyl groups<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_53\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCTTTGCGAGCCCCACCCCGACCCTGACGACCGAGCGGCTGAGCTTGCGCGGCCACCATCCCGACGATCTCGACGCGCTGGCGGCGATGTGGGCCGATCCCGCCGTATACGGGATGATCGGCGGCAAGCCCCGTTCGCGCGAAGAGGTGTGGATTCGGCTGCTCCGCTCGATCGGTTGCTGGACGGTGTTCGGCTATGGCGCCTGGGTGGTGTGCGACCGGGCGACGGGTGCGGTGCTGGGCGATATCGGGCTGCTCGAGTCGCGGCGGGCGATTATACCGGAGTTGACGGTGCCGGAGGTGGGCTGGACCTTGGTTCCAGCGGCGCATGGCCAGGGCTATGCGGGTGAGGCGATGCGCGCGGTGCTGGACTGGGCGGATGCGAACGGCATCGACCGGACCTGCTGCATCATCGATCCGGGCAATGCCGCGTCGATCCGGCTGGCCGAGAAGCTGGGCTACCGCGCGCCGGTGGAGGGGGTTTATTACGAGCGGCCGATCCTGATCTTCCACCGGGTATAA",
    "translation": "MTFASPTPTLTTERLSLRGHHPDDLDALAAMWADPAVYGMIGGKPRSREEVWIRLLRSIGCWTVFGYGAWVVCDRATGAVLGDIGLLESRRAIIPELTVPEVGWTLVPAAHGQGYAGEAMRAVLDWADANGIDRTCCIIDPGNAASIRLAEKLGYRAPVEGVYYERPILIFHRV",
    "product": ""
   },
   {
    "start": 51507,
    "end": 52322,
    "strand": 1,
    "locus_tag": "ctg5_54",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_54</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_54</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 51,507 - 52,322,\n (total: 816 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_54 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04116.16 (Fatty acid hydroxylase): [94:230](score: 104.0, e-value: 8e-30)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg5_54 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04116.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF04116.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n   PF04116.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008610' target='_blank'>GO:0008610</a>: lipid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_54\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_54_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACGCTTGCCCTGATCCTGTCCGCCATCGCCATGACGCTGATCGTCGGTGTCCGCTATCTACTCGCCTCGGGCGCGTTCGCGCTGGCGACCCGGGCGCGGCATCCCGATCTCTATGCCGGTCTCGATCCGCAGATCCGGCGCGAGATCGGCTGGAGCCTGGCCTCGGCCGCGATCTATGGCGTGCCGGCCGGCATCGTCGCTTGGGGGTGGCAGAATCGCGGCTGGACGCAGATTTACGCCGACGTCCATGCCTATCCGCTCTGGTATCTGCCCGTCTCGGTCCTGCTCTATCTGATCGCGCACGATAGTTGGTTCTACTGGACGCATCGCTGGATGCACCGGCCCGCCATCTTCAAGCGCGCGCATGCCGTCCATCACGCCAGCCGACCGCCGACCGCCTGGGCGGCGATGGCGTTCCACCCGATCGAAGCGGTAACCGGCGCTGTGGCCATTCCGCTACTGGTCTTCGTGATTCCGATCCATGTCGGCGCACTCGGCTTGGTGCTGACGATCATGACGGTTATGGGCGTGACCAACCACATGGGCTGGGAAATCTTTCCCCGTTTCCTGTGGCAGGGGCACCTGGGGGGGTGGCTCATCACTGCGAGCCACCATCAACGGCATCACGAGCAATATGGGTGCAATTATGGACTCTACTTCCGTTTCTGGGATCGACTGTGCGGGACGGACCGGGGACTGGGAGATTTCGCGCGCGCCCATGCGCAGGCGGCGCGGCGCGTCGGTGCTGCTGGCGCTGGCCAGCCTGCCGCTGATCGGCGCGGCGCCGGTCAGCCGGCTGGACATCGGGATTGA",
    "translation": "MTLALILSAIAMTLIVGVRYLLASGAFALATRARHPDLYAGLDPQIRREIGWSLASAAIYGVPAGIVAWGWQNRGWTQIYADVHAYPLWYLPVSVLLYLIAHDSWFYWTHRWMHRPAIFKRAHAVHHASRPPTAWAAMAFHPIEAVTGAVAIPLLVFVIPIHVGALGLVLTIMTVMGVTNHMGWEIFPRFLWQGHLGGWLITASHHQRHHEQYGCNYGLYFRFWDRLCGTDRGLGDFARAHAQAARRVGAAGAGQPAADRRGAGQPAGHRD",
    "product": ""
   },
   {
    "start": 52345,
    "end": 52665,
    "strand": 1,
    "locus_tag": "ctg5_55",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_55</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_55</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 52,345 - 52,665,\n (total: 321 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_55 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF09912.12 (Uncharacterized protein conserved in bacteria (DUF2141)): [1:94](score: 83.7, e-value: 9.1e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_55\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCCGGCTGTGCTTGACCGCCGATCCGGACAATTTTCCCGCCTGCGTCGATGACGCGCGCGCGCTGACCCGCTCGGTGCCGGCGGGGCAGCGCGCCATCCATCTCGACGGCCTGCCCCATGGCCAGTACGCCGCCGCCGTCATCCATGACGAGAACAACAACGCCAAGCTGGACACGCTGGCCGGCATTCCCCGCGAGGGCTTTGGCTTCTCCCGCAATCCGGCGATCCATTTCGGCCCGCCCCGTTTTACGGCCGCACGCTTCGCGCTCGATTCTGTTGCCGAAACACAACAGATTCGGATGCGATACATATTCTGA",
    "translation": "MIRLCLTADPDNFPACVDDARALTRSVPAGQRAIHLDGLPHGQYAAAVIHDENNNAKLDTLAGIPREGFGFSRNPAIHFGPPRFTAARFALDSVAETQQIRMRYIF",
    "product": ""
   },
   {
    "start": 52738,
    "end": 53622,
    "strand": 1,
    "locus_tag": "ctg5_56",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_56</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_56</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 52,738 - 53,622,\n (total: 885 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_56 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06629.15 (MltA-interacting protein MipA): [49:294](score: 117.3, e-value: 1.2e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_56\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGCGCCTTTTTCCGCGCGTTGCCGCCCCGCTCATCGCTTCGGCGGCTCTATCCCTGTCCCTGCCCGCCCATGCGCAGGACCTCCCCGCGGCCGATGCTTCCGATGCCGCCGCTGTTGGCGCTCAGATGGGCAAGAATACCATCACGCTCGGCTTGGGCGCGGCCTATCTGCCCGATTATCAGGGGTCGAACGATTATCAGTTCACGCCCGCACCCGCCGGCTTGGCCTATATTGATGGGCATACGATCACCTGGATCGGCAATCGCCTGTCGGTCGACCTGATCGGCGACCGGAGCAATCCGGGTTGGGATTTTCAGGCCGGGCCGGTCGGCGTCGTCAATCTGGACCGTACCGCGCCGTCGCGCATTGATGATCCCCGCGTCCGCGCGCTGGGCAAGATCGGCGCGGCGGTCGAACTGGGCGGCTATGTCGGCATCGGCAAGGTGGGCGTGGTCACCAGCCCCTATGACCGCCTGTCCGTCGCGCTCAGCTATCGCCACGACGTCACCGGCGTGCATGACAGCGGCATCTGGCAGCCCAGCATCAACTATTTCACGCCGCTGTCGACCAAGGCGGCCGCCGGCCTGTTCGCGACCGCCGAACATGCCGGCGCGGGCTATGCCCGTCGCTATTATTCGATCACGCCGGGCCAGAGCGTGGCGAGCGGCCTGCCCATCTATGACGCGCGGTCGGGGTGGAAGAACTGGACCGCCGGTGCGCTGGGCACCTATTCGCTGACCGGCAATCTCCTTCAGGGTTGGAAGCTGGTCGGCAGCGTCGCCTATAGCCGCATGCTCAACGATTTCGGCGACAGCCCGATCGTGTCGCAGGCGGGTTCGCGCAGCCAGTGGCTGGGTGCGCTGGGCGTCGCCTATACCTTCTGA",
    "translation": "MRLFPRVAAPLIASAALSLSLPAHAQDLPAADASDAAAVGAQMGKNTITLGLGAAYLPDYQGSNDYQFTPAPAGLAYIDGHTITWIGNRLSVDLIGDRSNPGWDFQAGPVGVVNLDRTAPSRIDDPRVRALGKIGAAVELGGYVGIGKVGVVTSPYDRLSVALSYRHDVTGVHDSGIWQPSINYFTPLSTKAAAGLFATAEHAGAGYARRYYSITPGQSVASGLPIYDARSGWKNWTAGALGTYSLTGNLLQGWKLVGSVAYSRMLNDFGDSPIVSQAGSRSQWLGALGVAYTF",
    "product": ""
   },
   {
    "start": 53666,
    "end": 54178,
    "strand": -1,
    "locus_tag": "ctg5_57",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_57</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_57</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 53,666 - 54,178,\n (total: 513 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_57\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGCCGTTTCGCTTGTCTTGCCCCCTTGGCCCTGCTGGCACTGGCCGCCTGCGGCTCCAAGGACGGGGATACCGATTCGGATGTCGCGCCGGGCAATTTCACCCCGCCGGGAACCGCGCGCCCGACGCCGCTGGCGGGGGTGGCGCAGGTGACGCCGCTCAAGGCCTATATCGGCCAATATCCCAATGATGCGGTCGATGGAGTCACCTTCTTCGACCGGACCGAGGTGGCGGGTGCGCTGCACGATGCGGTGGGCGATCAGAAACTGGTGCAGCGGATCATATCACGTGGCGCGGTGACAGTGCCGATCTTCGCCATGGGGGCCACGGGGCTGGCCGCGCATGGCTGCACCCCGCATGACTGCGCCGACAACAATTGGACGATGCAGATGGATATGAAGACCGGCAAGGCGCAGGTCTGCTATCATGATCGCGATACGATGGGCGACCGAAGCCAATGGTATATGGGCGGCGCGCCCGTCACCCGCCCCGGGGAATGCCCGCAGGAATAA",
    "translation": "MRRFACLAPLALLALAACGSKDGDTDSDVAPGNFTPPGTARPTPLAGVAQVTPLKAYIGQYPNDAVDGVTFFDRTEVAGALHDAVGDQKLVQRIISRGAVTVPIFAMGATGLAAHGCTPHDCADNNWTMQMDMKTGKAQVCYHDRDTMGDRSQWYMGGAPVTRPGECPQE",
    "product": ""
   },
   {
    "start": 54234,
    "end": 54698,
    "strand": 1,
    "locus_tag": "ctg5_58",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_58</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_58</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 54,234 - 54,698,\n (total: 465 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_58 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08837.14 (Protein of unknown function (DUF1810)): [17:148](score: 175.4, e-value: 5.3e-52)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_58\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTTTGCCGGGCGGTTGCCGGGATATGCCCCATCCCTCTCCCGATCCGCTGACGCGCTTCGTCGAAGCCCAGGCGCAAGACCTTGCCACCGCTCTGGCCGAGTTGCGCGACGGGCGAAAGCGCAGCCATTGGATGTGGTATGTCTTTCCCCAGATCGCCGGGCTGGGGCGCAGCGAGACCGCGCGCTACTATGCGATCGCCGATGTCGTGGAAGCCCGCGCCTATCTGGCGCATCCGCTGCTCGGGCCCCGTCTGCACGAGGCGGTGCGCACCGCCTGCGCCGCGTCGGGATCGGCCGAGGCGGTGTTCGGTCCGGTCGATGCGATGAAGCTGCGTTCCTCGCTGACGCTGTTCGCGGCGGTGGCCGAGGACCCTGCGCCGTTCCAGGCGGGGCTCGACCGATTCTTCGACGGGCAGGGCGATCCGGCGACGCTTCGCCTGATCGGCCATGCGACCTCCTGA",
    "translation": "MALPGGCRDMPHPSPDPLTRFVEAQAQDLATALAELRDGRKRSHWMWYVFPQIAGLGRSETARYYAIADVVEARAYLAHPLLGPRLHEAVRTACAASGSAEAVFGPVDAMKLRSSLTLFAAVAEDPAPFQAGLDRFFDGQGDPATLRLIGHATS",
    "product": ""
   },
   {
    "start": 54749,
    "end": 55129,
    "strand": -1,
    "locus_tag": "ctg5_59",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_59</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_59</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 54,749 - 55,129,\n (total: 381 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_59\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGCGTACGATCATCACCGCCATTCTGGCCGCCGCCCTGCCGCTGGCGGCCTGTGGCTCCTCGACCGAAGCCACCGGCAACACCGCGACGGCGGCGGCTCCGTCCAACACCAGCGGGATGAGCGCGCAGGACCTGGGCGCCAAGGTCCGCAACCTGCCCGAGGGGCAGCGGCGCGGTGTGCTGTTCCGCGCGATCCGCGATGCCGGCACGAGCGGCGCGACCTGTCAGTCGGTGACCAGCATGACCGAGATCGCCCCGGTCAACGGCAACCCGACCTGGACGGCGGTGTGCGACAATGTCGCGCAGTGGACGATCGTACTGACCGCCGATGGCTCGGCCAGCGTGACGGGCCCCGGGCCGGTGAAGACCAAGGGATGA",
    "translation": "MKRTIITAILAAALPLAACGSSTEATGNTATAAAPSNTSGMSAQDLGAKVRNLPEGQRRGVLFRAIRDAGTSGATCQSVTSMTEIAPVNGNPTWTAVCDNVAQWTIVLTADGSASVTGPGPVKTKG",
    "product": ""
   },
   {
    "start": 55245,
    "end": 55940,
    "strand": 1,
    "locus_tag": "ctg5_60",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_60</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_60</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 55,245 - 55,940,\n (total: 696 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_60 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03167.22 (Uracil DNA glycosylase superfamily): [56:214](score: 84.3, e-value: 9.7e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_60\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg5_60_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGATATTCGTCTTCACGAAAGCTGGCTGGCCCCGTTACGGCCCGAGTTTGACGAGCCCTATATGAAGGCGCTCAAGACTTTTCTGGCGCAGGAGCGCGCCGCCGGGCAGCGCATCTTCCCCCGCCCGACCGAATGGTTCCGCGCACTCGACCTGACCCCGCTCGACCAGGTGCGCGTCGTCATCCTGGGGCAGGACCCCTATCATGGCGAGGGGCAGGCGCATGGCCTGGCCTTCTCCGTCCAGCCCGGCGTCCGGCCGCCGCCCAGCCTGGTCAATATCTACAAGGAGATGGCCGACGATCTGGGCATCGCCCCGCCCGGCCACGGCCTGCTCGACCATTGGGCGCGGCAGGGGGTGCTGCTGCTCAACTCGGTGCTGACCGTGCGCATGGGGCAGGCCGCTTCGCATCAGGGGCGCGGGTGGGAACGCTTCACCGACGCCGTCATCCGCGCCGTCGCCGCCAAGCCCGAGCCGGTCGTCTTTATCCTCTGGGGCGCCTATGCCCAGAAAAAGGCGGGCTTCGTGCGCGAGATGGGCGGCGGGCGGCACGGCGTGATCACGTCGGTCCATCCCTCCCCCTTGTCGGCGAGGGGCGGCTTTTTCGGCTCCAAGCCCTTTTCGCGCGCCAACGCCTTTCTGGTCGAGCATGGCCAAAAACCGATCGACTGGGCGCTGCCGCCGCTGCTCTGA",
    "translation": "MSDIRLHESWLAPLRPEFDEPYMKALKTFLAQERAAGQRIFPRPTEWFRALDLTPLDQVRVVILGQDPYHGEGQAHGLAFSVQPGVRPPPSLVNIYKEMADDLGIAPPGHGLLDHWARQGVLLLNSVLTVRMGQAASHQGRGWERFTDAVIRAVAAKPEPVVFILWGAYAQKKAGFVREMGGGRHGVITSVHPSPLSARGGFFGSKPFSRANAFLVEHGQKPIDWALPPLL",
    "product": ""
   },
   {
    "start": 56017,
    "end": 56328,
    "strand": 1,
    "locus_tag": "ctg5_61",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg5_61</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg5_61</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,017 - 56,328,\n (total: 312 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg5_61 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03831.17 (PhnA domain): [35:102](score: 100.2, e-value: 4.8e-29)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg5_61\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg5_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg5_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCCGACGAAGACTATGTCTATGACGAAGCGACCGGAGAATGGATCAGCGCGGCGGACGCCGCCGCCAAGGCCGGCACGGTCGGCGAGGATGATGCGGTGGTGGTGCGGGACTCGGTCGGCAATGTGCTGAGCGATGGGGATCAGGTGACGCTGATCAAGGACCTGACCGTCAAGGGCGCGGGCCAGACGCTGAAGCGCGGCACGCTCATCAAGTCGATCCGCCTGACCGGCGACGCGCAGGAAATCGACTGCAAGTTCGACGGGATCAAGGGACTCGTGCTGCGCGCGGAGTTTGTGCGTAAGCGGTAA",
    "translation": "MADEDYVYDEATGEWISAADAAAKAGTVGEDDAVVVRDSVGNVLSDGDQVTLIKDLTVKGAGQTLKRGTLIKSIRLTGDAQEIDCKFDGIKGLVLRAEFVRKR",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 38686,
    "end": 46791,
    "tool": "rule-based-clusters",
    "neighbouring_start": 28686,
    "neighbouring_end": 56791,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [
    {
     "start": 36921,
     "end": 36923,
     "strand": -1,
     "containedBy": [
      "ctg5_41"
     ]
    },
    {
     "start": 48522,
     "end": 48524,
     "strand": -1,
     "containedBy": [
      "ctg5_51"
     ]
    },
    {
     "start": 55284,
     "end": 55286,
     "strand": 1,
     "containedBy": [
      "ctg5_60"
     ]
    }
   ],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r5c1"
 },
 "r11c1": {
  "start": 51426,
  "end": 93954,
  "idx": 1,
  "orfs": [
   {
    "start": 52039,
    "end": 52986,
    "strand": 1,
    "locus_tag": "ctg11_43",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 52,039 - 52,986,\n (total: 948 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_43 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13668.9 (Ferritin-like domain): [66:231](score: 54.8, e-value: 1.2e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_43\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAGAACCCGACCTTTTCCCATGCCCCCCACCCCTATGATCGGCGCCACTATGATCGTCGCAACGTCCTTCGCCTGATCGCCACCTTTTCGACCGGCGCGCTGCTCGCCGGATGCGGCAGCGGCGGCGGAGACGATTCGATCGTCACACCGCCCGCCGCCACCACCCCCGTGCCCGTCGCCTCACCAGGGCACCCACTGAATCTGGCCCTGACGCTTGCCTATCTCGGCGGGCAATATTTCTCCTATGTCGCGCGCGGTGCACCGCTGCCGAGCGTGCTGACCGGAAACGGTGCGGGGGCGGTGACCGGCGCCCGGCAGATGCGTTTCAACGATTCCTCGATCGCCTGGCTGGCGGCGGATCTGGCGGATGACAAGGCAGCCCACGTCACCGCGCTGCGCGGACAGATAGGCGCGTCCGCGCCGGCGCAGCCCGCCATCGACCTGTCGCCGGGCGCATCGGGTGCGTTTTCGCTCGCCGCCCAGCGCGCCGGGATCGTCGGGTTGGGCCAGGCCTTCGATCCCTATGCCGACGACACTCATTTCCTGATCGGCGCGCTGCTGATCGAAAATGCCGTGGCGGCAAGCTATCGCCGATTGTTGCTGGTCGAACCGGATTCGGCGAACGGTGCGATGGCGGCGGCGCATCTGGCCGATTCCATCTATCATGGCGGGGTGATCCGGGCGCTGCTCGACGACCGTGCCGCCACGACGCCCGCGGTCGATGCGATGCTCGGCCGCATCGGCACGATGCTCGCCACGCTCGACGGCACGCAAGGCAGCGACCAGATCCTGCCCGGCGGCGATACGAACAGCTCCAACCTGCTCGACGCGGAAGGACGCCCCATCCCCTTTACCCGCACCGATCGGCAGGTGCTGAACGCGCTTTACCTCTCCGCCACCGGGCCGGGCGGGTTCCTGCCCCAAGGCGCGGTCGGCATCGCATGA",
    "translation": "MQNPTFSHAPHPYDRRHYDRRNVLRLIATFSTGALLAGCGSGGGDDSIVTPPAATTPVPVASPGHPLNLALTLAYLGGQYFSYVARGAPLPSVLTGNGAGAVTGARQMRFNDSSIAWLAADLADDKAAHVTALRGQIGASAPAQPAIDLSPGASGAFSLAAQRAGIVGLGQAFDPYADDTHFLIGALLIENAVAASYRRLLLVEPDSANGAMAAAHLADSIYHGGVIRALLDDRAATTPAVDAMLGRIGTMLATLDGTQGSDQILPGGDTNSSNLLDAEGRPIPFTRTDRQVLNALYLSATGPGGFLPQGAVGIA",
    "product": ""
   },
   {
    "start": 52926,
    "end": 53486,
    "strand": -1,
    "locus_tag": "ctg11_44",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 52,926 - 53,486,\n (total: 561 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_44 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01648.23 (4&#39;-phosphopantetheinyl transferase superfamily): [65:132](score: 26.1, e-value: 8e-06)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_44 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01648.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000287' target='_blank'>GO:0000287</a>: magnesium ion binding<br>\n  \n   PF01648.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008897' target='_blank'>GO:0008897</a>: holo-[acyl-carrier-protein] synthase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_44\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_44_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGTGCCTGCGCGACCTGATGACGGTGCCCTGCGGCGAGGCGATGGCGGCTGATCTGGGCAAGGGGCGGACTCTGCTCCTCGCGCCATCCGCCGCAGATCGGGATGCGGCGGCCGTGCGGATGGCGGGGCGCGCGACCGTGGTCAGCCGGAGCAGCACCTCGGCTTGCCATGCCGTCGCCTGGGCCAGAGGCGGGCGGATCGGCCTGGACGTGGAGACGGTGTCGCGTGTCGCACTGAACGCGAACGTCGACGATCCCTGGCTGGCCGATAGCGAGCGTCATTCCGTCATCGCGGCGGCGGACCCGGTAATCGAACTGGCCTGTCGGTGGGTCCTGCGGGAGGCCTATGGCAAGGCGCTAGGCGTCGGCCTTGCCCTGCCGCTCGATCGCCTTGTCTTTCACGGACGGGGCGGGCGGATCGTGCTGAAGACGCCCTGGCCCAGCGATGGATGGGATTTTGCCCTGTACCGCCGGGGTGAGACGCTGTGTGCCGTTGCCCATCATGCGATGCCGACCGCGCCTTGGGGCAGGAACCCGCCCGGCCCGGTGGCGGAGAGGTAA",
    "translation": "MCLRDLMTVPCGEAMAADLGKGRTLLLAPSAADRDAAAVRMAGRATVVSRSSTSACHAVAWARGGRIGLDVETVSRVALNANVDDPWLADSERHSVIAAADPVIELACRWVLREAYGKALGVGLALPLDRLVFHGRGGRIVLKTPWPSDGWDFALYRRGETLCAVAHHAMPTAPWGRNPPGPVAER",
    "product": ""
   },
   {
    "start": 53518,
    "end": 54291,
    "strand": -1,
    "locus_tag": "ctg11_45",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 53,518 - 54,291,\n (total: 774 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1133:Transcription regulator, crp (Score: 75.4; E-value: 6.3e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_45 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13545.9 (Crp-like helix-turn-helix domain): [168:242](score: 44.5, e-value: 1.2e-11)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_45 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF13545.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF13545.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_45\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCAGTCTTGCTTTGAGCAGCCATCGGCCCGCGCCCGCCCCGCGTGCGATCACCAGCGAATTGTTGCTGCATCGCCTGCGCAGTTTCGCCACCCTTGCCGCCCATGAGGTGGAACTGGTTCTGTCACTGGCCGAACCGCCCAAGAGCCATGCGGCGGGAACCAGCATCTGTCCCCGCGAGGACGGTAGCCCACACCCCCGCCTGATCGTCGGCGGCTGGGCTTGTCGTCCGCGCATCCTACCCGACGGCCGCCGCCAGATGCTGGGAGTGCTCCTGCCCGGCGACATGATGGGTGATCGGGGCGAGCGGCGGCCATTGGCCATGAACCCTGTCATCGCGCTGACCCCCGTGCGCACGATCGGCATCGCCCGGCTAGTGCAGGCGGTACGGATGGAGCCGCAGGACCATCCCGGCATCGTGCGTGCGCTCGCGGCGATCGATCGGTGCGAGGAGATGGCGCTGCTCGACCATATCGTCCGCCTGGGGTGCCAAAGCGCGTTGCAGCGGACCGCGCATCTGCTGCTCGAACTGCATCACCGGCTGTCGGTGATCGGCTTCGTGCACGGTGGCACCTTTCCGATGCCGCTGACCCAGGACACGCTGGGCGAGCTGTTGGGGTTGAGCCTGGTCCATATCAACCGGATCGTGTCGCAGATGCGGCGCGAGGAACTGGCCCTGATCCGCGGCGGGGTGGTGACGATCCAGGATTTTCCCCGGCTGGCGCTGCTCGCCGATCGGATCGACCCGACGAGCCATGCTGGCTCGGCCTGA",
    "translation": "MGSLALSSHRPAPAPRAITSELLLHRLRSFATLAAHEVELVLSLAEPPKSHAAGTSICPREDGSPHPRLIVGGWACRPRILPDGRRQMLGVLLPGDMMGDRGERRPLAMNPVIALTPVRTIGIARLVQAVRMEPQDHPGIVRALAAIDRCEEMALLDHIVRLGCQSALQRTAHLLLELHHRLSVIGFVHGGTFPMPLTQDTLGELLGLSLVHINRIVSQMRREELALIRGGVVTIQDFPRLALLADRIDPTSHAGSA",
    "product": ""
   },
   {
    "start": 54294,
    "end": 56516,
    "strand": -1,
    "locus_tag": "ctg11_46",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_46</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_46</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 54,294 - 56,516,\n (total: 2223 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1216:exopolysaccharide biosynthesis domain protein (Score: 388.8; E-value: 6.8e-118)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_46 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02706.18 (Chain length determinant protein): [34:119](score: 29.3, e-value: 8.7e-07)<br>\n \n  PF13807.9 (G-rich domain on putative tyrosine kinase): [404:471](score: 31.2, e-value: 1.7e-07)<br>\n \n  PF01656.26 (CobQ/CobB/MinD/ParA nucleotide binding domain): [552:715](score: 27.2, e-value: 3.5e-06)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_46 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02706.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009103' target='_blank'>GO:0009103</a>: lipopolysaccharide biosynthetic process<br>\n  \n   PF02706.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_46\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_46_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCCAGCCTGCCGATTCGTTACGATAGCGCTACTTTCGAAGGCGCTCGTTCATCACCCGCCTATGTCGAACGGGGCCCGCTGCCTCAAAACGGGGTCATGGACCTGATCAAGGCCTATCGCCGCCATCTCACGCTGTTCCTGGCGGTCGCGGGCGGCATCCTGGCGCTGGTCGCGGCCTATAGCTGGCTGCAGACCCCGCGCTATACGGCGACCGCCACGCTGGTCATCGCGCCCCAGCCCGCGCAGATCGGGGCGGAGCGAACCAGTGCCCTCAGTGATCCGGCCGCCGATTCCAGTGTCGATACGCAGGTCGAATTGCTGAAGAGCCGGACGCTCGCGGGGCTGGTCGTCGACCGGCTGGGATTGGCCGAGGAAGCGCGGTTCCAGGCGCTGGTCCACAACCCCTCGATCCTCGAGCGGATTCCTGGATTGGAGCGCCCACCCACGCCCCTGCCGGCCTCGGCCCGGCGTGATGCGGCGATCGATCGGCTGGCAAGTGGCATCGAGGTGCATCGCAATGCGCAGACCTTCATGCTCAGCCTGTCCTTCGAGCATCCCGACCGCGAGCTCGCGACCGCGATCGTCAACAGCTATGCGCAGGAATTCGTCGCTCAATCGGGCGCGGTGAAGCGCGAAGGCGCGGACGCCGCCGCCGCGTTGCTGCGCGGCCAGCTCGACGAGGCGCGCCGCGAGGTCGAGGAGGCGGACGGCGATCTGGGCCGCTACAAGGTCGCGCACAATCTGATGAGCGTGCAGGGGGGCACCATCGCCGAGCAGCAGCTATCCTCGCTCGACGGCCAGGTCGCACTCGCCCGCGCCGGAGAGGCGGAAGCGACCGCCCGCCTTCAGACCGCCCGCCAGCAGCTCGCCCGCGGTTCCAAGGGCGACGATCTGGGCGAGGCGCTGGGCTCGCCGGTGATCCAGCAACTGCGCAGCCAGCGCGCGACGGTCAGCGCGCAGGTCGCCGATCTGGGCGGCAAGTACGGACCCAAATATCCCCCGCTTGCGGCCGCACAGCGCCAGGTCGCCGATATCGACGCGCAGATCGAAGGCGAGATCAAGCGCACCATCTCCAATCTGGAGGCGCAGCGCGATGTCGCCGCTCGGCGGACCGCCTCGCTGGCGGGCAGCGCGTCGGGTGCGCGATCGCAGGTGGTGAACAACAATGTCGCTTCAATCGCGCTGGGCGGGCTTCAACTCCGTTCGGACACCGCGCATCAAAGCTATGCACTGTTGCTGACCCGACTGAACGAGATCGGCGCGCAGGCCGCCTCCACCCGGTCGGACGCACGCATCGCCAGTCTCGCCGCGTTGCCCACGCATCCCAGTTCGCCCAACCGGCCGATCAACATGCTCGTCGGCGCGCTGCTGGCGATCGCAATCGGGCTGGGCGTGGTCTTCATGCGGCAGGGGACCGATCGCGGCATCCGTACGCTGGAAGATGTCGAGGGACGGTTGCAGCTTCCCTATCTGGCGGGGCTGCCGACGCTGAACTCGGCGGTGCGCCATATCGGCGGCAGCGACCCGATCAGTGCGCTGGTCGACCATAGCGGCTCGGCCTATGCGGAGGGGTATCGCAACCTGGCCGCCTCGGTCCTGCAATCGGCGGCGGCCGGAACGGTGCGGACGATCGCGCTGACCTCTGCGCTACCCAATGAGGGCAAGACCACCGCCGCGATCGGGCTGGCGCGGATCGTCGCGATGAGCGGGGTCAGCGTGGTGCTGGTCGATGCCGATATGCGCCGGCCGAGCATCGCCAATGCCCTGGGCCTGCGTCCGGCGGTCGGCTTGCAACAGGTGCTGGAGGGCGAGGCGCGGCTGGATGAGGCACTGCTCCGCGATCTCGATTCGCCGCTGACCATCCTGCCCATGGTTCGCGCCGGACTGGGCGGTGCGGCGGCGTTGGGCGGCGCGGGCTTCGACGCGCTGATCGAGGATTTGAAGGCGCGGTTCGATGTCGTGATCTTCGACGCCTCGCCGGTGCTGCCGGTGGTCGACGGGCGGCTGGTCGCCAAGAAGGCGGATTCGACCGTGCTACTGGTCCGCTGGCGCAAGACCCCCGACGCGGCGGTCGAGATGGCGATCCACCTGCTCCAGACACTGGGCGTCAAGATGACCGGCGTGGCGCTCAGCCGGGTCGATCTTCATGCGCTCGCCCGTTCCGGCTATGGCGATCCGGCGCAGTTCATGGGGTCCTACAACACCTATTATGCGAATTGA",
    "translation": "MASLPIRYDSATFEGARSSPAYVERGPLPQNGVMDLIKAYRRHLTLFLAVAGGILALVAAYSWLQTPRYTATATLVIAPQPAQIGAERTSALSDPAADSSVDTQVELLKSRTLAGLVVDRLGLAEEARFQALVHNPSILERIPGLERPPTPLPASARRDAAIDRLASGIEVHRNAQTFMLSLSFEHPDRELATAIVNSYAQEFVAQSGAVKREGADAAAALLRGQLDEARREVEEADGDLGRYKVAHNLMSVQGGTIAEQQLSSLDGQVALARAGEAEATARLQTARQQLARGSKGDDLGEALGSPVIQQLRSQRATVSAQVADLGGKYGPKYPPLAAAQRQVADIDAQIEGEIKRTISNLEAQRDVAARRTASLAGSASGARSQVVNNNVASIALGGLQLRSDTAHQSYALLLTRLNEIGAQAASTRSDARIASLAALPTHPSSPNRPINMLVGALLAIAIGLGVVFMRQGTDRGIRTLEDVEGRLQLPYLAGLPTLNSAVRHIGGSDPISALVDHSGSAYAEGYRNLAASVLQSAAAGTVRTIALTSALPNEGKTTAAIGLARIVAMSGVSVVLVDADMRRPSIANALGLRPAVGLQQVLEGEARLDEALLRDLDSPLTILPMVRAGLGGAAALGGAGFDALIEDLKARFDVVIFDASPVLPVVDGRLVAKKADSTVLLVRWRKTPDAAVEMAIHLLQTLGVKMTGVALSRVDLHALARSGYGDPAQFMGSYNTYYAN",
    "product": ""
   },
   {
    "start": 56534,
    "end": 57862,
    "strand": -1,
    "locus_tag": "ctg11_47",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_47</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_47</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,534 - 57,862,\n (total: 1329 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_47 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF10082.12 (Putative beta-barrel porin 2): [65:442](score: 248.3, e-value: 1.2e-73)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_47\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGATCCTGTGCGGCGCGCCTCGGCGGCTGTCGCGCCTGGCGTCGCTGATGATCGCCGGCGCCTGTACCGCGCCGCTGGGCGCTCAGCTGTTGCAGGATGTACCGACCGTCCAGGTGCCGCCCGAGCCGCCGCTGACCGATGCACGCTCGGTCTTCGCTCGCGAACGCGACACGGGTGTCGCCGACCGGACATTGCCGGCCTTCACCGCGCAAGGGGTCACGGTCGGTGCGTTCGATGTGTTTCCGGCGGTGTCGGTCGGGGGGCTGTTTACCTCCAACCTGTTCGCCAACAATGAGGACCGGCGCAGCGATGTCGCTCTGGTTGTCCGGCCGGAGGTGACGGTGCGCACCAGCGGCGGCCCCTATCGCCTGACCGCCTATGGCCGCGCCGACCTACGCCGCTTCGCCACCTATGCCAGTGAAAATACCGAGGAGGGCATGGCGGGGCTGGAAGGCAGCATTGCGGTCGGCGCGCTCAGCAGCCTCGCGGCGGGGGCCAGCTATGGCAGCTTCGTCAATCCGCGTTTCGCGCCGGACTCGCCGATCGAGGCGGCCAAGCCGCTCGAATATAATGCGCTCAACGGCTATGCGGGTGCGACGATCGAGCAGGCGAACACCCGCATCATTTTGCGCGCCGATGTCATCGACCTGCGCTTTCGCGATACGCCTGCGCGGGACGGCGGCACGCTGTTCACCCGCGACCGCGACCGGACCCGCTATCAGGCACTGGTGCGGGTCGAGCGCGCACTGAGTCCCGCCGTTTCGATTTATGGCGCCGCCAGCCTGAACAAGGTCGATTTCCGCCTCGCACCTGGTGGTACGCGCGATTCCAAGGGCTATGGCGTCTATCTCGGGTCGAGCTTCCAGGTTACCGATCTGATGCGCGGCGATGTCCGCGTCGGCTATATTCGCCAGGACTTCGATCGGGCCGGTATTCGTCCGCTTTCAGGTCTCGGGGCGCTGGGCAAGCTCGTCTATTTCCCGACCCGGTTGTGGACGCTAACCGCGACCGCCGAGAGCAGTATTCAGGACAGCGGCGTGCCGGGAACCGGCGGCTTCTTGCATCGCGGCGGATCGTTGCGCTCGGATCACGAGCTTCGCCGTTACCTCATCGCCTCGGTCGAGGGGGGCTATTACCGCGACACCTATCGCGGCATCCCTCGGCGGGATTCGCTTCCCTATGCCGATGCGGGCCTGACCTATCTGTCGCGCAACCATTGGAATGCGCGGCTCGGCTATCGCTATCTCGCGCGGGATTGCACCTGCGGGTCCGGCGTCACCAATTTCGACGATCATCGCGTCTCACTGACGCTGACCCTTCAACGATAG",
    "translation": "MILCGAPRRLSRLASLMIAGACTAPLGAQLLQDVPTVQVPPEPPLTDARSVFARERDTGVADRTLPAFTAQGVTVGAFDVFPAVSVGGLFTSNLFANNEDRRSDVALVVRPEVTVRTSGGPYRLTAYGRADLRRFATYASENTEEGMAGLEGSIAVGALSSLAAGASYGSFVNPRFAPDSPIEAAKPLEYNALNGYAGATIEQANTRIILRADVIDLRFRDTPARDGGTLFTRDRDRTRYQALVRVERALSPAVSIYGAASLNKVDFRLAPGGTRDSKGYGVYLGSSFQVTDLMRGDVRVGYIRQDFDRAGIRPLSGLGALGKLVYFPTRLWTLTATAESSIQDSGVPGTGGFLHRGGSLRSDHELRRYLIASVEGGYYRDTYRGIPRRDSLPYADAGLTYLSRNHWNARLGYRYLARDCTCGSGVTNFDDHRVSLTLTLQR",
    "product": ""
   },
   {
    "start": 57859,
    "end": 58449,
    "strand": -1,
    "locus_tag": "ctg11_48",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_48</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_48</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 57,859 - 58,449,\n (total: 591 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Poly_export<br>\n \n  transport (smcogs) SMCOG1186:polysaccharide export protein (Score: 116.6; E-value: 1.7e-35)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_48 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02563.19 (Polysaccharide biosynthesis/export protein): [44:117](score: 63.7, e-value: 1.5e-17)<br>\n \n  PF10531.12 (SLBB domain): [122:167](score: 39.7, e-value: 3.4e-10)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_48 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02563.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015159' target='_blank'>GO:0015159</a>: polysaccharide transmembrane transporter activity<br>\n  \n   PF02563.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015774' target='_blank'>GO:0015774</a>: polysaccharide transport<br>\n  \n   PF02563.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_48\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_48_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMPSGVSRNSATRLMTLFLATALPAVAPGQEVATTTNGASAQLPIYNYVLSGGDRVRVVVFGDPALGGEFTIAGSGMIAMPLIGEVDVRGLTSTQLQDRIVARLADGYIKDPRVAVEVLSTRPFYILGEVNKPGQYPFANGLTVLGAVAQAGGYTYRAKTKQVFIKHAGQDAEVAEPVTATTLVAPGDTIRIKERWF\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCCAGTGGCGTATCGCGAAATTCTGCGACCCGTCTGATGACGCTGTTCCTGGCCACCGCACTGCCGGCGGTAGCTCCGGGGCAGGAGGTCGCCACGACCACGAACGGCGCTTCGGCGCAGCTTCCCATCTATAATTATGTGCTGTCGGGCGGCGACCGGGTGCGGGTCGTGGTGTTCGGCGATCCGGCGCTGGGTGGCGAGTTCACCATCGCCGGGTCGGGGATGATCGCGATGCCGCTGATCGGCGAGGTCGATGTGCGCGGCCTGACCTCCACCCAGTTGCAGGACCGCATCGTTGCACGGCTGGCCGATGGTTATATCAAGGACCCGCGCGTCGCGGTCGAAGTATTGTCGACCCGCCCTTTCTACATCTTGGGCGAGGTCAACAAACCCGGCCAATATCCCTTTGCCAACGGATTGACCGTGCTGGGCGCTGTGGCGCAGGCGGGCGGCTATACCTATCGCGCCAAGACCAAGCAGGTCTTCATCAAACATGCCGGCCAGGATGCGGAGGTCGCGGAACCCGTCACCGCGACGACGCTGGTGGCGCCGGGCGACACCATCCGGATCAAGGAACGCTGGTTTTGA",
    "translation": "MPSGVSRNSATRLMTLFLATALPAVAPGQEVATTTNGASAQLPIYNYVLSGGDRVRVVVFGDPALGGEFTIAGSGMIAMPLIGEVDVRGLTSTQLQDRIVARLADGYIKDPRVAVEVLSTRPFYILGEVNKPGQYPFANGLTVLGAVAQAGGYTYRAKTKQVFIKHAGQDAEVAEPVTATTLVAPGDTIRIKERWF",
    "product": ""
   },
   {
    "start": 58792,
    "end": 59445,
    "strand": 1,
    "locus_tag": "ctg11_49",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_49</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_49</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 58,792 - 59,445,\n (total: 654 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Bac_transf<br>\n \n  biosynthetic-additional (smcogs) SMCOG1146:sugar transferase (Score: 265.7; E-value: 1.4e-80)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_49 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02397.19 (Bacterial sugar transferase): [20:211](score: 188.1, e-value: 1.2e-55)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_49\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_49_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGTTTCCTATATATCCCCCGCGCCCCCATCCCTCTCACGCCCCGGGCTGTTGCAGACGGCGGACGTGATTCTGGCGCTTATCCTGTTGGTCCTGCTGTCCCCGCTGATGCTGGCCGTGGCGGCGCTGATCGCGCTGGAGAGCGGCGGCGGCACACCCATCTATGGCCATCGCCGTTACGGCAAAGATGGGCGGACCTTCCTATGCTACAAATTCCGCTCGATGGCGCTGGATGCCGATGCGCGGCTGGCCCGGCTGGTGGCGCATGATCCTGCCGCACGCGCCGAATGGGCGCGCGACCACAAGCTGCGTCATGATCCGCGCGTCACCCGGATCGGCCGCTTCATCCGCCGCACCAGCCTCGACGAACTGCCGCAGCTGTTCAATATCCTGCGCGGCGAAATGAGCCTGGTCGGCCCGCGCCCGATCGTGGCGGCCGAAGTGCGGCGCTATGGCCGCCATTTCGTCGATTATTGCTCGGTGCGGCCCGGGATGACCGGCATCTGGCAGATCAGCGGGCGCAACGACATCGGCTATCGGCGGCGGGTCGCGATGGACTGCCTGATGGCGCGGCGCATGTCGCCCCGACTCTATGCCGAGGTGCTGATCGGCACTGCGCGCTGCGTTGTGACCCGCCAAGGTGCCTATTGA",
    "translation": "MTVSYISPAPPSLSRPGLLQTADVILALILLVLLSPLMLAVAALIALESGGGTPIYGHRRYGKDGRTFLCYKFRSMALDADARLARLVAHDPAARAEWARDHKLRHDPRVTRIGRFIRRTSLDELPQLFNILRGEMSLVGPRPIVAAEVRRYGRHFVDYCSVRPGMTGIWQISGRNDIGYRRRVAMDCLMARRMSPRLYAEVLIGTARCVVTRQGAY",
    "product": ""
   },
   {
    "start": 59455,
    "end": 60642,
    "strand": -1,
    "locus_tag": "ctg11_50",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 59,455 - 60,642,\n (total: 1188 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1045:glycosyl transferase group 1 (Score: 115.4; E-value: 5.9e-35)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_50 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13579.9 (Glycosyl transferase 4-like domain): [17:209](score: 56.4, e-value: 4.6e-15)<br>\n \n  PF00534.23 (Glycosyl transferases group 1): [225:362](score: 84.6, e-value: 6e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_50 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00534.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016757' target='_blank'>GO:0016757</a>: glycosyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_50\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_50_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAAGCCCCGCATCCTGCATCTCTCCAGCCTCTATCCGCCACATATCGTCGGCGGCGCGGAGCGATCGGTGTCGATGCTGGCGGAGGCGCAGGCGGCCGAGGGTTGGAATGTCGCCGCCGCCTGCCTGACTCCCAGCGAAGCGGTGGAAGAGGAGCGGCACGGCGTCACCGTCTTCCGCATGCCGCACGGCAACGACTTCTGGCTGGAGGACTGGGCGGCGCATAGCCAGCGCCAGCGTGAATGGGCCAAGTTCAAGCAACAGGCCAATTTCGCGATCGAACGCCGCTTTGGCGAGGTGCTCGACCGATTTCGCCCTAATGTCGTCCACACCCATTCGATGGTCGATATCTCGACCCGGGTCTGGCACGCGGCGCGCGCGCGCGGGATTCCGATCGTCCACACGTTGCGCGACTTCGACCTGCTGTGCGCCGCCAGTTCCATGTACCGGGAGACGGGACCTTGTGTGGGACGGCATCTGAAATGCCGGGTGCTGACCTTCGCCAAGCAGCTCGACCAGCGTCTCGTCGCGTCGGTGACGGCGGTGGGGGAGGAAGTGCTTTCGCGGCATTTGCGCTATGGCTTTTTTGGTCATGTGCCGGCCGACCGGCGACGCGTCATCTGGAACACGGCGGCGGTCGAGGGGGTGGAGGCGGACTATACCAAGCCCGTGCTCACCGGTCCCATCACCTTCGGCTATCTGGGGCGGATCAGCCCGGAAAAGGGGGTCGATACGCTGCTCAAGGCCGCACGGCTGTTGCCGCCTAACGGCTGGCGGTTGCTGATCGCCGGCGCGGCGCTGGGCGATCCGGCGCCCTATCACGCGCTTGCCGAAGGGCTTCCGGTCGAATTCATCGGCTTTCAGCGTCCCAAGGTGCTATTCGACCAGATCGACTGCCTCGTCGCGCCGTCCTTGTGGGCCGAGCCGCTCGGGCGGACCGTGCTCGAGGCCTATCAGGCGCAGGTACCCGTCATCGGCGCGCGCAGCGGCGGGATTGCCGAGATCATCGCCGATGACGCTTGGCTGGTGCCGCCGGGCGATGAGGCGGCGCTGGCGGCCCGGATGCGCGCGCTGCTGGAGATAGGGCGCCCCGGCCCGCCCAAGGGCCGGGCGCGGGTAGTCGCCCGCACCACGCCCGAGGCGGTGGCGCGGGCCTTCGCGCAAGTTTACGCTCAGCTTCTTCAATAG",
    "translation": "MKPRILHLSSLYPPHIVGGAERSVSMLAEAQAAEGWNVAAACLTPSEAVEEERHGVTVFRMPHGNDFWLEDWAAHSQRQREWAKFKQQANFAIERRFGEVLDRFRPNVVHTHSMVDISTRVWHAARARGIPIVHTLRDFDLLCAASSMYRETGPCVGRHLKCRVLTFAKQLDQRLVASVTAVGEEVLSRHLRYGFFGHVPADRRRVIWNTAAVEGVEADYTKPVLTGPITFGYLGRISPEKGVDTLLKAARLLPPNGWRLLIAGAALGDPAPYHALAEGLPVEFIGFQRPKVLFDQIDCLVAPSLWAEPLGRTVLEAYQAQVPVIGARSGGIAEIIADDAWLVPPGDEAALAARMRALLEIGRPGPPKGRARVVARTTPEAVARAFAQVYAQLLQ",
    "product": ""
   },
   {
    "start": 60639,
    "end": 61823,
    "strand": -1,
    "locus_tag": "ctg11_51",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 60,639 - 61,823,\n (total: 1185 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1045:glycosyl transferase group 1 (Score: 156.9; E-value: 1.4e-47)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_51 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13439.9 (Glycosyltransferase Family 4): [17:210](score: 74.7, e-value: 9.4e-21)<br>\n \n  PF13692.9 (Glycosyl transferases group 1): [224:358](score: 86.8, e-value: 1.8e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_51\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_51_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGAGCGGGATGCGCATCCTTCATGTCAGCTCGGTCTATCCCCCGCACGTCGTCGGTGGCGCGGAGAAGGTCGTCGCCATGCTCGCCGAGGCGCAGGTGCAGCGCGGACATCAGGTGGGCGCGGCCTATCTGTCGCGCAAGGCGCAAGAGGCGGGCGAGCGACACGGCGTCACCGTCCTGCCGCAGCGCAGCCGCAACCTAGTCTGGATGGAGGAGGTGTTCGCCGCCCCGCGCGCGATGCGGACCGCCAACAAATTGGGGCAGATGGTCAATTATCGCGGGGCCGCCGATGTCGCGCGTGCGGTCGCGCAGTTCCGCCCCGACATCGTCCACACCCATTCGATGGTCGAGCTGCCGCCGATGATCTGGTCGGCGATCGCCGACAGCGGCGCGCGCAGCGTCCATACGCTGCACGATTACGACTTGATCTGCTCGCGCGCGTCGATGTTCCGCGACGGGCGCTCCTGTGTCGAGCGCCACGCGTCCTGCCGGATCACCGGTGCGTGGAAGGCACGCTTCGCCAAGCGGATCGATGCAGTCGCGGCGGTGTCGCAGCCGGTGCTCGACGAACATCGCCGCTTCGGCCTGTTTCAGGACACGCGCGCGAAGGTGATCTGGAACGGGGTGGAGGTGCCGCCAGCGCGGCAGCGCTCCGACCGGACAGGGGACTTTATCTTCGGCTTTCTCGGACGGCTTGTCCCCGAAAAGGGAATTGAGACACTGCTCGCCGCCTGTCGTCTCCTACCCGAGACCGGCTGGCAGTTGCAGGTAGCGGGCCGTGCACAAGAAGGCGATGCCGCGTACCGTGCCTTGGCCGAGGGGATGCCGGTCGAATTTCTGGGCTTCACCGATCCGCAGGCGTTTCTGCGCGGCATAGACCTGCTCGTCGTGCCGTCCATCTGGCGTGAGCCGTTCGGGCTGACCGTCGTCGAGGCCTTTGCCCAAGGCGTGCCCGTGATCGGGTCACGGCTTGGCGCGATCGGCGATCTGGTCGGTGCGGTGGGCGAGGAATGGCTGGTGCCACCGGGCGACCCGGCGGCGTTGGCCGCGCGGATGCTGGCGGCGATACACGACGGGCGGTCGGCCTTGCCCGCGCCCCCCGCCTTTGACGGTGTGCTGTCGGTGGTGACGCCGCAGCGGATGCTCGACGCCTATGACGTCCTCTATGCGGAGGTGCTGGCGTGA",
    "translation": "MSGMRILHVSSVYPPHVVGGAEKVVAMLAEAQVQRGHQVGAAYLSRKAQEAGERHGVTVLPQRSRNLVWMEEVFAAPRAMRTANKLGQMVNYRGAADVARAVAQFRPDIVHTHSMVELPPMIWSAIADSGARSVHTLHDYDLICSRASMFRDGRSCVERHASCRITGAWKARFAKRIDAVAAVSQPVLDEHRRFGLFQDTRAKVIWNGVEVPPARQRSDRTGDFIFGFLGRLVPEKGIETLLAACRLLPETGWQLQVAGRAQEGDAAYRALAEGMPVEFLGFTDPQAFLRGIDLLVVPSIWREPFGLTVVEAFAQGVPVIGSRLGAIGDLVGAVGEEWLVPPGDPAALAARMLAAIHDGRSALPAPPAFDGVLSVVTPQRMLDAYDVLYAEVLA",
    "product": ""
   },
   {
    "start": 61820,
    "end": 62818,
    "strand": -1,
    "locus_tag": "ctg11_52",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 61,820 - 62,818,\n (total: 999 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_52 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF16317.8 (Glycosyl hydrolase family 99): [30:312](score: 132.6, e-value: 1.9e-38)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_52 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF16317.8: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016798' target='_blank'>GO:0016798</a>: hydrolase activity, acting on glycosyl bonds<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_52\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGCTGGTCGCGGCGCAGCGTCGTCGGTGCCGGGTTGGCGCTGGCGGCAGCACCGATCTCGGCGGGCCCCCGGCGTTACCCGCGTCAGGTGCTGGCCTTCTATTATCCCTGGTATGGCAATCCGACGACCAGCGGGCGTTGGCTTCATTGGCAGGGTCCGCATGGCGAAGCCCCCCGGCAGAGCCCGACGCTCAACTATCCGGTGCTCGGTCTCTACGACAGCCATGATGCGGGCGTGATCCGCACCCATGTCGCCCAGGCCAAGGCGGCGGGGATCACGGCGCTCATCGTCAGCTGGTGGGGACCGAATTCGTTTGAGGACAAGGCGCTGCCGATGATCCTTGAGGCCGCACGGGCGGCGGGCCTACATGTCACCGTCTATCTCGAACAGCAGAAGGACGGGGCGGCGGGCGCGGCGCGCGATATCGCCTATCTCACCCGGACCTATGGCGCGCATCCCGCCTGGCTGGGGGTGGACAAGCGTCCGGTGCTGTTCCTCTATCTGCAAGCCTTGCGCGATCTGCCCGCACGCGACTGGCGCAAAGCGGCGGAGGGAGCGTTCATGGTGGGTGACGTTTCCCCGCGCGAGACGCGCGATTTCGCCGCCTGGGCGCCGTTCATGGACGGCATCCATGTCTATGTGCTCGCCCCCTATCTGAAGGGCATGACGCCGCCCCAGATGAAGGCCTGGGCGGACCGCACCTACCCGGTCTGGCGGCGCATGGCGGGGAGCAAGCTGTTCTGCGCCACCGTCATCCCCGGCTTCGACGACAGCAAAGTCCCCGGCCGCCCGGCGCCGCGCCCGACGGTCGCGCGCTATGACGGCGCGACCTATCGCACGCTGTGGGACGCCGCGATCCGCCACGACGCCGATTGGGTGCTCGTGACCAGTTTCAACGAATGGCATGAGGGGTCCGAGATCGAACCGTCCACCGAACAGGGCGACCGCTATCTGACCCTGACGGCGCAAGCCGCACGCCGGTTCATGGGGCATTGA",
    "translation": "MSWSRRSVVGAGLALAAAPISAGPRRYPRQVLAFYYPWYGNPTTSGRWLHWQGPHGEAPRQSPTLNYPVLGLYDSHDAGVIRTHVAQAKAAGITALIVSWWGPNSFEDKALPMILEAARAAGLHVTVYLEQQKDGAAGAARDIAYLTRTYGAHPAWLGVDKRPVLFLYLQALRDLPARDWRKAAEGAFMVGDVSPRETRDFAAWAPFMDGIHVYVLAPYLKGMTPPQMKAWADRTYPVWRRMAGSKLFCATVIPGFDDSKVPGRPAPRPTVARYDGATYRTLWDAAIRHDADWVLVTSFNEWHEGSEIEPSTEQGDRYLTLTAQAARRFMGH",
    "product": ""
   },
   {
    "start": 62815,
    "end": 64329,
    "strand": -1,
    "locus_tag": "ctg11_53",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_53</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_53</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 62,815 - 64,329,\n (total: 1515 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_53 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF19982.2 (Family of unknown function (DUF6418)): [364:460](score: 51.0, e-value: 1.4e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_53\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCATCTCGATACACAGGGGCGCGGATGGGCCGACCGATCGCGATGGGCCGGCGGCGCGCCGGTTGCCGCGACCATTGCCTTGGGGGGCGATCATCGCGCTGACCGCCGCGCTTGCGCTCCACTGGGCGTTGGCGGCGGCATGGCCCAGCACGGCCTTCTCCCTATCCTCGCTCCTCCTGTTCGGTGCCTTGCTGTTGCTGGTCGGGCGGATCAGTGCGGCGGGGCTGATCCTGCTGCTCCCGCTGGTCATCACGCGCGGCGCTACATTGGTGTCGCTGCTGGTGATCGAGGCCGGGGCCTATATGCCCGAGGTCAATCAGCAGGGTGTGCCGGGCGATGCGAGCGCGTCCTTTGTCGCCTTCACCGCGATCTTCTTCCTCATCTTCGCGCTGGTCTTTCGCCGATGCGAGCGCTGGTTCCTCGCCTATGCCCGCTCGCCCCTGCTCGATCAGGTCGTGGCGTGGCTCGGCTGGCCGGTGGTGGGCCTGTGCACGGCGTTGGGGGCACTTGCCTTTCTGCATGGGATGCAGAGCGGGTTTCCGCTGCTCGCGGGTGTCGACCGGTTCCTCTATCGGCGGGAATATAGCAGCGGCTTGGTCCTGATCCTGCTCGACAACAAGTTCCTGTTCGCCGCGATGCTGGGGGCCATCGCCTTCGCACCGCGGTACCAGCCGCTGCTCAAGACGGCGGCGATCCTGACCTTCCTTGCCCTCACCGCACTCTATTTCCTGTTCGGCGACAAGTTCTTCACCATCCTGGCCGAAGTCGCCTTCTTCGCCATGCCCTTGCTGCTCGTGCGGCAGGGGCGGCTGGCGGGGACGATGCTGCGGCTCGCGGTGCCGGTCGCGGCGTTGCTGTGCGCGGCGCTGGGGGCCACCCTCTATATCTATTCGGGCTATGGACGGTTACCGCTCGACCGCACCGTGACCCTGGTCGGAGAGCGGATCGCCGGGCAGGGCGAATTGTGGTTCGTCGCCAGCCGCGATGCGCGCCGGGTCACGCATTGGGACGCGCATCTGGTTGCGCGCAACCTCGACACGCTGGGCGACAAGTCGCCGCCCGCCACCGCCTTCGCCAACGGGGTCGAGACCTATTATTTCATCCAGCGCTACGCCCCTGCCGCGCTGGCGGACAGTTTCCGCAAGAATGGCGGCTGGGTGCAGCTGACCATGGGCACCGAGGCGATGGCGCTCGTCATGTTCGGCTATGTCGGCGTGGCCGTCGTCATGGTGGTGCTGGGGGTATTGGTCGCCTTTGCCGCGCTCTATCTGCGTCGCGCCTTCGAATCCGCCTTCCCGTTGAGCCTGTTCTTCGCGGTGTGGACCTTCCTTCAGGTCTATTTCTCGGCACAGCAGGCTTCGCTCTGGAGCATCGCCGCGCCGGGGCAGATCAACCGCCTGCTGTTGTTCGTCACGATCGAGATCATCCTGCTGGCGATCAACCGCGCGCAGATCCGGGTCGGCTGGGACCGCGCCCGCGCGGCGATCTTCGCCGCGAGGCGTACCGCGTGA",
    "translation": "MGISIHRGADGPTDRDGPAARRLPRPLPWGAIIALTAALALHWALAAAWPSTAFSLSSLLLFGALLLLVGRISAAGLILLLPLVITRGATLVSLLVIEAGAYMPEVNQQGVPGDASASFVAFTAIFFLIFALVFRRCERWFLAYARSPLLDQVVAWLGWPVVGLCTALGALAFLHGMQSGFPLLAGVDRFLYRREYSSGLVLILLDNKFLFAAMLGAIAFAPRYQPLLKTAAILTFLALTALYFLFGDKFFTILAEVAFFAMPLLLVRQGRLAGTMLRLAVPVAALLCAALGATLYIYSGYGRLPLDRTVTLVGERIAGQGELWFVASRDARRVTHWDAHLVARNLDTLGDKSPPATAFANGVETYYFIQRYAPAALADSFRKNGGWVQLTMGTEAMALVMFGYVGVAVVMVVLGVLVAFAALYLRRAFESAFPLSLFFAVWTFLQVYFSAQQASLWSIAAPGQINRLLLFVTIEIILLAINRAQIRVGWDRARAAIFAARRTA",
    "product": ""
   },
   {
    "start": 64428,
    "end": 65867,
    "strand": 1,
    "locus_tag": "ctg11_54",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_54</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_54</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 64,428 - 65,867,\n (total: 1440 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Polysacc_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_54 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13440.9 (Polysaccharide biosynthesis protein): [27:315](score: 157.3, e-value: 5.1e-46)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_54\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTTGCCAGGAACATGCTCTCGATGTCGGGGCTCAGCCTCTATCGCAACGCCGTCCAGTTCGGGATGAACGTCGCCATCGCCGCCTTTGTGCTGCCCGGCGATTATGGGCTGATCGTCTTCACCACGCCCTTTCTGGTGTTGATCGCGATGCTGACCGATTTGGGCATGACCAGCGCGATCACCCGTGCGCCGACCCTGTCGCGCGACGAGGCGGGGGCGGCGATGGGGGCGATGATGATCGGAGGCGCGGTCTGCGCCGTGCTGCTGGTCGCAGGCGCCTGGCCCCTGGAGCGCGCGATCGGCATGGCGGGGCTGGCCCCCGTGATGGCGGCGATGGCGGGGGTCGTGCTGTTGTCGATCGCCGCCGCCACCCCGCGCGCCTTGATGGAGCGCGAATTGCGCTATGCCGGGATCGCCCGGATCGAGGCGATCGCCATCGCCCTGGCCGCGATCGCGGGGCTCGCGGCTGCGTGGAGCGGGGCCGGGGTCTGGTCGCTCGTCCTCTACAATATCCTGGTCCAGGCGATGCGGCTCGGCGCGTTCGGCTGGACGATGCGCGGCGTGCTGCGGCCCAATGCCCGGTTCGGCCAGTTGAAAGGCTTGCTCTCCTTCGGTGGCTGGGTGCTGGCGAACAACATCCTCAACTTTCTGGCGCGCAACAGCGACAATCTGCTGATCGGCGCCTGGCTGGGTGCGGCGGCGGTCGGGGTGTACGGCCTGGCCTATCAGTTCATGCTCGCCCCATTGATGGCGATCACCTGGCCGACCAGCGGCATATTGCTGTCCACATTGCGCGGCGAAGACCCGCATGGGCCGCGCGCGCAGGCGACGGTGGAGGGCGTGCTGTCCGCCACCGCGCTGATCGTCACGCCCGCGATGATCTACCTCACCTTCGGCCTCGCCTTTCCGGTGGACAGCCTGTTGTCGGGGCATTGGGCGGCGGTGCCCGCAATCGTCGCCTGGCTGGCCCCGGCGGGCGCGCTTCAAGCGATCGCCTCCTATAATGGCGCGCTGCTGATGGTCGCGGGGCGTGTGAAGGCGCAGTTCCTGCTCAGCGTCGCCAATACGGCCGTGCTGGTCGCGACCTTTGTGCTGGCGCTACCGCATGGGCTGATGGCGTTGGTCCAGGCCTATACGGCGGCGATTTCGGTGATGAGCCTCGCCTTTCTGGCGATGACGGTCATGCTGACGGGCTTGCGCGTCGAGCGGCTCGCCCGCGCGCTGGCCCCCGCGCTGCTCGCCACCGGGGCAGGCGTCGTGGGGGTGGCCGTCACCACGGGCCTGCATCCGGCAAGCTGGACGGGGTGGATCGCCGCGACGGCCATGTACGGCGCGGGGGTGCTGGCCTGCTACGCCGCGCTGCACCTGCATGTCCGGCGCACGCTGGCGGCACTTCTCACACGCGGGGCACCGGATGCGGCGATTACAGGAAGGTAG",
    "translation": "MLARNMLSMSGLSLYRNAVQFGMNVAIAAFVLPGDYGLIVFTTPFLVLIAMLTDLGMTSAITRAPTLSRDEAGAAMGAMMIGGAVCAVLLVAGAWPLERAIGMAGLAPVMAAMAGVVLLSIAAATPRALMERELRYAGIARIEAIAIALAAIAGLAAAWSGAGVWSLVLYNILVQAMRLGAFGWTMRGVLRPNARFGQLKGLLSFGGWVLANNILNFLARNSDNLLIGAWLGAAAVGVYGLAYQFMLAPLMAITWPTSGILLSTLRGEDPHGPRAQATVEGVLSATALIVTPAMIYLTFGLAFPVDSLLSGHWAAVPAIVAWLAPAGALQAIASYNGALLMVAGRVKAQFLLSVANTAVLVATFVLALPHGLMALVQAYTAAISVMSLAFLAMTVMLTGLRVERLARALAPALLATGAGVVGVAVTTGLHPASWTGWIAATAMYGAGVLACYAALHLHVRRTLAALLTRGAPDAAITGR",
    "product": ""
   },
   {
    "start": 65854,
    "end": 66552,
    "strand": -1,
    "locus_tag": "ctg11_55",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_55</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_55</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 65,854 - 66,552,\n (total: 699 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_55\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATGCACAGCCTGCGCCACCGTTTGCGGCATTGGACCGGACGGGCCGACGCCTTCGCCCCCGAACCGGGGCTGGAGGCGATCTATCGCGACCTGTTCCTGCGCGAGTTAAAGCTGCTCGGAGAGGAAGACCGGTTCTTCCCCACAGGCGGCGCGGCCAATTACAGCCTGCTCTATCTGATCCTGCGCATCGGGGTGGAGTTCGGCCCAGCCTCCGTGCTCGATATCGGGGCAGGACAGAGCAGCCTGTTATGGGCGATGCTGCAACGGCGCGGGCTGGTCGGCGAAGTGCTGACGCTGGAGAACGACCCCGAATGGGGCGAGCGGATCGCGGCGCAGGTGATGCATGAGGTGCTGGTAACGCCGCTGGCGGTCCGCCAAGTGGGCAAGCGTGCGGTGACGACCTATGACTGGGCGGCGGTGCGGGCCGGGCGGCGCTTCGACGTGATCCTGTGCGACGGGCCGCGCGGCACGCCTTTCCATTCGCGGGGCGGGGTGCTGGCGATGCTCGAGGATTTGCCGCGCGACTTCGCGCTGATCCTCGACGATGCCGAGCGCGATGGCGAACAGGATACGGTGGGGGCGATCCATGCGCGGCTTCAGGCCGACGGGGTCGATTACGGCGTCGGCGTGGTGCGCGCGGCCAAGACCCAGGTGGTGTTTGCGGGCGGCCGCTTCCTGCCCGCTACCTTCCTGTAA",
    "translation": "MMHSLRHRLRHWTGRADAFAPEPGLEAIYRDLFLRELKLLGEEDRFFPTGGAANYSLLYLILRIGVEFGPASVLDIGAGQSSLLWAMLQRRGLVGEVLTLENDPEWGERIAAQVMHEVLVTPLAVRQVGKRAVTTYDWAAVRAGRRFDVILCDGPRGTPFHSRGGVLAMLEDLPRDFALILDDAERDGEQDTVGAIHARLQADGVDYGVGVVRAAKTQVVFAGGRFLPATFL",
    "product": ""
   },
   {
    "start": 66553,
    "end": 67719,
    "strand": -1,
    "locus_tag": "ctg11_56",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_56</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_56</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 66,553 - 67,719,\n (total: 1167 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1088:acyltransferase 3 (Score: 154; E-value: 9.3e-47)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_56 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01757.25 (Acyltransferase family): [29:360](score: 70.5, e-value: 1.4e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_56 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01757.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016747' target='_blank'>GO:0016747</a>: acyltransferase activity, transferring groups other than amino-acyl groups<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_56\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_56_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGAAAAGGGCGGTGGAGAAGCAGGGGAGACCATAGTCCACCCCGTTGGCATGGCCCCGTCGACGCGTACGCTTTGGACGGTCCAGGCCTTGCGCGGTGCGGCCGCGCTGATGGTCGTGATCGGTCACAGCCAGAGCGCGGCGGCGGGAATCGTAACCGCGCGGGGCGACCATTTCGCGCGCTCGACACTGATGCCATGGGGGGCGGGGGTGGACCTGTTCTTCGTCCTGTCGGGCTTCATCATGGTCCATGCCTCCACCCGCTTGTTCGGGCAGGGGAATGCGCACGAGGAGTTCCTGCGGCGGCGGCTGGTGCGGATCGTGCCGCTCTACTGGCTGGTCACGACCCTCTTTCTCGCACTGCTCGCGGCGGCGACGCTGAAGGGGGGCGATCCCTTTCCCGACGCTCGGGCGATCCTCGCTTCCTATACCTTCGTCCCGGCGAACACATGGGGCGACGGGCGGTTCTTTCCGGTCTTCGATCTGGGCTGGACGCTGAATTACGAGATGTTCTTCTATGCGCTGTTCGCCTTCGTCGTGGCGCTGCCGCGCGGGCGGGCGCTGGTGGCGATCGGCGTGATGCTGGTCGCGGCGACGGGGATTGGCGCTGTGGTGCCGGGGCCGTCTGGGCTGTGGTTCTGGACGCGGCCGATCATCTTGGATTTCGGGCTGGGGCTGGCGGTCGGGGCACTGCTGGGGCGGGGCGTCGTCCTGCCACCGATGGTGCGGCTCGCGCTGGCGGCCGCCGGGGCCGCGCTGCTGCTCGCCGATCCCTTCCATATCTTTGACGGCGCGGTCGGTGTGACCGTCGCTAATGACTGGCCGCGCGTGGTCTGTGCCGGGCTGCCGATCGCGATGCTGCTGGCGGCGGCGGTGCTGGGGCCCGAGCCGGTGATGCCGCGTATCCTGTTGCCCGCCGCGCTTGTGGGGGATGCGTCCTATTCACTCTATCTCTTCCACCCCTTCGCGCTGATCCTGACGGAGAAGCTGGCACAGAAGCTGCCCGTGATGCGGGCGGCCGAGGGATGGCAGCTCGTGGCCGTCATGGTCGGTGTCGCGCTGATCCTCGCCTTCGCGGTCCATCGCTGGATCGAGCGACCCCTGACCGCGCAACTCGCGACCCCAACCCAGCCGCGTGCCGTCGCGGCGCATTCTGGAGAGTGA",
    "translation": "MTEKGGGEAGETIVHPVGMAPSTRTLWTVQALRGAAALMVVIGHSQSAAAGIVTARGDHFARSTLMPWGAGVDLFFVLSGFIMVHASTRLFGQGNAHEEFLRRRLVRIVPLYWLVTTLFLALLAAATLKGGDPFPDARAILASYTFVPANTWGDGRFFPVFDLGWTLNYEMFFYALFAFVVALPRGRALVAIGVMLVAATGIGAVVPGPSGLWFWTRPIILDFGLGLAVGALLGRGVVLPPMVRLALAAAGAALLLADPFHIFDGAVGVTVANDWPRVVCAGLPIAMLLAAAVLGPEPVMPRILLPAALVGDASYSLYLFHPFALILTEKLAQKLPVMRAAEGWQLVAVMVGVALILAFAVHRWIERPLTAQLATPTQPRAVAAHSGE",
    "product": ""
   },
   {
    "start": 67826,
    "end": 68950,
    "strand": 1,
    "locus_tag": "ctg11_57",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_57</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_57</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 67,826 - 68,950,\n (total: 1125 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1045:glycosyl transferase group 1 (Score: 182.5; E-value: 2.5e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_57 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13579.9 (Glycosyl transferase 4-like domain): [11:173](score: 61.0, e-value: 1.9e-16)<br>\n \n  PF00534.23 (Glycosyl transferases group 1): [183:319](score: 99.7, e-value: 1.4e-28)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_57 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00534.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016757' target='_blank'>GO:0016757</a>: glycosyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_57\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_57_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGGATTCTTCACATCGCCGAATCCGCGCAGGGCGGCGTCGGCACCTATCTGACCGAGATATTGTCCGATCAGGCACGCCGCTATGGCGGCGACCGGGTCCGCGCGCTGGTCCCAGCACAACATGCCGCACATCTGAGCGGGGTCGATCGCCGGCTGTTGATCCCGTGGCGACGGCAGCACCGCTCGGTCCGCGGCATGATGTCGCTGGCCGGCGCGATCGCGAGCGCGGTAGAGCAGGTAAGGCCGACGATCGTCCATGCCCATTCCAGCTTTGCGGGTGCGGTGCTGCGGCTGTTGTACGGATCATGGCGGCGCGCGCCGTTCCGTATCGTCTATTGCCCGCATGGCTGGGCCTTCGACCGCCGTTCCTCGGCGTGGAAGCGCCGCGTGGTCGAGGGGGTCGAGCGCATCCTGGCGCCGGCCGCCGACCGCATCGTCCTGATCTCCGACCATGAACGGCGCGAGGGCGTGCGGATCGGCATCGATCCGGCCGCGCTGACCCTGGTGCTGAACGGCATCGCCGACCTGCACAGCGAACGCCCCGCGCGATGGCAGGACGATCGGGTGCGGGTGCTGTTCGTCGGGCGGCTCGACACGCAAAAGGGGTTCGACACGCTGCTCGACGCGGTCGAGCCCATTCAGGACCATGTCGCGGTGCGCGTCATCGGCAAGGCGGTGGCCGGCCCCGCCACCACCCCGCGCAAACGCAGCCCGCAGATCGAATATCTCGGCTGGCGATCGCTGTCCGAAGTCGCGACCGAGATCGCCGCCGCCGATGTCGTCGTCGTCCCCTCGCGCTGGGAAGGCTTCGGCCTCGTCGCGCTGGAGGCGATGTGCGGCGGCTGCGCGGTCGTCGCCTCCGATGTGGGGGGCCTGCGCGAGATCGTCGCCGATGGCGAGACGGGCTATCTCGTCCCCCCCGATCATCCGGAGCGGCTGATGCGCACGCTCGCCCGGCATGACCGCGCCACCTGGCAGGCGATGGGTGCCGCCGGACGCGCGCGCTACGAGGCGCGGTTCACCGCGCAGCGGATGAATGCCGAACTCGCCGCGCTCTATGCCGAATTGTCGCCGGTCGTGCGGGAAGAGCATGTGGCCACGCCGCTGGTCGCCCATGCGTAA",
    "translation": "MRILHIAESAQGGVGTYLTEILSDQARRYGGDRVRALVPAQHAAHLSGVDRRLLIPWRRQHRSVRGMMSLAGAIASAVEQVRPTIVHAHSSFAGAVLRLLYGSWRRAPFRIVYCPHGWAFDRRSSAWKRRVVEGVERILAPAADRIVLISDHERREGVRIGIDPAALTLVLNGIADLHSERPARWQDDRVRVLFVGRLDTQKGFDTLLDAVEPIQDHVAVRVIGKAVAGPATTPRKRSPQIEYLGWRSLSEVATEIAAADVVVVPSRWEGFGLVALEAMCGGCAVVASDVGGLREIVADGETGYLVPPDHPERLMRTLARHDRATWQAMGAAGRARYEARFTAQRMNAELAALYAELSPVVREEHVATPLVAHA",
    "product": ""
   },
   {
    "start": 68919,
    "end": 70205,
    "strand": 1,
    "locus_tag": "ctg11_58",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_58</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_58</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 68,919 - 70,205,\n (total: 1287 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1045:glycosyl transferase group 1 (Score: 94.2; E-value: 1.6e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_58 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13692.9 (Glycosyl transferases group 1): [243:371](score: 54.0, e-value: 2.2e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_58\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTGGCCACGCCGCTGGTCGCCCATGCGTAACGGGCGCATCGTCCTGCTCTCCGATTATATCGGTGGCGAGGGGCCGGGTAGCGGCGGGGCCGGCCATGCCGCGCTCGACAGCTACCGCGCGCTCAGGGCCGCGGGCGCGGATGTCCATGTCATGGCAGGGTTCGGTGAGCCGCCCGCGATCGAGCCCGAGCGGTTCCGAGGACTGGGCGGCGCGGACCTGCGCGGCGGGGGCGCCGGCGCCATGCTGCGCGCCATCTACAACCCTGACGCCGGAGCAATGCTGTCTCGCGAAGTGGCGGGGCTTGATCCCGACACCACATTGATCGTGCTTCACCAATGGACCCGGTATCTGTCCCCGGCCGCCTTGCGAATCGCCAGCCGCTTTCCGATCATGATCTATATGCACGACTATTTCTGGGTCTGTCCCAACGGCATTTATTATGATTTCGCGGCCGGCCGCCCATGCGATCGGCGGCCGATGCGGCGCCATTGCCTGACCAGCGATTGCGACCGCCAGGGCCGCCTGCCCAAGCTCGGCCGGCTGGCCAGGCACGCGATGCGCCACATGGCGACCGCGACCCGGCCGAGCCGCCGCCTGTTCCTGCATTTGTCCGAACATGCGCAACGGACCATCATGCCGCTGCTCCCCGAACAGCGCCATGCGGTGCTCCACAATCCCCTATCGCTCTCCGATATCGAGCCACCCCCCGCTCCGCCACCGACCTATGACGTGGGCTATTTCGGACGACTGGAGCAAGACAAGGGTGTCGAACTTCTGGTCGAGGCACTGCGCGAGACGGGACGTACCGGCCTGTTCGTTGGCCAGGGTTCGCTGGAACCGCTGCTGCACGCCACGCCCGGCATCACCCACCGATCCTGGCAACCGCGCGAGACGATGGCGGCGGCGATGCGATCCTGCCGCGTCGTCGTCCTGCCCTCGCTCTGGAACGAGACCTGGGGGCTGATCATCGCCGAGGCGATGGCCGCGGGCGTAACGGTGCTGGTGTCGTCGCGCGCCGGTTCGTCCGAACTGGTCCGTCGCTTTGGCGGGGGACAGATGTTCGATCCCGGGCAGACCGGCAGCTTGGCGGCGAGCCTGCGCCAGATGCTGGGGGCGCCCCCCTCGCCCACCCGGCAACATGGCGCGCTTCGCCGCTTCCTGTCTCCCGAACGCCATGCCGCGCGCATCATGGGGCTGGCGGAGAGTCACTTCGGGCTGAGCCTGCGGAGTGACGACCGCCGTGTCAGGACGTCAGCACCTCACTCAGTATCCCGGCCAGCCTGA",
    "translation": "MWPRRWSPMRNGRIVLLSDYIGGEGPGSGGAGHAALDSYRALRAAGADVHVMAGFGEPPAIEPERFRGLGGADLRGGGAGAMLRAIYNPDAGAMLSREVAGLDPDTTLIVLHQWTRYLSPAALRIASRFPIMIYMHDYFWVCPNGIYYDFAAGRPCDRRPMRRHCLTSDCDRQGRLPKLGRLARHAMRHMATATRPSRRLFLHLSEHAQRTIMPLLPEQRHAVLHNPLSLSDIEPPPAPPPTYDVGYFGRLEQDKGVELLVEALRETGRTGLFVGQGSLEPLLHATPGITHRSWQPRETMAAAMRSCRVVVLPSLWNETWGLIIAEAMAAGVTVLVSSRAGSSELVRRFGGGQMFDPGQTGSLAASLRQMLGAPPSPTRQHGALRRFLSPERHAARIMGLAESHFGLSLRSDDRRVRTSAPHSVSRPA",
    "product": ""
   },
   {
    "start": 70165,
    "end": 71304,
    "strand": -1,
    "locus_tag": "ctg11_59",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_59</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_59</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 70,165 - 71,304,\n (total: 1140 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1045:glycosyl transferase group 1 (Score: 117.3; E-value: 1.6e-35)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_59 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00534.23 (Glycosyl transferases group 1): [215:322](score: 62.7, e-value: 3.2e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_59 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00534.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016757' target='_blank'>GO:0016757</a>: glycosyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_59\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_59_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTTTGCAATCCCTTCCCCGCGATGCGCTCTTCCGAAACGGTACGCGATCCGACCGGCCGTGCCTGTTCTTCAACGGCAAATTCTATTCGGGGAAGACCAACGGGGTTCATCGGGTCGCGGATCGGCTGTTGCGCGAACTGGACGCGCTGGCGGTGGCGGGGGCCGCGCCGGCGGGATGGGACATGCGGTTGCTGCTGCCCAGACGCGCCAACTGGGCGCCGCGCTTCGCCGCGATCACACCGATGCCGCAGCGTTATGGCGCTAGCCAATTCTGGGAGCAGATGATCCTGCCCGTTGCGGCGCGGCGCGGGGCGCTGGCCAGCTTCGCCAATCTCGCCCCAGGCTGGCATGGGCGCAAGGTGACGATGGTACATGATGCACAATTCCTGCTGTCGCCCGAAAGCTATTCGCCCAAATTGCGGTGGGGCTATCGCCTGCTCGTGCCGTGGGGCGCGCGGTCGAGCCGGGTGGTCCTGACCGTGTCCGATTATGCGCGCGACAGCCTGGCGACGTTCGGCATCGCGTCGCCCGCGCAGACGCAGGTGCTGCATAATGGCGCGGACCATATTCTGGACGTGCCCGCCGACCGAAGCGTGCTGGACAGGCATGGCCTGGCGCCCGGCTCCTATGGCCTGATCTTCGGCTCGACCTCGGCGTACAAGAATGTCGCGGCCGTCTTCACCGCCTTTGCCGATCCGCGTCTGGCCGCGATGCCACTGGTCGTGGTCGGGCCGTCGCGGGCGGTGCTCGAGGCGGCAGGACTGCGGCCGCCGCCGGGCGTGGTGTTCGTCGGCGGGGTCGATGATAGCGGCCTGCGTGCCCTGTACGAAGGGGCGCATTGCCTGCTCTACCCTTCACGGACAGAGGGTTTCGGTCTGCCGCCGGTCGAGGCGATGCTGTGCGGCTGCCCGGTCGTCGCGGCCCCGGCGGGGGCCATTCCGGAAGTATGCCGCGACGCCGTCGTCTATGCCGGGATGGACGATATCGGCGAATGGATCGGCGGCGTCCTGGTGCTGGGTAATCGTGAGGTACGTGCCGCCAAAGTCGCCGCCGGTCGCGCGCGTGCCGGCCATTTCACCTGGGCGGCGGCGGGCGTCAGGCTGGCCGGGATACTGAGTGAGGTGCTGACGTCCTGA",
    "translation": "MALQSLPRDALFRNGTRSDRPCLFFNGKFYSGKTNGVHRVADRLLRELDALAVAGAAPAGWDMRLLLPRRANWAPRFAAITPMPQRYGASQFWEQMILPVAARRGALASFANLAPGWHGRKVTMVHDAQFLLSPESYSPKLRWGYRLLVPWGARSSRVVLTVSDYARDSLATFGIASPAQTQVLHNGADHILDVPADRSVLDRHGLAPGSYGLIFGSTSAYKNVAAVFTAFADPRLAAMPLVVVGPSRAVLEAAGLRPPPGVVFVGGVDDSGLRALYEGAHCLLYPSRTEGFGLPPVEAMLCGCPVVAAPAGAIPEVCRDAVVYAGMDDIGEWIGGVLVLGNREVRAAKVAAGRARAGHFTWAAAGVRLAGILSEVLTS",
    "product": ""
   },
   {
    "start": 71426,
    "end": 73954,
    "strand": 1,
    "locus_tag": "ctg11_60",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_60</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_60</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 71,426 - 73,954,\n (total: 2529 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 344.6; E-value: 1.3e-104)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-ctg11_60 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>Thioesterase</strong> (645..801)</dt>\n   <dd>\n   \n    active site serine inconclusive<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_60 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [23:409](score: 301.3, e-value: 9.8e-90)<br>\n \n  PF13193.9 (AMP-binding enzyme C-terminal domain): [416:491](score: 44.2, e-value: 3.1e-11)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [517:582](score: 55.1, e-value: 7.6e-15)<br>\n \n  PF00975.23 (Thioesterase domain): [645:740](score: 46.7, e-value: 4.5e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_60 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00975.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_60\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_60_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCTGCGCCAGGAAGAGACGACCGCCTATGTCCCCAAACGGGGGTGGCACGCGCTTCCCGATATCTTCGCCCGTCACGCCTGGTGCGATCCCGACGCCCCGGCGGTCGAAGCACGCGGGCAGCGGCGCAGCTATGGCGAACTGGCGGCGCGTGTCGACCAGTTGGCGGCGCGGCTGGCCTATCTGGTGGCCGACGATCATCCCTTGATCGGTCTGTGCCTGTCGCGCGATGTCGATCTGCCCGCCTGGCTGCTCGCGGTGCTGAAGATCGGTGCGGCCTATCTACCGATCGATCCCGCGACCCCGCCCAACCGTCTGGCGCATATCATGGAGGATGCGCGCCCCGCCCTGATCATCGCCAATCGCTGCTATGGCGATATCATCGCCGATCTGGGGATACCGGTGATGATCGCCGAGGAGGAAGGCGATCCCGTCATGATGGTCCCGACCCCAGCGATCACCTCCTCGACGCTCGCCTATGTCATCTTCACCTCCGGTTCGACCGGCCGGCCTAAGGGCGTGGAGATCGAACATGGCGCGCTCGTCGCACTGCTGGCGACCATGGCGGCGAGCCCGGGCTTTCGCGCGAATGAGAAGATGCTGGGGATCACCCGGCTCAGCTTCGATCTGTCCGTGCCGGACCTGTTCCTGCCCTTCTATGTCGGCGGATCGCTGGCGCTGATCGATCTCGAGGAGGCTGCCGATCCCACACGGCTCGCCGCTGCGCTCGATCGGCATCGCCCCGACCTGGTGCAGGCGACACCCTCCACCTGGCGGGCACTGGTCGAACAGGGTTGGAGCGGGCTGCCAGGCTTGCGCATCCTGGCGGGCGGGGAAACGCTGACCCGTTCGCTCGCCGACCGATTGCTGCTACGCTGCGACGAGTTGTGGAATATCTATGGGCCGACCGAAACGACCGTGTGGTCGACCGCCTGCCGCGTGACCCCTAGCCATGACGCGATCCCGATCGGCTGGCCGATGAGCGGCATCACCGTGTACGTCACCGACGTCGATCTGAAACCCGTGCCGCCCGGCCAGGTGGGTGAGATCGTCATCGGCGGGCCGGGTGTCGCGCGCGGCTATCGCAATCGCCCCGACCTCACCACCGAGCGCTTCGTGCGCCTAGCCGACGGGGCGCGGGTCTATCGCACCGGCGATCTTGGCCGGTTTGACGAACGCGGCGCGCTTTATTGCCTGGGGCGGATCGACGATCAGGTGAAGGTGCGCGGCTTTCGCATCGAACTGGGCGATGTCGAGGCGGCACTGTCGCTCCACCCCGGCGTCGTCTGGAGCGCGGTGCGGCTCTGGACCGATCCTTCGGGCGAGGCGCTGCTGGTTGGCTATGTCGTACCGCGCGACAGATCGCTCGGCCCCCGCGAGATCAAGGCGTTCCTGGCCGGTCACCTGCCCGCCTATATGATCCCCGACCGGATCGTGACGCTGTCGGCCATGCCGCTGACGCCCAATGGCAAGATCGACCGCGCCGCGCTGCCCGACCCTGCTGCGGAAGGACGCCCAACCATCGCACAGCATGCGGCCGACGCAATCGATCGGCGGCTGGCGGCGATCTGGAGCGATCTGCTCAATATCGGCGCGATCGCCGCGGAGGATGATTTCTTCGACCTGGGGGGCTATTCGCTGATGACCGTGCGGCTGGCCCGCCGGATCGAGGCGGCGTTCGGCGTCCGTCTCGCACTGATCGACCTGATGCGACATTCCACGCTGTCCGACATGGCGGCGCGCATCGCGCTGGGCGAGCAGCCCGCCGATCGGACGATGACGCTGTTCAATCCCGAGGGGCGGCGGACGCCGCTCTTCTGGCTCGATACCGGGCCGCTGATGCGCAACATCCTGCGCGACCTATCCGCCGACCAGCCGGTGCTGGCGCTCAATATCGATCCGCACGACGAAGACGCGCTCGGCTCAGGCACGCTGTCGATCACGGCAGTCGCGGCGCGGCTCAAGGAGCATCTGCTGGCGGCCTATCCCATCGGCGCGCTGAATCTGGGCGGATGGTGCCGCTGGGGAATCGTCGCCTATGAATTGGCGCAACAACTGGCCGCACAAGGGCGCGAGGTTCGCCTGCTTGCCCTTCTCGACGCCGAATGTCCCCGGCAGGGCGTGGGGCAGCGGCTCCGGAGGCAGATGCGCCAAATGCTCCACCGCATCGGGACCGTCCAACACGAGAAGGCCAGTTTCAGCCAGCGGGTCGAACATGCGACCCACAGCTATGCAGCCGCTCTTTACGCCGGTGACGTGCTGTTGCTGCAGCCCACCGCCCGGCGCACGAATGCCGGCTGGAATGCCGTCGTGCGCGGCGCGTTGACGGTCGAGCTCATCCCCGGCGACCATGAGACGATGATGCGGGGCAGCGCCGCGCCCATGCTCGCCTCCGCGCTGAACACCGCGCTTGCATCCACGCAGCACCGCCCGGCCATACTCCCGGAGGTCAGGTCGCCTGTCCCCGTCCCGCTCCTACAGCCCCGTGCGATCCCGGCCGCCGGGGAACGCCGGTGCCAGTCCAGTTAA",
    "translation": "MLRQEETTAYVPKRGWHALPDIFARHAWCDPDAPAVEARGQRRSYGELAARVDQLAARLAYLVADDHPLIGLCLSRDVDLPAWLLAVLKIGAAYLPIDPATPPNRLAHIMEDARPALIIANRCYGDIIADLGIPVMIAEEEGDPVMMVPTPAITSSTLAYVIFTSGSTGRPKGVEIEHGALVALLATMAASPGFRANEKMLGITRLSFDLSVPDLFLPFYVGGSLALIDLEEAADPTRLAAALDRHRPDLVQATPSTWRALVEQGWSGLPGLRILAGGETLTRSLADRLLLRCDELWNIYGPTETTVWSTACRVTPSHDAIPIGWPMSGITVYVTDVDLKPVPPGQVGEIVIGGPGVARGYRNRPDLTTERFVRLADGARVYRTGDLGRFDERGALYCLGRIDDQVKVRGFRIELGDVEAALSLHPGVVWSAVRLWTDPSGEALLVGYVVPRDRSLGPREIKAFLAGHLPAYMIPDRIVTLSAMPLTPNGKIDRAALPDPAAEGRPTIAQHAADAIDRRLAAIWSDLLNIGAIAAEDDFFDLGGYSLMTVRLARRIEAAFGVRLALIDLMRHSTLSDMAARIALGEQPADRTMTLFNPEGRRTPLFWLDTGPLMRNILRDLSADQPVLALNIDPHDEDALGSGTLSITAVAARLKEHLLAAYPIGALNLGGWCRWGIVAYELAQQLAAQGREVRLLALLDAECPRQGVGQRLRRQMRQMLHRIGTVQHEKASFSQRVEHATHSYAAALYAGDVLLLQPTARRTNAGWNAVVRGALTVELIPGDHETMMRGSAAPMLASALNTALASTQHRPAILPEVRSPVPVPLLQPRAIPAAGERRCQSS",
    "product": ""
   },
   {
    "start": 73971,
    "end": 75401,
    "strand": -1,
    "locus_tag": "ctg11_61",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_61</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_61</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 73,971 - 75,401,\n (total: 1431 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1076:RND efflux system, outer membrane lipoprotein, (Score: 407.5; E-value: 1e-123)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_61 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02321.21 (Outer membrane efflux protein): [70:262](score: 64.3, e-value: 1.3e-17)<br>\n \n  PF02321.21 (Outer membrane efflux protein): [287:469](score: 88.7, e-value: 4.4e-25)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_61 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02321.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015562' target='_blank'>GO:0015562</a>: efflux transmembrane transporter activity<br>\n  \n   PF02321.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_61\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_61_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMAKHLCRWLAGAALGLLGGCSMAPAYHPPAMPTPPAFKEAFSASASIWKPAGALTTAPRGDWWTGFGDPTLNQLEARIDADSPTLAAALARYDLARATLAGARSGLFPHVELTPGLIRNRQSGERPLRGGNQPDFYTAATLGGDISYEADLWGRVRNSVASGRALAEASRDDLAAVKLALQGQLATDFVQLRGQDQQLALLTQTIMAFAKADALTHNRFRGGIATGMDVGRAGALLGEARAQYAETEAARAITEHAIASLVGQPASTFSIPHRDGVMTLPAIPIGLPSTLLARRPDVAAAERRMAAANARIGVAKAAFFPQITLGGAGGFQSTALAGLVAAPNLFWAIGPGAILNLFDGGKRRAEVAAARADWNGAMADYRTHALGAFQDVEDALATLHHLGEAQAAQDQAVASATRTEQIALDRYIKGAATYLDVATAQESALHDRQAALALENRRLMAGVALIRALGGGWSAAI\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTAAGCACCTGTGCCGCTGGCTGGCGGGGGCGGCGCTGGGGCTGCTCGGTGGCTGCTCCATGGCACCCGCCTATCACCCGCCCGCCATGCCCACGCCGCCCGCGTTCAAGGAAGCGTTCTCGGCCAGCGCCTCCATCTGGAAACCGGCTGGGGCGCTGACCACCGCGCCGCGCGGCGATTGGTGGACCGGCTTCGGCGATCCGACGCTCAATCAATTGGAAGCGCGGATCGATGCCGACAGTCCGACGCTGGCGGCCGCCTTGGCACGCTATGACCTAGCCCGAGCGACGCTGGCAGGGGCACGGTCCGGACTGTTCCCGCATGTCGAACTGACCCCCGGTTTGATCCGCAACCGTCAGTCGGGCGAGCGACCGCTGCGCGGTGGCAACCAGCCCGATTTCTATACCGCCGCGACGCTGGGCGGCGATATTTCCTATGAGGCGGACCTATGGGGCCGGGTGCGCAACTCGGTCGCCTCGGGCCGTGCGCTGGCCGAGGCGAGCCGCGACGATCTGGCGGCGGTGAAGCTGGCACTGCAAGGGCAACTGGCCACCGATTTCGTGCAGTTGCGCGGACAGGACCAGCAATTGGCGTTGCTGACCCAGACGATCATGGCCTTTGCCAAGGCCGATGCGCTGACCCACAACCGCTTCCGGGGCGGGATCGCGACCGGCATGGATGTCGGCCGCGCCGGCGCGTTGCTGGGCGAGGCGCGGGCGCAATATGCCGAGACGGAGGCTGCGCGCGCGATCACCGAACATGCCATCGCCAGCCTGGTCGGACAGCCCGCCTCGACCTTCTCGATCCCGCACCGCGACGGTGTAATGACCTTGCCCGCCATTCCTATCGGCCTGCCCTCGACCCTGCTTGCCCGCCGTCCCGATGTCGCGGCGGCGGAGCGGCGGATGGCGGCAGCCAATGCGCGCATCGGCGTCGCCAAGGCGGCGTTCTTCCCGCAGATTACGCTGGGCGGGGCGGGGGGCTTTCAAAGCACCGCGCTCGCCGGACTGGTCGCAGCGCCCAACCTGTTCTGGGCGATCGGGCCGGGGGCGATCCTGAACCTGTTCGATGGCGGCAAGCGTCGTGCCGAGGTCGCCGCCGCGCGCGCCGACTGGAACGGCGCGATGGCCGATTACCGCACCCATGCGCTGGGCGCATTCCAGGATGTCGAGGACGCGCTCGCCACGCTGCACCATCTGGGCGAGGCGCAAGCGGCGCAGGACCAGGCGGTCGCCTCCGCTACCCGCACCGAACAGATCGCGCTCGATCGTTATATCAAGGGGGCGGCCACCTATCTCGACGTCGCGACCGCGCAAGAGAGCGCCTTGCACGACCGGCAGGCGGCGCTGGCGCTCGAGAACCGGCGGCTGATGGCGGGCGTCGCATTGATCCGGGCGTTGGGCGGAGGGTGGTCGGCCGCCATCTAG",
    "translation": "MAKHLCRWLAGAALGLLGGCSMAPAYHPPAMPTPPAFKEAFSASASIWKPAGALTTAPRGDWWTGFGDPTLNQLEARIDADSPTLAAALARYDLARATLAGARSGLFPHVELTPGLIRNRQSGERPLRGGNQPDFYTAATLGGDISYEADLWGRVRNSVASGRALAEASRDDLAAVKLALQGQLATDFVQLRGQDQQLALLTQTIMAFAKADALTHNRFRGGIATGMDVGRAGALLGEARAQYAETEAARAITEHAIASLVGQPASTFSIPHRDGVMTLPAIPIGLPSTLLARRPDVAAAERRMAAANARIGVAKAAFFPQITLGGAGGFQSTALAGLVAAPNLFWAIGPGAILNLFDGGKRRAEVAAARADWNGAMADYRTHALGAFQDVEDALATLHHLGEAQAAQDQAVASATRTEQIALDRYIKGAATYLDVATAQESALHDRQAALALENRRLMAGVALIRALGGGWSAAI",
    "product": ""
   },
   {
    "start": 75394,
    "end": 76569,
    "strand": -1,
    "locus_tag": "ctg11_62",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_62</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_62</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 75,394 - 76,569,\n (total: 1176 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1029:RND family efflux transporter MFP subunit (Score: 182.1; E-value: 2.5e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_62 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF16576.8 (Barrel-sandwich domain of CusB or HlyD membrane-fusion): [85:304](score: 92.3, e-value: 2.7e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_62\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_62\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_62_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMHDAAPTPAVSADTPAPKGLKIAGLTAAMLAIGVVGLGALARSHDVAAAANWSNANAIPTVHLVPVKGGAASDALDLPATLEAWEAARLFPRVSGYVRSWSQDIGAHVGAGQALGVVDTPELDEQIGQARAALASAIAHEKLARSTAARWNDLLTSSSVSKQEVDEKNGDLAVKAAGVAEARAALSRLEAMKRYAVIRAPFAGVVTARNAEVGDLVGPGAAAQSPMFGVDDTHRIRVYVSVPQSLSATIKPGMTASLTVPAFPGRQFTATVAGLSSAVDPQSGAFRVQLYADNPDGALKPGGYAEARFDLPGQAGAAQVPSSAILFGAGGAQVATVDPHGRIMMHKVHIGQDNGPTVQILSGIKPGAQIVDNPPDSLAQGELVRVGASNHG\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_62\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_62\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCATGATGCAGCCCCGACCCCCGCTGTGTCGGCCGACACCCCCGCGCCCAAGGGCCTGAAGATCGCCGGGCTGACCGCCGCCATGCTCGCGATCGGCGTGGTCGGCCTCGGTGCCCTGGCCCGGTCCCATGATGTCGCGGCGGCGGCGAACTGGTCCAACGCCAATGCGATCCCGACCGTGCATCTCGTCCCCGTTAAGGGCGGCGCGGCAAGCGATGCGCTCGACCTGCCCGCCACGCTGGAGGCATGGGAAGCGGCACGGCTCTTCCCCCGCGTGTCCGGCTATGTGCGTAGCTGGTCGCAGGATATCGGCGCGCATGTCGGTGCCGGCCAGGCACTGGGCGTCGTCGACACGCCCGAACTGGACGAGCAGATCGGCCAGGCGCGCGCCGCGCTCGCCAGTGCCATTGCGCATGAAAAACTGGCGCGCAGTACGGCGGCGCGCTGGAACGACCTGCTCACCAGTTCCTCGGTGTCGAAACAGGAAGTCGACGAGAAGAATGGCGATCTCGCGGTCAAGGCGGCCGGGGTGGCGGAGGCGCGCGCGGCCCTGTCGCGGCTGGAGGCGATGAAGCGCTATGCCGTCATCCGCGCGCCCTTTGCGGGCGTGGTCACCGCGCGCAATGCCGAGGTCGGCGATCTGGTCGGCCCCGGTGCCGCGGCGCAATCGCCGATGTTTGGTGTCGACGATACCCATCGCATCCGCGTTTATGTCAGCGTGCCGCAATCGCTGTCCGCGACGATCAAGCCGGGTATGACCGCGTCCCTGACCGTGCCGGCCTTTCCCGGACGTCAGTTCACCGCGACGGTGGCGGGGCTGTCGAGCGCGGTCGATCCGCAGTCGGGCGCCTTCCGCGTCCAGCTCTATGCCGACAATCCCGACGGTGCGCTCAAGCCCGGCGGCTATGCCGAGGCGCGCTTCGATCTGCCCGGACAGGCGGGGGCGGCGCAGGTGCCGTCGAGTGCGATCCTGTTCGGCGCGGGCGGCGCGCAGGTGGCGACCGTCGATCCACATGGCCGCATCATGATGCACAAGGTCCATATCGGGCAGGACAATGGGCCAACCGTGCAGATCCTGTCGGGGATCAAGCCGGGCGCGCAGATCGTCGACAATCCGCCCGACTCGCTCGCGCAGGGCGAACTGGTGCGCGTGGGGGCGAGCAACCATGGCTAA",
    "translation": "MHDAAPTPAVSADTPAPKGLKIAGLTAAMLAIGVVGLGALARSHDVAAAANWSNANAIPTVHLVPVKGGAASDALDLPATLEAWEAARLFPRVSGYVRSWSQDIGAHVGAGQALGVVDTPELDEQIGQARAALASAIAHEKLARSTAARWNDLLTSSSVSKQEVDEKNGDLAVKAAGVAEARAALSRLEAMKRYAVIRAPFAGVVTARNAEVGDLVGPGAAAQSPMFGVDDTHRIRVYVSVPQSLSATIKPGMTASLTVPAFPGRQFTATVAGLSSAVDPQSGAFRVQLYADNPDGALKPGGYAEARFDLPGQAGAAQVPSSAILFGAGGAQVATVDPHGRIMMHKVHIGQDNGPTVQILSGIKPGAQIVDNPPDSLAQGELVRVGASNHG",
    "product": ""
   },
   {
    "start": 76562,
    "end": 79789,
    "strand": -1,
    "locus_tag": "ctg11_63",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_63</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_63</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 76,562 - 79,789,\n (total: 3228 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1049:AcrB/AcrD/AcrF family protein (Score: 893.8; E-value: 2.4e-270)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_63 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00873.22 (AcrB/AcrD/AcrF family): [4:1052](score: 685.9, e-value: 9e-206)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_63 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00873.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity<br>\n  \n   PF00873.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00873.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_63\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_63\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_63_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMLQLVKLALSKPYTFVVLAILIVLGGGIAAVETPTDIFPDIRIPVIAAVWTYRGLPPRDMSGRVIYYYERSLSATVGDIDHIESQSLSGVGIVKIFFRPGVDIRTATAQVTAASQTVLKQMPPGITPPLILNYNASTVPILQLALSGKGLSEQKIYDLGQNMIRPALASVQGSAIPSPYGGKERQVQIDLDPAALQAHRLSATDVANALAQQNQIIPSGTAKIGQYEYNLRLNNSPSVIDDLNDLPIKTVDGATVLMHDVAHVRDGSPPQRNEVRVDGARSVLMTVLKSGSASTIAIVDSVKALMPKLEATLPPGLNVTLLSDQSVFVKAAVSGVMREGVIAAALTSLMILLFLGSWRSTVIIAASIPLAILAAIAGLSVAGQTLNIMTLGGLALAVGILVDDATVTIENINWHLEQGKPVREAILDGAKQIVGPAFVSLLCICIAFLPMFFLPGVAGFLFAPMAMAVVFAMIASFILSRTLVPTMGNYLLRDHAGPHTAEVMVAHDAQAGRPQSRNPFRRFQHGFEQRFEAVRGYYTGLLAFALARRRPFVIGFMVVVLISFALVPMLGRNFFPAVDAGQISIHVRAPVGTRIEETAALFDHIENRIRAVVPADQLDTIVDNIGLPVSGINRAYSNTGGVGPQDGDILVTLKEGHAPTAGYVKALREQLPRDFPGSSFAFLPADIVSQILNFGSPAPIDVQVAGPDTKGGEAYARMLVDRLSRIPGLADVRLQQASNYPEYAVDVDRAQASRLGITENDVTRSLTVNLAGSSQVAPTFWLNPKNGVSYPIVVQTPQYRASTVEQIDNLPITGSAGGNVQTLQALGTLHREPSPALVSHYAVQPVFDVYATTQGRDLGAVAADIDKVLAATKGQLPKGATVAMRGQVETMNTAFTGLILGLAGAIILIYLLIVVNFQSWIDPLVIVSALPAALAGIVWMLFATHTPLSVPALTGAIMCMGVATANSVLVVSFARERLAACGNAIQAAMEAGATRFRPVLMTALSMMIGMAPMALGLGEGGEQNAPLGRAVIGGLLCATLATLVFVPVVFAIAHRRDKAAAPSTSNDLSLGEAIHA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_63\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_63\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTTCAGCTCGTCAAGCTCGCCCTCAGCAAACCTTATACCTTCGTCGTTCTCGCGATCCTGATCGTGCTGGGCGGCGGCATCGCGGCGGTCGAGACGCCGACCGACATTTTCCCCGACATCCGCATCCCGGTGATCGCGGCGGTGTGGACCTATCGCGGTCTGCCGCCACGCGACATGTCGGGCCGCGTCATCTATTATTACGAACGTTCGCTGTCGGCGACGGTCGGCGATATCGACCATATCGAAAGCCAGTCGCTGTCGGGCGTCGGCATCGTGAAGATCTTCTTCCGCCCCGGCGTCGACATCCGCACCGCCACCGCGCAGGTGACCGCCGCCTCGCAGACCGTGCTGAAGCAGATGCCGCCGGGCATCACCCCGCCGCTGATCCTGAACTACAACGCCTCGACCGTGCCGATCCTGCAACTCGCGCTCTCCGGCAAGGGGCTGTCCGAGCAGAAGATCTACGACCTGGGGCAGAACATGATCCGCCCGGCGCTGGCGTCGGTGCAGGGTTCGGCCATCCCGTCGCCCTATGGCGGCAAGGAGCGACAGGTCCAGATCGACCTCGATCCCGCCGCCCTTCAGGCGCATCGCCTGTCCGCGACCGATGTCGCCAATGCGCTGGCGCAGCAGAACCAGATCATCCCGTCGGGCACGGCCAAGATCGGCCAGTATGAATATAACCTCCGGCTCAACAACAGCCCGAGCGTCATCGACGATCTGAACGACCTGCCGATCAAGACGGTCGACGGAGCGACCGTGCTGATGCACGACGTGGCGCATGTCCGCGACGGTTCGCCGCCGCAGCGCAACGAGGTGCGGGTCGATGGCGCGCGATCGGTGCTGATGACCGTGCTGAAGAGCGGTTCGGCCTCGACCATCGCCATCGTCGACTCGGTCAAGGCGCTGATGCCCAAGCTGGAGGCGACCCTGCCGCCGGGGCTGAACGTCACGCTGCTGTCCGACCAGTCGGTCTTCGTGAAGGCGGCGGTGTCGGGGGTGATGCGCGAAGGCGTGATCGCCGCCGCGCTCACCAGCCTGATGATCCTGCTGTTCCTGGGTTCGTGGCGCTCGACCGTCATCATCGCCGCGTCGATCCCGCTCGCCATCCTGGCGGCGATCGCCGGGTTGTCGGTGGCGGGGCAGACGCTCAATATCATGACGCTGGGCGGCCTGGCCCTGGCGGTCGGCATCCTGGTCGACGATGCGACCGTCACCATCGAGAATATCAACTGGCATCTGGAACAGGGCAAGCCGGTGCGCGAGGCGATCCTGGACGGCGCCAAGCAGATCGTCGGCCCGGCCTTCGTCTCGTTGCTGTGCATCTGCATCGCCTTCCTGCCGATGTTCTTCCTGCCGGGCGTCGCGGGCTTCCTGTTCGCGCCGATGGCGATGGCGGTGGTCTTCGCGATGATCGCCTCGTTCATCCTGTCGCGCACGCTGGTGCCGACCATGGGCAATTACCTGCTGCGCGATCATGCCGGGCCGCACACCGCCGAGGTGATGGTGGCCCATGACGCGCAGGCGGGCCGCCCACAGAGCCGCAACCCGTTCCGCCGTTTCCAGCATGGCTTCGAGCAGCGGTTCGAGGCAGTGCGCGGCTATTATACCGGCCTCCTCGCCTTTGCGCTGGCCCGGCGGCGGCCGTTCGTCATCGGCTTCATGGTCGTGGTGCTGATCTCGTTCGCACTGGTGCCGATGCTGGGGCGGAATTTCTTCCCTGCGGTCGATGCCGGACAGATCAGCATCCATGTCCGCGCGCCGGTCGGCACCCGCATCGAGGAGACGGCGGCGCTGTTCGACCATATCGAAAACCGTATCCGCGCCGTGGTGCCCGCCGACCAGCTCGACACCATCGTCGACAATATCGGCCTGCCGGTCAGCGGCATCAACCGCGCCTATTCCAACACCGGCGGCGTCGGTCCGCAGGACGGCGACATCCTCGTCACGCTGAAGGAAGGCCATGCGCCCACCGCCGGCTATGTGAAGGCGTTGCGCGAGCAACTGCCGCGTGACTTCCCCGGCTCGTCCTTCGCCTTCCTGCCCGCCGATATCGTCAGCCAGATCCTGAACTTCGGCTCGCCCGCGCCGATCGACGTGCAGGTCGCCGGGCCCGATACCAAGGGCGGCGAGGCCTATGCGCGGATGCTGGTCGACAGGCTGTCGCGCATTCCCGGGCTGGCCGATGTGCGCCTGCAACAGGCGTCCAACTATCCCGAATATGCGGTCGATGTGGACCGCGCCCAGGCCAGCCGCCTCGGCATCACCGAGAATGACGTGACGCGCAGCCTGACCGTCAATCTGGCCGGCAGTTCGCAGGTCGCCCCGACCTTCTGGTTGAATCCGAAGAACGGCGTCTCCTATCCGATCGTCGTCCAGACCCCGCAATATCGCGCCAGCACCGTCGAGCAGATCGACAATCTGCCGATCACGGGCAGCGCGGGGGGCAATGTCCAGACGCTTCAGGCGCTGGGCACGCTCCACCGCGAACCCAGCCCCGCGCTCGTCTCGCATTATGCGGTGCAGCCGGTGTTCGACGTCTATGCGACGACGCAAGGTCGCGATCTGGGCGCGGTCGCGGCGGACATCGACAAGGTGCTGGCCGCCACCAAGGGCCAGTTGCCCAAGGGCGCGACCGTCGCGATGCGGGGACAGGTGGAGACGATGAACACCGCCTTCACCGGCCTGATCCTGGGTCTCGCGGGTGCGATCATCCTGATCTACCTGCTGATCGTCGTGAACTTCCAGAGCTGGATCGATCCGCTGGTGATCGTCTCGGCCCTGCCCGCCGCGCTTGCCGGGATCGTATGGATGCTGTTCGCGACGCATACGCCGCTCAGCGTGCCCGCGCTGACCGGGGCCATCATGTGCATGGGCGTGGCCACCGCCAACAGCGTGCTGGTGGTCAGCTTCGCCCGCGAAAGGCTGGCGGCGTGCGGCAACGCGATCCAGGCGGCGATGGAGGCGGGCGCCACCCGCTTCCGCCCGGTGCTGATGACCGCGCTGTCGATGATGATCGGCATGGCCCCCATGGCGCTGGGTCTGGGCGAGGGCGGCGAACAGAATGCGCCACTCGGCCGTGCGGTCATCGGCGGGCTGCTCTGCGCCACGCTCGCCACCTTGGTCTTCGTTCCCGTCGTCTTCGCCATCGCGCACCGCCGCGACAAGGCGGCCGCTCCTTCCACTTCCAACGACCTGTCCCTCGGAGAAGCCATCCATGCATGA",
    "translation": "MLQLVKLALSKPYTFVVLAILIVLGGGIAAVETPTDIFPDIRIPVIAAVWTYRGLPPRDMSGRVIYYYERSLSATVGDIDHIESQSLSGVGIVKIFFRPGVDIRTATAQVTAASQTVLKQMPPGITPPLILNYNASTVPILQLALSGKGLSEQKIYDLGQNMIRPALASVQGSAIPSPYGGKERQVQIDLDPAALQAHRLSATDVANALAQQNQIIPSGTAKIGQYEYNLRLNNSPSVIDDLNDLPIKTVDGATVLMHDVAHVRDGSPPQRNEVRVDGARSVLMTVLKSGSASTIAIVDSVKALMPKLEATLPPGLNVTLLSDQSVFVKAAVSGVMREGVIAAALTSLMILLFLGSWRSTVIIAASIPLAILAAIAGLSVAGQTLNIMTLGGLALAVGILVDDATVTIENINWHLEQGKPVREAILDGAKQIVGPAFVSLLCICIAFLPMFFLPGVAGFLFAPMAMAVVFAMIASFILSRTLVPTMGNYLLRDHAGPHTAEVMVAHDAQAGRPQSRNPFRRFQHGFEQRFEAVRGYYTGLLAFALARRRPFVIGFMVVVLISFALVPMLGRNFFPAVDAGQISIHVRAPVGTRIEETAALFDHIENRIRAVVPADQLDTIVDNIGLPVSGINRAYSNTGGVGPQDGDILVTLKEGHAPTAGYVKALREQLPRDFPGSSFAFLPADIVSQILNFGSPAPIDVQVAGPDTKGGEAYARMLVDRLSRIPGLADVRLQQASNYPEYAVDVDRAQASRLGITENDVTRSLTVNLAGSSQVAPTFWLNPKNGVSYPIVVQTPQYRASTVEQIDNLPITGSAGGNVQTLQALGTLHREPSPALVSHYAVQPVFDVYATTQGRDLGAVAADIDKVLAATKGQLPKGATVAMRGQVETMNTAFTGLILGLAGAIILIYLLIVVNFQSWIDPLVIVSALPAALAGIVWMLFATHTPLSVPALTGAIMCMGVATANSVLVVSFARERLAACGNAIQAAMEAGATRFRPVLMTALSMMIGMAPMALGLGEGGEQNAPLGRAVIGGLLCATLATLVFVPVVFAIAHRRDKAAAPSTSNDLSLGEAIHA",
    "product": ""
   },
   {
    "start": 79937,
    "end": 81310,
    "strand": -1,
    "locus_tag": "ctg11_64",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_64</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_64</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 79,937 - 81,310,\n (total: 1374 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1003:sensor histidine kinase (Score: 139; E-value: 4.4e-42)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_64 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02518.29 (Histidine kinase-, DNA gyrase B-, and HSP90-like ATPase): [346:450](score: 62.5, e-value: 5.2e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_64\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_64\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_64_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_64\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_64\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGGCTGAGCCGTTCCGCTGGCGTGACGTCGTCCGGATCAGCACCTTCCGCCTGTCGGCCATGCTGGGCGCGGTGTTCGTCACCGCCGTGATCGCCATGCTGGGCGTGGTCTATATCGCGACCGCGCGCGATCTGACCGTCCGCAGCGACCGCATCCTCCACGCCGCCGCCGGGCAATTGCTGCAGGTCCCGGCCGACGAACTGCCCGACCGCATCCGCGCCGAGTTGAAGCGTGATCGGTCCGGCTTCAACTATCTGGCGCTGATCGCGGCGGACGGCACCCTGATCGTCGGCAATGTCCGCCCTTTGCGTCCGCTAATCCCCGGCCATCCGGTCGATGTCGAGAGCGGATCACGCGGGCCCTTTCGCCTGGTCGCCCTGCGCACCCGTGAGAAGGAGACGCTGCTGGTCGGGCGTGACATCAGCCTGCTGCGCGATCTGCGGAACACGGTTCTGGAGACGCTGGTGGTCAGCGGGTTGATGACCCTGATCTGCATCGGGACTGCGGCGATCGGATTCAGCCGGGCGCCGCTGCACCGCGTCCGGGCGCTCCAGCGGGCCAGCCGGGAGATTGCGGCGGGGGATTTTTCGGTGCGGATGCCGATCGCGGGGCGGCATGACGAACTCGATCAGTTCGCCGCGACCGTGAACGTCACCGTCGAGGAGGTCGGCCGCGTCGTTGCGCAGGTGAAGGGCGTGACCGACGCCATCGCGCACGATTTGCGCACACCGCTGACCCGCGTCCGCGCCACGTTGAATGCGGTCGGCCACCGGCCCGACGATCCGGCGGGCGTCGTCGCCGGGATCGCGCAGGCGACCGCCGACCTGGACCTGGTGCTCGAGCGTTTCGCCGCGCTGCTCCGGATATCGGAATTGGAGGCGGGGCGGCGGCGGGCCGGGTTCCGCCGCGTCGATCTGGGCGCTCTCGTCGCGCAGGTGGCCGAGCTGTACGAGCCTCTGGCCGAAGACCGCGCCATCACCCTGTCGGTCGCCGCCAGGCCCCTGTCGGTCGCCGCCAGGCCCCTGTCGGTCGAGGGCGACGACAAGCTGTTGTTCGAGGCGCTGAGCAATCTGGTCGACAATGCGATCAAGTTCGGGCGGCCCGGTGGGCAAGTGCATATCGCGCTGTTCGACGATGAGGCGGCCCGCGCGATCGAGGTCCGCGACGACGGCCCCGGCATCCCGTCCGAAGAGCGCGACGCGGTGCTCCATCGTTTCCATCGGGGCACACACGCCGCCGGTGTGCCGGGCAGCGGTTTGGGCTTGAGCGTCGTGGCGGCGATCCTGCACCTCCACGGTTTTCGCCTGCGCCTGTCCGATGCCGACCCGGGGCTTTGCGTGCGGATCGAGGTCGGGCCGGCGGTGGCCTGA",
    "translation": "MAAEPFRWRDVVRISTFRLSAMLGAVFVTAVIAMLGVVYIATARDLTVRSDRILHAAAGQLLQVPADELPDRIRAELKRDRSGFNYLALIAADGTLIVGNVRPLRPLIPGHPVDVESGSRGPFRLVALRTREKETLLVGRDISLLRDLRNTVLETLVVSGLMTLICIGTAAIGFSRAPLHRVRALQRASREIAAGDFSVRMPIAGRHDELDQFAATVNVTVEEVGRVVAQVKGVTDAIAHDLRTPLTRVRATLNAVGHRPDDPAGVVAGIAQATADLDLVLERFAALLRISELEAGRRRAGFRRVDLGALVAQVAELYEPLAEDRAITLSVAARPLSVAARPLSVEGDDKLLFEALSNLVDNAIKFGRPGGQVHIALFDDEAARAIEVRDDGPGIPSEERDAVLHRFHRGTHAAGVPGSGLGLSVVAAILHLHGFRLRLSDADPGLCVRIEVGPAVA",
    "product": ""
   },
   {
    "start": 81300,
    "end": 82001,
    "strand": -1,
    "locus_tag": "ctg11_65",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_65</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_65</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 81,300 - 82,001,\n (total: 702 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1008:response regulator (Score: 194.5; E-value: 3.1e-59)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_65 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00072.27 (Response regulator receiver domain): [12:122](score: 84.2, e-value: 7.4e-24)<br>\n \n  PF00486.31 (Transcriptional regulatory protein, C terminal): [154:230](score: 80.3, e-value: 9.3e-23)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_65 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00072.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF00486.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_65\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_65\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_65_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_65\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_65\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGGGCGGGCGGCTATGCCGATGGCATGGCGGCTATCCTGGTCATCGAAGACGACGGCGCGACCGCTGCGGCGATCATCGCCGAGCTGAAGCAGCATGGGCATGAGGTGACACATGCTAGCGATGGCGATGCCGGCCTGGAGCTCGCGACCCGCGAGGCGTTCGATGCGATCACGCTAGACCGGATGTTGCCGAGGCTGGACGGCCTGTCGCTCGTGGCCCGGCTGCGCGAACGGCATATCACCATTCCCGTGCTGATGCTGAGCGCGTTGAGCGATGTCGATGAGCGGATTGCGGGGCTGCGCGCAGGGGGCGACGATTATCTGACCAAGCCCTTCGACTTTGCCGAAATGGCGATGCGGGTCGAGGTGCTGCTGCGCCGCCGCGAGCAGGCCGAGGCCGTGGTGCTGCGCGGCGGAGGCATCGAGTGCGACCTCGTCCGCCGGACCGTGAAGGTCGATGGCGAGCCGGTGCGGCTGCTGCATATGGAATTCCGCCTGCTCGAATTCCTGATGCGCAACCAGGGCGAGGTGATGACCCGGCGGATCATCTTCGAACGGGTCTGGGGCTATTATTTCGATCCCGGCGCCAATCTGATCAGCGTGCATATCGCGCGGCTGCGCAAGAAGATCGACCGGCCGGATCGTTCCTCGCCCATCCAGACGGTGAAGGGCGAGGGATATCTGTTCGATGGCGGCTGA",
    "translation": "MGAGGYADGMAAILVIEDDGATAAAIIAELKQHGHEVTHASDGDAGLELATREAFDAITLDRMLPRLDGLSLVARLRERHITIPVLMLSALSDVDERIAGLRAGGDDYLTKPFDFAEMAMRVEVLLRRREQAEAVVLRGGGIECDLVRRTVKVDGEPVRLLHMEFRLLEFLMRNQGEVMTRRIIFERVWGYYFDPGANLISVHIARLRKKIDRPDRSSPIQTVKGEGYLFDGG",
    "product": ""
   },
   {
    "start": 82107,
    "end": 82364,
    "strand": 1,
    "locus_tag": "ctg11_66",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_66</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_66</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 82,107 - 82,364,\n (total: 258 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_66\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_66\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_66\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_66\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTCCACACCCGCTTATGGATCATCATCCTCTCGACCGCCCTCCTCGCCACCCCCGCTGTCGCCGCCGGGGACCAGGCCGATACAGGGGACGACTGCTTCGCCGTCGCCGCGCCGATGGCCGACGCGACGCCCTGCTTTGTGCCCGGGCGTCACAAGAAACATCATAAACCCCGACCCAAGCACGCAAGCCATGCCGCCGGGGAACGGGTTTTGCAAACCGGGGACTCGACCAAGAGAACGACGCAAGGATCATAG",
    "translation": "MLHTRLWIIILSTALLATPAVAAGDQADTGDDCFAVAAPMADATPCFVPGRHKKHHKPRPKHASHAAGERVLQTGDSTKRTTQGS",
    "product": ""
   },
   {
    "start": 83004,
    "end": 83417,
    "strand": -1,
    "locus_tag": "ctg11_67",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_67</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_67</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 83,004 - 83,417,\n (total: 414 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_67\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_67\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_67\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_67\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGTTGGTGCCGTTTGTGATCGGCGGCGCGGTATGGGCGCACGGCGCGATGTTCCCGGCCAGGCACAGGATCGTGATCGAGCCCGTGAGGGGGCTATGCGAATATGTGCTTTTCCCACACTTCAACGCGGGACTCCGCGAGAGCTTCGTGGCCGAGGTGAGCCACAGGCTTCCTGCCCACTATTCCGTGGCCGCCAATGGTGAAAAAGCCGATCTCCATGCGAGTGTCAGTGTCCGGCAGACGTCGCAACGAACGACCGTGGTTGTGACGCTGGCCGAGGATGGTTCCGATCGCGTGTTGTGGTCCAGTCAGTTTTCCGCTCCAACCGACATGCAGGATTACGTGCCGCTTCAAGAGAAGCTGGCGAGAAGCATGGCGACCGGTCTTGCGCGGACAGTTGCTCGGATGAGTTGA",
    "translation": "MLVPFVIGGAVWAHGAMFPARHRIVIEPVRGLCEYVLFPHFNAGLRESFVAEVSHRLPAHYSVAANGEKADLHASVSVRQTSQRTTVVVTLAEDGSDRVLWSSQFSAPTDMQDYVPLQEKLARSMATGLARTVARMS",
    "product": ""
   },
   {
    "start": 83857,
    "end": 85404,
    "strand": 1,
    "locus_tag": "ctg11_68",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_68</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_68</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 83,857 - 85,404,\n (total: 1548 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1053:beta-lactamase (Score: 140.6; E-value: 1e-42)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_68 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00144.27 (Beta-lactamase): [64:388](score: 159.2, e-value: 1.6e-46)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_68\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_68\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_68\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_68\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGGCCTGAGCGCCGGGGGAGGATAACCGATCCGAACACCGTCTGCATCCTTCCGAAAGGCCTATCCTTGCGACAGACATTCCATCTTCCGGATACCGACCGGCGACGTGTTCTTGCCCTTGGCCTGTCCGGCCTGATGACATCGATAGGGTGGGCGACGACCGTCCATGCGACCGAGCCTTCTGCGGCGATCGACGACCTGCTCGACCGCTCCGCAGATGCTTATGGCACGGTGGGCCACTCCGTCGCCGTTCTACGACGCGGCAGGCTCGTCTATTCGCGTCATGCCGGGCTGTCCGATCGCGAGACGGGCGCTCCTATCACCGACGCCTCCGTCTATCCGCTCTTTTCGATCTCCAAGCTGTTCGTGATCGTGGAGTTGCTCAAGGCGCGTCAGGCCGGACTGATCAACCTTGATGCATCACTAGCCACGATACGCGCTGGTCTTCCATCAGCATGGGCCGGGATCACCTTGTTACAGGCCTTGGCCCATGTTTCGGGCCTACCCGACTATATTCCCGATCATGTCGAGCCGACCGACGAGCAGGCCTTCGCCAGCATCGCGACGCTTCCGCTCCGTTTCGCACCAGGCTCGCGTAACGAGTATAATCAGACAAACTTCCTGTTCGCCAAAAAAGCGCTAGAACAGGCGACGCGAACGCCGCTGACGAACTTGACGGGGCGTCAGTTCGCTCGCGCCGGAATGACGCGGACCAGCTACCATGTGGAGGGGCAACCCCGGTTGCCGGACCTGGTGTCGAGCTACCGCCCGGCTCCCAAGCGCGATCGACCGCCGCTGCCCTATGTCTCTCCCTCGTGGCCGGCCTATACCTTCGGCTCGCGGGGCGTCTTCACGACGCTGCCCGATCTGGTCCGATGGTCACAGGCGCTGCTTTATGGTGCGCTCGTGCCGCTCGCGGCGCTTCGGGAATCATGGTCGCCCTTTGCCATGCCGTCCCGGAATGCGGCGTGGCACACCCATGGGTGGGAATATTATCGGCACGACGACGTGACGATCGTCGGCCATGGCGGCGAAGCGCGGCTCGTCTGGCGGCATTTCTTCCGTCAGGCCGACCCGGACGACAGCGCGACGGTGATCTATCTCGACAATGGCGGCCGTACGACGTTCGACCGCCATCGGCTTGCCACGCTGGTCGCCGATCGCGTCATGCCGGGGGTCGCCCGCAAGGACGAAGAGCAGGAGGAGGCACTTTACCGGGGCATGGCGTCAGGCCGGTGGGAGCAGGCCAGCGCGACCGTCGCGGCGGCGATATCCACGGACCGGCTGGAAGCGATCGTCAACCGTGTCGGCTACGACGCCATGAACATCCTCGATGCCGAAGCCGCCCTGCCGGTGTTCCGATGGAACGCCGAGCGCTTTCCCCGCTCTGCCAATGCCCATGACAGTTTGGGCGAAGCCTATCGGGCCGCTGGCCAATGCGACCGGGCCAAGGAGAGCTATGCCCGCGCATTGGCGCTCGATCCGGCAAACGATCGCCTCAAGGCGACGATCGACGAACTGAACCAGGCGGCGTGCTGCCGATAA",
    "translation": "MRPERRGRITDPNTVCILPKGLSLRQTFHLPDTDRRRVLALGLSGLMTSIGWATTVHATEPSAAIDDLLDRSADAYGTVGHSVAVLRRGRLVYSRHAGLSDRETGAPITDASVYPLFSISKLFVIVELLKARQAGLINLDASLATIRAGLPSAWAGITLLQALAHVSGLPDYIPDHVEPTDEQAFASIATLPLRFAPGSRNEYNQTNFLFAKKALEQATRTPLTNLTGRQFARAGMTRTSYHVEGQPRLPDLVSSYRPAPKRDRPPLPYVSPSWPAYTFGSRGVFTTLPDLVRWSQALLYGALVPLAALRESWSPFAMPSRNAAWHTHGWEYYRHDDVTIVGHGGEARLVWRHFFRQADPDDSATVIYLDNGGRTTFDRHRLATLVADRVMPGVARKDEEQEEALYRGMASGRWEQASATVAAAISTDRLEAIVNRVGYDAMNILDAEAALPVFRWNAERFPRSANAHDSLGEAYRAAGQCDRAKESYARALALDPANDRLKATIDELNQAACCR",
    "product": ""
   },
   {
    "start": 85620,
    "end": 87422,
    "strand": -1,
    "locus_tag": "ctg11_69",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_69</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_69</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 85,620 - 87,422,\n (total: 1803 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_69 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03600.19 (Citrate transporter): [23:546](score: 158.4, e-value: 2.4e-46)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_69 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03600.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF03600.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_69\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_69\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg11_69_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_69\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_69\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGAAATCCTCGCCGGCATCGAGGCCCATCGTGCGGCGCTGGGGCTGATATTCATAACTGGTTTGTTCGTTGCGTTCGCGCTCGAACGCTTTCCCCCCGTCACGATCGCGGTCGCCGGTGCGGCGATCATGATGGCGCTGGGCTGGCTCACGCCACCGCTCGTCACCGCCGCGTTCGCGAATCCGGCGCCGATTACGATCGCGGCCTTCTTCATCCTGTCAGGCGCGCTGGTGCGGACCGGTACGATAGAGGCGCTCGCCAGTCTGATCGTTCGGCGGGCGGGAAATGCGCCACGGCGCACGGTCGCCGAAATGCTGACCGGCGCGGCTATCGCACCCGCGTTCATCAATAACACGCCGGTCGTCATGGTCTTGATCCCGCTCGTACGCAGACTGGCGCGGACGGTCGGCATACCGGCGACCCGCCTGCTGATCCCACTGTCCTATCTTTCGATTTTGGGCGGTACGCTGACATTGGTCGGCACCTCGACAAACCTGCTGGTCGACGGCGTGGCACGCGCGAACGGGCAGCCGGGTTTCGGCATCTTCGATATCACGGCCATCGGTCTGGTGACGATGGCGGCGGGGGCGGTGGCCATGCTGGTTCTTGGTCCCCGTCTGCTGCCGTCTCGGCCCGACAATACCATAGCCGATCGGCACCAGCTGTCCTATCTCACCGAGATCGCGCTGATGCCTGACGTATCAGCGAAGAATATATGCGTGGCAGATATCGCATTCCTGCGCCGCGATGCGATCAGGCTGATCGCGGTCCGCCGCGGGTCGCGGATTGAGCGTAACCCCCCGGCGGATATGATTCTTCAAACGGCCGATCGCTTGGTCGTCAGCGCAACCGCTGACGAACTCGATGATCTGGCGCGCAGCGAGGAGTATCTGGTTGGCCTTCAAAATGTGGGGCGCCCCATTCGCCTGTCCGACAGCGCACGGTCGGACGATGTAAAGCTCATTGGCTTGACGATCGGCCCCGCGCATCCGGCGCTGGGTCGCGAGCTACGCGACATTCCTTTCCTGTCGAATCTTCCGGCACGCATTCTGGGGATTGGCCGGGCGCGACACCTTCCAGGCCCCGATCTGGCAAGCGTGCGTTTGCGCGCGGCGGACAATTTACTGGTGGCGGCAGATGGCACGGCCCTTGCCGAATTGCGCGCCAACACGAACCTGATTGCTGAAGACACCAGCCATATTCGCCGCTTCCGCCGCGCGCGTGCCCCGATCGCGATCGGGGTACTGGCTGGCGTGATTGCGCTGGCCGCCTTGGGGGTGGCGTCGGCCACGTCGCTCGCCATCGTCGGAGTCGGCATGGTTCTGATCACGCGGTGCGTGGATGCGGAAGAAGCCTGGCGATCGATCGATGGCAGCGTCCTGGTGTTGATCTTCGCCATGCTGGGCATCGGCGGTGCCTTGGAGAATATGGGGACCATCGACCTGATCGTCGGCGCGATATCGCCATGGTTGGCCACGTTGTCACCACTTGGGGTGCTTCTGATCCTGTATTTCCTGACCTCGGCTTTGACGGAAACGGTGACCAACAGTGCGGTAGCCGTCATCATGACCCCGGTGGCCATCGGTTTGGCCCAATCCACCAGCCAAGACCCGCGCGCGCTTATCATCGCGGTGATGTTCGCGGCCTCCGCGAGCTTCGCGACGCCTGTCGGGTATCAGACCAACACGATGGTCTACGCTGCGGCCGATTACCGTTTCTCCGATTTTGTCCGGATCGGCCTGCCTATGAATGTCATCGTTGGCTTGGCCACTTGCTTCGCTATCAATTGGCTGGCGTAG",
    "translation": "MSEILAGIEAHRAALGLIFITGLFVAFALERFPPVTIAVAGAAIMMALGWLTPPLVTAAFANPAPITIAAFFILSGALVRTGTIEALASLIVRRAGNAPRRTVAEMLTGAAIAPAFINNTPVVMVLIPLVRRLARTVGIPATRLLIPLSYLSILGGTLTLVGTSTNLLVDGVARANGQPGFGIFDITAIGLVTMAAGAVAMLVLGPRLLPSRPDNTIADRHQLSYLTEIALMPDVSAKNICVADIAFLRRDAIRLIAVRRGSRIERNPPADMILQTADRLVVSATADELDDLARSEEYLVGLQNVGRPIRLSDSARSDDVKLIGLTIGPAHPALGRELRDIPFLSNLPARILGIGRARHLPGPDLASVRLRAADNLLVAADGTALAELRANTNLIAEDTSHIRRFRRARAPIAIGVLAGVIALAALGVASATSLAIVGVGMVLITRCVDAEEAWRSIDGSVLVLIFAMLGIGGALENMGTIDLIVGAISPWLATLSPLGVLLILYFLTSALTETVTNSAVAVIMTPVAIGLAQSTSQDPRALIIAVMFAASASFATPVGYQTNTMVYAAADYRFSDFVRIGLPMNVIVGLATCFAINWLA",
    "product": ""
   },
   {
    "start": 87419,
    "end": 88462,
    "strand": -1,
    "locus_tag": "ctg11_70",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_70</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_70</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 87,419 - 88,462,\n (total: 1044 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_70 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07885.19 (Ion channel): [34:112](score: 51.7, e-value: 7e-14)<br>\n \n  PF02254.21 (TrkA-N domain): [132:251](score: 82.0, e-value: 4.1e-23)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_70 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02254.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006813' target='_blank'>GO:0006813</a>: potassium ion transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_70\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_70\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_70\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_70\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGACATCGCTGGCCGGAAACCCGATTATCACCTGTACCGCCGTAGCCGGACGCCGATCTGGCTGGCCCTGTCCTGGCGGGCCTTGCTGGCGCTGGGCCTGATCGGTATCGCGCTGGCCGTCCACTGGTTCGACCGCGATGGCCTGCGCCAGTCATCGGGCGAGCCGGTCACCTTCACCGACATCCTCTACTTCACGATGATCACGGTCACGACCGTCGGCTATGGCGACATCGTGCCCGTCACTCAGCAGTCGCGGCTGTTCGACACCTTCGTCGTCACCCCGATCCGGCTGTTCGTGTGGCTCATTTTCCTGGGAACCGCCTATGACTTTCTTCTCAAGCGCGTGTGGGAGCGATGGCGCATGTCGGTGATCCAGCGGCAGCTGCGCGACCATGTCGTCATCGCGGGCTTCGGCAATAGCGGATCGGAAGCCGCCAGCGAATTGATCCGCCGCGGCGCGCATCCCGACATGATCGTCGTGATCGATGAAAGCCCTGCTGCACTCCGTAACGCCGAAGCGCTGGACGTCGCCGTCATGGAGGGCAACGCCACGCGCGATGCCGCCTTGCGGGCGGTGCGTGTGGGTACGGCCAGGGCGTTGATCGTGGCCGCTGGGCGCGACGATACCTCCATCCTGATCGTCCTGACCGCCCGCCGCATCGCGCCGACGCTGCCGATCAGCGTCATCATCCGCTCGCTCGACAATGAAGCGATCGCGCGGCAGGCGGGGGCCAATACCGTCATCAATCCGGCGAGCTTCGCCGGCCTGCTTCTCGCCGGGTCCACGCACGGCACACATTTGGCCGACTATATGGCGGATCTGGCGGCAACGGATGGCCGGGTCGCGCTGCGTGAACGGCGCGTCGCGGCGGACGAAATCGGTGTGCCGCTGCGGGCTATCACCACCGGCCTTGGCCATCGCATTTATCGTAAGGGCTCAATGATCGGTTTTTGGGAAGCGGCGGCAAACCGCCTGGAAGCGGGGGACGTCATTCTGGAGGTCGTACCAGCCCTCGGCCAGGATACAGACGGGCCGGCATGA",
    "translation": "MDIAGRKPDYHLYRRSRTPIWLALSWRALLALGLIGIALAVHWFDRDGLRQSSGEPVTFTDILYFTMITVTTVGYGDIVPVTQQSRLFDTFVVTPIRLFVWLIFLGTAYDFLLKRVWERWRMSVIQRQLRDHVVIAGFGNSGSEAASELIRRGAHPDMIVVIDESPAALRNAEALDVAVMEGNATRDAALRAVRVGTARALIVAAGRDDTSILIVLTARRIAPTLPISVIIRSLDNEAIARQAGANTVINPASFAGLLLAGSTHGTHLADYMADLAATDGRVALRERRVAADEIGVPLRAITTGLGHRIYRKGSMIGFWEAAANRLEAGDVILEVVPALGQDTDGPA",
    "product": ""
   },
   {
    "start": 88472,
    "end": 88885,
    "strand": -1,
    "locus_tag": "ctg11_71",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_71</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_71</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 88,472 - 88,885,\n (total: 414 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_71 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03334.17 (Na+/H+ antiporter subunit): [11:91](score: 82.3, e-value: 2.4e-23)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_71 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03334.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015297' target='_blank'>GO:0015297</a>: antiporter activity<br>\n  \n   PF03334.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0098662' target='_blank'>GO:0098662</a>: inorganic cation transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_71\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_71\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_71\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_71\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGTCATCGCCGACATCGCCATCACCGTCCTGCTGATCCTCGGGGGCGGCTTCGCGCTCATCGGCAGCTGGGGGCTGGTGCGCCTGCCATCGACCATGGAGCGGCTTCACGGACCGACCAAGGCGACGACCCTGGGGCTGGGGGCGCTGCTCCTCGCCTCCGTCGTCTATTTTCAGACGCGGCTCGGCATCTGGACCGCGCATGAGCTGCTGATCTCGCTGTTCTTGTTCATCACCGCGCCGATCTCGGCCAATATGATCGCCAAGGTCCATCTCCACCGCGCGCGCCTCGGCAAAGCCCATGAGGATGACGGCATCGCCGGTCCGCCGCCCCGCCCCGGCGGGGACGGCGATTGGGCCACGTTCGAGGCGCCCAAGCGCAAGACGCCCGCCTCGACGGCCAGCGACTGA",
    "translation": "MSVIADIAITVLLILGGGFALIGSWGLVRLPSTMERLHGPTKATTLGLGALLLASVVYFQTRLGIWTAHELLISLFLFITAPISANMIAKVHLHRARLGKAHEDDGIAGPPPRPGGDGDWATFEAPKRKTPASTASD",
    "product": ""
   },
   {
    "start": 88882,
    "end": 89151,
    "strand": -1,
    "locus_tag": "ctg11_72",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_72</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_72</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 88,882 - 89,151,\n (total: 270 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_72 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04066.16 (Multiple resistance and pH regulation protein F (MrpF / PhaF)): [31:82](score: 72.9, e-value: 2.2e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_72 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04066.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015075' target='_blank'>GO:0015075</a>: monoatomic ion transmembrane transporter activity<br>\n  \n   PF04066.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0034220' target='_blank'>GO:0034220</a>: monoatomic ion transmembrane transport<br>\n  \n   PF04066.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_72\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_72\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_72\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_72\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCGAGGTCGCCCTTCACATCGCGTCGGGCTGCATCGCGCTCGCCCTGGCGCTGAACGTATGGCGGTTGTTGCGCGGGCCGACGCTGGGCGACCGCATCGTCGCGCTCGACACCATGGTCATCAACGCCATCGCGCTGATCATCCTGATCGGCATGATCGGCGGCAACGACACCTATTTCGAGGCCGCGCTGCTGCTGGCGATGGTCGGGTTCGTGAGCACCATCGCCTATTGCAAGTTCATCCTGCGCGGGGACATCGTCGAATGA",
    "translation": "MIEVALHIASGCIALALALNVWRLLRGPTLGDRIVALDTMVINAIALIILIGMIGGNDTYFEAALLLAMVGFVSTIAYCKFILRGDIVE",
    "product": ""
   },
   {
    "start": 89148,
    "end": 89636,
    "strand": -1,
    "locus_tag": "ctg11_73",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_73</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_73</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 89,148 - 89,636,\n (total: 489 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_73 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01899.19 (Na+/H+ ion antiporter subunit): [11:160](score: 134.8, e-value: 2e-39)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg11_73 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01899.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008324' target='_blank'>GO:0008324</a>: monoatomic cation transmembrane transporter activity<br>\n  \n   PF01899.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006812' target='_blank'>GO:0006812</a>: monoatomic cation transport<br>\n  \n   PF01899.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_73\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_73\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_73\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_73\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGCGCGTCCTGCCCCATCCGGCGCTGTCGGCGATGCTGCTGATCGTCTGGCTGTTGATGGCGAACCACATCACGGTCGGCGGCATCGTGCTGGGCGGCATCTTCGCTCTGATCCTGCCCAAATTCACCCAGCCCTTCTGGCCCGATCGCCCGCGCATGCGCTTCCGCCGCGCATTTCTAGGATATCTGGCGATCGTGCTGGTCGACATCGTCGTCGCCAATTTCGAGGTCGCCAGGCTGATCCTGTTCCGGCGCAACCGCGACCTGCGCGCGCGCTGGCTGGTCGTGCCGATCGCGCTGACGACCCCGGAAGCGATCACCATGCTGGCGGGCACGATCAGCCTGACGCCGGGCACCGTCTCGTCCGACGTCTCGGCGGATGGCCGTTTTCTCCTCGTCCACGCGCTCGACGTCGCGGACGAGGCGGCGGAGATCGCCCGCATCAAGTCGCGCTACGAAGCCCGCCTGCAACGGATTTTCGCATGA",
    "translation": "MKRVLPHPALSAMLLIVWLLMANHITVGGIVLGGIFALILPKFTQPFWPDRPRMRFRRAFLGYLAIVLVDIVVANFEVARLILFRRNRDLRARWLVVPIALTTPEAITMLAGTISLTPGTVSSDVSADGRFLLVHALDVADEAAEIARIKSRYEARLQRIFA",
    "product": ""
   },
   {
    "start": 89633,
    "end": 91156,
    "strand": -1,
    "locus_tag": "ctg11_74",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_74</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_74</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 89,633 - 91,156,\n (total: 1524 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_74 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00361.23 (Proton-conducting membrane transporter): [129:427](score: 120.2, e-value: 1.1e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_74\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_74\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_74\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_74\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGCTTCCCGACCACCTCGTCATCGCGCCGATCATCATACCCGCGGTGATCGCGCCCGTGACGATGTTGCTGATGCGACGCCATCGCCCCGTGGCGCTGGGGCTGTCGCTGGGTGGCGGCATCGCGATGCTGGCGGCGGCCGTCGCGCTGTTCGTCCGTGCGCAGGACGATGCGATCCGCAGCTATGCGCTGGGCGCGTGGCGCGCGCCGTTCGGCATCGTCCTGATGCTCGACCGGCTGGCGGCGACGATGCTGGTGCTGGCGGCGGTGCTGGCCGTCACCGTGCTGCTCCACGCCGTCATCACCGGGGCGGACAAGCGCGGCTGGCATTTCCATCCGCTGTTCCATTTCCAGCTCATGGGCCTGAACGGCGCGTTCCTGACCGGCGACCTGTTCAACCTGTTCGTGTTCTTTGAGGTGCTGCTGATCGCCTCCTACGGCCTGATGCTGCACGGGCAGGGCGCGCTGCGACTGAAGGCGGGCGTGGCCTATGTCGTGGTCAATATCGTCGGATCGGCGCTGTTCCTGATGTCGCTCGGGCTGCTCTATGGGCTGACGGGTACGCTCAACATGGCGGACCTGGCCGTCAGGGTCGCGGCGCTGGCGCGGGAGGATCAAGGGCTGCTGCGCATCGCCGGGCTGCTGCTGATGGCGGTGTTCGCGCTGAAGGCGGCGGTGGTGCCGATCCATCTCTGGCTGCCGCGCACCTACGGCGCCACCATGCCCGTCGTCGCCGCCTTGTTCGCGATCATGACCAAGGTCGGCGTCTATGCGATGATCCGCACCGTGCCGCTGATCTTCGGTGCGCAGGCGGGGGCCGCGGCCTGGGTACCGGCACCCTATTTGCTGCCCGCCGCGATCCTGGGGGCGGTGATCGGCTTTGTCGGCGTGCTGACCACGCGCGGGATGCGCGAACAGGCGGCCTTTGCGGTGCTGGCGTCCACCGGCACGCTGCTGATGGCGGTGTCGCTATGGCGCGAGGCGACGCTGGCGGCCGCGCTCTATTACATGGTGCAGGCGACCTTGGCGGGCGCGGCGCTGTTCCTGGTCGCCGATGTGACGATGCGGCGTCGCGGCCCCTATGCCGACAGCATCGTACCCAGCCCGCGCTTCGCCGGGCAGGATGTCGCCGGGCTGCTCTATCTCACCGCCGCGATCGCCGCTGTCGGGTTGCCGCCGCTGGCGGGCTTCGTCGGCAAGCTGCTGATCCTGGACGCCAGCTTCGCGCTGCCGGGGTGGCAGGCGATCTGGGCGACGATCCTCGTCACCACACTGATCGGCGTGGTCGGCTTTTCGCGCAGCGGCTCCTCGCTGTTCTGGAAGGCCGCGCCTCCGGAGACCGTCGCGATCACCGGCACGGCCCGGTCGCGCGCCGAGTTCGTCGCGCCGATCATGCTCCTGGCGATGCTCGCCCTGCTGACCATCGGCGCCGGTTGGGTCACGGAGCAGACCCGCGCCACCGCCGCGCAGGTCATGGACCCCGGCCGCTATGTCAGCGCGATCCTGGGGGGCGGGCGATGA",
    "translation": "MTLPDHLVIAPIIIPAVIAPVTMLLMRRHRPVALGLSLGGGIAMLAAAVALFVRAQDDAIRSYALGAWRAPFGIVLMLDRLAATMLVLAAVLAVTVLLHAVITGADKRGWHFHPLFHFQLMGLNGAFLTGDLFNLFVFFEVLLIASYGLMLHGQGALRLKAGVAYVVVNIVGSALFLMSLGLLYGLTGTLNMADLAVRVAALAREDQGLLRIAGLLLMAVFALKAAVVPIHLWLPRTYGATMPVVAALFAIMTKVGVYAMIRTVPLIFGAQAGAAAWVPAPYLLPAAILGAVIGFVGVLTTRGMREQAAFAVLASTGTLLMAVSLWREATLAAALYYMVQATLAGAALFLVADVTMRRRGPYADSIVPSPRFAGQDVAGLLYLTAAIAAVGLPPLAGFVGKLLILDASFALPGWQAIWATILVTTLIGVVGFSRSGSSLFWKAAPPETVAITGTARSRAEFVAPIMLLAMLALLTIGAGWVTEQTRATAAQVMDPGRYVSAILGGGR",
    "product": ""
   },
   {
    "start": 91153,
    "end": 91506,
    "strand": -1,
    "locus_tag": "ctg11_75",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg11_75</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg11_75</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 91,153 - 91,506,\n (total: 354 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg11_75 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00420.27 (NADH-ubiquinone/plastoquinone oxidoreductase chain 4L): [9:106](score: 71.5, e-value: 4e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg11_75\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg11_75\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_75\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg11_75\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCCTGGAATTCCTGGTCGCCTCCGCTATCGCCATGCTGGTTGCCGGCGGCATCTATCTGGCCCTGCGCGGACGGACCTTTCAGGTTGTGCTGGGGCTCACCCTCTTGTCCTATGCGGTCAATCTGTTCCTGTTCGCGATCGGCCGGTTGGTGGTCGATCGCCCGCCGCTTTACGCCAAGGGCGTGGCGCTGCATGCCGATCCGCTACCCCAGGCGCTGGTGCTGACCGCGATCGTCATCACCTTCGGCATGACCGCGATGACCGTGATCCTGAGCTTGCGCAGCTTCCTCGAAACCGGATCGGATCAGGTCGATGGCCGCGTTGCGCCGGACGAGGAGGACGCGGCATGA",
    "translation": "MSLEFLVASAIAMLVAGGIYLALRGRTFQVVLGLTLLSYAVNLFLFAIGRLVVDRPPLYAKGVALHADPLPQALVLTAIVITFGMTAMTVILSLRSFLETGSDQVDGRVAPDEEDAA",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 71425,
    "end": 73954,
    "tool": "rule-based-clusters",
    "neighbouring_start": 51425,
    "neighbouring_end": 93954,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [
    {
     "start": 63418,
     "end": 63420,
     "strand": -1,
     "containedBy": [
      "ctg11_53"
     ]
    },
    {
     "start": 66442,
     "end": 66444,
     "strand": -1,
     "containedBy": [
      "ctg11_55"
     ]
    },
    {
     "start": 66301,
     "end": 66303,
     "strand": -1,
     "containedBy": [
      "ctg11_55"
     ]
    },
    {
     "start": 82122,
     "end": 82124,
     "strand": 1,
     "containedBy": [
      "ctg11_66"
     ]
    },
    {
     "start": 84334,
     "end": 84336,
     "strand": 1,
     "containedBy": [
      "ctg11_68"
     ]
    },
    {
     "start": 86295,
     "end": 86297,
     "strand": -1,
     "containedBy": [
      "ctg11_69"
     ]
    }
   ],
   "bindingSites": []
  },
  "type": "NRPS-like",
  "products": [
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS-like",
  "anchor": "r11c1"
 }
};
var details_data = {
 "nrpspks": {
  "r11c1": {
   "id": "r11c1",
   "orfs": [
    {
     "id": "ctg11_60",
     "sequence": "MLRQEETTAYVPKRGWHALPDIFARHAWCDPDAPAVEARGQRRSYGELAARVDQLAARLAYLVADDHPLIGLCLSRDVDLPAWLLAVLKIGAAYLPIDPATPPNRLAHIMEDARPALIIANRCYGDIIADLGIPVMIAEEEGDPVMMVPTPAITSSTLAYVIFTSGSTGRPKGVEIEHGALVALLATMAASPGFRANEKMLGITRLSFDLSVPDLFLPFYVGGSLALIDLEEAADPTRLAAALDRHRPDLVQATPSTWRALVEQGWSGLPGLRILAGGETLTRSLADRLLLRCDELWNIYGPTETTVWSTACRVTPSHDAIPIGWPMSGITVYVTDVDLKPVPPGQVGEIVIGGPGVARGYRNRPDLTTERFVRLADGARVYRTGDLGRFDERGALYCLGRIDDQVKVRGFRIELGDVEAALSLHPGVVWSAVRLWTDPSGEALLVGYVVPRDRSLGPREIKAFLAGHLPAYMIPDRIVTLSAMPLTPNGKIDRAALPDPAAEGRPTIAQHAADAIDRRLAAIWSDLLNIGAIAAEDDFFDLGGYSLMTVRLARRIEAAFGVRLALIDLMRHSTLSDMAARIALGEQPADRTMTLFNPEGRRTPLFWLDTGPLMRNILRDLSADQPVLALNIDPHDEDALGSGTLSITAVAARLKEHLLAAYPIGALNLGGWCRWGIVAYELAQQLAAQGREVRLLALLDAECPRQGVGQRLRRQMRQMLHRIGTVQHEKASFSQRVEHATHSYAAALYAGDVLLLQPTARRTNAGWNAVVRGALTVELIPGDHETMMRGSAAPMLASALNTALASTQHRPAILPEVRSPVPVPLLQPRAIPAAGERRCQSS",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 22,
       "end": 409,
       "predictions": [
        [
         "substrate consensus",
         "Gly"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FARHAWCDPDAPAVEARGQRRSYGELAARVDQLAARLAYLVADDHPLIGLCLSRDVDLPAWLLAVLKIGAAYLPIDPATPPNRLAHIMEDARPALIIANRCYGDIIADLGIPVMIAEEEGDPVMMVPTPAITSSTLAYVIFTSGSTGRPKGVEIEHGALVALLATMAASPGFRANEKMLGITRLSFDLSVPDLFLPFYVGGSLALIDLEEAADPTRLAAALDRHRPDLVQATPSTWRALVEQGWSGLPGLRILAGGETLTRSLADRLLLRCDELWNIYGPTETTVWSTACRVTPSHDAIPIGWPMSGITVYVTDVDLKPVPPGQVGEIVIGGPGVARGYRNRPDLTTERFVRLADGARVYRTGDLGRFDERGALYCLGRIDDQVKVR",
       "dna_sequence": "TTCGCCCGTCACGCCTGGTGCGATCCCGACGCCCCGGCGGTCGAAGCACGCGGGCAGCGGCGCAGCTATGGCGAACTGGCGGCGCGTGTCGACCAGTTGGCGGCGCGGCTGGCCTATCTGGTGGCCGACGATCATCCCTTGATCGGTCTGTGCCTGTCGCGCGATGTCGATCTGCCCGCCTGGCTGCTCGCGGTGCTGAAGATCGGTGCGGCCTATCTACCGATCGATCCCGCGACCCCGCCCAACCGTCTGGCGCATATCATGGAGGATGCGCGCCCCGCCCTGATCATCGCCAATCGCTGCTATGGCGATATCATCGCCGATCTGGGGATACCGGTGATGATCGCCGAGGAGGAAGGCGATCCCGTCATGATGGTCCCGACCCCAGCGATCACCTCCTCGACGCTCGCCTATGTCATCTTCACCTCCGGTTCGACCGGCCGGCCTAAGGGCGTGGAGATCGAACATGGCGCGCTCGTCGCACTGCTGGCGACCATGGCGGCGAGCCCGGGCTTTCGCGCGAATGAGAAGATGCTGGGGATCACCCGGCTCAGCTTCGATCTGTCCGTGCCGGACCTGTTCCTGCCCTTCTATGTCGGCGGATCGCTGGCGCTGATCGATCTCGAGGAGGCTGCCGATCCCACACGGCTCGCCGCTGCGCTCGATCGGCATCGCCCCGACCTGGTGCAGGCGACACCCTCCACCTGGCGGGCACTGGTCGAACAGGGTTGGAGCGGGCTGCCAGGCTTGCGCATCCTGGCGGGCGGGGAAACGCTGACCCGTTCGCTCGCCGACCGATTGCTGCTACGCTGCGACGAGTTGTGGAATATCTATGGGCCGACCGAAACGACCGTGTGGTCGACCGCCTGCCGCGTGACCCCTAGCCATGACGCGATCCCGATCGGCTGGCCGATGAGCGGCATCACCGTGTACGTCACCGACGTCGATCTGAAACCCGTGCCGCCCGGCCAGGTGGGTGAGATCGTCATCGGCGGGCCGGGTGTCGCGCGCGGCTATCGCAATCGCCCCGACCTCACCACCGAGCGCTTCGTGCGCCTAGCCGACGGGGCGCGGGTCTATCGCACCGGCGATCTTGGCCGGTTTGACGAACGCGGCGCGCTTTATTGCCTGGGGCGGATCGACGATCAGGTGAAGGTGCGC",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PCP",
       "start": 517,
       "end": 583,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "RRLAAIWSDLLNIGAIAAEDDFFDLGGYSLMTVRLARRIEAAFGVRLALIDLMRHSTLSDMAARIA",
       "dna_sequence": "CGGCGGCTGGCGGCGATCTGGAGCGATCTGCTCAATATCGGCGCGATCGCCGCGGAGGATGATTTCTTCGACCTGGGGGGCTATTCGCTGATGACCGTGCGGCTGGCCCGCCGGATCGAGGCGGCGTTCGGCGTCCGTCTCGCACTGATCGACCTGATGCGACATTCCACGCTGTCCGACATGGCGGCGCGCATCGCG",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "Thioesterase",
       "start": 645,
       "end": 801,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "SITAVAARLKEHLLAAYPIGALNLGGWCRWGIVAYELAQQLAAQGREVRLLALLDAECPRQGVGQRLRRQMRQMLHRIGTVQHEKASFSQRVEHATHSYAAALYAGDVLLLQPTARRTNAGWNAVVRGALTVELIPGDHETMMRGSAAPMLASALN",
       "dna_sequence": "TCGATCACGGCAGTCGCGGCGCGGCTCAAGGAGCATCTGCTGGCGGCCTATCCCATCGGCGCGCTGAATCTGGGCGGATGGTGCCGCTGGGGAATCGTCGCCTATGAATTGGCGCAACAACTGGCCGCACAAGGGCGCGAGGTTCGCCTGCTTGCCCTTCTCGACGCCGAATGTCCCCGGCAGGGCGTGGGGCAGCGGCTCCGGAGGCAGATGCGCCAAATGCTCCACCGCATCGGGACCGTCCAACACGAGAAGGCCAGTTTCAGCCAGCGGGTCGAACATGCGACCCACAGCTATGCAGCCGCTCTTTACGCCGGTGACGTGCTGTTGCTGCAGCCCACCGCCCGGCGCACGAATGCCGGCTGGAATGCCGTCGTGCGCGGCGCGTTGACGGTCGAGCTCATCCCCGGCGACCATGAGACGATGATGCGGGGCAGCGCCGCGCCCATGCTCGCCTCCGCGCTGAAC",
       "abbreviation": "TE",
       "html_class": "jsdomain-terminal"
      }
     ],
     "modules": [
      {
       "start": 22,
       "end": 801,
       "complete": true,
       "iterative": false,
       "monomer": "Gly",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  }
 }
};
var resultsData = {
 "r5c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000656: 169-3770": {
       "start": 169,
       "end": 3770,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "crtI",
         "query_loc": 40593,
         "subject_loc": 2080
        },
        {
         "query": "ctg5_43",
         "subject": "crtY",
         "query_loc": 39272,
         "subject_loc": 748
        },
        {
         "query": "ctg5_48",
         "subject": "crtB",
         "query_loc": 46315,
         "subject_loc": 3302
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 2834,
         "end": 3770,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_48"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 1323,
         "end": 2838,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "crtY",
         "start": 169,
         "end": 1327,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_43"
         }
        }
       ]
      },
      "BGC0000647: 251-2872": {
       "start": 251,
       "end": 2872,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "crtI",
         "query_loc": 40593,
         "subject_loc": 1029
        },
        {
         "query": "ctg5_48",
         "subject": "crtB",
         "query_loc": 46315,
         "subject_loc": 2338
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 1804,
         "end": 2872,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_48"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 251,
         "end": 1808,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        }
       ]
      },
      "BGC0000664: 0-8391": {
       "start": 0,
       "end": 8391,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "SGR_6829",
         "query_loc": 40593,
         "subject_loc": 6355
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "SGR_6824",
         "start": 0,
         "end": 1242,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6825",
         "start": 1238,
         "end": 1967,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6826",
         "start": 1963,
         "end": 3520,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6827",
         "start": 3555,
         "end": 4572,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6828",
         "start": 4568,
         "end": 5597,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6829",
         "start": 5593,
         "end": 7117,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "SGR_6830",
         "start": 7113,
         "end": 8391,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001227: 0-12144": {
       "start": 0,
       "end": 12144,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "B446_02730",
         "query_loc": 40593,
         "subject_loc": 2780
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "B446_02720",
         "start": 0,
         "end": 1020,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02725",
         "start": 1016,
         "end": 2033,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "B446_02730",
         "start": 2029,
         "end": 3532,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "B446_02735",
         "start": 3564,
         "end": 4836,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "B446_02740",
         "start": 5082,
         "end": 6279,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "B446_02745",
         "start": 6490,
         "end": 7225,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "B446_02750",
         "start": 7221,
         "end": 8856,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "B446_02755",
         "start": 8896,
         "end": 9736,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02760",
         "start": 9842,
         "end": 10559,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02765",
         "start": 10585,
         "end": 11170,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02770",
         "start": 11073,
         "end": 12144,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000633: 0-14284": {
       "start": 0,
       "end": 14284,
       "links": [
        {
         "query": "ctg5_43",
         "subject": "crtY",
         "query_loc": 39272,
         "subject_loc": 4125
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "BAB69138.1",
         "start": 0,
         "end": 363,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAB69139.1",
         "start": 418,
         "end": 967,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAB69147.1",
         "start": 10059,
         "end": 12159,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAB69148.1",
         "start": 12241,
         "end": 14284,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtE",
         "start": 5060,
         "end": 6200,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI-1",
         "start": 6196,
         "end": 7738,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI-2",
         "start": 7734,
         "end": 8763,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtT",
         "start": 2677,
         "end": 3409,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtU",
         "start": 1121,
         "end": 2624,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtV",
         "start": 8759,
         "end": 9839,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 3452,
         "end": 4799,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_43"
         }
        }
       ]
      },
      "BGC0000640: 2399-8466": {
       "start": 2399,
       "end": 8466,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "crtI",
         "query_loc": 40593,
         "subject_loc": 6328
        },
        {
         "query": "ctg5_48",
         "subject": "crtB",
         "query_loc": 46315,
         "subject_loc": 7530
        },
        {
         "query": "ctg5_43",
         "subject": "crtY",
         "query_loc": 39272,
         "subject_loc": 5008
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 7067,
         "end": 7994,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_48"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 2399,
         "end": 3305,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 5589,
         "end": 7068,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "crtY",
         "start": 4423,
         "end": 5593,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_43"
         }
        },
        {
         "locus_tag": "crtZ",
         "start": 7908,
         "end": 8466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "idi",
         "start": 3342,
         "end": 4392,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000630: 389-6051": {
       "start": 389,
       "end": 6051,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "crtI",
         "query_loc": 40593,
         "subject_loc": 3509
        },
        {
         "query": "ctg5_48",
         "subject": "crtB",
         "query_loc": 46315,
         "subject_loc": 4715
        },
        {
         "query": "ctg5_43",
         "subject": "crtY",
         "query_loc": 39272,
         "subject_loc": 2179
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 4258,
         "end": 5173,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_48"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 5169,
         "end": 6051,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 2756,
         "end": 4262,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 389,
         "end": 1118,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 1599,
         "end": 2760,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_43"
         }
        },
        {
         "locus_tag": "crtZ",
         "start": 1114,
         "end": 1603,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000649: 148-10747": {
       "start": 148,
       "end": 10747,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "crtI",
         "query_loc": 40593,
         "subject_loc": 4378
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 5136,
         "end": 6165,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtE",
         "start": 2342,
         "end": 3620,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 3616,
         "end": 5140,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "crtT",
         "start": 8780,
         "end": 9509,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtU",
         "start": 7227,
         "end": 8781,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtV",
         "start": 6161,
         "end": 7178,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 9505,
         "end": 10747,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "fadD",
         "start": 148,
         "end": 1771,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000650: 28-7720": {
       "start": 28,
       "end": 7720,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "crtI",
         "query_loc": 40593,
         "subject_loc": 1284
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ABB88947.1",
         "start": 28,
         "end": 541,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ABB88953.1",
         "start": 5263,
         "end": 7720,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 2170,
         "end": 3013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 545,
         "end": 2024,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 4532,
         "end": 5303,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtYcd",
         "start": 3015,
         "end": 3726,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ispH",
         "start": 3729,
         "end": 4575,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000646: 60-6380": {
       "start": 60,
       "end": 6380,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "ACI04498.1",
         "query_loc": 40593,
         "subject_loc": 3040
        },
        {
         "query": "ctg5_43",
         "subject": "ACI04496.1",
         "query_loc": 39272,
         "subject_loc": 648
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACI04496.1",
         "start": 60,
         "end": 1236,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_43"
         }
        },
        {
         "locus_tag": "ACI04497.1",
         "start": 1232,
         "end": 2288,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACI04498.1",
         "start": 2280,
         "end": 3801,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "ACI04499.1",
         "start": 3797,
         "end": 4727,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ACI04500.1",
         "start": 4710,
         "end": 5298,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACI04501.1",
         "start": 5294,
         "end": 6380,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000656: 169-3770": {
       "start": 169,
       "end": 3770,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "crtI",
         "query_loc": 40593,
         "subject_loc": 2080
        },
        {
         "query": "ctg5_43",
         "subject": "crtY",
         "query_loc": 39272,
         "subject_loc": 748
        },
        {
         "query": "ctg5_48",
         "subject": "crtB",
         "query_loc": 46315,
         "subject_loc": 3302
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 2834,
         "end": 3770,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_48"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 1323,
         "end": 2838,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "crtY",
         "start": 169,
         "end": 1327,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_43"
         }
        }
       ]
      },
      "BGC0000647: 251-2872": {
       "start": 251,
       "end": 2872,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "crtI",
         "query_loc": 40593,
         "subject_loc": 1029
        },
        {
         "query": "ctg5_48",
         "subject": "crtB",
         "query_loc": 46315,
         "subject_loc": 2338
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 1804,
         "end": 2872,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_48"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 251,
         "end": 1808,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        }
       ]
      },
      "BGC0000664: 0-8391": {
       "start": 0,
       "end": 8391,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "SGR_6829",
         "query_loc": 40593,
         "subject_loc": 6355
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "SGR_6824",
         "start": 0,
         "end": 1242,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6825",
         "start": 1238,
         "end": 1967,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6826",
         "start": 1963,
         "end": 3520,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6827",
         "start": 3555,
         "end": 4572,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6828",
         "start": 4568,
         "end": 5597,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6829",
         "start": 5593,
         "end": 7117,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "SGR_6830",
         "start": 7113,
         "end": 8391,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001227: 0-12144": {
       "start": 0,
       "end": 12144,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "B446_02730",
         "query_loc": 40593,
         "subject_loc": 2780
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "B446_02720",
         "start": 0,
         "end": 1020,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02725",
         "start": 1016,
         "end": 2033,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "B446_02730",
         "start": 2029,
         "end": 3532,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "B446_02735",
         "start": 3564,
         "end": 4836,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "B446_02740",
         "start": 5082,
         "end": 6279,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "B446_02745",
         "start": 6490,
         "end": 7225,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "B446_02750",
         "start": 7221,
         "end": 8856,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "B446_02755",
         "start": 8896,
         "end": 9736,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02760",
         "start": 9842,
         "end": 10559,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02765",
         "start": 10585,
         "end": 11170,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02770",
         "start": 11073,
         "end": 12144,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000633: 0-14284": {
       "start": 0,
       "end": 14284,
       "links": [
        {
         "query": "ctg5_43",
         "subject": "crtY",
         "query_loc": 39272,
         "subject_loc": 4125
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "BAB69138.1",
         "start": 0,
         "end": 363,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAB69139.1",
         "start": 418,
         "end": 967,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAB69147.1",
         "start": 10059,
         "end": 12159,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAB69148.1",
         "start": 12241,
         "end": 14284,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtE",
         "start": 5060,
         "end": 6200,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI-1",
         "start": 6196,
         "end": 7738,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI-2",
         "start": 7734,
         "end": 8763,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtT",
         "start": 2677,
         "end": 3409,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtU",
         "start": 1121,
         "end": 2624,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtV",
         "start": 8759,
         "end": 9839,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 3452,
         "end": 4799,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_43"
         }
        }
       ]
      },
      "BGC0000640: 2399-8466": {
       "start": 2399,
       "end": 8466,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "crtI",
         "query_loc": 40593,
         "subject_loc": 6328
        },
        {
         "query": "ctg5_48",
         "subject": "crtB",
         "query_loc": 46315,
         "subject_loc": 7530
        },
        {
         "query": "ctg5_43",
         "subject": "crtY",
         "query_loc": 39272,
         "subject_loc": 5008
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 7067,
         "end": 7994,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_48"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 2399,
         "end": 3305,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 5589,
         "end": 7068,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "crtY",
         "start": 4423,
         "end": 5593,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_43"
         }
        },
        {
         "locus_tag": "crtZ",
         "start": 7908,
         "end": 8466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "idi",
         "start": 3342,
         "end": 4392,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000630: 389-6051": {
       "start": 389,
       "end": 6051,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "crtI",
         "query_loc": 40593,
         "subject_loc": 3509
        },
        {
         "query": "ctg5_48",
         "subject": "crtB",
         "query_loc": 46315,
         "subject_loc": 4715
        },
        {
         "query": "ctg5_43",
         "subject": "crtY",
         "query_loc": 39272,
         "subject_loc": 2179
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 4258,
         "end": 5173,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_48"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 5169,
         "end": 6051,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 2756,
         "end": 4262,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 389,
         "end": 1118,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 1599,
         "end": 2760,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_43"
         }
        },
        {
         "locus_tag": "crtZ",
         "start": 1114,
         "end": 1603,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000649: 148-10747": {
       "start": 148,
       "end": 10747,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "crtI",
         "query_loc": 40593,
         "subject_loc": 4378
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 5136,
         "end": 6165,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtE",
         "start": 2342,
         "end": 3620,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 3616,
         "end": 5140,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "crtT",
         "start": 8780,
         "end": 9509,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtU",
         "start": 7227,
         "end": 8781,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtV",
         "start": 6161,
         "end": 7178,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 9505,
         "end": 10747,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "fadD",
         "start": 148,
         "end": 1771,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000650: 28-7720": {
       "start": 28,
       "end": 7720,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "crtI",
         "query_loc": 40593,
         "subject_loc": 1284
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ABB88947.1",
         "start": 28,
         "end": 541,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ABB88953.1",
         "start": 5263,
         "end": 7720,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 2170,
         "end": 3013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtI",
         "start": 545,
         "end": 2024,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 4532,
         "end": 5303,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtYcd",
         "start": 3015,
         "end": 3726,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ispH",
         "start": 3729,
         "end": 4575,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000646: 60-6380": {
       "start": 60,
       "end": 6380,
       "links": [
        {
         "query": "ctg5_44",
         "subject": "ACI04498.1",
         "query_loc": 40593,
         "subject_loc": 3040
        },
        {
         "query": "ctg5_43",
         "subject": "ACI04496.1",
         "query_loc": 39272,
         "subject_loc": 648
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACI04496.1",
         "start": 60,
         "end": 1236,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg5_43"
         }
        },
        {
         "locus_tag": "ACI04497.1",
         "start": 1232,
         "end": 2288,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACI04498.1",
         "start": 2280,
         "end": 3801,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg5_44"
         }
        },
        {
         "locus_tag": "ACI04499.1",
         "start": 3797,
         "end": 4727,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ACI04500.1",
         "start": 4710,
         "end": 5298,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACI04501.1",
         "start": 5294,
         "end": 6380,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg5_31": {
     "functions": []
    },
    "ctg5_32": {
     "functions": [
      {
       "description": "PF04055",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg5_33": {
     "functions": []
    },
    "ctg5_34": {
     "functions": []
    },
    "ctg5_35": {
     "functions": []
    },
    "ctg5_36": {
     "functions": []
    },
    "ctg5_37": {
     "functions": []
    },
    "ctg5_38": {
     "functions": []
    },
    "ctg5_39": {
     "functions": [
      {
       "description": "PCMT",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1089:methyltransferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg5_40": {
     "functions": []
    },
    "ctg5_41": {
     "functions": []
    },
    "ctg5_42": {
     "functions": []
    },
    "ctg5_43": {
     "functions": [
      {
       "description": "Lycopene_cycl",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg5_44": {
     "functions": [
      {
       "description": "SMCOG1222:dehydrogenase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg5_45": {
     "functions": [
      {
       "description": "ABC_efflux ",
       "function": "resistance",
       "tool": "resist"
      },
      {
       "description": "SMCOG1288:ABC transporter related protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg5_46": {
     "functions": [
      {
       "description": "Abhydrolase_6",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Peptidase_S9",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg5_47": {
     "functions": []
    },
    "ctg5_48": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg5_49": {
     "functions": []
    },
    "ctg5_50": {
     "functions": []
    },
    "ctg5_51": {
     "functions": []
    },
    "ctg5_52": {
     "functions": [
      {
       "description": "SMCOG1122:ATP-dependent RNA helicase ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg5_53": {
     "functions": [
      {
       "description": "SMCOG1111:GCN5-related N-acetyltransferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg5_54": {
     "functions": []
    },
    "ctg5_55": {
     "functions": []
    },
    "ctg5_56": {
     "functions": []
    },
    "ctg5_57": {
     "functions": []
    },
    "ctg5_58": {
     "functions": []
    },
    "ctg5_59": {
     "functions": []
    },
    "ctg5_60": {
     "functions": []
    },
    "ctg5_61": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "ctg5_32",
      "seqLength": 412,
      "domains": [
       {
        "start": 148,
        "end": 319,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051536' target='_blank'>GO:0051536</a>: iron-sulfur cluster binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Radical_SAM",
        "accession": "PF04055",
        "description": "Radical SAM superfamily",
        "evalue": "2.2e-16",
        "score": "60.8"
       }
      ]
     },
     {
      "id": "ctg5_33",
      "seqLength": 253,
      "domains": [
       {
        "start": 10,
        "end": 244,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "TauE",
        "accession": "PF01925",
        "description": "Sulfite exporter TauE/SafE",
        "evalue": "5.8e-27",
        "score": "95.0"
       }
      ]
     },
     {
      "id": "ctg5_35",
      "seqLength": 195,
      "domains": [
       {
        "start": 63,
        "end": 143,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "bPH_2",
        "accession": "PF03703",
        "description": "Bacterial PH domain",
        "evalue": "1.9e-15",
        "score": "56.9"
       }
      ]
     },
     {
      "id": "ctg5_36",
      "seqLength": 206,
      "domains": [
       {
        "start": 26,
        "end": 174,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0010181' target='_blank'>GO:0010181</a>: FMN binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Flavin_Reduct",
        "accession": "PF01613",
        "description": "Flavin reductase like domain",
        "evalue": "8e-14",
        "score": "52.1"
       }
      ]
     },
     {
      "id": "ctg5_37",
      "seqLength": 242,
      "domains": [
       {
        "start": 19,
        "end": 236,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009055' target='_blank'>GO:0009055</a>: electron transfer activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Ni_hydr_CYTB",
        "accession": "PF01292",
        "description": "Prokaryotic cytochrome b561",
        "evalue": "1e-37",
        "score": "129.6"
       }
      ]
     },
     {
      "id": "ctg5_38",
      "seqLength": 247,
      "domains": [
       {
        "start": 85,
        "end": 223,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Oxidored_molyb",
        "accession": "PF00174",
        "description": "Oxidoreductase molybdopterin binding domain",
        "evalue": "7.3e-39",
        "score": "133.2"
       }
      ]
     },
     {
      "id": "ctg5_39",
      "seqLength": 409,
      "domains": [
       {
        "start": 118,
        "end": 378,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "CMAS",
        "accession": "PF02353",
        "description": "Mycolic acid cyclopropane synthetase",
        "evalue": "1.2e-87",
        "score": "293.8"
       }
      ]
     },
     {
      "id": "ctg5_41",
      "seqLength": 143,
      "domains": [
       {
        "start": 1,
        "end": 108,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "BLH_phosphatase",
        "accession": "PF04273",
        "description": "Beta-lactamase hydrolase-like protein, phosphatase-like domain",
        "evalue": "1.3e-37",
        "score": "128.5"
       }
      ]
     },
     {
      "id": "ctg5_43",
      "seqLength": 390,
      "domains": [
       {
        "start": 7,
        "end": 378,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Lycopene_cycl",
        "accession": "PF05834",
        "description": "Lycopene cyclase protein",
        "evalue": "2.1e-93",
        "score": "313.5"
       }
      ]
     },
     {
      "id": "ctg5_44",
      "seqLength": 491,
      "domains": [
       {
        "start": 11,
        "end": 488,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Amino_oxidase",
        "accession": "PF01593",
        "description": "Flavin containing amine oxidoreductase",
        "evalue": "5e-44",
        "score": "151.5"
       }
      ]
     },
     {
      "id": "ctg5_45",
      "seqLength": 608,
      "domains": [
       {
        "start": 39,
        "end": 313,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0140359' target='_blank'>GO:0140359</a>: ABC-type transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-transport",
        "name": "ABC_membrane",
        "accession": "PF00664",
        "description": "ABC transporter transmembrane region",
        "evalue": "1.8e-35",
        "score": "123.1"
       },
       {
        "start": 374,
        "end": 524,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-transport",
        "name": "ABC_tran",
        "accession": "PF00005",
        "description": "ABC transporter",
        "evalue": "1.1e-33",
        "score": "116.8"
       }
      ]
     },
     {
      "id": "ctg5_46",
      "seqLength": 656,
      "domains": [
       {
        "start": 416,
        "end": 628,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008236' target='_blank'>GO:0008236</a>: serine-type peptidase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006508' target='_blank'>GO:0006508</a>: proteolysis"
        ],
        "html_class": "generic-type-other",
        "name": "Peptidase_S9",
        "accession": "PF00326",
        "description": "Prolyl oligopeptidase family",
        "evalue": "1.4e-43",
        "score": "149.0"
       }
      ]
     },
     {
      "id": "ctg5_48",
      "seqLength": 316,
      "domains": [
       {
        "start": 21,
        "end": 277,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "2.9e-63",
        "score": "214.0"
       }
      ]
     },
     {
      "id": "ctg5_49",
      "seqLength": 193,
      "domains": [
       {
        "start": 45,
        "end": 176,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Lysine_decarbox",
        "accession": "PF03641",
        "description": "Possible lysine decarboxylase",
        "evalue": "1.1e-37",
        "score": "129.3"
       }
      ]
     },
     {
      "id": "ctg5_52",
      "seqLength": 589,
      "domains": [
       {
        "start": 20,
        "end": 175,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-other",
        "name": "DEAD",
        "accession": "PF00270",
        "description": "DEAD/DEAH box helicase",
        "evalue": "3.8e-16",
        "score": "59.5"
       },
       {
        "start": 227,
        "end": 319,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Helicase_C",
        "accession": "PF00271",
        "description": "Helicase conserved C-terminal domain",
        "evalue": "4.1e-11",
        "score": "43.3"
       },
       {
        "start": 331,
        "end": 392,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "RecQ_Zn_bind",
        "accession": "PF16124",
        "description": "RecQ zinc-binding",
        "evalue": "3.2e-13",
        "score": "50.3"
       },
       {
        "start": 394,
        "end": 504,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043138' target='_blank'>GO:0043138</a>: 3'-5' DNA helicase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006260' target='_blank'>GO:0006260</a>: DNA replication",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006281' target='_blank'>GO:0006281</a>: DNA repair"
        ],
        "html_class": "generic-type-other",
        "name": "RQC",
        "accession": "PF09382",
        "description": "RQC domain",
        "evalue": "3e-19",
        "score": "69.1"
       },
       {
        "start": 519,
        "end": 585,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding"
        ],
        "html_class": "generic-type-other",
        "name": "HRDC",
        "accession": "PF00570",
        "description": "HRDC domain",
        "evalue": "2.2e-21",
        "score": "75.7"
       }
      ]
     },
     {
      "id": "ctg5_53",
      "seqLength": 174,
      "domains": [
       {
        "start": 13,
        "end": 155,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016747' target='_blank'>GO:0016747</a>: acyltransferase activity, transferring groups other than amino-acyl groups"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Acetyltransf_3",
        "accession": "PF13302",
        "description": "Acetyltransferase (GNAT) domain",
        "evalue": "1.8e-26",
        "score": "93.6"
       }
      ]
     },
     {
      "id": "ctg5_54",
      "seqLength": 271,
      "domains": [
       {
        "start": 94,
        "end": 230,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008610' target='_blank'>GO:0008610</a>: lipid biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "FA_hydroxylase",
        "accession": "PF04116",
        "description": "Fatty acid hydroxylase",
        "evalue": "8e-30",
        "score": "104.0"
       }
      ]
     },
     {
      "id": "ctg5_55",
      "seqLength": 106,
      "domains": [
       {
        "start": 1,
        "end": 94,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "DUF2141",
        "accession": "PF09912",
        "description": "Uncharacterized protein conserved in bacteria (DUF2141)",
        "evalue": "9.1e-24",
        "score": "83.7"
       }
      ]
     },
     {
      "id": "ctg5_56",
      "seqLength": 294,
      "domains": [
       {
        "start": 49,
        "end": 294,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MipA",
        "accession": "PF06629",
        "description": "MltA-interacting protein MipA",
        "evalue": "1.2e-33",
        "score": "117.3"
       }
      ]
     },
     {
      "id": "ctg5_58",
      "seqLength": 154,
      "domains": [
       {
        "start": 17,
        "end": 148,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DUF1810",
        "accession": "PF08837",
        "description": "Protein of unknown function (DUF1810)",
        "evalue": "5.3e-52",
        "score": "175.4"
       }
      ]
     },
     {
      "id": "ctg5_60",
      "seqLength": 231,
      "domains": [
       {
        "start": 56,
        "end": 214,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "UDG",
        "accession": "PF03167",
        "description": "Uracil DNA glycosylase superfamily",
        "evalue": "9.7e-24",
        "score": "84.3"
       }
      ]
     },
     {
      "id": "ctg5_61",
      "seqLength": 103,
      "domains": [
       {
        "start": 35,
        "end": 102,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "YjdM",
        "accession": "PF03831",
        "description": "PhnA domain",
        "evalue": "4.8e-29",
        "score": "100.2"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   }
  ]
 },
 "r11c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000800: 32-15282": {
       "start": 32,
       "end": 15282,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "gumD",
         "query_loc": 59118,
         "subject_loc": 4366
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "gumA",
         "start": 32,
         "end": 332,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumB",
         "start": 1333,
         "end": 1975,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "gumC",
         "start": 2047,
         "end": 3397,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gumD",
         "start": 3639,
         "end": 5094,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "gumE",
         "start": 5176,
         "end": 6475,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumF",
         "start": 6471,
         "end": 7566,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumG",
         "start": 7562,
         "end": 8702,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumH",
         "start": 8698,
         "end": 9841,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gumI",
         "start": 9837,
         "end": 10887,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumJ",
         "start": 10883,
         "end": 12380,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gumK",
         "start": 12759,
         "end": 13647,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumL",
         "start": 13688,
         "end": 14483,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumM",
         "start": 14490,
         "end": 15282,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002295: 0-9315": {
       "start": 0,
       "end": 9315,
       "links": [
        {
         "query": "ctg11_60",
         "subject": "minA",
         "query_loc": 72689,
         "subject_loc": 3634
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "minA",
         "start": 1564,
         "end": 5704,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg11_60"
         }
        },
        {
         "locus_tag": "minB",
         "start": 5735,
         "end": 6689,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "minC",
         "start": 6724,
         "end": 8566,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "minD",
         "start": 8592,
         "end": 9315,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "minT",
         "start": 0,
         "end": 1260,
         "strand": 1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0000763: 750-18450": {
       "start": 750,
       "end": 18450,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "AAC27321.2",
         "query_loc": 59118,
         "subject_loc": 1467
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AAC27321.2",
         "start": 750,
         "end": 2184,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "ACO05911.1",
         "start": 2639,
         "end": 3779,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ACO05912.1",
         "start": 3788,
         "end": 4223,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO05913.1",
         "start": 4235,
         "end": 6413,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05914.1",
         "start": 6658,
         "end": 7795,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO05915.1",
         "start": 7923,
         "end": 8841,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05916.1",
         "start": 8916,
         "end": 9675,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05917.1",
         "start": 9721,
         "end": 10756,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05918.1",
         "start": 10844,
         "end": 13055,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO05919.1",
         "start": 13204,
         "end": 14467,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO05920.1",
         "start": 14471,
         "end": 15695,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05921.1",
         "start": 15859,
         "end": 17032,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05922.1",
         "start": 17299,
         "end": 18196,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05923.1",
         "start": 18245,
         "end": 18450,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000730: 151-21786": {
       "start": 151,
       "end": 21786,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "wbap",
         "query_loc": 59118,
         "subject_loc": 11297
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAF47017.1",
         "start": 13284,
         "end": 13803,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47020.1",
         "start": 15815,
         "end": 17066,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "acidPPc",
         "start": 2506,
         "end": 3136,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "galF",
         "start": 151,
         "end": 1048,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gnd",
         "start": 20379,
         "end": 21786,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wbaZ",
         "start": 17253,
         "end": 18417,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wbap",
         "start": 10582,
         "end": 12013,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "wcaN",
         "start": 13795,
         "end": 14659,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wcaO",
         "start": 14655,
         "end": 15789,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wza",
         "start": 6745,
         "end": 7885,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "wzb",
         "start": 7872,
         "end": 8319,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzc",
         "start": 8336,
         "end": 10508,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzi",
         "start": 5161,
         "end": 6601,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzx",
         "start": 18698,
         "end": 19958,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzy",
         "start": 12440,
         "end": 13292,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000731: 151-19654": {
       "start": 151,
       "end": 19654,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "wbaP",
         "query_loc": 59118,
         "subject_loc": 9165
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAF47032.1",
         "start": 11152,
         "end": 11671,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47035.1",
         "start": 13683,
         "end": 14934,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "acidPPc",
         "start": 1440,
         "end": 2070,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "galF",
         "start": 151,
         "end": 1048,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gnd",
         "start": 18247,
         "end": 19654,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wbaP",
         "start": 8450,
         "end": 9881,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "wbaZ",
         "start": 15121,
         "end": 16285,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wcaN",
         "start": 11663,
         "end": 12527,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wcaO",
         "start": 12523,
         "end": 13657,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wza",
         "start": 4613,
         "end": 5753,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "wzb",
         "start": 5740,
         "end": 6187,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzc",
         "start": 6204,
         "end": 8376,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzi",
         "start": 3029,
         "end": 4469,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzx",
         "start": 16566,
         "end": 17826,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzy_K20",
         "start": 10308,
         "end": 11160,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000868: 230-9248": {
       "start": 230,
       "end": 9248,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "tuaA",
         "query_loc": 59118,
         "subject_loc": 500
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "tuaA",
         "start": 230,
         "end": 770,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "tuaB",
         "start": 919,
         "end": 2371,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "tuaC",
         "start": 2367,
         "end": 3537,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "tuaD",
         "start": 3598,
         "end": 4984,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "tuaE",
         "start": 5068,
         "end": 6535,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "tuaF",
         "start": 6563,
         "end": 7244,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tuaG",
         "start": 7267,
         "end": 8026,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "tuaH",
         "start": 8054,
         "end": 9248,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000728: 151-18855": {
       "start": 151,
       "end": 18855,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "rfbp",
         "query_loc": 59118,
         "subject_loc": 16583
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAF46985.1",
         "start": 11166,
         "end": 12309,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF46986.1",
         "start": 12265,
         "end": 13120,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF46987.1",
         "start": 13103,
         "end": 13652,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF46988.1",
         "start": 13680,
         "end": 14652,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF46989.1",
         "start": 14664,
         "end": 15111,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF46990.1",
         "start": 15110,
         "end": 15605,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "acidPPc",
         "start": 1439,
         "end": 2069,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "galF",
         "start": 151,
         "end": 1048,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gnd",
         "start": 17448,
         "end": 18855,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "rfbp",
         "start": 15881,
         "end": 17285,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "wza",
         "start": 4582,
         "end": 5716,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "wzb",
         "start": 5721,
         "end": 6156,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzc",
         "start": 6172,
         "end": 8326,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzi",
         "start": 3026,
         "end": 4460,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzx",
         "start": 9716,
         "end": 11159,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzy",
         "start": 8499,
         "end": 9711,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000729: 151-18871": {
       "start": 151,
       "end": 18871,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "rfbp",
         "query_loc": 59118,
         "subject_loc": 16599
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAF47001.1",
         "start": 11182,
         "end": 12325,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47002.1",
         "start": 12281,
         "end": 13136,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47003.1",
         "start": 13119,
         "end": 13668,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47004.1",
         "start": 13696,
         "end": 14668,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47005.1",
         "start": 14680,
         "end": 15127,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47006.1",
         "start": 15126,
         "end": 15621,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "acidPPc",
         "start": 1440,
         "end": 2070,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "galF",
         "start": 151,
         "end": 1048,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gnd",
         "start": 17464,
         "end": 18871,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "rfbp",
         "start": 15897,
         "end": 17301,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "wza",
         "start": 4583,
         "end": 5717,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "wzb",
         "start": 5722,
         "end": 6157,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzc",
         "start": 6173,
         "end": 8342,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzi",
         "start": 3027,
         "end": 4461,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzx",
         "start": 9732,
         "end": 11175,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzy_K5",
         "start": 8515,
         "end": 9727,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000767: 708-22961": {
       "start": 708,
       "end": 22961,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "NCC2767LJ0007",
         "query_loc": 59118,
         "subject_loc": 4904
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "NCC2767LJ0002",
         "start": 708,
         "end": 882,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0003",
         "start": 1109,
         "end": 2114,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0004",
         "start": 2120,
         "end": 2984,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0005",
         "start": 2994,
         "end": 3762,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0006",
         "start": 3768,
         "end": 4539,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0007",
         "start": 4565,
         "end": 5243,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "NCC2767LJ0008",
         "start": 5246,
         "end": 6026,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0009",
         "start": 6043,
         "end": 7153,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0010",
         "start": 7200,
         "end": 8271,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0011",
         "start": 8277,
         "end": 9372,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0012",
         "start": 9374,
         "end": 10313,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0013",
         "start": 10378,
         "end": 11614,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0014",
         "start": 11638,
         "end": 12757,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0015",
         "start": 12758,
         "end": 13649,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0016",
         "start": 13650,
         "end": 15078,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0017",
         "start": 15079,
         "end": 16096,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0018",
         "start": 16117,
         "end": 16549,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0019",
         "start": 16604,
         "end": 17114,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0020",
         "start": 17989,
         "end": 18196,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0021",
         "start": 18360,
         "end": 18876,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0022",
         "start": 18892,
         "end": 19879,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0023",
         "start": 21111,
         "end": 21837,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0024",
         "start": 21836,
         "end": 22961,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000742: 0-2815": {
       "start": 0,
       "end": 2815,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "cpsE",
         "query_loc": 59118,
         "subject_loc": 852
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "cpsD",
         "start": 0,
         "end": 126,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cpsE",
         "start": 177,
         "end": 1527,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "cpsF",
         "start": 1550,
         "end": 2000,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cpsG",
         "start": 1999,
         "end": 2473,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "cpsH",
         "start": 2469,
         "end": 2815,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000800: 32-15282": {
       "start": 32,
       "end": 15282,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "gumD",
         "query_loc": 59118,
         "subject_loc": 4366
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "gumA",
         "start": 32,
         "end": 332,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumB",
         "start": 1333,
         "end": 1975,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "gumC",
         "start": 2047,
         "end": 3397,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gumD",
         "start": 3639,
         "end": 5094,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "gumE",
         "start": 5176,
         "end": 6475,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumF",
         "start": 6471,
         "end": 7566,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumG",
         "start": 7562,
         "end": 8702,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumH",
         "start": 8698,
         "end": 9841,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gumI",
         "start": 9837,
         "end": 10887,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumJ",
         "start": 10883,
         "end": 12380,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gumK",
         "start": 12759,
         "end": 13647,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumL",
         "start": 13688,
         "end": 14483,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gumM",
         "start": 14490,
         "end": 15282,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002295: 0-9315": {
       "start": 0,
       "end": 9315,
       "links": [
        {
         "query": "ctg11_60",
         "subject": "minA",
         "query_loc": 72689,
         "subject_loc": 3634
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "minA",
         "start": 1564,
         "end": 5704,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg11_60"
         }
        },
        {
         "locus_tag": "minB",
         "start": 5735,
         "end": 6689,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "minC",
         "start": 6724,
         "end": 8566,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "minD",
         "start": 8592,
         "end": 9315,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "minT",
         "start": 0,
         "end": 1260,
         "strand": 1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0000763: 750-18450": {
       "start": 750,
       "end": 18450,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "AAC27321.2",
         "query_loc": 59118,
         "subject_loc": 1467
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AAC27321.2",
         "start": 750,
         "end": 2184,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "ACO05911.1",
         "start": 2639,
         "end": 3779,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ACO05912.1",
         "start": 3788,
         "end": 4223,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO05913.1",
         "start": 4235,
         "end": 6413,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05914.1",
         "start": 6658,
         "end": 7795,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO05915.1",
         "start": 7923,
         "end": 8841,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05916.1",
         "start": 8916,
         "end": 9675,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05917.1",
         "start": 9721,
         "end": 10756,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05918.1",
         "start": 10844,
         "end": 13055,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO05919.1",
         "start": 13204,
         "end": 14467,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO05920.1",
         "start": 14471,
         "end": 15695,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05921.1",
         "start": 15859,
         "end": 17032,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05922.1",
         "start": 17299,
         "end": 18196,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO05923.1",
         "start": 18245,
         "end": 18450,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000730: 151-21786": {
       "start": 151,
       "end": 21786,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "wbap",
         "query_loc": 59118,
         "subject_loc": 11297
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAF47017.1",
         "start": 13284,
         "end": 13803,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47020.1",
         "start": 15815,
         "end": 17066,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "acidPPc",
         "start": 2506,
         "end": 3136,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "galF",
         "start": 151,
         "end": 1048,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gnd",
         "start": 20379,
         "end": 21786,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wbaZ",
         "start": 17253,
         "end": 18417,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wbap",
         "start": 10582,
         "end": 12013,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "wcaN",
         "start": 13795,
         "end": 14659,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wcaO",
         "start": 14655,
         "end": 15789,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wza",
         "start": 6745,
         "end": 7885,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "wzb",
         "start": 7872,
         "end": 8319,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzc",
         "start": 8336,
         "end": 10508,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzi",
         "start": 5161,
         "end": 6601,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzx",
         "start": 18698,
         "end": 19958,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzy",
         "start": 12440,
         "end": 13292,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000731: 151-19654": {
       "start": 151,
       "end": 19654,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "wbaP",
         "query_loc": 59118,
         "subject_loc": 9165
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAF47032.1",
         "start": 11152,
         "end": 11671,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47035.1",
         "start": 13683,
         "end": 14934,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "acidPPc",
         "start": 1440,
         "end": 2070,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "galF",
         "start": 151,
         "end": 1048,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gnd",
         "start": 18247,
         "end": 19654,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wbaP",
         "start": 8450,
         "end": 9881,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "wbaZ",
         "start": 15121,
         "end": 16285,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wcaN",
         "start": 11663,
         "end": 12527,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wcaO",
         "start": 12523,
         "end": 13657,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wza",
         "start": 4613,
         "end": 5753,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "wzb",
         "start": 5740,
         "end": 6187,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzc",
         "start": 6204,
         "end": 8376,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzi",
         "start": 3029,
         "end": 4469,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzx",
         "start": 16566,
         "end": 17826,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzy_K20",
         "start": 10308,
         "end": 11160,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000868: 230-9248": {
       "start": 230,
       "end": 9248,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "tuaA",
         "query_loc": 59118,
         "subject_loc": 500
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "tuaA",
         "start": 230,
         "end": 770,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "tuaB",
         "start": 919,
         "end": 2371,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "tuaC",
         "start": 2367,
         "end": 3537,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "tuaD",
         "start": 3598,
         "end": 4984,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "tuaE",
         "start": 5068,
         "end": 6535,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "tuaF",
         "start": 6563,
         "end": 7244,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tuaG",
         "start": 7267,
         "end": 8026,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "tuaH",
         "start": 8054,
         "end": 9248,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000728: 151-18855": {
       "start": 151,
       "end": 18855,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "rfbp",
         "query_loc": 59118,
         "subject_loc": 16583
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAF46985.1",
         "start": 11166,
         "end": 12309,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF46986.1",
         "start": 12265,
         "end": 13120,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF46987.1",
         "start": 13103,
         "end": 13652,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF46988.1",
         "start": 13680,
         "end": 14652,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF46989.1",
         "start": 14664,
         "end": 15111,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF46990.1",
         "start": 15110,
         "end": 15605,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "acidPPc",
         "start": 1439,
         "end": 2069,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "galF",
         "start": 151,
         "end": 1048,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gnd",
         "start": 17448,
         "end": 18855,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "rfbp",
         "start": 15881,
         "end": 17285,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "wza",
         "start": 4582,
         "end": 5716,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "wzb",
         "start": 5721,
         "end": 6156,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzc",
         "start": 6172,
         "end": 8326,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzi",
         "start": 3026,
         "end": 4460,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzx",
         "start": 9716,
         "end": 11159,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzy",
         "start": 8499,
         "end": 9711,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000729: 151-18871": {
       "start": 151,
       "end": 18871,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "rfbp",
         "query_loc": 59118,
         "subject_loc": 16599
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAF47001.1",
         "start": 11182,
         "end": 12325,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47002.1",
         "start": 12281,
         "end": 13136,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47003.1",
         "start": 13119,
         "end": 13668,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47004.1",
         "start": 13696,
         "end": 14668,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47005.1",
         "start": 14680,
         "end": 15127,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAF47006.1",
         "start": 15126,
         "end": 15621,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "acidPPc",
         "start": 1440,
         "end": 2070,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "galF",
         "start": 151,
         "end": 1048,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "gnd",
         "start": 17464,
         "end": 18871,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "rfbp",
         "start": 15897,
         "end": 17301,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "wza",
         "start": 4583,
         "end": 5717,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "wzb",
         "start": 5722,
         "end": 6157,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzc",
         "start": 6173,
         "end": 8342,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzi",
         "start": 3027,
         "end": 4461,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "wzx",
         "start": 9732,
         "end": 11175,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "wzy_K5",
         "start": 8515,
         "end": 9727,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000767: 708-22961": {
       "start": 708,
       "end": 22961,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "NCC2767LJ0007",
         "query_loc": 59118,
         "subject_loc": 4904
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "NCC2767LJ0002",
         "start": 708,
         "end": 882,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0003",
         "start": 1109,
         "end": 2114,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0004",
         "start": 2120,
         "end": 2984,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0005",
         "start": 2994,
         "end": 3762,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0006",
         "start": 3768,
         "end": 4539,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0007",
         "start": 4565,
         "end": 5243,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "NCC2767LJ0008",
         "start": 5246,
         "end": 6026,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0009",
         "start": 6043,
         "end": 7153,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0010",
         "start": 7200,
         "end": 8271,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0011",
         "start": 8277,
         "end": 9372,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0012",
         "start": 9374,
         "end": 10313,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0013",
         "start": 10378,
         "end": 11614,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0014",
         "start": 11638,
         "end": 12757,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0015",
         "start": 12758,
         "end": 13649,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0016",
         "start": 13650,
         "end": 15078,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0017",
         "start": 15079,
         "end": 16096,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0018",
         "start": 16117,
         "end": 16549,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0019",
         "start": 16604,
         "end": 17114,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0020",
         "start": 17989,
         "end": 18196,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0021",
         "start": 18360,
         "end": 18876,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0022",
         "start": 18892,
         "end": 19879,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0023",
         "start": 21111,
         "end": 21837,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "NCC2767LJ0024",
         "start": 21836,
         "end": 22961,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000742: 0-2815": {
       "start": 0,
       "end": 2815,
       "links": [
        {
         "query": "ctg11_49",
         "subject": "cpsE",
         "query_loc": 59118,
         "subject_loc": 852
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "cpsD",
         "start": 0,
         "end": 126,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cpsE",
         "start": 177,
         "end": 1527,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg11_49"
         }
        },
        {
         "locus_tag": "cpsF",
         "start": 1550,
         "end": 2000,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cpsG",
         "start": 1999,
         "end": 2473,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "cpsH",
         "start": 2469,
         "end": 2815,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "ctg11_60",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 22,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PCP",
        "modifier": false,
        "special": false,
        "cds": "ctg11_60",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 517,
        "terminalDocking": ""
       },
       {
        "name": "TE",
        "description": "Thioesterase",
        "modifier": false,
        "special": false,
        "cds": "ctg11_60",
        "css": "jsdomain-terminal",
        "inactive": false,
        "start": 645,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "Gly"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg11_43": {
     "functions": []
    },
    "ctg11_44": {
     "functions": []
    },
    "ctg11_45": {
     "functions": [
      {
       "description": "SMCOG1133:Transcription regulator, crp ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_46": {
     "functions": [
      {
       "description": "SMCOG1216:exopolysaccharide biosynthesis domain protein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_47": {
     "functions": []
    },
    "ctg11_48": {
     "functions": [
      {
       "description": "Poly_export",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1186:polysaccharide export protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_49": {
     "functions": [
      {
       "description": "Bac_transf",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1146:sugar transferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_50": {
     "functions": [
      {
       "description": "Glycos_transf_1",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1045:glycosyl transferase group 1 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_51": {
     "functions": [
      {
       "description": "Glycos_transf_1",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1045:glycosyl transferase group 1 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_52": {
     "functions": []
    },
    "ctg11_53": {
     "functions": []
    },
    "ctg11_54": {
     "functions": [
      {
       "description": "Polysacc_synt",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg11_55": {
     "functions": []
    },
    "ctg11_56": {
     "functions": [
      {
       "description": "SMCOG1088:acyltransferase 3 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_57": {
     "functions": [
      {
       "description": "Glycos_transf_1",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1045:glycosyl transferase group 1 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_58": {
     "functions": [
      {
       "description": "Glycos_transf_1",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1045:glycosyl transferase group 1 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_59": {
     "functions": [
      {
       "description": "Glycos_transf_1",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1045:glycosyl transferase group 1 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_60": {
     "functions": [
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_61": {
     "functions": [
      {
       "description": "SMCOG1076:RND efflux system, outer membrane lipoprotein, ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_62": {
     "functions": [
      {
       "description": "SMCOG1029:RND family efflux transporter MFP subunit ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_63": {
     "functions": [
      {
       "description": "SMCOG1049:AcrB/AcrD/AcrF family protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_64": {
     "functions": [
      {
       "description": "SMCOG1003:sensor histidine kinase ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_65": {
     "functions": [
      {
       "description": "SMCOG1008:response regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_66": {
     "functions": []
    },
    "ctg11_67": {
     "functions": []
    },
    "ctg11_68": {
     "functions": [
      {
       "description": "SMCOG1053:beta-lactamase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg11_69": {
     "functions": []
    },
    "ctg11_70": {
     "functions": []
    },
    "ctg11_71": {
     "functions": []
    },
    "ctg11_72": {
     "functions": []
    },
    "ctg11_73": {
     "functions": []
    },
    "ctg11_74": {
     "functions": []
    },
    "ctg11_75": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "ctg11_43",
      "seqLength": 315,
      "domains": [
       {
        "start": 66,
        "end": 231,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Ferritin_2",
        "accession": "PF13668",
        "description": "Ferritin-like domain",
        "evalue": "1.2e-14",
        "score": "54.8"
       }
      ]
     },
     {
      "id": "ctg11_44",
      "seqLength": 186,
      "domains": [
       {
        "start": 65,
        "end": 132,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000287' target='_blank'>GO:0000287</a>: magnesium ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008897' target='_blank'>GO:0008897</a>: holo-[acyl-carrier-protein] synthase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "ACPS",
        "accession": "PF01648",
        "description": "4'-phosphopantetheinyl transferase superfamily",
        "evalue": "8e-06",
        "score": "26.1"
       }
      ]
     },
     {
      "id": "ctg11_45",
      "seqLength": 257,
      "domains": [
       {
        "start": 168,
        "end": 242,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-other",
        "name": "HTH_Crp_2",
        "accession": "PF13545",
        "description": "Crp-like helix-turn-helix domain",
        "evalue": "1.2e-11",
        "score": "44.5"
       }
      ]
     },
     {
      "id": "ctg11_46",
      "seqLength": 740,
      "domains": [
       {
        "start": 34,
        "end": 119,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009103' target='_blank'>GO:0009103</a>: lipopolysaccharide biosynthetic process",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Wzz",
        "accession": "PF02706",
        "description": "Chain length determinant protein",
        "evalue": "8.7e-07",
        "score": "29.3"
       },
       {
        "start": 404,
        "end": 471,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "GNVR",
        "accession": "PF13807",
        "description": "G-rich domain on putative tyrosine kinase",
        "evalue": "1.7e-07",
        "score": "31.2"
       },
       {
        "start": 552,
        "end": 715,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "CbiA",
        "accession": "PF01656",
        "description": "CobQ/CobB/MinD/ParA nucleotide binding domain",
        "evalue": "3.5e-06",
        "score": "27.2"
       }
      ]
     },
     {
      "id": "ctg11_47",
      "seqLength": 442,
      "domains": [
       {
        "start": 65,
        "end": 442,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "BBP2_2",
        "accession": "PF10082",
        "description": "Putative beta-barrel porin 2",
        "evalue": "1.2e-73",
        "score": "248.3"
       }
      ]
     },
     {
      "id": "ctg11_48",
      "seqLength": 196,
      "domains": [
       {
        "start": 44,
        "end": 117,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015159' target='_blank'>GO:0015159</a>: polysaccharide transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015774' target='_blank'>GO:0015774</a>: polysaccharide transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Poly_export",
        "accession": "PF02563",
        "description": "Polysaccharide biosynthesis/export protein",
        "evalue": "1.5e-17",
        "score": "63.7"
       },
       {
        "start": 122,
        "end": 167,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "SLBB",
        "accession": "PF10531",
        "description": "SLBB domain",
        "evalue": "3.4e-10",
        "score": "39.7"
       }
      ]
     },
     {
      "id": "ctg11_49",
      "seqLength": 217,
      "domains": [
       {
        "start": 20,
        "end": 211,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Bac_transf",
        "accession": "PF02397",
        "description": "Bacterial sugar transferase",
        "evalue": "1.2e-55",
        "score": "188.1"
       }
      ]
     },
     {
      "id": "ctg11_50",
      "seqLength": 395,
      "domains": [
       {
        "start": 17,
        "end": 209,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Glyco_trans_4_4",
        "accession": "PF13579",
        "description": "Glycosyl transferase 4-like domain",
        "evalue": "4.6e-15",
        "score": "56.4"
       },
       {
        "start": 225,
        "end": 362,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016757' target='_blank'>GO:0016757</a>: glycosyltransferase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Glycos_transf_1",
        "accession": "PF00534",
        "description": "Glycosyl transferases group 1",
        "evalue": "6e-24",
        "score": "84.6"
       }
      ]
     },
     {
      "id": "ctg11_51",
      "seqLength": 394,
      "domains": [
       {
        "start": 17,
        "end": 210,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Glyco_transf_4",
        "accession": "PF13439",
        "description": "Glycosyltransferase Family 4",
        "evalue": "9.4e-21",
        "score": "74.7"
       },
       {
        "start": 224,
        "end": 358,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Glyco_trans_1_4",
        "accession": "PF13692",
        "description": "Glycosyl transferases group 1",
        "evalue": "1.8e-24",
        "score": "86.8"
       }
      ]
     },
     {
      "id": "ctg11_52",
      "seqLength": 332,
      "domains": [
       {
        "start": 30,
        "end": 312,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016798' target='_blank'>GO:0016798</a>: hydrolase activity, acting on glycosyl bonds"
        ],
        "html_class": "generic-type-other",
        "name": "Glyco_hydro_99",
        "accession": "PF16317",
        "description": "Glycosyl hydrolase family 99",
        "evalue": "1.9e-38",
        "score": "132.6"
       }
      ]
     },
     {
      "id": "ctg11_53",
      "seqLength": 504,
      "domains": [
       {
        "start": 364,
        "end": 460,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DUF6418",
        "accession": "PF19982",
        "description": "Family of unknown function (DUF6418)",
        "evalue": "1.4e-13",
        "score": "51.0"
       }
      ]
     },
     {
      "id": "ctg11_54",
      "seqLength": 479,
      "domains": [
       {
        "start": 27,
        "end": 315,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Polysacc_synt_3",
        "accession": "PF13440",
        "description": "Polysaccharide biosynthesis protein",
        "evalue": "5.1e-46",
        "score": "157.3"
       }
      ]
     },
     {
      "id": "ctg11_56",
      "seqLength": 388,
      "domains": [
       {
        "start": 29,
        "end": 360,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016747' target='_blank'>GO:0016747</a>: acyltransferase activity, transferring groups other than amino-acyl groups"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Acyl_transf_3",
        "accession": "PF01757",
        "description": "Acyltransferase family",
        "evalue": "1.4e-19",
        "score": "70.5"
       }
      ]
     },
     {
      "id": "ctg11_57",
      "seqLength": 374,
      "domains": [
       {
        "start": 11,
        "end": 173,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Glyco_trans_4_4",
        "accession": "PF13579",
        "description": "Glycosyl transferase 4-like domain",
        "evalue": "1.9e-16",
        "score": "61.0"
       },
       {
        "start": 183,
        "end": 319,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016757' target='_blank'>GO:0016757</a>: glycosyltransferase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Glycos_transf_1",
        "accession": "PF00534",
        "description": "Glycosyl transferases group 1",
        "evalue": "1.4e-28",
        "score": "99.7"
       }
      ]
     },
     {
      "id": "ctg11_58",
      "seqLength": 428,
      "domains": [
       {
        "start": 243,
        "end": 371,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Glyco_trans_1_4",
        "accession": "PF13692",
        "description": "Glycosyl transferases group 1",
        "evalue": "2.2e-14",
        "score": "54.0"
       }
      ]
     },
     {
      "id": "ctg11_59",
      "seqLength": 379,
      "domains": [
       {
        "start": 215,
        "end": 322,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016757' target='_blank'>GO:0016757</a>: glycosyltransferase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Glycos_transf_1",
        "accession": "PF00534",
        "description": "Glycosyl transferases group 1",
        "evalue": "3.2e-17",
        "score": "62.7"
       }
      ]
     },
     {
      "id": "ctg11_60",
      "seqLength": 842,
      "domains": [
       {
        "start": 23,
        "end": 409,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "9.8e-90",
        "score": "301.3"
       },
       {
        "start": 416,
        "end": 491,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "AMP-binding_C",
        "accession": "PF13193",
        "description": "AMP-binding enzyme C-terminal domain",
        "evalue": "3.1e-11",
        "score": "44.2"
       },
       {
        "start": 517,
        "end": 582,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "7.6e-15",
        "score": "55.1"
       },
       {
        "start": 645,
        "end": 740,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Thioesterase",
        "accession": "PF00975",
        "description": "Thioesterase domain",
        "evalue": "4.5e-12",
        "score": "46.7"
       }
      ]
     },
     {
      "id": "ctg11_61",
      "seqLength": 476,
      "domains": [
       {
        "start": 70,
        "end": 262,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015562' target='_blank'>GO:0015562</a>: efflux transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport"
        ],
        "html_class": "generic-type-other",
        "name": "OEP",
        "accession": "PF02321",
        "description": "Outer membrane efflux protein",
        "evalue": "1.3e-17",
        "score": "64.3"
       },
       {
        "start": 287,
        "end": 469,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015562' target='_blank'>GO:0015562</a>: efflux transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport"
        ],
        "html_class": "generic-type-other",
        "name": "OEP",
        "accession": "PF02321",
        "description": "Outer membrane efflux protein",
        "evalue": "4.4e-25",
        "score": "88.7"
       }
      ]
     },
     {
      "id": "ctg11_62",
      "seqLength": 391,
      "domains": [
       {
        "start": 85,
        "end": 304,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "HlyD_D23",
        "accession": "PF16576",
        "description": "Barrel-sandwich domain of CusB or HlyD membrane-fusion",
        "evalue": "2.7e-26",
        "score": "92.3"
       }
      ]
     },
     {
      "id": "ctg11_63",
      "seqLength": 1075,
      "domains": [
       {
        "start": 4,
        "end": 1052,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "ACR_tran",
        "accession": "PF00873",
        "description": "AcrB/AcrD/AcrF family",
        "evalue": "9e-206",
        "score": "685.9"
       }
      ]
     },
     {
      "id": "ctg11_64",
      "seqLength": 457,
      "domains": [
       {
        "start": 346,
        "end": 450,
        "go_terms": [],
        "html_class": "generic-type-regulatory",
        "name": "HATPase_c",
        "accession": "PF02518",
        "description": "Histidine kinase-, DNA gyrase B-, and HSP90-like ATPase",
        "evalue": "5.2e-17",
        "score": "62.5"
       }
      ]
     },
     {
      "id": "ctg11_65",
      "seqLength": 233,
      "domains": [
       {
        "start": 12,
        "end": 122,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system"
        ],
        "html_class": "generic-type-regulatory",
        "name": "Response_reg",
        "accession": "PF00072",
        "description": "Response regulator receiver domain",
        "evalue": "7.4e-24",
        "score": "84.2"
       },
       {
        "start": 154,
        "end": 230,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "Trans_reg_C",
        "accession": "PF00486",
        "description": "Transcriptional regulatory protein, C terminal",
        "evalue": "9.3e-23",
        "score": "80.3"
       }
      ]
     },
     {
      "id": "ctg11_68",
      "seqLength": 515,
      "domains": [
       {
        "start": 64,
        "end": 388,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Beta-lactamase",
        "accession": "PF00144",
        "description": "Beta-lactamase",
        "evalue": "1.6e-46",
        "score": "159.2"
       }
      ]
     },
     {
      "id": "ctg11_69",
      "seqLength": 600,
      "domains": [
       {
        "start": 23,
        "end": 546,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "CitMHS",
        "accession": "PF03600",
        "description": "Citrate transporter",
        "evalue": "2.4e-46",
        "score": "158.4"
       }
      ]
     },
     {
      "id": "ctg11_70",
      "seqLength": 347,
      "domains": [
       {
        "start": 34,
        "end": 112,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Ion_trans_2",
        "accession": "PF07885",
        "description": "Ion channel",
        "evalue": "7e-14",
        "score": "51.7"
       },
       {
        "start": 132,
        "end": 251,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006813' target='_blank'>GO:0006813</a>: potassium ion transport"
        ],
        "html_class": "generic-type-other",
        "name": "TrkA_N",
        "accession": "PF02254",
        "description": "TrkA-N domain",
        "evalue": "4.1e-23",
        "score": "82.0"
       }
      ]
     },
     {
      "id": "ctg11_71",
      "seqLength": 137,
      "domains": [
       {
        "start": 11,
        "end": 91,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015297' target='_blank'>GO:0015297</a>: antiporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0098662' target='_blank'>GO:0098662</a>: inorganic cation transmembrane transport"
        ],
        "html_class": "generic-type-other",
        "name": "PhaG_MnhG_YufB",
        "accession": "PF03334",
        "description": "Na+/H+ antiporter subunit",
        "evalue": "2.4e-23",
        "score": "82.3"
       }
      ]
     },
     {
      "id": "ctg11_72",
      "seqLength": 89,
      "domains": [
       {
        "start": 31,
        "end": 82,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015075' target='_blank'>GO:0015075</a>: monoatomic ion transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0034220' target='_blank'>GO:0034220</a>: monoatomic ion transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "MrpF_PhaF",
        "accession": "PF04066",
        "description": "Multiple resistance and pH regulation protein F (MrpF / PhaF)",
        "evalue": "2.2e-20",
        "score": "72.9"
       }
      ]
     },
     {
      "id": "ctg11_73",
      "seqLength": 162,
      "domains": [
       {
        "start": 11,
        "end": 160,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008324' target='_blank'>GO:0008324</a>: monoatomic cation transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006812' target='_blank'>GO:0006812</a>: monoatomic cation transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "MNHE",
        "accession": "PF01899",
        "description": "Na+/H+ ion antiporter subunit",
        "evalue": "2e-39",
        "score": "134.8"
       }
      ]
     },
     {
      "id": "ctg11_74",
      "seqLength": 507,
      "domains": [
       {
        "start": 129,
        "end": 427,
        "go_terms": [],
        "html_class": "generic-type-transport",
        "name": "Proton_antipo_M",
        "accession": "PF00361",
        "description": "Proton-conducting membrane transporter",
        "evalue": "1.1e-34",
        "score": "120.2"
       }
      ]
     },
     {
      "id": "ctg11_75",
      "seqLength": 117,
      "domains": [
       {
        "start": 9,
        "end": 106,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Oxidored_q2",
        "accession": "PF00420",
        "description": "NADH-ubiquinone/plastoquinone oxidoreductase chain 4L",
        "evalue": "4e-20",
        "score": "71.5"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   }
  ]
 }
};
