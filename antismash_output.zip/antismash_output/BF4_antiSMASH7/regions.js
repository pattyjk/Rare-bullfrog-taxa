var recordData = [
 {
  "length": 200471,
  "seq_id": "NODE_6_length_200471_cov_24.637729",
  "regions": []
 },
 {
  "length": 173483,
  "seq_id": "NODE_7_length_173483_cov_24.273445",
  "regions": []
 },
 {
  "length": 148317,
  "seq_id": "NODE_12_length_148317_cov_26.309781",
  "regions": []
 },
 {
  "length": 137753,
  "seq_id": "NODE_13_length_137753_cov_24.269161",
  "regions": []
 },
 {
  "length": 109536,
  "seq_id": "NODE_17_length_109536_cov_25.008103",
  "regions": []
 },
 {
  "length": 107778,
  "seq_id": "NODE_18_length_107778_cov_24.810494",
  "regions": []
 },
 {
  "length": 106032,
  "seq_id": "NODE_19_length_106032_cov_27.727167",
  "regions": []
 },
 {
  "length": 103505,
  "seq_id": "NODE_20_length_103505_cov_26.719534",
  "regions": [
   {
    "start": 54463,
    "end": 78843,
    "idx": 1,
    "orfs": [
     {
      "start": 55085,
      "end": 56239,
      "strand": 1,
      "locus_tag": "ctg8_50",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 55,085 - 56,239,\n (total: 1155 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_50\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGTAAGACGCTCACAGAGGTCGCTAGCCAGCTGAGCGCCACAAACAAGCAGGTGCAGCTGATCTACGCCTTCAACGGCACGGGGAAAACCCGCCTTTCCCGCGAGTTCAAGCAGCTCGTTGCACCCAAGAGCGGGGAGATTGAAGAAGGATCCGCCGACAAACTGGCACCGCCTCGCACCAAGATTCTGTACTACAGCGCCTTCACGGAAGACCTCTTTTATTGGGACAATGACCTCGAGATGGATGCTACTCCGAAGCTCTTGATCCAGCCCAACTCATTTACTGACTGGTTGCTCGCACTACTCAGAGATCTCGGACAAGATGGAAATATTGTCAGGAACTTCCAGCATTATGCCAGCAACAAGCTGACCCCATATTTTAACGAAACCTTCTCTGAGATCACTTTCTCACTCGAGCGGGGGGACGATGAAAACTCCGGCAGCCTCAAGATCTCAAAAGGTGAAGAGAGCAACTTCATCTGGAGTGTTTTCTACACGTTGTTGGACCAAGCCATATCTACGCTCAACATTGTCGAAGCAGAGGACCGCGAAACCCCGCAGTTCGATCGGCTTGAGTATGTCTTCATAGACGACCCGGTAAGTTCTCTGGACGAAAACCATTTGATCGAGCTAGCCGTCGATCTTGCGGGTTTGATCAAGACAAGTCCAGATTGTCTGAAGTTTATTGTTACCACCCACAGCCCTTTGTTCTACAACGTGCTTCATAACGAGTTAGGTCTTGCCAAGAGTGCCAAGAGCAAGGGCTGTTATTTACTACGCGGTCTCGAAGACGGTACCTTCGATCTGGATGTTAAACTTGGTGATTCCAACACCAGCTTTTCCTATCATCTGCATCTTAGGAAGACTCTTGAACAGGCGATTTCTGCCGGCCAAGTCGAGCGGTATCACTTCACGCTCCTTCGTAACCTCTACGAGAAAACTGCAAGCTTCCTTGGCTACCGAGACTGGTCGGACCTTTTGCCCGGTGACAAGCAGACCTATTTGAAACGCATTATCAATTTCACCAGTCACAGTAACTTGTCCAATGAGGCGGTTGCCGAACCGACGCCGCAAGAGAAGCAGACAGTTAAGTATCTTCTGGACTATCTGATTGATGAGTACGGCTATCGGCAGGAGCAACAGAATGGTTGA",
      "translation": "MGKTLTEVASQLSATNKQVQLIYAFNGTGKTRLSREFKQLVAPKSGEIEEGSADKLAPPRTKILYYSAFTEDLFYWDNDLEMDATPKLLIQPNSFTDWLLALLRDLGQDGNIVRNFQHYASNKLTPYFNETFSEITFSLERGDDENSGSLKISKGEESNFIWSVFYTLLDQAISTLNIVEAEDRETPQFDRLEYVFIDDPVSSLDENHLIELAVDLAGLIKTSPDCLKFIVTTHSPLFYNVLHNELGLAKSAKSKGCYLLRGLEDGTFDLDVKLGDSNTSFSYHLHLRKTLEQAISAGQVERYHFTLLRNLYEKTASFLGYRDWSDLLPGDKQTYLKRIINFTSHSNLSNEAVAEPTPQEKQTVKYLLDYLIDEYGYRQEQQNG",
      "product": ""
     },
     {
      "start": 56232,
      "end": 59333,
      "strand": 1,
      "locus_tag": "ctg8_51",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,232 - 59,333,\n (total: 3102 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_51 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04313.17 (Type I restriction enzyme R protein N terminus (HSDR_N)): [29:220](score: 188.2, e-value: 1.6e-55)<br>\n \n  PF18766.4 (SWI2/SNF2 ATPase): [275:493](score: 170.5, e-value: 4.5e-50)<br>\n \n  PF12008.11 (Type I restriction and modification enzyme - subunit R C terminal): [722:1026](score: 228.0, e-value: 1.6e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_51 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04313.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF04313.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004519' target='_blank'>GO:0004519</a>: endonuclease activity<br>\n  \n   PF04313.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006304' target='_blank'>GO:0006304</a>: DNA modification<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_51\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTTGAGCAAACCAAGCCGATCGTCGAAGCTAGCAACTTCATCGTTCTTGACAGATACGTCAAAGAATGGACGTCTACGGAAAGCTACCAAACTGAGTCTGACTTGGAACGCGAGTTCCTCCAAGACCTTGTCGATTTGGGGTATGAATATCTACCAGATCTGAGTACACCGCCATTGTTGCTTACCAACGTCCGTGAGCAGCTACAAGCGTTGAACAATGTGGAGTTCTTAGATGGCGAATGGGCGCGATTCGTAGAATCCTGGCTGGATAGGCCGAGTGATGGCGTGGTCGAAAAAACTCGGAAGATTCACGATGACTACGTTCATGACTTTGTGTTCGACGATGGTCGAATCCAGAACATCTATCTGCTCGACAAGAAAAACATTGCTCGCAACAAGGTCCAGGTGATCAAGCAGTTCCAGCAAACCGGCAGCCACGCCAACCGCTACGATGTGACCGTTCTGGTGAACGGTCTGCCTCTAGTCCAAGTAGAGCTGAAGAGGCGTGGCGTAGCCATCCGCGAAGCCTTTAACCAGGTACACCGCTACAGCAAGGAGAGCTTCAACGGCGAGCAGTCCCTGTTCAGGTACTTGCAGCTATTCGTAATCTCCAACGGTACCGACACGCGCTATTTCGCCAACACGACGCAGCGCGGTAAGAACAGCTTTGACTTCACCATGAACTGGGCGCAGGCAGATAACAGCCCGATCAAGGACCTGAAGGACTTTACCGCCACCTTCTTCCAGAAACACACCTTACTCAATGTACTGCTGAGCTATTCCGTCTTCGATGTCGGCAATACGCTGCTGGTGATGCGGCCGTATCAAATTGCCGCGACTGAGCGCATCTTGTGGAAGATCAAGAGTGCGTATCAGGCCAAACACTGGAACAGTACCGAGAGCGGCGGCTACATCTGGCATACGACTGGTTCGGGAAAAACCCTGACCAGCTTCAAGGCCGCGCGCCTTGCGACGGAGCTTGATTTTATCGACAAAGTATTCTTCGTAGTTGACCGCAAAGATCTGGATTACCAGACCATGAAGGAATACCAGCGTTTCTCGCCCGATAGTGTGAACGGTTCGGATAGCACGGCGGCCCTGAAACGCAATCTGGACAAGGACGATAACAAGATCATCGTCACCACCATCCAGAAGCTAAACAACCTAATGAGGAGCGAAAGCGATCTGCCAATCTACGGCAGGCAAGTCGTCTTCATCTTCGACGAATGCCATCGCAGTCAGTTCGGCGAGGCACAAAGGAACCTGACTAAGAGGTTCAAAAAGTTCTACCAGTTCGGTTTCACCGGTACCCCGATCTTCCCGCAAAACGCTCTGGGCGCGGATACCACAGCGAGCGTGTTCGGCAGAGAGCTGCACTCGTACGTCATCACTGATGCTATTCGTGACGAGAAGGTTCTCAAGTTCAAGGTGGACTACAGCGACGTTCGTCCGCAGTTCAAAAGCATCGAAAGCGAGCAGGACGAGAAGAAGCTCAGCGCCGCGGAAAACCGGGAGGCCTTGCTGCACCCGGATCGCATCCGTGAAATCACTCAATACATCCTCGACACCTTCCGGCAAAAGACTCACCGCCTACAAGCGGGGGCCAAGGGCTTCAACGCTATGTTCGCCGTAAGTAGCGTGGACGCCGCGAAGCTTTATTACGAAGCTTTCAAGACCTTACAGAGAAGCCGCGAAAAGCCTTTGAAGGTTGCGACCATTTTCTCGTACGCTGCCAACGAGGAGCAGGATGCGGTAGGTGAGATAGCGGATGAAGTTTTTGAAGTCTCAGCCTTGGGCACCAGCGCCAAAGAGTTCCTGAACGCAGTCGTTGCCGACTATAATTCACTGTTCAAAACCAGCTTCAGCGTGGACAGCAAAGGCTTCCAGAATTACTACCGTGACCTGGCAAAGCGCGTAAAAGACCAGGACGTGGATTTGCTCATCGTTGTTGGGATGTTCCTGACGGGCTTCGACGCGCCCACACTGAACACCTTGTTTGTGGACAAGAACCTGCGCTACCACGGCCTGGTTCAGGCCTATTCGCGTACCAACCGAATTTTCGACTCCACTAAGACCTTCGGCAATGTCGTCACCTTCCGCGACTTGGAAGACGCAACCATCGACGCCATCACCCTATTCGGCGACAAGAACACCCGCAATGTGGTGCTGGAGAAGAGCTATACCGAGTACATGGAAGGCTTCACTGACGTCGCTACAGGAGAGGCACGGCGCGGATTCGTCGACGTGGTCAGCGAACTTGAGCAGAGATTCCCTGATCCCGTGGACATCGTCAGAGAGTCCGATAAGAAGGCATTTGCAAAGCTGTTCGGTGAGTACCTGCGCGTGGAGAACGTGCTGCAGAACTACGATGAATTCGCCAGCCTAAAGGCCTTGCAGAGCATCGACACGGGCGATCCCCAGGCGGTGGAGAATTTCAAGACCAAGCACCACCTGAGCGACGACGACCTAGCTGTACTGCAGAAGATTCGGGTTCCCACCGAGCGGATAATCCAGGACTACCGGTCCACCTACAACGACATCCGCGACTGGCTACGCCGCGAGAAAGCCTCGGAGGAGAAGGCGCGTTCCACTATCGACTGGGATGATGTGGTGTTCGAAGTGGATCTGCTTAGATCGCAGGAGATCAATCTTGATTACATTCTGGAGTTGATCTTCGAGAAGAACAAAAAAACCAGGGACAAGGTGTCTTTGGTCGAGGAAGCGCGCCGGATGATTCGCGCTAGCCTCGGCAACCGGGCTAAGGAAAGCCTTGTGGTGGATTTCATCAATCAGACTGATTTGGACACACTGGCGGATAAGGCCAGCGTAATCGAGGCATTTTTCAGCTTTGCGCAGGTCGAGCAGCAGCGCGAGGCCCAGGAACTAATCAACGATGAAGCACTAAATGCTGAAGCCGCCAGACGTTATATCAGCAACTCGCTCAGGCGTGAATTTGCCAGCGAGAACGGCACCGAACTCAATGCGCTTCTTCCCAGAATGAGCCCGCTTAATCCGGACTACCTAACAAAAAAGCACAGCGTCTTTCACAAGATCGCCGCATTCGTTGAGAAATTCAAAGGAGTTGGTGGCGAGGTCTGA",
      "translation": "MVEQTKPIVEASNFIVLDRYVKEWTSTESYQTESDLEREFLQDLVDLGYEYLPDLSTPPLLLTNVREQLQALNNVEFLDGEWARFVESWLDRPSDGVVEKTRKIHDDYVHDFVFDDGRIQNIYLLDKKNIARNKVQVIKQFQQTGSHANRYDVTVLVNGLPLVQVELKRRGVAIREAFNQVHRYSKESFNGEQSLFRYLQLFVISNGTDTRYFANTTQRGKNSFDFTMNWAQADNSPIKDLKDFTATFFQKHTLLNVLLSYSVFDVGNTLLVMRPYQIAATERILWKIKSAYQAKHWNSTESGGYIWHTTGSGKTLTSFKAARLATELDFIDKVFFVVDRKDLDYQTMKEYQRFSPDSVNGSDSTAALKRNLDKDDNKIIVTTIQKLNNLMRSESDLPIYGRQVVFIFDECHRSQFGEAQRNLTKRFKKFYQFGFTGTPIFPQNALGADTTASVFGRELHSYVITDAIRDEKVLKFKVDYSDVRPQFKSIESEQDEKKLSAAENREALLHPDRIREITQYILDTFRQKTHRLQAGAKGFNAMFAVSSVDAAKLYYEAFKTLQRSREKPLKVATIFSYAANEEQDAVGEIADEVFEVSALGTSAKEFLNAVVADYNSLFKTSFSVDSKGFQNYYRDLAKRVKDQDVDLLIVVGMFLTGFDAPTLNTLFVDKNLRYHGLVQAYSRTNRIFDSTKTFGNVVTFRDLEDATIDAITLFGDKNTRNVVLEKSYTEYMEGFTDVATGEARRGFVDVVSELEQRFPDPVDIVRESDKKAFAKLFGEYLRVENVLQNYDEFASLKALQSIDTGDPQAVENFKTKHHLSDDDLAVLQKIRVPTERIIQDYRSTYNDIRDWLRREKASEEKARSTIDWDDVVFEVDLLRSQEINLDYILELIFEKNKKTRDKVSLVEEARRMIRASLGNRAKESLVVDFINQTDLDTLADKASVIEAFFSFAQVEQQREAQELINDEALNAEAARRYISNSLRREFASENGTELNALLPRMSPLNPDYLTKKHSVFHKIAAFVEKFKGVGGEV",
      "product": ""
     },
     {
      "start": 59256,
      "end": 59597,
      "strand": -1,
      "locus_tag": "ctg8_52",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 59,256 - 59,597,\n (total: 342 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_52\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCCGCTTGGTAGAAAACCTCAATCTTCTTAGCGAGATCCCCCTGAATCCTACGGCTGTCCGGATCTTAATGCCTCTCATCACCTCTGGCGGAGATTGCGTATACAGCCGAAGAGCTCTCCCCCCGCACACGGCAATGGTCGCGTTGGCCGGAAACTACATCCGGATGCGCACGGGCAAAGTACTCGCGACGACACAGCTGGTGAACATTGTCGAGATGCGTATTTCAACTCAGTCCCTCGATAGGCAGAAGAGCCTCAGCTCAGACCTCGCCACCAACTCCTTTGAATTTCTCAACGAATGCGGCGATCTTGTGAAAGACGCTGTGCTTTTTTGTTAG",
      "translation": "MSRLVENLNLLSEIPLNPTAVRILMPLITSGGDCVYSRRALPPHTAMVALAGNYIRMRTGKVLATTQLVNIVEMRISTQSLDRQKSLSSDLATNSFEFLNECGDLVKDAVLFC",
      "product": ""
     },
     {
      "start": 59563,
      "end": 60693,
      "strand": -1,
      "locus_tag": "ctg8_53",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_53</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_53</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 59,563 - 60,693,\n (total: 1131 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_53\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTTTCAGTCGGGTGCAGTCGCCGTGCGATATCGGCCCACGCGAGTCATGGCTTGATCTGAGAGGCCGCGCCTGGTGTGCTCGCCAATGGCACAGCGATCCGATTCAGCAACGCCCTCATCATCAGTTGCCAAGCTGGTCGCATCTTGCGACTTTGAGCCAGGGTCTCCTCTTCCTCGTTCTCATCGGGCGCCATCGAGGCCAAGGCCCGGAAAGTCGGTACAGTCATGCCATGACGATCGAACACGCGCCAGGACCCGAAATGTCCGTTGTGCTCAAGAACGCGCGAGCCGGCGCACGCGAACGTGGCCTCCCGGTCCTAAACGCCAGCTTCGGTACCGAACCATCCGTTATTTTCGTCAATGCTCAGGTAGGACTCGACGAAGCACTGGATGTCGCGAAAGCGATGAATGCGCCGTTCCTTTCAATCGACGCAACGGAGTTCAGTTTCGAGGACTTCGTCTCCGAGATGAGCGAAGCAAGCGAAACTGCGGCACTTGAGCCCGAGGTCAAGGACTTCAAGAAATATGACGGCGAGCTCGACGGCGTCTACGTTCGTTGGGTCGCTGCCGGCGAAAGCTTCCTTTATATGGCTACTCCAGAGTGGAGCGATCAGATAGGTGAACTGCAGGGCCAGCAAGAGGAACGGGATAGAAAGAATCGATCCAGGGACGTTGCCGCGAGGTGGGCAAGACGGAGGGAACTTGCTGAAGAGATAGAGGCGCTCCCGGCAGTTCGCGGCATAGGCACTCGCGGCCGCAAGGCCCTCGCAACACGTCTCGCCGGCGGACTGCTCAAGGGAGAGGATGACCCCGAGCTCGCGCTGGGCGCGGTTCGCGACGCCGTCGAGTTAGCAAGCGTGAATGCGATCGGTGCGTACGCTGAAATCGAGTCGGATTTACGCGTCGTCGCACGACATCTCATCGAGACAGATGCCTGGCAGAACGCCTGGCGCACCCCAGATCGGATCGCTGCAGCAAAGGCTTTTCTGCTCAGCACCACTAACGGGTACGCCCCAACCGCTGCCCTCTCCGAACAACTCCGCGGAGTGGCCGAAGACGAAGCGCGGCTCAATCTGAAAAGGCCCCAACGGCATGTCCCGCTTGGTAGAAAACCTCAATCTTCTTAG",
      "translation": "MSFSRVQSPCDIGPRESWLDLRGRAWCARQWHSDPIQQRPHHQLPSWSHLATLSQGLLFLVLIGRHRGQGPESRYSHAMTIEHAPGPEMSVVLKNARAGARERGLPVLNASFGTEPSVIFVNAQVGLDEALDVAKAMNAPFLSIDATEFSFEDFVSEMSEASETAALEPEVKDFKKYDGELDGVYVRWVAAGESFLYMATPEWSDQIGELQGQQEERDRKNRSRDVAARWARRRELAEEIEALPAVRGIGTRGRKALATRLAGGLLKGEDDPELALGAVRDAVELASVNAIGAYAEIESDLRVVARHLIETDAWQNAWRTPDRIAAAKAFLLSTTNGYAPTAALSEQLRGVAEDEARLNLKRPQRHVPLGRKPQSS",
      "product": ""
     },
     {
      "start": 60635,
      "end": 61204,
      "strand": -1,
      "locus_tag": "ctg8_54",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_54</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_54</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 60,635 - 61,204,\n (total: 570 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_54 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01872.20 (RibD C-terminal domain): [5:177](score: 48.2, e-value: 1.2e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_54 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01872.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008703' target='_blank'>GO:0008703</a>: 5-amino-6-(5-phosphoribosylamino)uracil reductase activity<br>\n  \n   PF01872.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009231' target='_blank'>GO:0009231</a>: riboflavin biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_54\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_54_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGACCACTCCGATACTCGATCAATGTCACGCTCGACGGCTGCTGCCATCACGAGGCAGGACTCCCCCCGGACGAGGAGTCGATGCACTACTGGACCGCTCAGCTAGAGCGAGCCGATGCCCTACTGTTCGGCCGGGTGACCTACGAGATGATGGAGTCCGCGTGGCGGATGCCGGCCACGGGCAGGTGGCCCGACTGGATGAAGGACTGGCAGAAACCGTTCGCGGAGACCATCGACCGGGCGAAGAAGTACGTCGTGTCGAGCACAATGAGCGGGCTCGATTGGAATGCCGAGCTGGTGCGAGGCGACCTGGGAGCAGCGGTTCAGAGATTCAAGCAGGAGCCAGGCGAGGGTTTGTGGGTGGGTGGCGTGACGCTCCCCCGGGCGTTGGCCGATCTGGGGCTGATCGACGAGTATGAGTTTTTGGTGCAGCCGGTCCTTGCCGGGCACGGGCCGACTTTGCTTGCCGGTCTGCGTGAGCGCATTCAGCTCGAGCTTGTGGACCGCAATGAGTTTCAGTCGGGTGCAGTCGCCGTGCGATATCGGCCCACGCGAGTCATGGCTTGA",
      "translation": "MRPLRYSINVTLDGCCHHEAGLPPDEESMHYWTAQLERADALLFGRVTYEMMESAWRMPATGRWPDWMKDWQKPFAETIDRAKKYVVSSTMSGLDWNAELVRGDLGAAVQRFKQEPGEGLWVGGVTLPRALADLGLIDEYEFLVQPVLAGHGPTLLAGLRERIQLELVDRNEFQSGAVAVRYRPTRVMA",
      "product": ""
     },
     {
      "start": 61677,
      "end": 62663,
      "strand": -1,
      "locus_tag": "ctg8_55",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_55</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_55</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 61,677 - 62,663,\n (total: 987 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1083:oxidoreductase (Score: 101.2; E-value: 1.2e-30)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_55 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00296.23 (Luciferase-like monooxygenase): [30:285](score: 68.7, e-value: 6.1e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_55 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00296.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_55\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_55_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGGTTAGGCATCGTCTTCCCCGTCCAACCAAACAACACCAATGACATCAAGGCGTTCGGCCGATGGGCGATGGAGCGTCCCGGCACCCGGCTCTGGACTGCACAATCGACCCTCATTGATTCCCACCAGGCGGTAGCCTTCGCTGCCGGCGCTGGGATTCGCTGCCCGATTGGGTTCGGGGTCGCCCTCACTCCGTTGGCACACCCGGTACTAGCTGCCGCTCAAGCCCGTTCGCTAGCCCTCCTGACGGGGCACGATGTCTGGGCAGGTTTCGGCACAGGTGGCCTTCACGTGGAATCTGGGATGCTCGGACAAAAGTACGCGTCGCCGACGAAAGCAGTGCGCGAGTACCTTGAGGTCTGCCGCCTTGCCTTGGACGAGGCGAGCTTCGAGTACAGAGGAGAAGTCTTCAACGTGAGCGGCGGTGCTCCTTCGCTTCACACCAGTGAAGTGAGGGTAGGCGCCGGAGTCCTTCGCCCGCGGATGGCGAGCGTGATTAAGGATGCGGCGGATTTTGTCGTCACATGGCTTTCTCCGCTGCACCATGTTTCCGACACATTAATACCTGCCCTCACCCGGGTGGATCAGACCCGCCCCGCGGTCGTCGCAATGGTGCATTCACGCCTCACATCGTCCGGCCTCGACAAACAAGAACTAATCGAGGACATGACCACCCCCCATCTGGGGGCTGCACATTACCGGGCGATGCTTCGGTCCTCGGGTATAGGTGCCGATTTAGACGACACACCAGCGCAGGTCGCCGAGCAGCTTGTCGATGCGAACGTACTGCTCCACGGCGACGTTGATGACATCGTCGAAGGGCTTTTGGCGTACGAGAGCGCGGGCGTCGAAGAGGTCGCATTGAATATTTCGGGTTCATTCCGACGCTTTGGCGCTCAACGTGCGCTTGCCGAAATGTCCGCTATCCATGCTGCCTATTCTGCGGCGCGGCCGTCGTACCGGACGGAGCCCGCGATGGCGTAA",
      "translation": "MRLGIVFPVQPNNTNDIKAFGRWAMERPGTRLWTAQSTLIDSHQAVAFAAGAGIRCPIGFGVALTPLAHPVLAAAQARSLALLTGHDVWAGFGTGGLHVESGMLGQKYASPTKAVREYLEVCRLALDEASFEYRGEVFNVSGGAPSLHTSEVRVGAGVLRPRMASVIKDAADFVVTWLSPLHHVSDTLIPALTRVDQTRPAVVAMVHSRLTSSGLDKQELIEDMTTPHLGAAHYRAMLRSSGIGADLDDTPAQVAEQLVDANVLLHGDVDDIVEGLLAYESAGVEEVALNISGSFRRFGAQRALAEMSAIHAAYSAARPSYRTEPAMA",
      "product": ""
     },
     {
      "start": 62676,
      "end": 64502,
      "strand": -1,
      "locus_tag": "ctg8_56",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_56</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_56</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 62,676 - 64,502,\n (total: 1827 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 191.6; E-value: 2.8e-58)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_56 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00005.30 (ABC transporter): [376:530](score: 108.1, e-value: 5.2e-31)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_56 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00005.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_56\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_56_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMAGAVKPAGGNAVKTARMPIGLQDIGKVWRLAPGRFSLQAAMAWSVALVPALQVMLTARIVDMASTMVANPTDDWMPLTIAFFQLGLTLVLARAITGLARYLGTSTTLRVNTRLSQDVMKKGIAMPLASYETPEHYNRLQRALAETQSGRALMLVTGVIELVSSLVTVGSVALVLLSWSPLAAVIALIAPIPSALLSAKYGRLRWSIEMDRTENRRKSAYLQWLTTNDHSAKEVSHYQLGPTLMKRYAKFVKHFLTQDLAVNRRSELWVGLVDLLGLALTTSALGIAVVGSVQRGSVGEIAGFIQAMGSLQTATSGFLLGLAALYQNGLWARNLFGYLELPSNSLRATGKCLPFPADASIEFRNVSFTYPSTDRRVLNDLSFTLPAGSRTAIVGPNGAGKSTIVKLLTGLYIPDAGEVLIGGVPVKDLDPDEVRREVGVVFQDFVKYELSAADNIAFGNWPSATEDEVLGAAERAGIWGKLTNLPANIETLLGRRFTGAQQLSLGEWQKMALARAFVSGRTVLIMDEPSASLDPRAEADLVARIADVPKGTTAVVVAHRFATVRALDRIVVLDQGAITEMGNHDELMRLSGTYALMYEAQAAAFSESK\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGCGGGCGCTGTCAAGCCGGCGGGCGGCAACGCGGTGAAGACAGCAAGAATGCCGATCGGATTGCAGGACATTGGCAAAGTGTGGCGACTCGCGCCCGGGAGGTTTTCTCTTCAAGCAGCCATGGCGTGGTCGGTCGCCCTGGTGCCCGCACTACAGGTGATGCTCACGGCTCGAATTGTTGACATGGCGAGCACCATGGTTGCCAATCCAACGGATGACTGGATGCCGCTAACAATCGCATTCTTTCAGCTGGGGTTGACCCTGGTTCTCGCTCGCGCCATCACCGGTCTGGCCCGGTATCTCGGCACCAGCACCACGCTCCGAGTGAACACTCGTTTGTCGCAGGACGTCATGAAGAAGGGGATTGCGATGCCGCTGGCATCGTACGAAACTCCAGAGCATTACAACCGACTCCAACGCGCATTGGCCGAGACACAGTCGGGGCGTGCTCTGATGCTAGTGACAGGGGTCATCGAGCTGGTCTCGTCGCTCGTCACCGTAGGTTCGGTCGCATTGGTTCTACTGAGTTGGAGCCCTCTAGCCGCTGTAATCGCGCTCATTGCGCCAATTCCGTCAGCCTTGCTCTCCGCCAAATACGGACGTCTTCGGTGGTCGATCGAGATGGACAGAACCGAAAATCGTCGGAAGTCTGCCTATCTGCAGTGGCTCACAACCAACGATCACTCGGCAAAGGAGGTCTCGCATTACCAACTGGGCCCGACTCTTATGAAGCGTTACGCGAAGTTCGTAAAGCACTTCCTTACCCAGGACTTAGCGGTTAATCGCCGGAGCGAACTCTGGGTCGGACTTGTTGACTTGCTTGGCTTGGCCCTCACGACGTCCGCACTGGGAATCGCCGTTGTAGGAAGCGTGCAACGGGGAAGCGTTGGAGAGATCGCAGGGTTCATCCAGGCGATGGGGTCCTTGCAGACTGCTACGAGCGGTTTCTTACTCGGACTTGCCGCTTTGTATCAGAACGGGCTCTGGGCGAGGAATCTTTTCGGCTACCTTGAACTTCCGTCAAACTCCCTTCGGGCAACCGGGAAATGCCTGCCGTTCCCCGCAGATGCCAGCATCGAATTCCGAAACGTTAGTTTCACTTACCCGTCGACGGACCGCCGAGTCCTGAACGACCTCTCGTTCACGCTTCCCGCGGGAAGCCGTACGGCGATAGTTGGTCCCAACGGGGCCGGTAAATCGACGATCGTCAAACTGCTCACAGGATTGTACATTCCTGACGCCGGCGAGGTCCTAATTGGCGGAGTTCCGGTCAAAGATCTGGACCCTGATGAGGTCCGTCGAGAGGTTGGGGTTGTGTTCCAGGATTTTGTGAAATACGAGCTGTCCGCCGCGGACAACATTGCTTTCGGAAACTGGCCCTCGGCCACCGAAGACGAAGTGCTTGGAGCGGCTGAGCGAGCGGGCATCTGGGGAAAGCTCACCAACCTTCCGGCCAATATCGAAACGCTCCTGGGACGAAGATTCACCGGAGCGCAGCAGCTCTCCCTCGGGGAGTGGCAGAAGATGGCCTTGGCGCGTGCGTTCGTCAGCGGTCGAACAGTTCTGATCATGGACGAACCATCCGCGTCGTTGGACCCACGCGCGGAAGCCGATCTCGTCGCGCGGATAGCCGATGTACCCAAGGGCACGACCGCGGTGGTTGTTGCTCACCGTTTTGCTACGGTGCGGGCCCTTGACCGAATAGTCGTGCTCGACCAGGGTGCGATAACTGAGATGGGCAATCACGATGAACTCATGAGACTAAGCGGAACGTACGCGCTGATGTACGAAGCCCAGGCCGCCGCCTTCTCGGAATCGAAATAG",
      "translation": "MAGAVKPAGGNAVKTARMPIGLQDIGKVWRLAPGRFSLQAAMAWSVALVPALQVMLTARIVDMASTMVANPTDDWMPLTIAFFQLGLTLVLARAITGLARYLGTSTTLRVNTRLSQDVMKKGIAMPLASYETPEHYNRLQRALAETQSGRALMLVTGVIELVSSLVTVGSVALVLLSWSPLAAVIALIAPIPSALLSAKYGRLRWSIEMDRTENRRKSAYLQWLTTNDHSAKEVSHYQLGPTLMKRYAKFVKHFLTQDLAVNRRSELWVGLVDLLGLALTTSALGIAVVGSVQRGSVGEIAGFIQAMGSLQTATSGFLLGLAALYQNGLWARNLFGYLELPSNSLRATGKCLPFPADASIEFRNVSFTYPSTDRRVLNDLSFTLPAGSRTAIVGPNGAGKSTIVKLLTGLYIPDAGEVLIGGVPVKDLDPDEVRREVGVVFQDFVKYELSAADNIAFGNWPSATEDEVLGAAERAGIWGKLTNLPANIETLLGRRFTGAQQLSLGEWQKMALARAFVSGRTVLIMDEPSASLDPRAEADLVARIADVPKGTTAVVVAHRFATVRALDRIVVLDQGAITEMGNHDELMRLSGTYALMYEAQAAAFSESK",
      "product": ""
     },
     {
      "start": 64463,
      "end": 66508,
      "strand": -1,
      "locus_tag": "ctg8_57",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_57</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_57</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 64,463 - 66,508,\n (total: 2046 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) lanthipeptide-class-i: Lant_dehydr_C<br>\n \n  biosynthetic (rule-based-clusters) lanthipeptide-class-i: Lant_dehydr_N<br>\n \n  biosynthetic-additional (smcogs) SMCOG1155:Lantibiotic dehydratase domain protein (Score: 419.9; E-value: 3e-127)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_57 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04738.16 (Lantibiotic dehydratase, N terminus): [13:351](score: 213.4, e-value: 4.5e-63)<br>\n \n  PF14028.9 (Lantibiotic biosynthesis dehydratase C-term): [423:664](score: 111.9, e-value: 5e-32)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_57\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_57_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGTGCCGCGGTGCCGGGGACGCTCTCGAAGAATTCGACCGCTACCTCGACACGTACCGGAATGCGTTCCTGGAACGCTTCGGAGTCGACACCGCTGTGCCGATCGCCAAGGCAGTCGACCCTGTCTTCGGGATCGGTCTACCTGAGCACTTCAATGTCAGGCAGACGCCGCCGCCCACTCGGACCCCTGCTCTCACTCGCTACGAGCGAGTTCTCCTGGACCTTGCAACAGAGACATGGCAAACCGGGTCGAAGCAACTCGTGGTCACACCTGATGTGGAACGAAAACTCAAAGAGGCTGCGCCGGTCTCGTCAAGTCCGCGTCGCCCGCAACCCAGCCTCGACATATTTGCCCAGCTCCTCGCCACACCGAACAGCGAAGGCAGATGGCAAGCGGTGTTGAACTCGGTGCCAGTGGGCCTCGGGGGCGCGTCCTTTGGCCGGTTCATGCACGACATGGACCAGGTAGGGCGAGACAAGACAGCTGCCCTAATCCGACGTCGTGTTCCCAACCCCGAGTCGATCCTCGGCGCCGATCTGGCCTTCGTTCCGGCACAGGCCCGAGTCGCCAACGTCACTGTCCGACCACCAGTTCACGCACATCATGTTGGAATCAACGTTCCGAGCGTTTCCGGCTCAGAAGAGATCGCGCTTCCTGATGTGCACCTCGTTGCCACGTACGAACGGTTGTACCTCTGGTCGGCACGACACCAGCGGGAATTGCACATCTCCGCGCATCATCTGCTGTCGCTTGAAGCCGCGCCACCCGTTGCGCGACTCATAGTCGAGGTCAGCGAGCGACGGTATGCAGCTCCAGGCGGTTTTTCTTGGGGGCCGTTGGAAGGGAGCCTGCGTCTGCCTCGAGTTGTGCGGAAGAACGTTGTCTTGCGGGTCGCGGAATGGACCGTGCCGCGCTCGATGATCGACATCGAGACGGAAGACGTAGCTGAATGGCTCCCGCGCCACCGCGATCGTTGGGATATCCCATCGCAGGTCTACCTCACCAGCCAGGACCAACGACTGCTCATCGATTGCACGTCGGATCGAGGAATGCAGGAGATAAAGGACGCTCTGGCCACATCGGGACAGGTGAGGCTGCAGGAGGTGTACCCACCTCTGGAACCGTCCTGGGTGCACGACGCTCAGGGCTTCGGATACGTCGGCGAAATCGTCGTGCCAGTTGTTGCAAAATATAGAAATCGCCCGACTACCGTCGATCCCAAACCGCTCATTTGCGACCCCCCTGTTGTCGACCACGCCTCAGAGCTGTGGACCTACTGCAAGCTCTACACCGAGCCGCCTCTTCAAGACGAGATTCTTTCCCGGGACCTGCCGCGCCTACTTCAGGCCCACGACCCCGCAGCGTTTGAAAAATGGTTCTTCATCCGCTACTCAGATCCGGCTCACCATCTACGACTTAGATTTCGAAGCGGTTCCGAGGACGACAGGTGGCTCGTCCAACGACACGTCGACCGGTGGGCTACGGAGCTGAAGCGTGCAGGCATGATCAAGGACTTTGCCTTCGCTCAGTACTCACCCGAACTGGCGAGGTACGGCGGGTCGCATTCCATGGGCGTTGTCGAGAAAATATTCGAACTTTCCAGCAAACACGCGGCCGCCATGGCCAGCGCCTCACCCCCTTCTCGACTAATGTCCGCCGTCGCCACCGCAGATAAACTGGCCGCAGCCTGGGGATACTCAGTTTCAGATAGGCGCGGACTGGCTGGCGACTACCCAGCCGAACCCGATGTCACCGACGCCGCACGGGCCTTTGTCCGTTCACATCAACGTGAGCTCTTGGATGCGCTCGACAGCGCCGAAACCGAGCCGGACGAACTAGGCGATCTCATCAGACAGCTTCGCTCGAATGTGGATCGTTCAAGAGAGAACGCTGAGTTCGCCCCAAACAACGAGAGTGTCATCAGGAGCATCATTCACATGAACTTCAACAGGATGCTCAGCACCGATCACACCGAAGCCCTGGCGCACAGAGTGTGGCAGGACGGGTGGCGGGCGCTGTCAAGCCGGCGGGCGGCAACGCGGTGA",
      "translation": "MCRGAGDALEEFDRYLDTYRNAFLERFGVDTAVPIAKAVDPVFGIGLPEHFNVRQTPPPTRTPALTRYERVLLDLATETWQTGSKQLVVTPDVERKLKEAAPVSSSPRRPQPSLDIFAQLLATPNSEGRWQAVLNSVPVGLGGASFGRFMHDMDQVGRDKTAALIRRRVPNPESILGADLAFVPAQARVANVTVRPPVHAHHVGINVPSVSGSEEIALPDVHLVATYERLYLWSARHQRELHISAHHLLSLEAAPPVARLIVEVSERRYAAPGGFSWGPLEGSLRLPRVVRKNVVLRVAEWTVPRSMIDIETEDVAEWLPRHRDRWDIPSQVYLTSQDQRLLIDCTSDRGMQEIKDALATSGQVRLQEVYPPLEPSWVHDAQGFGYVGEIVVPVVAKYRNRPTTVDPKPLICDPPVVDHASELWTYCKLYTEPPLQDEILSRDLPRLLQAHDPAAFEKWFFIRYSDPAHHLRLRFRSGSEDDRWLVQRHVDRWATELKRAGMIKDFAFAQYSPELARYGGSHSMGVVEKIFELSSKHAAAMASASPPSRLMSAVATADKLAAAWGYSVSDRRGLAGDYPAEPDVTDAARAFVRSHQRELLDALDSAETEPDELGDLIRQLRSNVDRSRENAEFAPNNESVIRSIIHMNFNRMLSTDHTEALAHRVWQDGWRALSSRRAATR",
      "product": ""
     },
     {
      "start": 67446,
      "end": 68843,
      "strand": -1,
      "locus_tag": "ctg8_58",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_58</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_58</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 67,446 - 68,843,\n (total: 1398 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) lanthipeptide-class-i: LANC_like<br>\n \n  biosynthetic-additional (smcogs) SMCOG1140:Lanthionine synthetase C family protein (Score: 178.9; E-value: 2.4e-54)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_58 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05147.16 (Lanthionine synthetase C-like protein): [82:452](score: 120.6, e-value: 6e-35)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_58 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05147.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0031179' target='_blank'>GO:0031179</a>: peptide modification<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_58\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_58_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGACAGTGGTCTCGATCCTCACTACAAACGCGTGCGGATCTACTCAGACGACTGGGCGCTGCTAAGTCGAGTGGTTGTTGCAAGACAAGGGGCCGGCTCGTTGATCTCAACGGGCCGGCTTCGGTCGACCACGAATCATATGCAAATACTCGAGGACATAAGCGCGGGGATTGCCGATCGGCTCGGATCGCCACCAGCAGTGAAGGCTTTGGTTTCGCGTCAACCGAGCGGGATCAATGGGGTTGAGTGGCACGGGCCGTCGCTAGGGAACGGCCATGCGGGAATCTCGCTCTTCCTGCTTGAACGCGCGAAACGAACAGACACGCAGACTGACTACGACGCGGCGTTTGACCACCTGCGTGCAGCAGTCTCAGCTAACAATGAGTCTCCCTCCGGCGCATTGGGGCTGTTCTCAGGTGCTGCGGGCCTCTCTTACGCCATGACTCAATGCGCCAAGCAGGAGCCGCGTTTTGCTCCTAGCGCCGAGCGGTTTCATGAGCGAGTCGCCGATTCCGTGTTGGACGTGAAATGGGACTTCAAGCCACGTCGCGCCATTGACCAAGAATTTGACCTGATTTCAGGCGCATCCGGTGTCTTGCTGTACTTGGTCAGGTCCCCACAGCAATCTCGTACTTCGCGAGTCGCGATTGACCACCTTTCGCATTATCTCGGCTGGCTGCTCACCAGTGCACCACTTGACTTCACCTTCTTCAGAAGCCCCGACGATTACGTGCCAGGCGGCACATTGGCGAGAAAGTACCCACGGGGAGCAATCGATTGCAGTCTCTCGCATGGCATCTCGAGTGTGGCTCTGGCTCTCTCAGCGGTGGAGTTATCGGGTCAGTCCTCGATGGGCCTTCAGGAGCCGTTGCGTCGAGTTCGTGACTGGCTCGCTATAAGCGCCCTTGAAGATGGCGACATTAAGTTCTACCCGTCTGCTTTGGGTGAACCCGCCGGAGCCGTAGCAGGCAACGCTCTCGACTACAGCTGGTGCAGAGGATCCTCCGGAATCGTCGCCGCCCTTTCCGCGGCCAGCGATGCAACTGGAGACTTGGACGGAGCGCGTCATGCCCGGCATAGCGCTCGCGCCGCCTTTGAGAGATACGACCCCGAACGGCGTCCAGCAGGTCCTTCGTATTGTCTATGCCACGGCGCGGCCGGCGTCGCAATCATGGCCCAATCTCTTGGCTTGGACACGGACGCACACGAACGCGAGCTCGGACTAGCTTTCGATGCTGACCTCCCCACCGGATACGCCGAGAAGAATGTTGTAGACGATGACCTGTACGACCCGAGCTTTCTCTCTGGCTCAGCTGGTGTCGGTGCCACTGCCGAGCACCTGCTCAGCAAAACTGCTACTTGGACGAGAGACCTAGGATTCACGCTTGATGAGTGA",
      "translation": "MDSGLDPHYKRVRIYSDDWALLSRVVVARQGAGSLISTGRLRSTTNHMQILEDISAGIADRLGSPPAVKALVSRQPSGINGVEWHGPSLGNGHAGISLFLLERAKRTDTQTDYDAAFDHLRAAVSANNESPSGALGLFSGAAGLSYAMTQCAKQEPRFAPSAERFHERVADSVLDVKWDFKPRRAIDQEFDLISGASGVLLYLVRSPQQSRTSRVAIDHLSHYLGWLLTSAPLDFTFFRSPDDYVPGGTLARKYPRGAIDCSLSHGISSVALALSAVELSGQSSMGLQEPLRRVRDWLAISALEDGDIKFYPSALGEPAGAVAGNALDYSWCRGSSGIVAALSAASDATGDLDGARHARHSARAAFERYDPERRPAGPSYCLCHGAAGVAIMAQSLGLDTDAHERELGLAFDADLPTGYAEKNVVDDDLYDPSFLSGSAGVGATAEHLLSKTATWTRDLGFTLDE",
      "product": ""
     },
     {
      "start": 70012,
      "end": 71001,
      "strand": 1,
      "locus_tag": "ctg8_59",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_59</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_59</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 70,012 - 71,001,\n (total: 990 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_59 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03595.20 (Voltage-dependent anion channel): [15:307](score: 68.7, e-value: 5.7e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_59 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03595.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF03595.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_59\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACATCCACCCCGCGGCAGACATCCAACGACACCGCCAGGGCCCCGCTCAGCAGTCTCGGCATCCCGTTCGGGCTCTCCGGCCTCGCCGGAACCTGGACCATGGCCGCCGCCACCTCGCTCGCGCCGCAGATCATAGCCGAGGGGCTCTGGACGCTCGCGGCCACGGCCTGGATCGCCGTCGTCGCAAACTACGTCTGGCGATCCCGCAACCGCGGTGGAAGCATCCTTAACGACTTGCGCGACCCTGTGCAGGGGGCGTTCGCGTCGCTCGCCCCGACGTCGGCGATGCTCATCTGCACGCACTACGCGCAGCAGCTCCCGATGGCCGGCCGCATCATCGCGGGCGTGTTCATGGCCATCGGGTTGCTCTTCGGTGCCTGGTTTCTCGCCCAATTGGCGCTGCGCGAGCGAAGCGTCGATGCCATCCATGCCGGGTACCTGCTGCCCACCGTGGCGGCGGCTTTCATCGTCGGGCAGAGTGCAGGCACCTTCGGCTGGACCCTCCTGGGCGAGGGCGCCATCGCGGTGGGCATCCTCTTCTGGCTGATGCTCGGCACGATCATCCTGGCGCGGATGGCGTTCCGCCCGGCTCCGCCCGCCGCGCTCCTGCCGACGTTCGCGATTTTCTCTGCACCGCCGGCCGTCGCCGGCAACGCCTGGTTCGCGGTGAACGGCGGCCGCATCGATCTGGTGGAGACAATGCTGCTGGGAACCTTCGTCGTGCTGATTCTCGTGCAACTTATGATGCTGGGCGCGTACTGGCGGCTGCCGTTCACCCTGGGGTTCTGGGCGTTCACCTTTACCGCGGCATCCAGCGGAACCTACACGGTGCACTGGCTCGCGCTGTGGGGCGGCCCCGGACACGTGGTGTGGGCGTGGCTTGCCATCGGACTTGTCACACTGCTGATCGGGAGCATCGCCGTGCGATCCGCAGCCTTACTCACCGCTCACAGCCGATTCGACGCGCCGTCAGCTCAACTGCTCTGA",
      "translation": "MTSTPRQTSNDTARAPLSSLGIPFGLSGLAGTWTMAAATSLAPQIIAEGLWTLAATAWIAVVANYVWRSRNRGGSILNDLRDPVQGAFASLAPTSAMLICTHYAQQLPMAGRIIAGVFMAIGLLFGAWFLAQLALRERSVDAIHAGYLLPTVAAAFIVGQSAGTFGWTLLGEGAIAVGILFWLMLGTIILARMAFRPAPPAALLPTFAIFSAPPAVAGNAWFAVNGGRIDLVETMLLGTFVVLILVQLMMLGAYWRLPFTLGFWAFTFTAASSGTYTVHWLALWGGPGHVVWAWLAIGLVTLLIGSIAVRSAALLTAHSRFDAPSAQLL",
      "product": ""
     },
     {
      "start": 71024,
      "end": 71581,
      "strand": -1,
      "locus_tag": "ctg8_60",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_60</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_60</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 71,024 - 71,581,\n (total: 558 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1057:TetR family transcriptional regulator (Score: 73.5; E-value: 5.1e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_60 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00440.26 (Bacterial regulatory proteins, tetR family): [11:58](score: 53.4, e-value: 1.8e-14)<br>\n \n  PF17926.4 (Tetracyclin repressor-like, C-terminal domain): [75:173](score: 50.4, e-value: 2.2e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_60 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00440.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_60\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_60_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCTACGACTCCGCCGCAACACGCACCCGCCTGCTGGATTCTGCTTATGCGGAGTTCGCCGATCGAGGATTCGCCGGTGCGCGAGTGAACCGAATCGCATCAGAGTCAGGTGCGAACAAGCAGGCGATTTATCTCTACTTCGCTTCCAAAGAGGGTTTGTTCGACGCCGTCCTGGAAGACCGTCTGGGCGTGCTGGCCGACCTGGTCCCCTACACCCCGGATGACCTCACGGGATATATCGGCGCCCTCTTTGACCACATGGTTGAGCATCCCGAACTTGTCCGGCTCACGCAGTGGAAACAGCTAGAGCGGCCTGACGCCACAGACCTGGAACTGAACTCTCATGTGTCGAAAGCGGAGGCTCTTGCTCGAGCGATGGGCGTCGACGACACCCGCGGCATGGATGCTCTCATGCTTACTCTTGCCATGGCGCAAGCCTGGAATACAACGAGCACGTCAGTCCGATCCATGAAGGAACCAGCAGAACTGCGTCTTCGGCAACATCGCGCCTCGCTTATTACCGGGGTTGCGTCCGTCGTCAGTGCCCTTCAATAA",
      "translation": "MSYDSAATRTRLLDSAYAEFADRGFAGARVNRIASESGANKQAIYLYFASKEGLFDAVLEDRLGVLADLVPYTPDDLTGYIGALFDHMVEHPELVRLTQWKQLERPDATDLELNSHVSKAEALARAMGVDDTRGMDALMLTLAMAQAWNTTSTSVRSMKEPAELRLRQHRASLITGVASVVSALQ",
      "product": ""
     },
     {
      "start": 71682,
      "end": 72527,
      "strand": 1,
      "locus_tag": "ctg8_61",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_61</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_61</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 71,682 - 72,527,\n (total: 846 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 184.5; E-value: 4e-56)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_61 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00106.28 (short chain dehydrogenase): [3:186](score: 150.9, e-value: 3.1e-44)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_61\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_61_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGAACGTGGCTCATCACGGGGGCGTCATCCGGAATCGGTCGCTCCGTTACGTCGAGATTGTTGGAGCAGGGGGATCGTGTAGCTGCTTTCGTTCGTCGGCCAGAAGCCCTCAACGAACTGTCCGACACGTACCCCGGGAAGCTGTGGGTGGCGCCGGTCGATGTCACCGACACGCGCGTCCTGCGCGACGCCGTAGTCCGGGCGTTCACTGACCTCGGGAAGATCGATGTTGTCTTCTCGAATGCCGGAGCAGGAGCATTCGGAGCCGCCGAAGAGCTCGACGATAGCGCGATCGAGGAACAGATCGCGCTCAACCTCGTTGCACCGATCCAGCTCATCCGGGCCGTCCTCCCGCACCTCCGCGCCCAAGGTGGGGGTCGGATCATCCAGATGTCCACGATGGGCGGCCAGATCACCAGCACCGGAGGCAGCATGTACCACGCCTCCAAGTGGGGGATCGAGGGGTTCACCGAGTCGGTGATGGGCGAGGTCGCTCCGTTCGGCATCGGCATCACCCTGGTCGAGCCCGGAAATGTGCGCACCGCGTTTGGCGCGGCGCTCACCATCGCCGCGCCCATCGAGGCCTACGCCGACACTCCCGTCGGGCACGTACGGCAGTACATCGAGGCTGCCGGTGGCAACCTCACCGGCGACGCCCTGGGCGACCCGGCCCGCGTCGCCGAAGCGATCATCGCCGTGTCGGTGCAGTCACCCGCCCCTGAGCGCCTGGTCCTGGGAAGCGACGCCTACTCGGCAATCCGCGCCGCACTCACCTCCCGGCTCAGCCAACTCGATGCAGGCAAGGCGGTCTCCGAGAGCACCGACTTCCCCGCCACCACCTGA",
      "translation": "MRTWLITGASSGIGRSVTSRLLEQGDRVAAFVRRPEALNELSDTYPGKLWVAPVDVTDTRVLRDAVVRAFTDLGKIDVVFSNAGAGAFGAAEELDDSAIEEQIALNLVAPIQLIRAVLPHLRAQGGGRIIQMSTMGGQITSTGGSMYHASKWGIEGFTESVMGEVAPFGIGITLVEPGNVRTAFGAALTIAAPIEAYADTPVGHVRQYIEAAGGNLTGDALGDPARVAEAIIAVSVQSPAPERLVLGSDAYSAIRAALTSRLSQLDAGKAVSESTDFPATT",
      "product": ""
     },
     {
      "start": 72621,
      "end": 73025,
      "strand": 1,
      "locus_tag": "ctg8_62",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_62</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_62</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 72,621 - 73,025,\n (total: 405 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF07366<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_62 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07366.15 (SnoaL-like polyketide cyclase): [8:132](score: 90.7, e-value: 6.8e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_62 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF07366.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030638' target='_blank'>GO:0030638</a>: polyketide metabolic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_62\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_62\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_62_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_62\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_62\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACAAGCACGCCTGCTAAGACCATCGCCCGCGAATTCTGGGAGAGCTGGGGGCGCGGCGATCTGGACGCGACCTGGCGCCAGTACGTCGCGGACGACATCGTCATCCACCCGTCGTCGGGATACGAATTCACGCGGCAGAGTTGGCTGGAGGCCGAAAAAGCACTCCATGCCGCGTTCGAGGACATCAAGGTCACCGTCGTCGATCAGATCGAGGACGGCGACATGGTCGCGACCCGATGGGCCGTCACTGCCCGGCAGAGCGGAGAGTTCTTCGGCGTGCCCTCCAGCGGACGGACCGCCACCCTTACTGGAACCACCTTCGACCGCGTTCAGGACGGCAAACTTGCCGAGCACTGGGCCGAAGTGGGCGTTCCGCAGTTCCTCCAGCAGCTCTCCGCCTAA",
      "translation": "MTSTPAKTIAREFWESWGRGDLDATWRQYVADDIVIHPSSGYEFTRQSWLEAEKALHAAFEDIKVTVVDQIEDGDMVATRWAVTARQSGEFFGVPSSGRTATLTGTTFDRVQDGKLAEHWAEVGVPQFLQQLSA",
      "product": ""
     },
     {
      "start": 73056,
      "end": 73493,
      "strand": 1,
      "locus_tag": "ctg8_63",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_63</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_63</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 73,056 - 73,493,\n (total: 438 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_63 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13577.9 (SnoaL-like domain): [13:136](score: 50.2, e-value: 2.6e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_63\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_63\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_63\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_63\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCTCTAGAACAGATCGGCATCCTCGTCACTGATTCCGACCACGTCCAACTCACGCGCCTCGCCCTCGAGGTCGCCTGGCGCGTCGACATCGGCCAAGCCGAGACGCTCCCGGAGCTCTTCACCGAAGACGGCTGGATCGCGACCCTGGGCGAACCCAACGTCGGACACGCCGCCATCCGCAGCTGGGGGCAGATGATGGACACGGATAGCCCCATACCCGGGGTACGCCACGTTCTGACGAACTTCAGGTTCACAACTGAGGCACCTGACCAAGCCGTCGGCACGATGTACATCACCGCCTACTTGGCCGGGGCCCCGGAGGGACAGGCCACTGTCCCCTTCGCGATGGGCACTGGCACCGACCACTACCGCCGTACCGCCGACGGCTGGAAGGTCACCTCCCGAGCCTTCACACCACATTTTCTCCGGGAATAG",
      "translation": "MPLEQIGILVTDSDHVQLTRLALEVAWRVDIGQAETLPELFTEDGWIATLGEPNVGHAAIRSWGQMMDTDSPIPGVRHVLTNFRFTTEAPDQAVGTMYITAYLAGAPEGQATVPFAMGTGTDHYRRTADGWKVTSRAFTPHFLRE",
      "product": ""
     },
     {
      "start": 73603,
      "end": 74241,
      "strand": -1,
      "locus_tag": "ctg8_64",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_64</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_64</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 73,603 - 74,241,\n (total: 639 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_64 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01966.25 (HD domain): [31:118](score: 35.8, e-value: 8.7e-09)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_64\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_64\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_64_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_64\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_64\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACACAGACCATCGCCGGCATCGCCATTCCCGACAGTTCACTTGCTGTCGAAGCCACCGAATTGGTGCGCGATACGACCAACGAACTCATCTTCAACCACTCCCGCCGGGTGTTCCTGTTCGGCAGCCTGCGGGCGCAGGCGCTGAATATCACGCCGGAACCCGAGCTGTTATATGTCGCTGCGCTGTTCCACGATCTCGGACTCGTCGCCCCGTACAAGAACGTCGCCCAGCGCTTTGAATTGGATGGTGCCGGGCACGCTCGCGAGTTCCTGACCTCGCACGGTATCTCCGGTGCCGACGCGGAGGAGGTATGGACCGCGATTGCCCTGCACACCACGCCTGAAGTTCCCTACCGGATGAGCCCGGTGATCGCGGCGACAACGGCCGGGGTGGAGGCCGATGTGCTCGGGATCAACCTCGGCTCGCTGTCAGAGAGCCAGATCGGCGCCATCACGGCGGCGCATCCGCGTCCGGACTTCAAAAAGCGCATTCTGCAGGCGTTCTTCGACGGCTTCTCCGACCGCCCGGACACAACTTTCGGCACCGTCAACGCCGACGTTCTGGAGCATTTCCAAGCCGACTTCCGGCACATCGACTTCGTCGACGTGATCCGGAACTCCGCCTGGAGCGAATAG",
      "translation": "MTQTIAGIAIPDSSLAVEATELVRDTTNELIFNHSRRVFLFGSLRAQALNITPEPELLYVAALFHDLGLVAPYKNVAQRFELDGAGHAREFLTSHGISGADAEEVWTAIALHTTPEVPYRMSPVIAATTAGVEADVLGINLGSLSESQIGAITAAHPRPDFKKRILQAFFDGFSDRPDTTFGTVNADVLEHFQADFRHIDFVDVIRNSAWSE",
      "product": ""
     },
     {
      "start": 74436,
      "end": 75371,
      "strand": 1,
      "locus_tag": "ctg8_65",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_65</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_65</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 74,436 - 75,371,\n (total: 936 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1260:AraC family transcriptional regulator (Score: 72.3; E-value: 8e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_65 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01965.27 (DJ-1/PfpI family): [1:160](score: 93.0, e-value: 1.9e-26)<br>\n \n  PF12833.10 (Helix-turn-helix domain): [220:299](score: 78.1, e-value: 5e-22)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_65 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF12833.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity<br>\n  \n   PF12833.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043565' target='_blank'>GO:0043565</a>: sequence-specific DNA binding<br>\n  \n   PF12833.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_65\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_65\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_65_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_65\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_65\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACTTCTCGACATGGCTGGGCCCGCCGAAGTGTTCACCGAGGCGAACCTTTCCGGGGCGAATTACCGCATCAGCATGGTGTCCACCGGCGGCCACGACGTCCGATCCTCCATCGGCATGCGTGTGCCAGTCGATGTCTCCGCGGCCGACGCCGGACGCTTCGATACCGTCCTGGTCGCGGGCGGCGAGGTGTTCCCGGCTCACCCCGTCCCAGAGCCCCTCGCCGGCGCGGCGCTCCACCTTGCCGACCGGGCGTCCCGCACCGCATCAATCTGCACCGGTGCTTTCGTGTTGGCGGCGGCAGGACTGCTAGACGGCAAGCGGGCGACCACGCACTGGAAGCACACTCGAGAACTCGCCCTGCGGTATCCCGCAACACAGGTAGAACCCGATGCCATCTTCGTCCGGGATCAGAGCACGTATTCGTCCGCCGGAGTCACCGCCGGGATCGATCTCGCCCTCGCGCTGCTGGAGGAAGACGAAGGCGACGGACTCACCCGCACCGTCGCTCGCTCGTTGGTCGTCTACATGCAGCGCGCCGGAGGACAATCCCAGTTTTCCGCGACCCTGCAGGGCCCCGCACCCCGCACGGCCTTGCTGCGCGGCGTCGTCGACATTGTGAACGCCGACCCGGCGGCCGAGTACACCGTGACCCGGCTCGCGGCGATCGCCCAAGTGAGCCCACGCCACCTCACCCGCCTCTTCCACGACGAACTCGGGACCACTCCGGGCAGGTACGTCGAGCTGATCCGCTTCGACAAGGCCAAGGCGTTGCTGGATACCGGAATGAGCGTCACGGATGTGGCCCAGTACTCGGGCTTCGGCACATCCGAGTCGCTCCGGCGTGCCTTCATCGCTCACCTGGCGATCCCACCGTCCAAGTATCGAGGCCGGTTCTCCCCGATGTCGGGAACGAGAAATACTGCCGCCTGA",
      "translation": "MKLLDMAGPAEVFTEANLSGANYRISMVSTGGHDVRSSIGMRVPVDVSAADAGRFDTVLVAGGEVFPAHPVPEPLAGAALHLADRASRTASICTGAFVLAAAGLLDGKRATTHWKHTRELALRYPATQVEPDAIFVRDQSTYSSAGVTAGIDLALALLEEDEGDGLTRTVARSLVVYMQRAGGQSQFSATLQGPAPRTALLRGVVDIVNADPAAEYTVTRLAAIAQVSPRHLTRLFHDELGTTPGRYVELIRFDKAKALLDTGMSVTDVAQYSGFGTSESLRRAFIAHLAIPPSKYRGRFSPMSGTRNTAA",
      "product": ""
     },
     {
      "start": 75481,
      "end": 75993,
      "strand": 1,
      "locus_tag": "ctg8_66",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_66</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_66</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 75,481 - 75,993,\n (total: 513 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_66 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00210.27 (Ferritin-like domain): [28:163](score: 68.6, e-value: 5.8e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_66 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00210.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008199' target='_blank'>GO:0008199</a>: ferric iron binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_66\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_66\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_66\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_66\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCCCACGCCCAGAACCAGCACATCGTCGACATCCCCGTGTCGAGCACCCCACGATTCATCGCCAGCGACACGCTCCTGAGTAGCCTGCAGTCCGTGCTCGTGGATCTAATCGAACTGAACCTCCAGGGTAAGCAAGCACATTGGAACGTCGTCGGGCCGAACTTCCCCGACGTGCACCGGCAACTCGACCTGATTGTGTCGACGGCCCAGGATGCCGCGGACGGCGTAGCCGAGCGCATGCGCGCGGTTGGCGGAATTCCCGACGGGCTGAGCTCCACGGTGGCCGAGACCACCGGACTTCTGGCCTATCCCCGGGGCGAAGTGACCACTCGGCAGACGATCGACCTCATCTCGGAACGCATCTACACCACCGTGGCAAATGCCCGCGCCGTGCATTCAGCCGTCGACGACGAGGATCCGGTGTCCGCGGACCTGCTCAACGGCACGATCGCCCAGCTCGAGCAGCACGCCTGGTTGCTGTCGTCCGAGAACCGTACGCCGAGCTTGTGA",
      "translation": "MPHAQNQHIVDIPVSSTPRFIASDTLLSSLQSVLVDLIELNLQGKQAHWNVVGPNFPDVHRQLDLIVSTAQDAADGVAERMRAVGGIPDGLSSTVAETTGLLAYPRGEVTTRQTIDLISERIYTTVANARAVHSAVDDEDPVSADLLNGTIAQLEQHAWLLSSENRTPSL",
      "product": ""
     },
     {
      "start": 76111,
      "end": 76659,
      "strand": 1,
      "locus_tag": "ctg8_67",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_67</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_67</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 76,111 - 76,659,\n (total: 549 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_67 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02627.23 (Carboxymuconolactone decarboxylase family): [55:110](score: 36.5, e-value: 4.3e-09)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_67 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02627.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051920' target='_blank'>GO:0051920</a>: peroxiredoxin activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_67\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_67\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_67\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_67\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGGTCACCACCGCCACGCTCGCCCCCATCCAGCCCGAGGACGCCACGGGCGTCGCCAAAGACCTGCTCGCGCAGGTGCAGAAGGGCCTCGGCCGCGTGCCGAACATGACCAAGGTCATGGCGAACAGCCCGGCACTTCTCAAGAGCTACCTCGTTTTGTCTGCCGCCGTGGGCTCCGGCACCCTTCCGGCCGCCGTTCGTGACCGCCTCGCGATCGCGACCGCCCAGCTGAATGGATGCGAATACTGCCTCTCCGCACATACCTACATCGGCAGCAACGTGTCGAAGGTGACCGCCGACGAACTCGATTCCGCACGACGCAGCGACTCGACCAACCCCCACGTTGCCGCGCTGCTGACGCTTTCCAGCGCGATCGCGGAGAATGCCGGGGATGTGGCTGAGGACACGATCGCGAAGGCCCGCGAAGCCGGGGTGACGGACCAGGAGATCGGGGAACTGGTGGCTAATCTGGCGTTGAATGTGCTGACGAACTACTTCAACGTTCTCGCCCGGGTCGAAAACGACTGGCCTGTTGTGGCGTTGTAG",
      "translation": "MTVTTATLAPIQPEDATGVAKDLLAQVQKGLGRVPNMTKVMANSPALLKSYLVLSAAVGSGTLPAAVRDRLAIATAQLNGCEYCLSAHTYIGSNVSKVTADELDSARRSDSTNPHVAALLTLSSAIAENAGDVAEDTIAKAREAGVTDQEIGELVANLALNVLTNYFNVLARVENDWPVVAL",
      "product": ""
     },
     {
      "start": 76742,
      "end": 77713,
      "strand": 1,
      "locus_tag": "ctg8_68",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_68</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_68</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 76,742 - 77,713,\n (total: 972 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF00561<br>\n \n  biosynthetic-additional (rule-based-clusters) Abhydrolase_6<br>\n \n  biosynthetic-additional (smcogs) SMCOG1036:alpha/beta hydrolase fold protein (Score: 118.3; E-value: 8.1e-36)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_68 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00561.23 (alpha/beta hydrolase fold): [68:304](score: 95.8, e-value: 3.5e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_68\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_68\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_68_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_68\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_68\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCGTATTCGAGGGCAGTCTGGCCGGAGACGCGGGGCGGCTGAGGCCGGGCATCTTCAGACTGAATATACGGCCCGACCCAGAGCGGGCCACAGCGAGAACCTCTCTTCTAGCGGATAGGAACACCATGTCAGTCATCACCGTCGGCACCGAGAACAGCACGTCGATCGACCTGTACTACGAAGACCACGGCAGCGGCCAGCCTGTCGTCCTCATCCACGGCTACCCTCTCAACGGGGCCTCCTGGGCACCGCAAACCCGGGCGCTCCTCGCGGCCGGCTACCGAGTCATCACCTACGACCGCCGCGGTTTCGGCAAGTCCAGCCAGCCGAGCGAAGGCTACAACTACGACACCTTCGCCGCCGACCTCGACGTCGTCCTCACGACACTCGACCTCCAGAACGTGCTGCTCGTCGGCTTCTCCATGGGCACCGGCGAGGTCGGCCGGTACACGGCGACCTACGGTACCGACCGCCTCGCGAAGATCGCGTTCCTGGCGCCGATCGAGCCGTTCCTGCTCAAGACCGACGACAACCCCACCGGGCTCCCGCAGGAGGTTTTCGACGGCATCGCTGCGGGCGCGCAAGCCGACCCGTACGCGTTTTACACGTCATTCTATGAGAACTTCTACAACCTCGATGAGAACCTCGGCACCCGCGTGAGCCCCGAGGTCGTTCAGGGGAGCTGGAACGTCGCAACGGGCGGTTCGCTGATCGCGGCCTACGCTGTCGTGCCGTCCTGGCACGAAGACTTCCGCGGCGATATCGAGAAGATCCGCGCGACCGGGATTCGCAGCCTGATCATGCAGGGTGTGCTCGACCGCATCCTCCCGATCGACGCGACCGGGCGCGCCTTCCACAAGGCGTTCCCCGAGAGCGACTACGTGGAGATCGAGGGCGGGCCGCACGGCTTCGGCTGGAGCCACGCCGCCGAGGTCAACGAAAACCTGCTGCGCTTCCTCGCGAGCTAG",
      "translation": "MSVFEGSLAGDAGRLRPGIFRLNIRPDPERATARTSLLADRNTMSVITVGTENSTSIDLYYEDHGSGQPVVLIHGYPLNGASWAPQTRALLAAGYRVITYDRRGFGKSSQPSEGYNYDTFAADLDVVLTTLDLQNVLLVGFSMGTGEVGRYTATYGTDRLAKIAFLAPIEPFLLKTDDNPTGLPQEVFDGIAAGAQADPYAFYTSFYENFYNLDENLGTRVSPEVVQGSWNVATGGSLIAAYAVVPSWHEDFRGDIEKIRATGIRSLIMQGVLDRILPIDATGRAFHKAFPESDYVEIEGGPHGFGWSHAAEVNENLLRFLAS",
      "product": ""
     },
     {
      "start": 77789,
      "end": 78184,
      "strand": 1,
      "locus_tag": "ctg8_69",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_69</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_69</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 77,789 - 78,184,\n (total: 396 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_69 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03625.17 (Domain of unknown function DUF302): [35:97](score: 58.2, e-value: 6e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_69\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_69\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_69\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_69\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCGAGGAACTGAAAACACTACGGGTGCAGGGCAGCGTCGCTGAGGCGACCGCTCGACTCCGCGAGCTGTTGGAGCGACGAGGCGTTGCAGTGATCGCGAGCATCGATCACGCCGCAGGAGCGCGGGCGGCGGGCCTGGAGCTAGCCGATGAAGTCGTCGTGTTCTTCGGAGACCCGGCCGTGGGTACGGGGGTGATGCAGGACGATCCGAGAGCCGGAATCGATCTCCCGCTTCGGATGCTGGTCTGGGACGACAACGGTTCCACGTACATCGGCTACCGTGACCCGCACGTGCTCTCCGACCTGTTTGAGCTCGACATCCATCGCGACGTGCCGGCGAAGCTGAGCGGATTCATGGAACGACTTGCACACGATCTATCGGCCGAGCAGTGA",
      "translation": "MGEELKTLRVQGSVAEATARLRELLERRGVAVIASIDHAAGARAAGLELADEVVVFFGDPAVGTGVMQDDPRAGIDLPLRMLVWDDNGSTYIGYRDPHVLSDLFELDIHRDVPAKLSGFMERLAHDLSAEQ",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 64462,
      "end": 68843,
      "tool": "rule-based-clusters",
      "neighbouring_start": 54462,
      "neighbouring_end": 78843,
      "product": "lanthipeptide-class-i",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "lanthipeptide-class-i",
    "products": [
     "lanthipeptide-class-i"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP lanthipeptide-class-i",
    "anchor": "r8c1"
   }
  ]
 },
 {
  "length": 102523,
  "seq_id": "NODE_21_length_102523_cov_26.131025",
  "regions": []
 },
 {
  "length": 92788,
  "seq_id": "NODE_24_length_92788_cov_27.498075",
  "regions": []
 },
 {
  "length": 90938,
  "seq_id": "NODE_25_length_90938_cov_24.564742",
  "regions": []
 },
 {
  "length": 79042,
  "seq_id": "NODE_26_length_79042_cov_25.521573",
  "regions": []
 },
 {
  "length": 78513,
  "seq_id": "NODE_27_length_78513_cov_24.995232",
  "regions": []
 },
 {
  "length": 77802,
  "seq_id": "NODE_28_length_77802_cov_22.702798",
  "regions": [
   {
    "start": 14041,
    "end": 54779,
    "idx": 1,
    "orfs": [
     {
      "start": 14438,
      "end": 15334,
      "strand": -1,
      "locus_tag": "ctg14_17",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,438 - 15,334,\n (total: 897 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1069:putative ABC transporter permease protein (Score: 245; E-value: 1.5e-74)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_17 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00528.25 (Binding-protein-dependent transport system inner membrane component): [106:287](score: 65.2, e-value: 6.6e-18)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_17 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_17_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSRTQTEKIADAPDRTHRADGMSRGQNILRGVVLLVGALVFLFPFYYMVIGSLQAKPDPTIAGAFPNPANLTLDNYADINGRINLLQGLLNSGIFTGGVILCTVVFGVLVGYALAQLQWRGRGVTFALALLVQVVPFQLLMIPLYVMIARDYGLADNYLGMILPFAINSTAVIIFRQYFLQIPKELFDAARIDGAGELRILRRIALPLVRPALLTVVLLTFIGPWNEFLWPFLITKEASLQPLAVSLANYLSNVAATAANPFGAILAGACVLAGPAVLLFILFQRHFVSSNIGSGVKG\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCCGCACCCAGACCGAGAAGATCGCGGACGCCCCCGACCGCACCCACCGGGCGGACGGCATGAGCCGTGGCCAGAACATCCTCCGCGGCGTCGTGCTGCTGGTCGGCGCGCTGGTGTTCCTGTTCCCGTTCTACTACATGGTCATCGGATCGCTCCAGGCCAAACCGGACCCGACGATCGCCGGCGCGTTCCCCAACCCGGCGAACCTGACGCTGGACAACTACGCCGACATCAACGGCCGGATCAACCTGCTGCAGGGGCTGCTCAACTCGGGCATCTTCACCGGCGGCGTGATCCTGTGCACGGTCGTGTTCGGGGTTCTGGTCGGCTACGCCCTGGCGCAGCTGCAGTGGCGCGGCCGCGGCGTCACGTTCGCGCTGGCCCTGCTGGTGCAGGTGGTGCCGTTCCAGCTCCTGATGATCCCGCTCTACGTGATGATCGCCAGGGACTACGGCCTGGCCGACAACTACCTGGGCATGATCCTGCCGTTCGCCATCAACTCGACGGCGGTCATCATCTTCCGGCAGTACTTCCTGCAGATCCCCAAGGAGCTCTTCGATGCCGCCCGCATCGACGGCGCCGGAGAACTGCGGATCCTGCGCCGGATCGCGCTGCCGCTCGTGCGGCCGGCGCTGCTCACGGTGGTGCTGTTGACGTTCATCGGCCCGTGGAACGAGTTCCTCTGGCCGTTCCTGATCACCAAGGAGGCCTCGCTGCAACCGCTCGCGGTCTCCCTGGCGAACTACCTCAGCAACGTCGCGGCCACCGCGGCCAACCCCTTCGGAGCCATCCTGGCCGGCGCCTGCGTTCTGGCCGGCCCCGCTGTGCTCCTGTTCATCCTGTTCCAGCGTCACTTCGTCTCGAGCAATATCGGCTCGGGCGTGAAAGGTTAG",
      "translation": "MSRTQTEKIADAPDRTHRADGMSRGQNILRGVVLLVGALVFLFPFYYMVIGSLQAKPDPTIAGAFPNPANLTLDNYADINGRINLLQGLLNSGIFTGGVILCTVVFGVLVGYALAQLQWRGRGVTFALALLVQVVPFQLLMIPLYVMIARDYGLADNYLGMILPFAINSTAVIIFRQYFLQIPKELFDAARIDGAGELRILRRIALPLVRPALLTVVLLTFIGPWNEFLWPFLITKEASLQPLAVSLANYLSNVAATAANPFGAILAGACVLAGPAVLLFILFQRHFVSSNIGSGVKG",
      "product": ""
     },
     {
      "start": 15331,
      "end": 16290,
      "strand": -1,
      "locus_tag": "ctg14_18",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,331 - 16,290,\n (total: 960 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1067:putative ABC transporter permease protein (Score: 248.3; E-value: 1.6e-75)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_18 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00528.25 (Binding-protein-dependent transport system inner membrane component): [113:311](score: 58.1, e-value: 1e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_18 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_18_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSTLTPKRPLAGRPATPPGGGARPRRKRQWLGKNPFGLLLSAPYLIFVLAVFAYPLVFAFWMSFHDYFFAAPGAQVDRPFVGLANFQEVLGDPAVIRSFGNVGIFLLINVPLTVVLSLVLASALNKAVRFRTFLRVSYYVPYVTASVAVVGVWIFLFSGNGLVNQILGPLAPDPAWLINEQWAMPTIAIFVTWKGLGFFILLYLAALQNVSEELYEAAATDGAGKIRSFFSVTVPGVRPATVLVLLLSTVTGANLFTEPYLLTGGGGPNGASTSPVLIMYQRGIEQGSPDTAAAIGVILVIGVLILAFIQRKLAGGDES\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCACCCTCACCCCGAAACGACCCCTCGCCGGGAGGCCCGCAACGCCTCCCGGCGGGGGCGCCCGCCCGCGCCGCAAGCGCCAGTGGCTGGGCAAGAACCCGTTCGGGCTCCTGCTCAGCGCACCGTACCTGATCTTCGTCCTCGCGGTCTTCGCCTACCCCCTGGTGTTCGCGTTCTGGATGTCGTTCCACGACTACTTCTTCGCCGCCCCCGGCGCGCAGGTGGACCGGCCCTTCGTGGGGTTGGCCAACTTCCAGGAGGTGCTCGGCGATCCCGCCGTCATCCGGTCGTTCGGCAACGTGGGAATCTTCCTGCTGATCAATGTGCCGCTCACCGTGGTGCTCTCCCTGGTCCTGGCCAGCGCCCTGAACAAGGCGGTCAGGTTCCGCACCTTCCTGCGGGTGTCGTACTACGTGCCGTACGTCACCGCATCCGTCGCGGTCGTCGGCGTGTGGATCTTCCTGTTCAGCGGCAACGGACTGGTCAACCAGATCCTGGGCCCGCTGGCGCCCGACCCGGCCTGGCTGATCAACGAGCAGTGGGCAATGCCCACCATCGCCATCTTCGTCACCTGGAAGGGCCTGGGGTTCTTCATCCTGCTCTACCTCGCCGCGCTGCAGAACGTGTCGGAGGAACTGTACGAGGCCGCCGCGACGGATGGTGCGGGCAAGATCCGCAGCTTCTTCTCGGTGACGGTGCCCGGCGTGCGCCCCGCCACGGTGCTCGTGCTGCTGCTGTCCACCGTCACCGGCGCGAACCTCTTCACCGAGCCGTACCTGCTCACCGGCGGCGGCGGCCCGAACGGCGCCTCCACCTCTCCCGTGCTGATCATGTACCAGCGCGGCATCGAACAGGGCTCGCCGGACACGGCGGCCGCGATCGGAGTGATCCTCGTGATCGGTGTCCTCATCCTCGCGTTCATCCAGCGGAAGCTGGCCGGGGGTGACGAATCATGA",
      "translation": "MSTLTPKRPLAGRPATPPGGGARPRRKRQWLGKNPFGLLLSAPYLIFVLAVFAYPLVFAFWMSFHDYFFAAPGAQVDRPFVGLANFQEVLGDPAVIRSFGNVGIFLLINVPLTVVLSLVLASALNKAVRFRTFLRVSYYVPYVTASVAVVGVWIFLFSGNGLVNQILGPLAPDPAWLINEQWAMPTIAIFVTWKGLGFFILLYLAALQNVSEELYEAAATDGAGKIRSFFSVTVPGVRPATVLVLLLSTVTGANLFTEPYLLTGGGGPNGASTSPVLIMYQRGIEQGSPDTAAAIGVILVIGVLILAFIQRKLAGGDES",
      "product": ""
     },
     {
      "start": 16296,
      "end": 17630,
      "strand": -1,
      "locus_tag": "ctg14_19",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,296 - 17,630,\n (total: 1335 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1143:sugar-binding lipoprotein (Score: 235.6; E-value: 2.1e-71)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_19 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13416.9 (Bacterial extracellular solute-binding protein): [69:385](score: 121.3, e-value: 7.1e-35)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCACACCCGCACCACACCCACCGGCACCACCCGTCAGACCAGGCGCCGAAACGCGAGATTCCTCGCGGCCGCCGCCACCTCCGCCGCCATGATCGCCGCGCTGGGCGCCTGCTCCAGCGGAGGCGCCGCCTCCGGCGGCTCAGACTCCCGCGGTGACATCACCATCTGGTATTCCAACAACGAGACCGAGATCGCCTGGGGCAAGCAGATGGTCGAGGCCTGGAACGCCGATCACCCGGACGAGCAGGTCAAGGCCCAGGAGATCCCCGCCGGCAAGAGCAGCGAAGAGGTCATCGGCGCCGCCATCACGGCCGGCAACGCGCCCTGCCTGGTCTTCAACACCGCCCCCGTCGCGGTCCCGCAGTTCCAGAAGCAGGGCGGCCTGGTCGACCTCAGCAGCTTCGAGGACGGCGCGGCCTACATCGAGGAGCGCACCGGCGAGGCGTCCTCGCAGTACCAGGACGCCGACGGGAAGTACTACCAGATGCCCTGGAAGTCCAACCCCGTCATGATCTTCTACAACAAGGACATGTTCGCCGCGGCCGGGCTCGACCCGGAGAACCCGCAGCTGTCCACCTACGACGACTTCCTCGCCACCTCGCGTGCCCTCGTGGCCAGCGGTGCCGCCCCAAACGCCATCTACCCGGCCCCGACCAGCCAGTTCTTCCAGAGCTGGTTCGACTTCTACCCGCTGTACGCGGCCGAGACCGGCGGCACCCAGCTCGTCGCCGACGGCGAGGCCACGTTCAACGACGCCGACGGCGCCGCCGTGGCCGAGTTCTGGAAGACCCTCTACTCGGAGGGTCTGGCCGGCAAGGAGCAGTACCAGGGTGACTCGTTCGCCGACGGCCAGGCCGCCATGTCGATCGTGGGCCCGTGGGCGGTGTCCGTCTATAAGGACGCCGTGAACTGGGGCGCCGTCCCGGTTCCCACCAGTGCCGGCACCCCCGCCGACCAGACCTACACCTTCAGCGACGCCAAGAATGTGGGCATGTTCACGGCCTGCAAGAACCAGGCCACGGCCTGGGATGTGCTCAAGTTCGCCACCAGCGAGGAACAGGACGGCCAACTGCTCGAGCTGACCGGCCAGATGCCGCTGCGGGCCGACCTCACCACCGTGTACCCGGACTACTTCGCGGCCAACCCCGCCTACCAGCAGTTCGGTGACCAGGCGTCCCGCACGGTCGAGGTGCCCAGTGTGGCCAACTCGGTTGCCGTCTGGCAGGCCTTCCGTGACGCGTACACGAAGTCGGTGATCACCGGGGACGGCGACGTGGCCGGAGCCCTGGACGACGCCGCCACGAAGATCAACGACCTGATCACGCAGCCGTAG",
      "translation": "MHTRTTPTGTTRQTRRRNARFLAAAATSAAMIAALGACSSGGAASGGSDSRGDITIWYSNNETEIAWGKQMVEAWNADHPDEQVKAQEIPAGKSSEEVIGAAITAGNAPCLVFNTAPVAVPQFQKQGGLVDLSSFEDGAAYIEERTGEASSQYQDADGKYYQMPWKSNPVMIFYNKDMFAAAGLDPENPQLSTYDDFLATSRALVASGAAPNAIYPAPTSQFFQSWFDFYPLYAAETGGTQLVADGEATFNDADGAAVAEFWKTLYSEGLAGKEQYQGDSFADGQAAMSIVGPWAVSVYKDAVNWGAVPVPTSAGTPADQTYTFSDAKNVGMFTACKNQATAWDVLKFATSEEQDGQLLELTGQMPLRADLTTVYPDYFAANPAYQQFGDQASRTVEVPSVANSVAVWQAFRDAYTKSVITGDGDVAGALDDAATKINDLITQP",
      "product": ""
     },
     {
      "start": 17706,
      "end": 18776,
      "strand": -1,
      "locus_tag": "ctg14_20",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,706 - 18,776,\n (total: 1071 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1078:LacI family transcription regulator (Score: 304; E-value: 2.2e-92)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_20 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00356.24 (Bacterial regulatory proteins, lacI family): [21:67](score: 42.7, e-value: 3.8e-11)<br>\n \n  PF13377.9 (Periplasmic binding protein-like domain): [191:349](score: 117.2, e-value: 9.3e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_20 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00356.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF00356.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_20_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATTCCCACCCGGATTCCGGCACGAACGACGAGTCCGCGTCGAAGGATACGGGCAAGGTCACGATCGCCGACGTCGCCCGTCAGGCCGGGGTCAGCAAGGGCCTCGTGTCGTTCGCCCTCAATGACCGTCCTGGGGTGTCCGCCGAGACGCGCGCGCGCATCCTCTCGGTCGCCGGCCTGCTCGGCTGGACGCCGTCGCTCCGGGCCCGGTCGCTGTCCTCGCAGCGTTCCTTCGCCCTCGGCCTGGTCATCGCCAGGGACCCCGAGGTCCTCGGATCCGACCCCTTCTTCACGTCGTTCATCGCCGGGGTCGAGACCATCCTGGCGCCGGAGGGCCTGGCCCTGGTGCTCAGCGTCGTTCCCGACGAGAAGACCGAGCTGGCGACCTACCGCACCCTCGTGGCCGACGGCCGGGTCGACGGCGTCTTCCTCAGCGATCTCCGCCGCGACGACGCCCGCATCCCCTGCCTGACCGAACTCGCGCTGCCGACCGTGACCCTGGGCCGGCCGGACCAGCCGAGCCCGTTCCCCGCGGTGTCCATCGACGACACCCAGGGGGTCGCCGAGTCGGTGCGGCACCTGAGCACCCTCGGCCACCGACGCATCGCGCACGTCGCCGGCAGCCCCGCCATGCTGCACGGTCGTCGGCGACGGGATGCGTTCACCCGGGCCATGCAGGCCGCCGGACTCGGCCAGGGCCAGGTCGTCGAAACCGACTTCTCGATCGCGGCCGGCGCCGACGCCACCCGGCGTCTGCTGAGCCAGCCCGAACCCCCCACCGCCATCGTGTTCGCCAACGACCCGATGGCCATCGCCGGCATCGGCGTGGCCCAGGAACTGGGCGTGCGGGTTCCGGACGACCTGTCGATCACCGGCTTCGACGATATCGAGTTCGCCCGGTACGTCTACCCGGCGCTGACCACCGTCGGCGCCACCCCCATGGTCTGGGGCCGCGCCGCGGCGAGCACGCTGCTCGGCCTCATCCGGACCGGCAGCGCCGACGATGTCGAGCTTCCCGCCGCCCGCCTGATCGTGCGCGGCTCGGCATCCGCACCGCCGCCGTACTAG",
      "translation": "MDSHPDSGTNDESASKDTGKVTIADVARQAGVSKGLVSFALNDRPGVSAETRARILSVAGLLGWTPSLRARSLSSQRSFALGLVIARDPEVLGSDPFFTSFIAGVETILAPEGLALVLSVVPDEKTELATYRTLVADGRVDGVFLSDLRRDDARIPCLTELALPTVTLGRPDQPSPFPAVSIDDTQGVAESVRHLSTLGHRRIAHVAGSPAMLHGRRRRDAFTRAMQAAGLGQGQVVETDFSIAAGADATRRLLSQPEPPTAIVFANDPMAIAGIGVAQELGVRVPDDLSITGFDDIEFARYVYPALTTVGATPMVWGRAAASTLLGLIRTGSADDVELPAARLIVRGSASAPPPY",
      "product": ""
     },
     {
      "start": 18934,
      "end": 20400,
      "strand": 1,
      "locus_tag": "ctg14_21",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,934 - 20,400,\n (total: 1467 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_21 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06762.17 (Lipase maturation factor): [120:274](score: 195.0, e-value: 2.6e-57)<br>\n \n  PF06762.17 (Lipase maturation factor): [300:476](score: 200.8, e-value: 4.7e-59)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_21 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF06762.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051604' target='_blank'>GO:0051604</a>: protein maturation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_21_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACTGGTTCGGGACCGGCGACTATGGGATCGCCCGCGAGGTGCTGCAGCGCGGGATCGCCGCGATCTTCCTGATCGCGTTCGCCTCGGCGCTGGCCCAGTTCCCGGCGCTGCTGGGCGAGAACGGGCTGCTGCCGGTGCGCCGGTTCACCCAGGTGGTGAGCATGCGCCGGGCGCCCAGCCTGTTCCAGTGGCGGTACTCGGACCGATTGTTGCGCCTGGTGGCGTGGGGATGCATCGTCGTGGCCGCATCGGTACTCCTCGGCCTGCCCCAGGCCGGCCCGGCCTGGCTGCCGATGCTCGTGTTCCTGGTCCTGTTCGCGGCCTACCTGTCGGTCGTCAACGTCGGGCAGACCTTCTACGCCTTCGGCTGGGAGAGCCTGCTGGTCGAGGCCGGCTTCATCGTCGCGTTCCTCGGCTCGGACGCCGTGGCCACCCCGGTGCCGATCCTGCTGTTCCTGCGTTGGCTGGTGTTCCGGCTCGAGTTCGGCGCCGGCCTGATCAAGATCCGGGGCGGCCGCGAGTGGCGCGACCTCACCGCGCTGTATTACCACCACGAGACCCAGCCCATGCCCAACCCGGTGAGCTGGTTCGTGCACCACCTGCCGCGGTGGTTCCACCGCGGCGAGGTGCTGGGCAACCATGCCGTGCAGCTGGGGCTGCCGTTCCTGCTCTTCGCACCGCAGCCCGTGGCGTCGATCGCCGCCGGAATCATCGTGCTCAGCCAGCTCTGGCTGGTCCTCACGGGCAACTTCGCCTGGCTGAACTGGATCACCATCGTGCTGGCCGTCTCCGCCATCGACGATGCGTCTTTCCGCTGGCTGGGCGGATGGGTCGTGCCGGCCCTCCGCGAACCCGCACCGCCGGCCGCAGCGGGGGAGCAGCCGCCGTGGTTCGTCGTGGTGGTGCTGGCGGTGACCGCCCTGCTGGTCGCGCTGAGTTATTGGCCGGCCCGCAACCTGCTCCGCCGCCGGCAACTCATGAACGCGAGCTTCAACCCGTTCCACCTGGTGAACGCCTATGGGGCCTTCGGCACGGTCACCAAGGAACGCTTCGAGGTGGTGGTCGAGGGCAGCGTCGCGGAGGATCCGCGCTCCGAGGAGGGCTGGCTGGCCTACGAGTTCCGCGGCAAGCCGGGGAACGTCAGGCGTCTCCCCGGCCAGTTCGCCCCGTACCACCTGCGGCTGGACTGGCTGATGTGGTTCCTGGCCCTGGGTGCCCGCGACACCCGCTGGTTCGAGGTCTTCCTGGCCCGGCTGCTACAGGGCGACCGGGCCACCCTGCGCCTGCTGGCCCGCAATCCGTTCCCGGATGGGCCGCCGCGCTTCGTGCGGGCGCGGGTGTTCCGCTACCGGTTCAGCACCCCGGCCGAACGCCGTGCCGAGCAGGTCTGGTGGGTGCGCACGGAGGCCGGCGTGCTGGTACCGCCGGTGACCCTGCCGCCGGTCCCACCCCCGGAGCCGTAG",
      "translation": "MDWFGTGDYGIAREVLQRGIAAIFLIAFASALAQFPALLGENGLLPVRRFTQVVSMRRAPSLFQWRYSDRLLRLVAWGCIVVAASVLLGLPQAGPAWLPMLVFLVLFAAYLSVVNVGQTFYAFGWESLLVEAGFIVAFLGSDAVATPVPILLFLRWLVFRLEFGAGLIKIRGGREWRDLTALYYHHETQPMPNPVSWFVHHLPRWFHRGEVLGNHAVQLGLPFLLFAPQPVASIAAGIIVLSQLWLVLTGNFAWLNWITIVLAVSAIDDASFRWLGGWVVPALREPAPPAAAGEQPPWFVVVVLAVTALLVALSYWPARNLLRRRQLMNASFNPFHLVNAYGAFGTVTKERFEVVVEGSVAEDPRSEEGWLAYEFRGKPGNVRRLPGQFAPYHLRLDWLMWFLALGARDTRWFEVFLARLLQGDRATLRLLARNPFPDGPPRFVRARVFRYRFSTPAERRAEQVWWVRTEAGVLVPPVTLPPVPPPEP",
      "product": ""
     },
     {
      "start": 20425,
      "end": 20793,
      "strand": -1,
      "locus_tag": "ctg14_22",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,425 - 20,793,\n (total: 369 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_22 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01479.28 (S4 domain): [6:52](score: 45.6, e-value: 4.6e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_22 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01479.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_22\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAACTGCAGAGCGCTCGCGTCGACAGCTGGGCCTGGGCGGTGCGGATGTACAAGACCCGCTCCCAGGCGACGGCGGCCTGCCGCGCCGGTCATGTGCGGGTCAACGGCGAGCGGGCCAAGTCGGCCCAGTCGGTGAAACCGGGCGACGAGGTGCGCATCCGCTCCAACGGATTCGACCGGGTGCTCGTGGTGTCCCGGATCATCGTCAAGCGCGTGGGGCCGAGCGTGGCCGCGGAGTGCTTCGTGGACAACACCCCACCACCGCCGCCCCGCGAGGAGGTGGCCCTGGTGCCGATGCGCGACCGCGGCGCCGGCCGGCCCACCAAGCGCGAGCGGCGGGACATCGAGGAACTGCGCGGGTACTAA",
      "translation": "MELQSARVDSWAWAVRMYKTRSQATAACRAGHVRVNGERAKSAQSVKPGDEVRIRSNGFDRVLVVSRIIVKRVGPSVAAECFVDNTPPPPPREEVALVPMRDRGAGRPTKRERRDIEELRGY",
      "product": ""
     },
     {
      "start": 20838,
      "end": 21743,
      "strand": -1,
      "locus_tag": "ctg14_23",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,838 - 21,743,\n (total: 906 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) ubiA<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_23 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01040.21 (UbiA prenyltransferase family): [32:283](score: 119.1, e-value: 2.1e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_23 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01040.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016765' target='_blank'>GO:0016765</a>: transferase activity, transferring alkyl or aryl (other than methyl) groups<br>\n  \n   PF01040.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_23\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_23_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGAATCGGCACACCGGCCGGCCACCGGCCTCGGGCACACCGTGCGTCAGGTCGTGCTGTCGTCGCGCCCGCTCAGCTGGATCAACACGGCGTTCCCCTTCGCGGCCGCGTACATCGTCAGCACCGGTCGCGTCGACCTGCTGCTCGTGGTGGGCACCCTGTTCTTCCTCATTCCGTACAACCTGCTGATGTACGGCATCAACGACGTCTTCGACTACGAGTCCGACCTGCGCAACCCCCGGAAGGGCGGTGTCGAGGGCGCCATGCTCGACCGGAGCCTGCACCGCACGGTGCTGGTGTCCGGCGTGGCGACGGCGCTGCCGGTGCTGCTCGCGATGCTCCTGCTCGCCGGCGCGAACCCGTGGTCGTGGGTGGTGCTCGCGCTCAGCCTGTTCGCGGTGGTGGCCTACTCCGCCCCTGGCCTCCGCTTCAAGGAACGCCCGGTGCTGGACTCGGTGACCTCCAGCATCCACTTCGTCAGCCCGGCCGTGTACGGGCTGGCCGTGGCCGGCGCCCTGATCACGCCCGACCTCGTGGCCCTGCTCACGGCGTTCTTCTTCTGGGGCATCGCCAGCCACGCGTTCGGCGCCGTGCAGGATGTCGAACCCGACCGTCAGGGCGGCATCAGTTCCATCGCCACGGCGTTCGGCGCCGCCCAGACGGTGCGCCTGGCGATCGTGTTCTGGGTGCTGGCGGGCCTGTTGATGCTCGTGACGGACTGGCCCGGACCGCTCGCGGCGGTGCTCGTGATCCCCTATGTGCTCGCCGCGTGGCCGTACCGGTCGATCAGCGACGCCGATTCCGAGCTCGCCAACAACGGCTGGAAGCGGTTCCTCAGGCTGAACTTCTTCACCGGCTTCCTGGTGACCATGCTGCTGATCGTCTGGGTCGTGGTGCGTTGA",
      "translation": "MTESAHRPATGLGHTVRQVVLSSRPLSWINTAFPFAAAYIVSTGRVDLLLVVGTLFFLIPYNLLMYGINDVFDYESDLRNPRKGGVEGAMLDRSLHRTVLVSGVATALPVLLAMLLLAGANPWSWVVLALSLFAVVAYSAPGLRFKERPVLDSVTSSIHFVSPAVYGLAVAGALITPDLVALLTAFFFWGIASHAFGAVQDVEPDRQGGISSIATAFGAAQTVRLAIVFWVLAGLLMLVTDWPGPLAAVLVIPYVLAAWPYRSISDADSELANNGWKRFLRLNFFTGFLVTMLLIVWVVVR",
      "product": ""
     },
     {
      "start": 21740,
      "end": 22093,
      "strand": -1,
      "locus_tag": "ctg14_24",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,740 - 22,093,\n (total: 354 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_24 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF18916.3 (Lycopene cyclase): [1:89](score: 31.7, e-value: 1.8e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_24 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF18916.3: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016872' target='_blank'>GO:0016872</a>: intramolecular lyase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_24\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_24_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACCTACACCCTGCTCAACGTCGTGTTCCTCGGCCTCGCCGTGGTCGTGGCCGTCGTGGCGTACCTCCGCCGGCCGGGATACCGCCGGATGCTGCCGGCGGCGGGACTCGCCCTGGTGGCCGTCCTGCTGCTGACCGCGGTGTTCGATAACATCATGATCGGAGTGGGACTGGTCGACTACGACCCGGCCCTGATCTCCGGGTTCTTCGTGGGGATCGCTCCCGTGGAGGACTTCGCCTACCCCGTGGCGGCGGCACTCCTGCTGCCCGCGGTGTGGACGCTGCTCGGCGGTGACGCCGGGCGGGGCCCGCTGGGCCGGAGTTCGTCACGATCGGAAGGGCACCAGCAATGA",
      "translation": "MTYTLLNVVFLGLAVVVAVVAYLRRPGYRRMLPAAGLALVAVLLLTAVFDNIMIGVGLVDYDPALISGFFVGIAPVEDFAYPVAAALLLPAVWTLLGGDAGRGPLGRSSSRSEGHQQ",
      "product": ""
     },
     {
      "start": 22090,
      "end": 22428,
      "strand": -1,
      "locus_tag": "ctg14_25",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,090 - 22,428,\n (total: 339 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_25\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_25_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACCGGCCCGATGCCGGGTGTGCTGTACCTGCTGGCCCTGCTCGTCTCCCTGACCGGCATGGTCGTGCTCGACCGACGTTTCGGCCTGTTCTTCTGGCGTGCGCCCGTCGTGGCGGCGGCGGTACTGGCGATCGGGGTGGCCTTCTTCCTCGCCTGGGACCTGGTGGGGATCGGCGCCGGTATCTTCTACCGGGGCGAGACCGACTTCATGACCGGCGTGCAGCTGGCCCCCGAGCTGCCCGTCGAGGAGTTCTTCTTCCTCACCTTCCTCTGCTACCTGTTCATGAACGCCCTGCAGGGCGTGCGGATGCTGCTGGCTGCGAGGCGCGCCTCGTGA",
      "translation": "MTGPMPGVLYLLALLVSLTGMVVLDRRFGLFFWRAPVVAAAVLAIGVAFFLAWDLVGIGAGIFYRGETDFMTGVQLAPELPVEEFFFLTFLCYLFMNALQGVRMLLAARRAS",
      "product": ""
     },
     {
      "start": 22425,
      "end": 24044,
      "strand": -1,
      "locus_tag": "ctg14_26",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_26</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_26</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,425 - 24,044,\n (total: 1620 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) DAO<br>\n \n  biosynthetic-additional (smcogs) SMCOG1222:dehydrogenase (Score: 462.3; E-value: 3.9e-140)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_26 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01593.27 (Flavin containing amine oxidoreductase): [16:509](score: 91.9, e-value: 5.9e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_26 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01593.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_26\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_26_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCCGCCCGACCGCACGCCTCCGCACCGTCGTGATCGGCGGCGGGATCGCCGGGCTGGCCAGCGCGGCCCTGCTCGCCAAGGAGGGCCACGAGGTCACGCTGCTCGAGGCTCACGACACCCTCGGCGGCCGGGCCGGCTTCTGGGAGGCCGACGGCTTCAGGTTCGAAACCGGGCCGTCCTGGTACCTGATGCCCGAGGTGTTCGAGCACTTCTACCGGCTCATGGGCACGAGCGCGGCCGAACAGCTCGAGCTCACCCGGCTCGACCCGGGCTACCGGGTCTACTTCGAAGCCGACCTCGAGCCCGTGGATGTGCGCGCAGACCGCGCCGACAACATCCGCCTGTTCGAGAGCCTGGAGCCCGGTGCCGGCGCCCGGCTCGAGGACTACCTCGCCTCGGCGCGGGAGACCTACGACATGGCCGTGGACAGGTTCCTGTACACCAGCTTCGCCTCGTTCAAGCCCTTGCTGGTGCGCGACGTGCTGAGCCGGATGGGCCGGCTCGGCCGCCTGCTGCTCCAGCCGCTGGACCGGTTCGTCGCCGGCTACTTCCGCGACCCCCGGATCCGGCAGATCCTGGGCTACCCCGCCGTCTTCCTCGGTTCCTCCCCCGACCGCACCCCGTCGATGTACCACCTGATGAGCCACCTCGACCTGGCGGACGGCGTGCTCTACCCGCAGGGCGGCTTCACCCGGCTGATCGACAGCATCGCCGACCTCGCCCGCGCCGAGGGCGTCACCGTCGAGACCGGCGCCCGGGTGCAGGCGATCCGCTCCGGCGCAGCGCCGACCGGACGGGGCGCCAAGGCCGCCGTCGAGGGCGTGACGTACACGAACGCGTCCGGCGTGACGGTGTCCCTGGACGCCGACATCGTCGTCTCGGCGGCCGACCTGCACCACACCGAGACCGAGCTCGTGGAGCCCGCCAAGCAGACCTACCCCGAGCGCTGGTGGCAGAAGCGCACCTCGGGCCCCGGCGCCGTGCTGGTTCTGCTGGGGGTGACGGGCGAGCTGCCCGCGCTGACCCACCACACCCTGTTCTTCACGCAGGACTGGGCCGACAACTTCGACCGGATCTTCGGCGCCGAGACCTCGGTGCCCAACCCGGCGTCGTTCTATGCCTGCATGCCCAGCGCCACCGACCCCGGCGTCGCCCCGGACGGATCGAGCAACCTGTTCCTGCTCATCCCCGTGCCCGCCGACACCGGCCTCGGTCACGGCGGGGTGAACGGAGCCGGCTCGGCCACCGTCGAGGGCATCGCCGACGCCGCGATCGGCCAACTCGCCGAGTGGGCCGGCATCCCCGACCTGGCCGAGCGCATCGTGGTGCGCCGCACGATCGGCCCGGCCGACTTCGCCGACGACCTCAACTCCTGGAAGGGCGGGGCGTTGGGCCCGGCGCACACGCTCAAGCAGAGCGCCTTCTTCCGTGGCACCAATGTCTCCAAGCACATCGAGGGTCTCTACTACGCCGGCGGCAGCACCATTCCGGGTATCGGCCTGCCGATGTGCCTGATCAGCGCCGAGATCCTGCTCAAGCGCCTGCGCGGCGACGTGAGCACCGGGCCCCTGCCGGAGCCGTTGCCGAGCGGGCCGGCCGGCGCCAGGCTGCGGTGA",
      "translation": "MSRPTARLRTVVIGGGIAGLASAALLAKEGHEVTLLEAHDTLGGRAGFWEADGFRFETGPSWYLMPEVFEHFYRLMGTSAAEQLELTRLDPGYRVYFEADLEPVDVRADRADNIRLFESLEPGAGARLEDYLASARETYDMAVDRFLYTSFASFKPLLVRDVLSRMGRLGRLLLQPLDRFVAGYFRDPRIRQILGYPAVFLGSSPDRTPSMYHLMSHLDLADGVLYPQGGFTRLIDSIADLARAEGVTVETGARVQAIRSGAAPTGRGAKAAVEGVTYTNASGVTVSLDADIVVSAADLHHTETELVEPAKQTYPERWWQKRTSGPGAVLVLLGVTGELPALTHHTLFFTQDWADNFDRIFGAETSVPNPASFYACMPSATDPGVAPDGSSNLFLLIPVPADTGLGHGGVNGAGSATVEGIADAAIGQLAEWAGIPDLAERIVVRRTIGPADFADDLNSWKGGALGPAHTLKQSAFFRGTNVSKHIEGLYYAGGSTIPGIGLPMCLISAEILLKRLRGDVSTGPLPEPLPSGPAGARLR",
      "product": ""
     },
     {
      "start": 24041,
      "end": 24949,
      "strand": -1,
      "locus_tag": "ctg14_27",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_27</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_27</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,041 - 24,949,\n (total: 909 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_27 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [33:281](score: 113.5, e-value: 1.3e-32)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_27 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_27\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_27_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCCGCGACACCACGGGGCCGCGCACCAACGCCCTGCCCACCACTCTGGGCACCTACAACGCCGCCGCCCTGGCCAGTTCCGCCACGGTGATCGGACACTACTCGACGTCGTTCGGGCTCGCCGCCCGCCTCCTCGCGCCCGGCGTGCGGGAGGACGTGCGCACCATCTACGCTCTCGTGCGGATCGCCGACGAGATCGTCGACGGCGCCGCCGCCGAGGCCGGCATCGACCTGGCCGGCCAGCGCGAACTGCTCGACGACCTCGAGCAGGAGACCGAGCGCGCCCTGGCCCGGGGCTTCAGCACCAACCTGGTGGTGCACGCCTTCGCCCTCACCGCCCGCCGGGTGGGGATCGAGCCGGCCCTCACGCGCCCGTTCTTCGCATCGATGCGCCGCGACCTCGACCCGGCACCGTTCACGGCCGCGAGCGTCGCCGAGTACATCTACGGCTCGGCGGAGGTCGTCGGGCTGATGTGCCTGCAGAGCTTCCTGCAGGACTTCCCGCGCAGCCCCGCTGAGCGGGCCGAGCTGGTCCACGGCGCCCGCAGCCTCGGCGCGGCGTTCCAGAAGGTCAACTTCCTCCGCGACCTGGCCGCCGACCGCGACGCGCTCGGCCGCAACTACTTCCCCGGGATCGACCTGGCCCGGCTCACCGACCCGCAGAAGGACCTCCTGCTCGACGACATGGACGCCGATCTCGAGGCCGCCGAGCGGGTCCTGCCGCTGCTGCCGACGGGGAGCCGGCGCGCCGTCACGGCCGCCCACCACCTGTTCGCCCGGCTGTCTGCGAGACTGCGGGAGACCCCCGCGCACGAATTGATGAGCACCCGCGTGCGGGTGCCGGATCCGGAGAAACTGATGATCGCCCTGTCGTCCTCGCTCGGCCCGCAGGCATGGCGCCGATGA",
      "translation": "MSRDTTGPRTNALPTTLGTYNAAALASSATVIGHYSTSFGLAARLLAPGVREDVRTIYALVRIADEIVDGAAAEAGIDLAGQRELLDDLEQETERALARGFSTNLVVHAFALTARRVGIEPALTRPFFASMRRDLDPAPFTAASVAEYIYGSAEVVGLMCLQSFLQDFPRSPAERAELVHGARSLGAAFQKVNFLRDLAADRDALGRNYFPGIDLARLTDPQKDLLLDDMDADLEAAERVLPLLPTGSRRAVTAAHHLFARLSARLRETPAHELMSTRVRVPDPEKLMIALSSSLGPQAWRR",
      "product": ""
     },
     {
      "start": 24946,
      "end": 25992,
      "strand": -1,
      "locus_tag": "ctg14_28",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_28</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_28</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,946 - 25,992,\n (total: 1047 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1182:Polyprenyl synthetase (Score: 224.9; E-value: 2e-68)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_28 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00348.20 (Polyprenyl synthetase): [39:271](score: 165.8, e-value: 1.1e-48)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_28 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00348.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_28\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_28_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCATGAGATCGCGACGCTGGGCGTCGAGACCGAACTGCACCGCTTCTTCGCCGCCGCGAGGCTGCGTGCCAGCGACTACGGCGAGCACTACGTCGCGCTCTGGGACTCCCTCGACCAGGCCAGCCGCGGCGGCAAACGCGTGCGCCCGGCGCTGGTGCTGGCCGCCTACGACGGCTTCGGCGGCACCGACCACACCCTGTCCACGCCGGTCGCGGTGAGCTTCGAGCTGCTGCACACGGCGTTCCTCATCCACGACGACGTCATCGACCGCGACCTCTCCCGCCGGGGAATGGCCAACATCGCCGGCCGGTTCACCGAACGCGCCATCGCGCACGGAGCGGGCACCGGCCAGGCGGAAGCCTGGGCCGCGACCGCCGCCATCCTGGCCGGCGACCTGGCCCTGAGCGAGGCCCACCGCGCCCTGGCCCTGCTGCCCGTGGAGACCACCATGCGGGCGCGCCTGCTCGACCTGCTCGACCGCGCGGTGTTCGTGTCGGCTGCGGGCGAGCTGGCGGATGTGACCAACACGGTCAGCCGGGTGCCGCTCACGATCGAGCAGGTCATCGCGACCCTCGAGCACAAGACGGCCATCTACTCGTTCGAGGCCCCCCTGCAGGCCGGCGCCGTCCTGGCCGGGGCGCCGGAGGAGGCCATCGACGCCCTGGGCCGGTTCGGCCGCCTCATCGGCGTGGCCTTCCAACTCACCGACGACCTGCTCGGCGTGTTCGGCGACCCGGCCACCACGGGCAAGAGCACGCTCGCCGACCTGCGCGAGGGCAAGCAGACCGCCCTCATCGCGCACGCCGGCGCCACCGACCGGTGGCCGATGATCGCGCCGTTCCTGGGCAAGGACGATCTGACCGAACCGGAGGCCGAGTCCGTGCGCACGCACCTGCGCGAGTGCGGAGCCCTTGACACCGCGGATGCGCTCGCCCGCGAATACGCCGGCCGCGCCGTCGAGGCCCTCGCCGTGCCGCTCATGCCCGAGGACCTGCGCACCACCCTGACCCAGCTGGCGCGCAGCGCCGTGACCCGCCGCAAATGA",
      "translation": "MHEIATLGVETELHRFFAAARLRASDYGEHYVALWDSLDQASRGGKRVRPALVLAAYDGFGGTDHTLSTPVAVSFELLHTAFLIHDDVIDRDLSRRGMANIAGRFTERAIAHGAGTGQAEAWAATAAILAGDLALSEAHRALALLPVETTMRARLLDLLDRAVFVSAAGELADVTNTVSRVPLTIEQVIATLEHKTAIYSFEAPLQAGAVLAGAPEEAIDALGRFGRLIGVAFQLTDDLLGVFGDPATTGKSTLADLREGKQTALIAHAGATDRWPMIAPFLGKDDLTEPEAESVRTHLRECGALDTADALAREYAGRAVEALAVPLMPEDLRTTLTQLARSAVTRRK",
      "product": ""
     },
     {
      "start": 25985,
      "end": 26515,
      "strand": -1,
      "locus_tag": "ctg14_29",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_29</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_29</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,985 - 26,515,\n (total: 531 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_29 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00293.31 (NUDIX domain): [32:149](score: 65.8, e-value: 4.2e-18)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_29\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_29_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACCGGGTGGAAGATTGGGTCGTGCTGCTCGATGAGGACGGACTCGAGATCGGCACCGCCCCCAAGAGCAGCGTGCACGGAGCCGACACCTCGCTGCACCTGGCCTTCTCCTGCTACGTCTTCAACGATCGCGGCGAGGTCCTGCTGACCCGCAGGGCCCTGGGGAAGAAGACCTGGCCCGGCGTCTGGACGAACTCGTTCTGCGGCCACCCTGCCCCCGCCGAGCCCCTCCTGGATGCCGTGCACCGCCGCGCCGAGTTCGAGCTGGGCCTCCGCATCGACGACATCGAGCTTGCCCTCCCCCTGTTCCGGTACCGCGCCACCGACAGCAGCGGCATCGTCGAGAACGAGGTCTGCCCGGTCTACCTGGCCCGCGCAGTGGGCGACCCTGAAGCCAATCCCGACGAGGTGATGGAGTACACCTGGACCGACCCTGAGGTGATGCGGCGTTCCGTCCTGGCCAGCCCCTTTGCCTTCAGCCCGTGGATGGTCCTGCAGATGCGCGAACTGGAGACCTTCGGTGCATGA",
      "translation": "MDRVEDWVVLLDEDGLEIGTAPKSSVHGADTSLHLAFSCYVFNDRGEVLLTRRALGKKTWPGVWTNSFCGHPAPAEPLLDAVHRRAEFELGLRIDDIELALPLFRYRATDSSGIVENEVCPVYLARAVGDPEANPDEVMEYTWTDPEVMRRSVLASPFAFSPWMVLQMRELETFGA",
      "product": ""
     },
     {
      "start": 26529,
      "end": 27269,
      "strand": 1,
      "locus_tag": "ctg14_30",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_30</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_30</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,529 - 27,269,\n (total: 741 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_30 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01047.25 (MarR family): [108:149](score: 32.4, e-value: 6.9e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_30 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01047.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity<br>\n  \n   PF01047.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_30\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGTGCATCACTGGGCTCCCTCTCGTGCAGCCAAGATACCTGAAAAAGTACCTAACCGAGTTAGCGATATTCGAGGCTAGCATGGTGGCTATGCCCGCAGACGCCCAACCTGCCGGGGACGTGGAGGCCGGCCGCTCAGGCGGCTTCTGGTACCCGGTTTCCGGCGGTGCTCCTTTGAGCGCCGTTGACGTCCTGCGCGCCGTGCGCCGCTTCCGTGCTGCCGATCTGGCCATGCGCAATCGGGTCCGCTCGGGCATGGACATGCACCACACCGACCTCGTCGCGGTCCGGCACCTGATCGCGGCGGAGGAGCGGGGCGAGTCGGTCGGGCCCACCGACCTGAGCAGGTACCTCGGCATCTCCTCCGCTGCGACGGCCAAACTGCTCACCCGGTTGGAGTCGGCCGGCCGGCTCCGCCGCGAACCGCATCCGAGTGACCGGCGGGCGCAGGTGCTGCACGCCACCGGCGCCGCCCACGACGAGGTGCGCCTGGCCCTCGGGGCGGCGCACCAGCGGATGCTCGCCGCCGCCGAGAAGCTGAGCGCGTCGGAGCAGCTCGCGGTGGTGAGGTTCCTCGACGAGCTCAGCGGAGCCATGGACGAACCGGTCGAGCCGGCCGAGCCGACCGAGCAGCCCGGGTCGCGCGAGCCGACGGCCGACGGCGGGTCGGGTGGGCAGGCACAGCCCGGCCCCGTCGCACCCGGGACCTCCGGCCCGGCCGCGCAGCAGGGGCGACCCTGA",
      "translation": "MCITGLPLVQPRYLKKYLTELAIFEASMVAMPADAQPAGDVEAGRSGGFWYPVSGGAPLSAVDVLRAVRRFRAADLAMRNRVRSGMDMHHTDLVAVRHLIAAEERGESVGPTDLSRYLGISSAATAKLLTRLESAGRLRREPHPSDRRAQVLHATGAAHDEVRLALGAAHQRMLAAAEKLSASEQLAVVRFLDELSGAMDEPVEPAEPTEQPGSREPTADGGSGGQAQPGPVAPGTSGPAAQQGRP",
      "product": ""
     },
     {
      "start": 27292,
      "end": 27819,
      "strand": 1,
      "locus_tag": "ctg14_31",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_31</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_31</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 27,292 - 27,819,\n (total: 528 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_31 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00156.30 (Phosphoribosyl transferase domain): [39:153](score: 54.0, e-value: 1.3e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_31\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_31_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGATCGTTCCCGCAGCCCAGCACGTGCACACCCTTCTCGCCTCCTACCCCGACTTCCCGCTTCCCGGCATCCTGTTCCGAGACCTCAATCCGGTCTTCGCGGATGCGGTGGCGTTCCGGTCTATCATCGACGAACTGGCCGAGCGCTACCGGGGCTCCTTCGACGCCGTGGCCGGCATCGAAGCGCGCGGCTTCCTGCTCGCGGCCGGCATCGGGTATGCCGCCCAGTGCGCCGTGCTGGCGGTGCGGAAGGGCGGCAAGCTGCCGGGTACCGTGCTGACCGAGGAATACGACCTCGAGTACGGCTCGGCCCGGCTCGAGCTGGAGGTCGGGCAGTTGCCGGCCGGCTCCCGTGTGCTGATCGTGGACGACGTGCTCGCCACCGGCGGTACCGTCGCCGCCACCGCACGCCTGATCGAGCGGGCCGGGTACCTCACGGTCGGGGTGGGCGTGGTGCTCGAGCTGGCCGAACTCGACGGCCGCGGCCGCATCGGCAACGTGCCGGTGCACACCATCGTGTCGGTCTAG",
      "translation": "MIVPAAQHVHTLLASYPDFPLPGILFRDLNPVFADAVAFRSIIDELAERYRGSFDAVAGIEARGFLLAAGIGYAAQCAVLAVRKGGKLPGTVLTEEYDLEYGSARLELEVGQLPAGSRVLIVDDVLATGGTVAATARLIERAGYLTVGVGVVLELAELDGRGRIGNVPVHTIVSV",
      "product": ""
     },
     {
      "start": 27949,
      "end": 28662,
      "strand": -1,
      "locus_tag": "ctg14_32",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_32</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_32</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 27,949 - 28,662,\n (total: 714 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_32 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01791.12 (DeoC/LacD family aldolase): [17:216](score: 65.0, e-value: 8.3e-18)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_32 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01791.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016829' target='_blank'>GO:0016829</a>: lyase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_32\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_32_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCTCTTCCTCCTCCGCCAGCACCCTCGACGCGGCTGGTCTGGCCCGGTACATCGACCACACCCTGCTCAAGCCCGAAGCCACCCAGGCCGACGTCGCCGCCCTCATCGCCGAGGCCGTCGAGCTGGGCGTCTACTCGGTGTGCGTGTCACCGTCGATGCTGCCCCTGACCCTGCCCGCGGATGCCGACCTCAAGGTTGCCGTGGTCTGCGGGTTCCCGAGCGGGAAGCACGCGTCGGCGATCAAGGCCGCCGAGGCCGCACTGGCCGTGGCCCAGGGCACCGACGAGGTGGACATGGTGATCGACATCGGTGCCGCCAAGGCCGGCCGGTTCGACCTGGTCGAGGCCGACATCAGCGCCGTGCGCGCCGAGATCCCGGCCCCCCTGGTGCTCAAGGTCATCATCGAGTCGGCCGCCCTCACCGACGACGAGATCGTCGGCGCCTGCCGTGCGGCCGTTGCCGCCGGTGCCGACTTCGTCAAGACCTCCACCGGTTTCCACCCCACCGGCGGCGCCACCGTGCACGCCGTGCGCCTGATGCGCCAGACCGTGGGCGACGCTGTCGGCGTCAAGGCCTCCGGCGGGGTGCGCAGCCACGCGGACGCGCTGGCCATGATCGAGGCCGGCGCCACCCGCCTCGGCGTCTCCGGCAGCACGGCCGTGCTCTCCGGCGCCGTGGTCGAAGCCCCGGCCAACCCCGCCGCGTACTGA",
      "translation": "MTSSSSASTLDAAGLARYIDHTLLKPEATQADVAALIAEAVELGVYSVCVSPSMLPLTLPADADLKVAVVCGFPSGKHASAIKAAEAALAVAQGTDEVDMVIDIGAAKAGRFDLVEADISAVRAEIPAPLVLKVIIESAALTDDEIVGACRAAVAAGADFVKTSTGFHPTGGATVHAVRLMRQTVGDAVGVKASGGVRSHADALAMIEAGATRLGVSGSTAVLSGAVVEAPANPAAY",
      "product": ""
     },
     {
      "start": 28762,
      "end": 29226,
      "strand": 1,
      "locus_tag": "ctg14_33",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_33</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_33</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,762 - 29,226,\n (total: 465 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_33 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00293.31 (NUDIX domain): [27:138](score: 53.5, e-value: 2.5e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_33\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGGCAGCGTGAGTGTGAACAGCGGGGACGCCTGGGTGTACGGCCCGGACGGTTCCCGGTTCTGGGGACGCTACGGTGCGGCCGGCTTGCTCGTGCACCACGCAGAGCGCGGGGTGCTGCTCCAGCACCGGGCCGCCTGGAGCCACCACGGTGACACCTGGGGCGTGCCGGGCGGTGCGAGGCACGAGAACGAGAGCGCGCTGGATGCCGCGATCCGCGAGGCCGGCGAAGAGGCCGGGGTGCCCGCACGGCTGCTCCGGTTCAGCTTCAGCTCGGTGGTCGACCTGGGGTTCTGGTCGTACACGACCGTCGTGGTGGAGGCCGTGGAGGCCTTCGAGGCGGTGATCAGCGACTCCGAGAGCATTGCGTTGCGCTGGGTGGCGCCGGCCGAGGTCGACCTGTTGCCGCTCCATCCGGGCTTCGCCGCCAGCTGGCCCGCGCTCAGGGCCCGTCTGCCCTGA",
      "translation": "MSGSVSVNSGDAWVYGPDGSRFWGRYGAAGLLVHHAERGVLLQHRAAWSHHGDTWGVPGGARHENESALDAAIREAGEEAGVPARLLRFSFSSVVDLGFWSYTTVVVEAVEAFEAVISDSESIALRWVAPAEVDLLPLHPGFAASWPALRARLP",
      "product": ""
     },
     {
      "start": 29207,
      "end": 30073,
      "strand": -1,
      "locus_tag": "ctg14_34",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_34</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_34</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,207 - 30,073,\n (total: 867 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_34 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06966.15 (Protein of unknown function (DUF1295)): [23:259](score: 160.3, e-value: 5.8e-47)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_34\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_34_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGGGCCCGCCGCATCCGCCCTGCTGATCTGCCTGGTGATCGTGGGCCTCGCCTCGGCCACCTCGTGGCTGCTCTCGCTGGCGACCAGGGACTACTCCTGGGTGGACCGGGCCTGGTCGATCCTGCCGGCCGTCTACCTCTGGGTCTTCGCCGTCGCGGCGGACCCGCCGGATGCGCGCCTGCTCGTGCTGGCGGTGCTGGGCACCCTGTGGGGCATCCGGTTGACGCTGAACTTCGCGCGCAAGGGCGGCTACCGGCCCGGCGGCGAGGACTACCGCTGGGCCGAACTGCGCCGGCGGATGTCGCCGGGGCGCTTCGCCGTGGTCAACCTGGTGTTCATCTCGGTCGCCCAGAACGTGCTCCTGCTGCTGCTCGCCCTGCCGGCCTGGATCGTGCTGCAGCACCCCGGCCGGTTCGGGCTGCCCGAACTGGCTTTAACGGCACTGTTCCTGGCCCTGCTGGCAGGCGAGGGCATCGCGGACCAGCAACAGTGGCGGTTCCAGCAGGAGCGGCGCACGATCCGCGCCCGGGCAGGGGCGGATCCGGGCTTCCTCAGGAGCGGGCTGTTCCGCTTCTCCCGGCACCCGAACTACTTCTTCGAGATCGCCCAGTGGTGGACCGTCGCGCTGGTCGGCGCCGTCGCGGCCGGCACCCCCTGGCAGTCGGGGTCGCTCGGCGCCGTGCTGCTCACCCTGCTCTTCGTCGGCTCGATCGCCCTCACCGAGAGCATCTCGATGGGGCGGCATCCCGGCTATGCCGCGTACCGGCGCGAGGTATGGCCGCTGGTGCCGTGGTTCCCCAAACGATCGCCGGGCCTGGCGGCCCGGGGCGCCGAGGACCCGTTCAGGGCAGACGGGCCCTGA",
      "translation": "MSGPAASALLICLVIVGLASATSWLLSLATRDYSWVDRAWSILPAVYLWVFAVAADPPDARLLVLAVLGTLWGIRLTLNFARKGGYRPGGEDYRWAELRRRMSPGRFAVVNLVFISVAQNVLLLLLALPAWIVLQHPGRFGLPELALTALFLALLAGEGIADQQQWRFQQERRTIRARAGADPGFLRSGLFRFSRHPNYFFEIAQWWTVALVGAVAAGTPWQSGSLGAVLLTLLFVGSIALTESISMGRHPGYAAYRREVWPLVPWFPKRSPGLAARGAEDPFRADGP",
      "product": ""
     },
     {
      "start": 30070,
      "end": 32661,
      "strand": -1,
      "locus_tag": "ctg14_35",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_35</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_35</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,070 - 32,661,\n (total: 2592 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_35 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13298.9 (DNA polymerase Ligase (LigD)): [347:438](score: 113.4, e-value: 5.9e-33)<br>\n \n  PF01068.24 (ATP dependent DNA ligase domain): [503:700](score: 123.1, e-value: 1.2e-35)<br>\n \n  PF04679.18 (ATP dependent DNA ligase C terminal region): [719:825](score: 75.0, e-value: 6e-21)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_35 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01068.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003910' target='_blank'>GO:0003910</a>: DNA ligase (ATP) activity<br>\n  \n   PF01068.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF01068.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006281' target='_blank'>GO:0006281</a>: DNA repair<br>\n  \n   PF01068.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006310' target='_blank'>GO:0006310</a>: DNA recombination<br>\n  \n   PF04679.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003910' target='_blank'>GO:0003910</a>: DNA ligase (ATP) activity<br>\n  \n   PF04679.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006281' target='_blank'>GO:0006281</a>: DNA repair<br>\n  \n   PF04679.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006310' target='_blank'>GO:0006310</a>: DNA recombination<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_35\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_35_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGACGGTCGCCGAGTCACCCTGACCAATCTGGAGAAGGTGATGTACCCGGCCACCGGCACCACCAAGGCCGACGTCCTCAGCTACTACGCGGCAGTGGCGGATGCCCTCATCCGGCACGCCAGGGACCGCCCGGCCACCCGCAAGCGCTGGGTGCACGGAGTGGGTACCGCCGCCGAGCCCGGCCAGGTGTTCTTCCAGAAGAACCTGGGCGACGGCACTCCGGAATGGGTGGAACGCCGGGAACTGGAGCACAAGGAGCGTCGCACCGTGTATCCGCTCGTCAACGACCTGGCCACGCTCACCTGGCTCGCCCAGATCGGCACCCTCGAGATCCACGTTCCGCAGTGGCGATTCGACTCCGGCGGCGCGCCGAGCACTCCCGACCGGCTGGTGCTCGACCTGGACCCCGGCGAGGGGGTGGGCCTGGCCGAGTGCGCCGAGGTGGCGCGCTGGGCCCGGGCGCTGCTTCTCGACATGGGCCTGGACGCCCGGCCGGTGACGAGCGGCAGCAAGGGCATCCACCTGTACACGGCGCTGGACGGCAGCCACAGCTCCGAGCAGGTGAGCCAGGTGGCCCGGGAGCTGGCCCGGGCGCTCGAGGCCGACCACCCCGGCGAGGTGCTCAGCGCCATGACCCGGTCGCTGCGGCCGGGGAAGGTCTTCGTGGACTGGAGCCAGAACAGCGCCGCGAAGACCACGATCGCGCCGTACAGTCTGCGCGGACTGCTACGGCCGTTCGTGGCGGCCCCGCGCACGTGGCGCGAACTGGAGGCGCCCGGCCTGGAGCAGCTGGACTACCGCCAGGTGCTCAAACGGCTCTCCCGGGGGCCCGACCCTCTGGCGGCCGTGGCCGACGCCGCCGAGGCACACGCCGGCGGCCCGGCCGTGAACGCGGCCGTGAGCGCGGCCGGCGGGGCACCGGATGCGGCCCAGTCTGACCGTCTGCACACCTACCGGAGCAAGCGGGACGCCAAGCGCACGCCCGAGCCCATGCCGGAGCGCACCCCGGCCGGCACCGGCGGGGCCGCGTTCGTGATCCAGGAACACCACGCCAGGGCCCTGCACTTCGACCTGCGCCTCGAGCACGACGGTGTCCTGGCCTCCTGGGCGCTGCCGAAGGGCGTGCCCACCGACCCCACCCACAACCACCTGGCCGTGCAGACCGAGGACCACCCGTTGGAGTACCTCGAGTTCGAGGGAGACATCCCGGCCGGGGAATACGGCGCCGGTTCGATGTCGATCTGGGACCGTGGCGACTACAGCGTGGAGAAGTGGCGGGACGACGAGATCATCGTGGCCCTGCACGGCCGGGCGGGCGGCCCGCTCCAGACGGGTCCGGGCGAGCCGCGGCGCACCTTCGCCCTCATCCGCACCGGGGGCGCCGGCTCCCGCAACTGGCTGATCCATCTCATGAAGCCCAAGCCGGCCCCGGCCGGCCAGACCAGCGCCCGGGCCCAGGACGCCCCGGTCACCAGCGCACCGCTGCGGCCCGCACCCGGCTACTCCCCCATGCTCGCCCGGCCCGGCTCCCTCCTGAGCCTGTCCGCGGAGACGGAGTGGGCCTACGAGATGAAATGGGACGGCATCCGCATGATCGCCACCGTGGACGGCGGCCCGGGCGGAGCCGTGCGCTTTCTCACCCGCAACGGCAACGACGTCACGGCCGCGTTCCCCGAACTCGTCGACGACCTGCGCGCGGCCCTGGCCGGCCGCTCCGCGGTGCTGGACGGCGAGGTCGTCGCGCTGGACCGGCGCAACCGGCCGGACTTCTCCCTGCTGCAGACCCGGCTCGGACTCACCGGGGAGACCGAGGTGCGCCGGGCGCGACAGGGGGCGCCCGTGCACTATTTCGCCTTCGACCTCCTCGAACACGACGGTGTGCCCCTGGTCGAACTCCCGTACGCCGAGCGCCGGCAGGTGCTGGAGGAGGTGGTGCGCGGCACCGGCACCGTGCAGGTTCCGCCGGCCTTCGACGACCAGGATGCGGCGACCGTGCTGGCCACCAGCGCCCGGTTGGGCCTGGAGGGGATCATCGCCAAGGACACCCGCAGCGGCTATCTCACCGGCCGGCGCGCCGACCGCTGGGTGAAGATCAAGCATGTGACGAGCCAGGAGGTCGTCATCGGCGGCTGGCGGCCGGGCGCCGGGCATCGCTCCGCGACCCTCGGGTCGCTCCTGGTCGGGATCCCCGCGCCCGCCGACCCCGACGGCGGGGAGGCGACCGGCACGCCGCGCCCGCTGCTCTACGCGGGCCGGGTCGGTACGGGCTTCCGCGACCGGGACCTCACCGCGCTCCGGCGCCGCCTCGACGCACTGCCGGCCGCCGAGACCCCGTTCCAGGATGTGCCGCCGGCCGATGCGGCCGACGCCGTGTGGGTGCAGCCGGTCCTGGTGGGCGAGGTGGACTTCTCCGCCTGGACCCCGGCCGGCCGGCTGCGTCACCCCAGCTGGCGGGGACTGCGCGCCGACAAGGACCCCGCCGACGTCGTCCGGGAGGACGTGGTGCAGGAGGACGTCGTGCAGGAGGACATCGTGCGGGAGGACGGATCACCGGACGACCGATCACGAGGGGATGGTGGTCCCCGATGA",
      "translation": "MDGRRVTLTNLEKVMYPATGTTKADVLSYYAAVADALIRHARDRPATRKRWVHGVGTAAEPGQVFFQKNLGDGTPEWVERRELEHKERRTVYPLVNDLATLTWLAQIGTLEIHVPQWRFDSGGAPSTPDRLVLDLDPGEGVGLAECAEVARWARALLLDMGLDARPVTSGSKGIHLYTALDGSHSSEQVSQVARELARALEADHPGEVLSAMTRSLRPGKVFVDWSQNSAAKTTIAPYSLRGLLRPFVAAPRTWRELEAPGLEQLDYRQVLKRLSRGPDPLAAVADAAEAHAGGPAVNAAVSAAGGAPDAAQSDRLHTYRSKRDAKRTPEPMPERTPAGTGGAAFVIQEHHARALHFDLRLEHDGVLASWALPKGVPTDPTHNHLAVQTEDHPLEYLEFEGDIPAGEYGAGSMSIWDRGDYSVEKWRDDEIIVALHGRAGGPLQTGPGEPRRTFALIRTGGAGSRNWLIHLMKPKPAPAGQTSARAQDAPVTSAPLRPAPGYSPMLARPGSLLSLSAETEWAYEMKWDGIRMIATVDGGPGGAVRFLTRNGNDVTAAFPELVDDLRAALAGRSAVLDGEVVALDRRNRPDFSLLQTRLGLTGETEVRRARQGAPVHYFAFDLLEHDGVPLVELPYAERRQVLEEVVRGTGTVQVPPAFDDQDAATVLATSARLGLEGIIAKDTRSGYLTGRRADRWVKIKHVTSQEVVIGGWRPGAGHRSATLGSLLVGIPAPADPDGGEATGTPRPLLYAGRVGTGFRDRDLTALRRRLDALPAAETPFQDVPPADAADAVWVQPVLVGEVDFSAWTPAGRLRHPSWRGLRADKDPADVVREDVVQEDVVQEDIVREDGSPDDRSRGDGGPR",
      "product": ""
     },
     {
      "start": 32835,
      "end": 33824,
      "strand": 1,
      "locus_tag": "ctg14_36",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_36</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_36</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,835 - 33,824,\n (total: 990 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_36 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02735.19 (Ku70/Ku80 beta-barrel domain): [10:188](score: 119.0, e-value: 2.3e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_36 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02735.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF02735.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006303' target='_blank'>GO:0006303</a>: double-strand break repair via nonhomologous end joining<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_36\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_36_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGATCGATCTGGAAGGGTGCCATCACCTTCGGCCTGGTCAACGTGCCGGTCAAGGTGTACAGCGCCACCGAGGACCACGACGTCGAGCTGCACCAGGTGCACGACGCGGATGGCGGCCGCATCCGCTATCAGCGCCGCTGTGAGGTGTGCGGCAACATCGTGGACTACGCGCACATCGACAAGGCCTTCACCGACGCGGACAAGACCGTCATCATCACGGATGCCGACCTCAAGGCGCTGCCGGAGGAACGCAGCCGGGAGATCGACGTGCTCGAATTCGTGCCGAACGACCAGCTCAATCCGATCATGTTCGACAAGAGCTATTTCCTCGAACCCGACGGGAGCTCGCCCAAGGCCTACGTGCTCTTGCGCCGCACACTGGAGCAGTCCGATCGCACCGCCATCGTGCACTTCTCCCTCCGGCAGAAGACCCGCCTGGCCGCGTTGCGGGTGCAGGGGGACGTCCTGATGCTGCAGACCCTGCTCTGGAACGACGAGGTGCGCACGGCCGACTTCCCGGCGCTGGAGCAGACGGTGACGATCTCCGACCGGGAGCTGGACCTGTCGGCGGCGCTGGTCGAGTCGTTCGCGGCCGACTTCAGCCCGGGTGACTACACCGACGAGTACCAGGTCCAGCTGCGCCGGCTCATCGAGGAGAAGCTCGAGAAGGGCGACGCCATCGACACCGAGGCCACCTTCGGCGCCGCCGAGGAGGAGGGCGGCGGGGGAGAGGTGCTCGACCTGATGGAGGCGCTGCGTCGGAGTGTCGACCGCAGCCGCAAGGGACCCGCCGCGGCGGACGCGGCCTCGACGTCGTCCGGGGCGGAGCCCGCGGCCACGAAGGCCACGAAGCCGGCGGCCCGGAAGGCGGCGGCCAAGAAGCCCGCGGCCCGGAAGTCGGCCGAGAAGCCGGCCGAGAAGAAGACCGCCGCGACGGCGAAGAAGAAGAGCACGACCACGAGCGCCGCACAGCGGCACACGGCCTGA",
      "translation": "MRSIWKGAITFGLVNVPVKVYSATEDHDVELHQVHDADGGRIRYQRRCEVCGNIVDYAHIDKAFTDADKTVIITDADLKALPEERSREIDVLEFVPNDQLNPIMFDKSYFLEPDGSSPKAYVLLRRTLEQSDRTAIVHFSLRQKTRLAALRVQGDVLMLQTLLWNDEVRTADFPALEQTVTISDRELDLSAALVESFAADFSPGDYTDEYQVQLRRLIEEKLEKGDAIDTEATFGAAEEEGGGGEVLDLMEALRRSVDRSRKGPAAADAASTSSGAEPAATKATKPAARKAAAKKPAARKSAEKPAEKKTAATAKKKSTTTSAAQRHTA",
      "product": ""
     },
     {
      "start": 33878,
      "end": 34435,
      "strand": 1,
      "locus_tag": "ctg14_37",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_37</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_37</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,878 - 34,435,\n (total: 558 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_37 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01066.24 (CDP-alcohol phosphatidyltransferase): [7:162](score: 121.9, e-value: 3.5e-35)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_37 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01066.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016780' target='_blank'>GO:0016780</a>: phosphotransferase activity, for other substituted phosphate groups<br>\n  \n   PF01066.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008654' target='_blank'>GO:0008654</a>: phospholipid biosynthetic process<br>\n  \n   PF01066.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_37\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGTGAGCTCCCGGGTGATCACCGTGCCCAATCTGCTCAGTTTCCTGCGCCTGGGGCTCGTTCCGGTCTTCCTCGGCCTCATCGTCAGCGGCGCGGACGCCTGGGCACTGCTGGTGCTGGCGGTGTCCAGCCTCACCGACTTCCTCGACGGCTGGATCGCCCGCCGGTTCAACCAGGTCACCCGGCTGGGCCAGCTTCTGGACCCCGCCGCCGACAGGCTCTACATCTTCGCGGCGCTGATCGGCCTGGCCTGGCGTGACCTCGTGCCCTGGTGGATCGTGGTTGTCGTTGTGGGCCGGGACGTCTTCCTGCTGGGCCTGGGTGTGGTGCTGGCCAACCACGGTTTCGGCCCGCTGCCGGTGCACCAGCTGGGCAAGATCGCCACCTTCTGCCTGTTCTACGCCCTGCCGATGATCATGCTCGGGCAGGCGTTCCCCGAGCTGGCCTGGTGGTCGCAGCCCGTCGGCTGGGCCTTCGGGCTCTGGGGTGCGTACCTGTACTGGTGGGCCGGAGTCATCTACGCGATTGAAACGGTTCGGGTGATTCGGCTGCCATAG",
      "translation": "MVSSRVITVPNLLSFLRLGLVPVFLGLIVSGADAWALLVLAVSSLTDFLDGWIARRFNQVTRLGQLLDPAADRLYIFAALIGLAWRDLVPWWIVVVVVGRDVFLLGLGVVLANHGFGPLPVHQLGKIATFCLFYALPMIMLGQAFPELAWWSQPVGWAFGLWGAYLYWWAGVIYAIETVRVIRLP",
      "product": ""
     },
     {
      "start": 34486,
      "end": 34995,
      "strand": 1,
      "locus_tag": "ctg14_38",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_38</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_38</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,486 - 34,995,\n (total: 510 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_38 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00498.29 (FHA domain): [86:150](score: 61.4, e-value: 8.7e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_38 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00498.29: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_38\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGTCGATTCCGACGATAAGAAAGAACCCGAGCAGACGGTGGCGCCGGGGAAGACGGTCGCGCCAGAGAACGCCAGGGGGAACGTCGACACGACGATGACGTTCAGCCAGGAGTTCGCGGCGTCGTTGGCCGCCCTCGACTCGAACGTCACGGTCGAGGAGCAGGAAGCCATCGCCGCCCTGCCCTCAGGCTCGGCTCTGCTCGTGGTGCGCCGCGGCCCCAATTCGGGCGCACGCTTCCTCCTCGACGCCGACGTCACCACGGTCGGCCGTCACCCCAACGCCGACATCTTCCTCGATGACGTCACGGTCTCGCGTCGCCACGCCGAGTTCCTGCGCTCCGGTCGCACCTTCCAGGTGAAAGACCTGGGCTCGCTCAACGGAACCTATTTCGATGGCGAACGTATCGACCTGGCCGTCCTCACCGACGGGTCCGAAGTGCAGGTCGGAAAATTCCGCCTGACGTTCTACGCCTCGCGGCTCGACCTCGTACACCTGGCGAGCGACTAG",
      "translation": "MVDSDDKKEPEQTVAPGKTVAPENARGNVDTTMTFSQEFAASLAALDSNVTVEEQEAIAALPSGSALLVVRRGPNSGARFLLDADVTTVGRHPNADIFLDDVTVSRRHAEFLRSGRTFQVKDLGSLNGTYFDGERIDLAVLTDGSEVQVGKFRLTFYASRLDLVHLASD",
      "product": ""
     },
     {
      "start": 34995,
      "end": 35693,
      "strand": 1,
      "locus_tag": "ctg14_39",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_39</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_39</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,995 - 35,693,\n (total: 699 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_39 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13411.9 (MerR HTH family regulatory protein): [32:89](score: 38.2, e-value: 1.2e-09)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_39 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF13411.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF13411.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_39\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCCGGCGTCCTCCGCCCAGGCCAGGCTGCCGGGCGCGACGTCACTTCTGAGTATCGGCCAGGTCCTGGCCAGGCTCACGCCTGAGTTCCCGGACCTCACCCCGTCCAAGCTGCGCTTCCTCGAGGAGCAGGGCCTGGTCTCTCCGGCCCGCACCGAGTCCGGCTACCGCAAGTTCAACGGCGGCGACCTGGACCGGCTGCGACTGATCCTGTCGATGCAGCGCGACCATTACCTGCCGCTCAAGGTCATCCGCTCCTACCTCGACGACCTCGACTCCGGTCTGTCGCCGTCCCTGCCCGGCGGCGGGGCCCCCGGGCCGAGCATGCTCGTCGTGGCCCGCCGCTTCAGCCGGGACGAACTGCTGCGTGAGTCCGGCGCGACCGCCGCCCTGCTGCACGACGCCGTCTCGTCGTCGATCATCCTGCCGGCCGAGCACTACGGCGACGACGCCCTGCAGGTGCTCCGTGCCCTCGTCGACCTGCAGAAGAGCGGCATCGAACCGAGGCACCTGCGCGGGTTCCGCGGTGCCGCCGAACGCGAGCTCGGCCTGATCGAGAGCGCCCTCGTGCCGCTCGCCCGCCGCAAGGACGCCTCCAGCCGGGCCAAGGCCGCCGAGATGGCCGTGGAGATCGCCGGCCAGCTCGAAGTCATCCGCGGCAGCCTCATCCGCTCCGCCCTGGGTCGCCTGACCAAATAG",
      "translation": "MPASSAQARLPGATSLLSIGQVLARLTPEFPDLTPSKLRFLEEQGLVSPARTESGYRKFNGGDLDRLRLILSMQRDHYLPLKVIRSYLDDLDSGLSPSLPGGGAPGPSMLVVARRFSRDELLRESGATAALLHDAVSSSIILPAEHYGDDALQVLRALVDLQKSGIEPRHLRGFRGAAERELGLIESALVPLARRKDASSRAKAAEMAVEIAGQLEVIRGSLIRSALGRLTK",
      "product": ""
     },
     {
      "start": 35897,
      "end": 36448,
      "strand": 1,
      "locus_tag": "ctg14_40",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_40</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_40</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,897 - 36,448,\n (total: 552 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_40 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13411.9 (MerR HTH family regulatory protein): [34:103](score: 54.2, e-value: 1.2e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_40 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF13411.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF13411.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_40\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTGAGCTCAATCCCCGAGACGATTCGTCTCGCTACGGTCAGGGACTGCTCTTCACCGACGGTATGCCCGAGCTGGACGAGAACTCCGGGTACCGCGGCGCCGTCGCCGCCCGTGCCGCCGGCATCAGCTACCGCCAGCTCGACTACTGGGCCCGCACCGAACTCGTCGAACCCACCGTGCGCGGCGCGGCCGGATCCGGCTCCCAGCGCCTCTACGGCTTCCGCGACATTCTCGTGCTCAAGCTCGTCAAGCGCCTGCTCGACACCGGTATCTCCCTGCAGCAGATCCGCACCGCGGTCAACCAGTTGCGTGAGTCCGGCGTCAACGACCTGGCCCAGACCACCCTCATGAGCGACGGCGCCAGCGTCTACCTCTGCACCTCCAACGACGAGGTCATCGACCTGGTCAGCCGCGGCCAGGGCGTCTTCGGCATCGCCGTGGGCAAGGTCCTCCGCGAGGTCGAGACCACGCTGGTGGAACTCGACACCCAGGCCAACGACCCCTCCGACGAGCTCGCCGCCCGTCGCGTCTCCCGCAAGGTCTCCTAG",
      "translation": "MSELNPRDDSSRYGQGLLFTDGMPELDENSGYRGAVAARAAGISYRQLDYWARTELVEPTVRGAAGSGSQRLYGFRDILVLKLVKRLLDTGISLQQIRTAVNQLRESGVNDLAQTTLMSDGASVYLCTSNDEVIDLVSRGQGVFGIAVGKVLREVETTLVELDTQANDPSDELAARRVSRKVS",
      "product": ""
     },
     {
      "start": 36554,
      "end": 37264,
      "strand": -1,
      "locus_tag": "ctg14_41",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_41</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_41</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,554 - 37,264,\n (total: 711 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1157:hypothetical protein (Score: 119.4; E-value: 3.3e-36)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_41 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13614.9 (AAA domain): [0:146](score: 62.6, e-value: 4.6e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_41\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGTCGACCTCGATCCGCAATCGGATGTCTCAACCGGGCTCGACATCCAACTCGCCGGCCACCTCAATGTGGCCGATGTGCTGGCCTCGCCGAAGGAGAAAATCGTCCGGGCCGCCATCGCGCCCAGCGGCTGGACCCGCGGTCGCCCCGGCACCATCGACGTCATGATCGGCAGCCCCTCCGCCATCAATTTCGACGGCCCGCACCCCAGCATCCGCGACATCTGGAAGCTCGAGGAGGCCCTCTCCACAGTGGAGAAGGACTATGACCTGGTGCTCATCGACTGCGCGCCCTCGCTCAACGCCCTGACCCGCACCGCGTGGGCCGCGAGCGACCGTGTCGCCGTGGTCACCGAACCCGGCCTCTTCTCGGTGGCCGCCGCCGACCGCGCCCTCCGCGCGATCGAGGAGATCCGTCGTGGGCTCAGCCCGCGCCTGCAGCCGCTGGGCATCATCGTGAACCGGGCCCGCACGGCCTCGCTCGAGCACCAGTTCCGCATCAAGGAGCTCCGAGACATGTTCGGTCCCCTCGTGCTCACCCCGCAGCTTCCGGAGCGCACCAGCCTGCAGCAGGCGCAGGGCGCGGCGAAGCCCCTGCACACCTGGCCGGGTGACAGTGCCCAGGAGATGGCGCACTACTTCGACCAGCTGCTCGACCGGGTCCTGCGCACGGCACGCATCGGCGAATACGCGGAGGCGACCGCCCGCTAA",
      "translation": "MVDLDPQSDVSTGLDIQLAGHLNVADVLASPKEKIVRAAIAPSGWTRGRPGTIDVMIGSPSAINFDGPHPSIRDIWKLEEALSTVEKDYDLVLIDCAPSLNALTRTAWAASDRVAVVTEPGLFSVAAADRALRAIEEIRRGLSPRLQPLGIIVNRARTASLEHQFRIKELRDMFGPLVLTPQLPERTSLQQAQGAAKPLHTWPGDSAQEMAHYFDQLLDRVLRTARIGEYAEATAR",
      "product": ""
     },
     {
      "start": 37444,
      "end": 40848,
      "strand": 1,
      "locus_tag": "ctg14_42",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_42</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_42</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 37,444 - 40,848,\n (total: 3405 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: HMGL-like<br>\n \n  biosynthetic-additional (rule-based-clusters) Dala_Dala_lig_C<br>\n \n  biosynthetic-additional (rule-based-clusters) ATP-grasp<br>\n \n  biosynthetic-additional (smcogs) SMCOG1090:acetyl-CoA carboxylase biotin carboxylase (Score: 134.2; E-value: 9.6e-41)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_42 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00289.25 (Biotin carboxylase, N-terminal domain): [0:111](score: 131.5, e-value: 2e-38)<br>\n \n  PF02786.20 (Carbamoyl-phosphate synthase L chain, ATP binding domain): [116:326](score: 228.4, e-value: 7e-68)<br>\n \n  PF02785.22 (Biotin carboxylase C-terminal domain): [342:451](score: 122.3, e-value: 9.3e-36)<br>\n \n  PF00682.22 (HMGL-like): [528:801](score: 101.5, e-value: 6.1e-29)<br>\n \n  PF02436.21 (Conserved carboxylase domain): [824:1013](score: 167.3, e-value: 3.8e-49)<br>\n \n  PF00364.25 (Biotin-requiring enzyme): [1072:1130](score: 53.6, e-value: 1.6e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_42 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00682.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF02786.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_42\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_42_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTCACCAAAATCCTCGTCGCAAACCGTGGAGAGATAGCAATCCGCGCGTTCCGCGCCGCCTATGAATTGGGAGCAAAGACCGTCGCGGTCTTCCCGTTCGAAGACCGTAATTCACTGCACCGGCTCAAGGCCGACGAGGCGTACGAGATCGGCGAACCGGGTCACCCGGTGCGCGCGTACCTCGACGTGGCGGAGATCATCCGGGTGGCCAAGGAGAGTGGCGCAGATGCCATCTACCCCGGCTACGGATTCCTCTCCGAGAACCCCGACCTGGCGGAGGCGGCCACGGCGGCCGGCATCACCTTCATCGGCCCGGGTTCACACGTACTCGAAATGGCCGGTAACAAGGTCACCGCGAAGGAACACGCCATCGCGGCCGGCGTTCCCGTCCTCAAGTCCAGCGCACCGTCGCGCGACGTCGAGGAACTCATCGCCGCGGCCGAGGAGATCGGCTTCCCCATCTTCGCCAAGGCCGTCGCCGGCGGCGGCGGACGCGGCATGCGCCGCGTGGCCACCATGGCCGACCTGCGCGGCTCGCTCGAAGAAGCCATGCGCGAGGCCAACAGCGCCTTCGGCGATCCCACCATGTTCCTCGAGCAGGCGGTGCTCCGCCCGCGCCACATCGAGGTGCAGATCCTCGCGGATGCCACGGGCGAGACCGTGCACCTGTTCGAGCGGGACTGCTCCGTGCAGCGCCGCCACCAGAAGGTCATCGAGATCGCCCCGGCCCCCAACCTCCCCGAGGAGATCCGCCAGCGCCTGCACAAGGACGCCGTCGCCTTCGCCCGGTCGATCGGCTACGTCAACGCCGGCACGGTCGAGTTCCTGCTCGACACCGTGGGCGAGCGCGCCGGCCAGCACGTGTTCATCGAGATGAACCCGCGCATCCAGGTGGAGCACACCGTCACGGAAGAGGTCACCGACGTCGACCTCGTGCAGTCGCAGATCCGCATCGCCGCGGGGGAGACCCTCGCCGACCTGGGGCTCAGCCAGGACTCCATCAAACTGCGCGGCTTCGCCCTGCAGTGCCGCATCACCACGGAGGACCCCACGGCCGGGTTCCGCCCCGACACCGGCAAGATCACCACGTACCGCTCACCGGGCGGCGCCGGCATCCGCCTGGACGGCGGCACGATCAACCCGGGCGCGCAGATCAGCCCGCACTTCGACTCGATGCTGGCCAAGCTCACCTGCCGTGGCCGCGACTACGCCTCGGCCGTCACCCGGTCCAAGCGCGCGCTGGCGGAGTTCCGCATCCGCGGCGTCTCCACCAACATCGCCTTCCTGCAGGCCGTGCTCGAGGACCCCGACTTCGCCGCCGGCGACCTGAGCACCTCCTTCATCGACGAGCGTCCGCAGCTGCTGCGCGGCCGCGCGTCCAAGGACCGCGGCACGAAGATCCTCAACTGGCTGGCCGACGTCACCGTCAACCAGCCCAACGGTGTGCCGATCACGCTGATGAACCCGGCCGAGAAGCTCCCGAAGATCGACCTGTCGGTGCCGGCCCCGGAGGGCTCCCGGCAGAAGTTGCAACTGCTCGGCCCGGTCGGTTTCGCCAGTGCCCTGCGCAAGCAGACCGCACTGGCCGTCACGGACACCACCTTCCGCGACGCCCACCAGTCCCTGCTGGCGACCCGGGTGCGCACCAAGGACCTCGTGGCCGTGGCCCCGCACGTGGCCCGACTCACTCCCGAGCTGCTCTCGGTCGAGGCCTGGGGCGGCGCGACCTACGACGTCGCGCTACGCTTCCTCGGCGAGGACCCGTGGGAGCGACTCAGCGCCCTGCGGGAGGCGCTGCCCAACATCAACATCCAGATGCTGCTGCGCGGCCGCAACACCGTCGGCTACACGCCGTACCCCACCGAGGTGACGGATGCGTTCGTGCGCGAGGCCAGCGACACCGGCGTCGACATCTTCCGCATCTTCGACGCCCTCAACGACGTCAACCAGATGCGCCCGGCCATCGACGCGGTGCTGAACACCGGCACGAGCGTCGCCGAGGTCGCGGTCTGCTACACCGGCGACCTGCTGGACCCGGCCGAGGACCTCTACACGCTGGACTACTACCTACGCCTGGCCGACCAGATCGTCGCCTCCGGCGCGCACATCCTGGCGATCAAGGACATGGCCGGTCTGCTGCGCCCGGCCGCGGCGGAGAAGCTCGTCGCCGCGTTCCGCGAACGGTTCGACCTGCCGGTGCACGTGCACACGCACGACACCCCCGGTGGCCAGCTCGCCACGCTGCTCGCGGCCTCCCGCGCCGGGGCCGACGCCGTCGACGTCGCCAGCGCCCCGATGGGCGGCACCACCAGCCAGCCGTCGGCCTCCTCGCTCGTCGCCGCGCTCGCGCACACCGAACGCGACACGGGCATCTCGCTGCAGAACGTCTGCGACCTCGAGCCCTACTGGGAGGACGTGCGCCGGGTCTACCACCCCTTCGAATCCGGCCTCCGCGCCCCCACCGGCCGGGTGTACAAGCACGAGATCCCGGGCGGCCAGCTCTCCAACCTGCGCACGCAGGCCGTGGCGCTGGGACTCGCCGACGACTTCGAGCTCATCGAGGACATGTACGCGGCGGCCAACACCATCCTGGGCCGCGTGCCCAAGGTGACCCCGTCCTCCAAGGTGGTCGGCGACCTCGCCCTCTACCTCGCCGCGGTGAACGCCGACCCGGCCGACTTCGAGGCGAACCCGGCGAAGTACGACGTGCCCGACTCCGTGGTCGGCTTCATGGCCGGCGAACTGGGCGACCTGCCCGGCGGCTGGCCCGAGCCCTTCCGCAGCAAGGTCCTCGAGGGCCGGAACGTCCGGGTCAGCACCACCGAGCTGACCGACGAGGAGCGTGTCGCCCTGGCCGGCGACAGCGCCACCCGCCGCGGCATGCTCAACCAGCTACTCTTCCCGGCTCCCACCCGGCACTTCCAGCAGATCCGGGAGCTGTTCGGTGACCTGTCCGTGGTCGACACGGTCGACTACCTCTACGGCCTGCGCCAGGGCACCGAGCACTCGGTCGAGATCGACAAGGGCGTGCGGCTCTACGTGGGCCTCGAGGCGATCGGCGAGGCCGACGACAAGGGCATGCGCACCGTCATGACCATCCTCAACGGCCAGTTGCGGCCCGTGTTCGTGCGCGACCGCAGCATCGCCGTCGTCACCAAGGCGGCCGAGAAGGCGGATGCCAACCAGCCCGGCCAGATCGCCGCCCCGTTCTCCGGAGTGGTCACCCTGCAGGTCGCCGACGGCGACCACGTCGTGGCCGGCCAGAGCGTGGCCTCCATCGAAGCCATGAAGATGGAAGCGGCCATCACCTCGCCCATCGCGGGCGTCGTGGAGCGGGTGGCGATTCCCACCACCCAGCAGGTCGACGCCGGGGACCTGCTTGTGGTGGTGCGACCACGCTAG",
      "translation": "MFTKILVANRGEIAIRAFRAAYELGAKTVAVFPFEDRNSLHRLKADEAYEIGEPGHPVRAYLDVAEIIRVAKESGADAIYPGYGFLSENPDLAEAATAAGITFIGPGSHVLEMAGNKVTAKEHAIAAGVPVLKSSAPSRDVEELIAAAEEIGFPIFAKAVAGGGGRGMRRVATMADLRGSLEEAMREANSAFGDPTMFLEQAVLRPRHIEVQILADATGETVHLFERDCSVQRRHQKVIEIAPAPNLPEEIRQRLHKDAVAFARSIGYVNAGTVEFLLDTVGERAGQHVFIEMNPRIQVEHTVTEEVTDVDLVQSQIRIAAGETLADLGLSQDSIKLRGFALQCRITTEDPTAGFRPDTGKITTYRSPGGAGIRLDGGTINPGAQISPHFDSMLAKLTCRGRDYASAVTRSKRALAEFRIRGVSTNIAFLQAVLEDPDFAAGDLSTSFIDERPQLLRGRASKDRGTKILNWLADVTVNQPNGVPITLMNPAEKLPKIDLSVPAPEGSRQKLQLLGPVGFASALRKQTALAVTDTTFRDAHQSLLATRVRTKDLVAVAPHVARLTPELLSVEAWGGATYDVALRFLGEDPWERLSALREALPNINIQMLLRGRNTVGYTPYPTEVTDAFVREASDTGVDIFRIFDALNDVNQMRPAIDAVLNTGTSVAEVAVCYTGDLLDPAEDLYTLDYYLRLADQIVASGAHILAIKDMAGLLRPAAAEKLVAAFRERFDLPVHVHTHDTPGGQLATLLAASRAGADAVDVASAPMGGTTSQPSASSLVAALAHTERDTGISLQNVCDLEPYWEDVRRVYHPFESGLRAPTGRVYKHEIPGGQLSNLRTQAVALGLADDFELIEDMYAAANTILGRVPKVTPSSKVVGDLALYLAAVNADPADFEANPAKYDVPDSVVGFMAGELGDLPGGWPEPFRSKVLEGRNVRVSTTELTDEERVALAGDSATRRGMLNQLLFPAPTRHFQQIRELFGDLSVVDTVDYLYGLRQGTEHSVEIDKGVRLYVGLEAIGEADDKGMRTVMTILNGQLRPVFVRDRSIAVVTKAAEKADANQPGQIAAPFSGVVTLQVADGDHVVAGQSVASIEAMKMEAAITSPIAGVVERVAIPTTQQVDAGDLLVVVRPR",
      "product": ""
     },
     {
      "start": 41001,
      "end": 42308,
      "strand": 1,
      "locus_tag": "ctg14_43",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 41,001 - 42,308,\n (total: 1308 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1157:hypothetical protein (Score: 61.8; E-value: 1.3e-18)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_43 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01656.26 (CobQ/CobB/MinD/ParA nucleotide binding domain): [191:349](score: 32.9, e-value: 6e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_43\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCGGGCCGGTGACGAGTACCACAGCGAGCTCCCGCCGCACACCTTCGACAACCTCGCGGCCGCGCTGCCCGAGAGCCTCGGGGTGTCCCTGGGCGACGGGACGCGCCCCGTGTCGGCCGCGCCGGCATCCGCACTGACCCGCGGCTCCGCCCGCCCACCGGCCCGTCCCACCGGTGACGCCTCGGCGCACGCCCACCCCGGCACACACACCATCGAGATCGTCACGCCGCAGCCGGCCCGCGAGCTGGCCGTTCCCGTCGGGGCGAGCGGGATGGCCGCCGCCGCGCTCTCGCTCGGCACCGGCCCCACCGGCGCTCCCACCGCCAGCCGGCGGGAGCGCACCCGCACGGACACCGTGGCACCGGAATCCGCCTCGATGCTCACCTCCGACCGGCTGCTCGAGGTCAACCGGCGCACCCGGCGGCCCCCCAACGGCGCCTGGAACCGTTTCGTCTACAACGTCTCCCTGCACCTGATCAACCTCGGCGACTCCGCCGCGGTGCGTGCCCATCAGGCCATGGACGAACGCATCCGCAAGCAGTTCGAGGGCGGCGCCCGCTTCGTACCGGTGCTCACCCGTAAGGGCGGCGTGGGCAAGACCACGGTCACCGCGCTCATGGGTATGGCCCTGGCCGACGCCCGCGAGGACCGCATCATCGCCGTGGACGCCAACCCCGACCGCGGAACCCTGTCCGAACGCGTCACCAAGCAGACCAGGTCGACGGTGCGCGACGTCGTCACGAAGGCGGCCTCCATCGGCGGCTTCACCGACTTCTCCGCGCTGGTCTCCCGGGACGAGACCCGCCTCGACATCCTGGCCAGCGACACCGACCCGCTGCTCTCGGAGGCGTTCGACGAGAACGACTACAACGTCGTCGCCGATCTCGCGGCCCGGTTCTACTCCATCGTGCTCACCGACTGCGGCACCGGCATCGTGCACTCGGTCATGCGGGCGACCCTGCAGCGGGCCGACTCCATCGTGATCGTCTCCGGCGGCAGCGTCGACGAGGCCCGGCTGGCCTCCGAGACCCTCACCTGGCTCGAGGCCAACGGATACGGCGAGCTGGTCCGCAACGCCGTCGTCGCGTTGAACACGGCCACCCAGGGCACCAACCTCGTCAAGCTCGAGGAGATCGAGTCGCACTTCAGGTCCCGCGTGCGGGAGATCGTGCGGATCCCGTACGACCCGCAGCTGGCCGCCGGCAGTGTGGTCTCCTACAAGGACCTCAAGCCGATCACGCGCCTCGCCGCGCGCACCCTGGCAGCCCTCGTCGTGGAAGGGCTGCCTGCCGAGCGACGCGTCTGA",
      "translation": "MRAGDEYHSELPPHTFDNLAAALPESLGVSLGDGTRPVSAAPASALTRGSARPPARPTGDASAHAHPGTHTIEIVTPQPARELAVPVGASGMAAAALSLGTGPTGAPTASRRERTRTDTVAPESASMLTSDRLLEVNRRTRRPPNGAWNRFVYNVSLHLINLGDSAAVRAHQAMDERIRKQFEGGARFVPVLTRKGGVGKTTVTALMGMALADAREDRIIAVDANPDRGTLSERVTKQTRSTVRDVVTKAASIGGFTDFSALVSRDETRLDILASDTDPLLSEAFDENDYNVVADLAARFYSIVLTDCGTGIVHSVMRATLQRADSIVIVSGGSVDEARLASETLTWLEANGYGELVRNAVVALNTATQGTNLVKLEEIESHFRSRVREIVRIPYDPQLAAGSVVSYKDLKPITRLAARTLAALVVEGLPAERRV",
      "product": ""
     },
     {
      "start": 42401,
      "end": 42892,
      "strand": 1,
      "locus_tag": "ctg14_44",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 42,401 - 42,892,\n (total: 492 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1275:peptide deformylase (Score: 148; E-value: 2.8e-45)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_44 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01327.24 (Polypeptide deformylase): [3:150](score: 115.1, e-value: 2.5e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_44 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01327.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0042586' target='_blank'>GO:0042586</a>: peptide deformylase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_44\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_44_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCCCGAACGCCAGATCCGCCTGTTGGGCGACCCCGTCCTCAAGACCCGCTCCGAACCGATCGGTACGATCGACGCCCGCGTGCGGAGCCTGGTGGAGGACCTCGTCGACAGCGTGACGCTGCCGGGCCGTGCCGGTGTGGCGGCGTCCCAGATCGGCGTCAACCTGCGGGCGTTCAGCTACAACATCGACGGCGACATCGGCTACATCCTCAACCCCGTCATCGTGGAGCTCTCGGGCGAACCCGAGCTCGTCGACGAGGGCTGCCTGTCGGTGCCTGGCCTGTGGTACCCCACCCGGCGGTACCCGTTCGCGCGCGTCACGGGCATCGACCTCGACGGCAACACCGTCGAGCTGGCCGGGGAGGGCCTGCTGGCCCAGGCCCTGCAGCACGAGACCGACCACCTGGACGGCCTGCTCTACCTGGACAGGCTCGACAAGGAGAGCCGCCGGGCTGCCATGAAGGAAGTCCGCGAGTCGGACTGGTTCTGA",
      "translation": "MPERQIRLLGDPVLKTRSEPIGTIDARVRSLVEDLVDSVTLPGRAGVAASQIGVNLRAFSYNIDGDIGYILNPVIVELSGEPELVDEGCLSVPGLWYPTRRYPFARVTGIDLDGNTVELAGEGLLAQALQHETDHLDGLLYLDRLDKESRRAAMKEVRESDWF",
      "product": ""
     },
     {
      "start": 42935,
      "end": 44779,
      "strand": -1,
      "locus_tag": "ctg14_45",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 42,935 - 44,779,\n (total: 1845 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 250.6; E-value: 4.2e-76)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_45 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [36:467](score: 303.1, e-value: 2.8e-90)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_45\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_45_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAAACAGTTCGATGAGCCCGCCGTCGTCCCTGCAGACCCGAACGCGAACGTCACCGACCTGCTGGTCGACCGCCTCGCCCTGACCCCGCAGTCCGTGCTGTTCTCCCGCCCGGACCGGGGCGGCTGGCTGCCGGTCACCACCGCCGAGTTCCACGCCGAGGTCGTGGCCCTGGCCAAGGGGCTGGTCGCCTCAGGCGTGCAGCCGGGCGACAAGATCGGGCTGACCTGCAAGACCCGCTACGAGTGGACGCTGATCGACTTCGCCGTCTGGTTCGCAGGCGCGATCCTGGTCCCGGTCTACGAGACCAGCTCACCCAGCCAGATCCAGTGGATCCTCAGCGACTCGGGGGCAACGGCGCTCATCGTGGAGACTGCGGACCACTTCGCCCGGTTCGACGAGGTGCACCCCGACCTGCCCGGCGTCGAGACGGTGTGGCAGATCGATCTCGGTGACCTCGACAAGCTCGCCGCGCGCGGCGTCGACGTTCCGGATGCCGAGATCGAGCGACGTCGCCGCCTCGCGGTCGGCTCGGACATGGCCACCCTCATCTACACCTCGGGCTCCACCGGGCGCCCCAAGGGTTGCGTGCTCAGCCACAGCAACTTCGTGGAGACCAGCCGCAACGCCGGGATCGCCCTCAAGCCGGTGCTCACCGACCCGGAGGGCGCATCCACCCTGCTGTTCATCACGACGGCCCACGTGTTCGCCCGGTTCATCTCGGTGCTGTGCGTGCACGGCGGCGTGCGGGTCGGCCACCAGCCGGACACCCGGCAGCTGCTGCCGTCGCTGGGCAGCTTCAAGCCCACCTTCCTGCTGGCCGTCCCCCGGGTGTTCGAGAAGGTCTACAACTCGGCCGAGCAGAAGGCGGAGGCCGGCGGCAAGGGCAAGATCTTCGAGGCCGCGTCCGACGTCGCCGTTGCGCACTCCAAGCTCATCGAGGCCGGCGAGCGGATCCCGCTGGGCATGAAGATCAAGTTCGCCCTCTTCGACCGGCTGGTCTACAGCAAGCTGCGGGCCGCGATGGGTGGCAAGGTCAAGTACGCCGTGTCGGGCTCCGCCCCGCTCGGCGCCCACCTGGGCCACTTCTTCCACAGCCTCGGCATCGTCATCCTGGAGGGCTACGGCCTCACCGAGACCACGGCTCCCGCGACCGTCAACCTGGCCACCAAGTCCAAGATCGGCACTGTCGGGCCGGCGCTGCCCGGCGTGTCCGTCCGGGTCATGGACGACGGCGAGATCGAGGTGAAGGGCGTCAACGTCTTCACCGAGTACTGGCACAACCCGGAGGCCACGGCCGCCGCGTTCGACGACGGCTGGCTGAAGACCGGTGACATCGGCGCCCTGGACGCCGAGGGTTTCCTGTCCATCACCGGGCGCAAGAAGGAGATCATCGTGACCGCCGGCGGCAAGAACGTGGCCCCGGCCGCGCTCGAGGACCCCATCCGGTCGAACCCGTTGGTCGGCCAGGTCGTCGTGGTCGGCGACCAGAAACCGTTCATCGCCGCCCTCGTCACCCTCGACCCCGAGATGCTGCCGGTCTGGCTGAACAACAATCACGAAGACGCTGGTCTGTCGCTCATGGACGCGTCGGTGCACCCCAAGGTGCTCGCCGAGGTGCAACGCGCCATCGACCACGCCAACGAGACCGTGTCGCGCGCCGAGTCGATCCGCAAGTTCGTGGTGCTGCCCATCGAACTCACCGAGGCTGCCGGCTACCTCACCCCCAAGATGAGCATCAAACGCGATGTGATCCTGCGTGACTTCGCCGCCGAGATCCAGAACCTCTACGGGGCCAACCCGGTCACCGCGGCCGTGCCGGTGCGCTCGAGCGCACAGGACTGA",
      "translation": "MKQFDEPAVVPADPNANVTDLLVDRLALTPQSVLFSRPDRGGWLPVTTAEFHAEVVALAKGLVASGVQPGDKIGLTCKTRYEWTLIDFAVWFAGAILVPVYETSSPSQIQWILSDSGATALIVETADHFARFDEVHPDLPGVETVWQIDLGDLDKLAARGVDVPDAEIERRRRLAVGSDMATLIYTSGSTGRPKGCVLSHSNFVETSRNAGIALKPVLTDPEGASTLLFITTAHVFARFISVLCVHGGVRVGHQPDTRQLLPSLGSFKPTFLLAVPRVFEKVYNSAEQKAEAGGKGKIFEAASDVAVAHSKLIEAGERIPLGMKIKFALFDRLVYSKLRAAMGGKVKYAVSGSAPLGAHLGHFFHSLGIVILEGYGLTETTAPATVNLATKSKIGTVGPALPGVSVRVMDDGEIEVKGVNVFTEYWHNPEATAAAFDDGWLKTGDIGALDAEGFLSITGRKKEIIVTAGGKNVAPAALEDPIRSNPLVGQVVVVGDQKPFIAALVTLDPEMLPVWLNNNHEDAGLSLMDASVHPKVLAEVQRAIDHANETVSRAESIRKFVVLPIELTEAAGYLTPKMSIKRDVILRDFAAEIQNLYGANPVTAAVPVRSSAQD",
      "product": ""
     },
     {
      "start": 44981,
      "end": 45928,
      "strand": 1,
      "locus_tag": "ctg14_46",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_46</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_46</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 44,981 - 45,928,\n (total: 948 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1108:ROK family protein (Score: 268.8; E-value: 1.3e-81)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_46 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00480.23 (ROK family): [3:310](score: 264.9, e-value: 1e-78)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_46\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_46_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCACGCCATTGGGATTGACATCGGCGGGACCAAGATCGCCGGTGCCCTCGTCGACGAATTCGGAACCATCATCAAGTCGGACCGCCGGCCCACCGAGGCGGCCGATCCGCGCGAGATCGAGGACGCCGTCGTCGAGATGATCGAGGGGCTCTCCGCCGGCGAGGACGTCGTGGCCGCCGGCGTGGCCGCCGCCGGCTTCATCGACGCCGCCCAGTCGACCGTCTACTACGCTCCCAACATCAACTGGCGCAACGAGCCGCTGCGCGAGAAGCTCGAGTCCCGCCTGTCGGTGCCCATCATCATCGAGAACGACGCCAACGCCGCCGGCTGGGCCGAGTTCTGCTTCGGCGCCGGGCGGCTCTACAGCGACATGGTGACCCTCACCATCGGCACCGGGGTGGGCGGGGCCATCGTCTCCCGCGACCGGTTGTTCCGCGGCGGCTTCGGCGTGGGCGCCGAGCTCGGCCACATGCGCGTCGTGCCGGACGGCCTGCCCTGCGGCTGCGGTGCGCACGGCTGCATCGAACAGTACGGCTCGGGCCGCGCGTTGTTGCGCATCGCCAACGAGTTCGCGGATGCCGGCGGCATCGGGCTGGGCCTGGCCGCGTCGCGCGCCAAGCGCGGCAAGCTCACCGGCAAGGATGTCGGCCGGTTCATCCAGGAGGGTGACCCCGGCGCCCTGGCGGCGCTCCGCCAGCTCGGCGCCTCCCTCGGCCAGGCCTGCGCCAGCCTGGCCGCGGTCCTCGACCCGCAGGTCTTCGTCTTCGGCGGCGGCGTGGCCGCAGCGGGCGAACTGCTGCTCGAACCCATCCGCAGCGCCTACCTGGACAACCTGCCGGCGCGGGGCTACCACCCCGAGGCCGAGTTCGCGATCGCAGAACTGGTCAACGATGCCGGAGTGGTCGGCGCCGCCGATCTCGCCCGCCGGCACGTGACCGGTGAGTAG",
      "translation": "MHAIGIDIGGTKIAGALVDEFGTIIKSDRRPTEAADPREIEDAVVEMIEGLSAGEDVVAAGVAAAGFIDAAQSTVYYAPNINWRNEPLREKLESRLSVPIIIENDANAAGWAEFCFGAGRLYSDMVTLTIGTGVGGAIVSRDRLFRGGFGVGAELGHMRVVPDGLPCGCGAHGCIEQYGSGRALLRIANEFADAGGIGLGLAASRAKRGKLTGKDVGRFIQEGDPGALAALRQLGASLGQACASLAAVLDPQVFVFGGGVAAAGELLLEPIRSAYLDNLPARGYHPEAEFAIAELVNDAGVVGAADLARRHVTGE",
      "product": ""
     },
     {
      "start": 45983,
      "end": 46672,
      "strand": 1,
      "locus_tag": "ctg14_47",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_47</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_47</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,983 - 46,672,\n (total: 690 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1141:acyltransferase (Score: 197.6; E-value: 2.9e-60)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_47 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01553.24 (Acyltransferase): [22:151](score: 87.3, e-value: 7.3e-25)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_47 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01553.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016746' target='_blank'>GO:0016746</a>: acyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_47\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_47_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTCTACTGGTTCATGAAGAATATTGTCGCCGGGCCGCTCCTGCTCGGCCTGTTCCGGCCGTGGGTGATCGGGCTCGAGAACATCCCCAAAGAGGGCGGCGTGGTGCTCGCGAGCAACCACCTCTCGTTCATCGACTCGGTCTTCCTGCCGCTCGTGGTGCCGCGCCGGGTCGTCTTCCTGGCCAAGAGCGAGTACTTCACCGGCACGGGCCTCAAGGGCTGGGCCACCCGTCAGTTCTTCAAGGCCACCGGCCAGCTGCCGATCGACCGGTCCGGCGGCAAGGCCTCAGAAGACTCCCTGAACACCGGGCTCGCGGTGCTGAATGCCGGGGGAGCGCTCGGCATCTATCCGGAGGGCACCCGCAGTCCGGACGCGCGCATGTACCGCGGTCGCACCGGCGTGGCGCGGATGGTGCTCGAGGCCGGTGTCCCCGTCGTCCCGGTGGCCATGATCGACACCGAGAAGGCCATGCCCACCGGAACCCGCATCCCGAAGGTGCGCCGGATCGGCATCGTGATCGGGAAGCCGTTGGACTTCAGCAGGTTCGAGGGAATGGAGGGCGACAGGTTCGTGTTGCGCTCCGTGACGGACGAGCTGATGTACGAACTGCGCCGCCTCAGCACGCAGGAGTACGTCGACGTCTATGCCACCAGCGTCAAGGAGAAGCGCGCCAGCCTTTCACGCTAG",
      "translation": "MFYWFMKNIVAGPLLLGLFRPWVIGLENIPKEGGVVLASNHLSFIDSVFLPLVVPRRVVFLAKSEYFTGTGLKGWATRQFFKATGQLPIDRSGGKASEDSLNTGLAVLNAGGALGIYPEGTRSPDARMYRGRTGVARMVLEAGVPVVPVAMIDTEKAMPTGTRIPKVRRIGIVIGKPLDFSRFEGMEGDRFVLRSVTDELMYELRRLSTQEYVDVYATSVKEKRASLSR",
      "product": ""
     },
     {
      "start": 46802,
      "end": 48145,
      "strand": 1,
      "locus_tag": "ctg14_48",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_48</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_48</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 46,802 - 48,145,\n (total: 1344 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_48 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01474.19 (Class-II DAHP synthetase family): [10:441](score: 648.7, e-value: 3.7e-195)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_48 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01474.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003849' target='_blank'>GO:0003849</a>: 3-deoxy-7-phosphoheptulonate synthase activity<br>\n  \n   PF01474.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009073' target='_blank'>GO:0009073</a>: aromatic amino acid family biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_48\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_48_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAGACACATCTGTAATCAACGGGCTGGACTATTGGCGCACCCTCCCCATCAAGCAGCAGCCGGCCTGGCCGGATGCCGACGCCGTCGCCGCGGCGTCCGCGGAGCTGGCCACCCAGCCGCCGCTGGTCTTCGCCGGCGAGGTCGACATCCTGCGCGACCGCCTGGCCCAGGCCGCCCGCGGCGAGGCCTTCCTGCTCCAGGGCGGTGACTGCGCCGAGACGTTCAGCGGCGCCACCGCCGAGCAGATCCGCAACCGGGTCAAGACGGTGCTGCAGATGGCCGTCGTCCTCACCTACGGCGCCTCCATGCCCGTCGTGAAGATGGGCCGCATGGCCGGACAGTTCGCCAAGCCCCGCTCCAGCGACTTCGAGACCCGCGGCGACGTCACCCTGCCCGCCTACCGCGGCGACATCGTGAACGGCTACGACTTCACCCCGGAGTCCCGCGAAGCGGACCCCGACCGGCTGGTCAAGGCGTACCACACGAGCGCCTCCACCCTCAATCTGATCCGCGCGTTCACGCAGGGCGGCTTCGCCGACCTCCGTCAGGTGCACAGCTGGAACCAGGGCTTCGCGAAGAACCCGGCCAACCAGCGCTACGAGGGCCTGGCCAAGGACATCGACCGCGCCATCAAGTTCATGATCGCCTGCGGCGCCGACTTCGAGGCCATGCGCCGCACGGAGTTCTACACCAGCCACGAGGGTCTGCTGATGGACTACGAGCGCCCCATGACGCGCATCGACTCCCGTACCGGCACGCCGTACAACACCTCGGCGCACTTCGTCTGGATCGGCGAACGCACCCGGGAGATCGACGGCGCCCACGTGGACTTCCTGTCCCGCGTGCGCAACCCCATCGGCGTCAAGCTCGGCCCGAGCACCTCGATCGACGACATGCTGCGCCTGATCGACAAGCTGGACCCGAACCGCGAACCCGGCCGGCTCACCTTCATCACCCGGATGGGCGCCGGCAAGATCCGCGACGCCCTTCCGCCCCTGCTCGAGGCGATCAAGGCCAGCGACGCGACACCGCTCTGGGTCACCGACCCGATGCACGGCAACGGCGTCACCACCCCCACCGGGTACAAGACCCGTCGCTTCGACGACGTCGTCGACGAGGTCAAGGGCTTCTTCGAGGCGCACCGCGCCGTCGGCACGCACCCGGGCGGCATCCACGTCGAGCTCACCGGAGACGATGTCACCGAGTGCCTCGGCGGATCGGAGCACATCGACGAGGCCGCCCTGGCGACCCGCTACGAGTCGCTCTGCGACCCGCGCCTGAACCACATGCAGTCGCTGGAGCTGGCGTTCCTGGTGGCCGAGGAACTGGCCGCCCGCTAA",
      "translation": "MADTSVINGLDYWRTLPIKQQPAWPDADAVAAASAELATQPPLVFAGEVDILRDRLAQAARGEAFLLQGGDCAETFSGATAEQIRNRVKTVLQMAVVLTYGASMPVVKMGRMAGQFAKPRSSDFETRGDVTLPAYRGDIVNGYDFTPESREADPDRLVKAYHTSASTLNLIRAFTQGGFADLRQVHSWNQGFAKNPANQRYEGLAKDIDRAIKFMIACGADFEAMRRTEFYTSHEGLLMDYERPMTRIDSRTGTPYNTSAHFVWIGERTREIDGAHVDFLSRVRNPIGVKLGPSTSIDDMLRLIDKLDPNREPGRLTFITRMGAGKIRDALPPLLEAIKASDATPLWVTDPMHGNGVTTPTGYKTRRFDDVVDEVKGFFEAHRAVGTHPGGIHVELTGDDVTECLGGSEHIDEAALATRYESLCDPRLNHMQSLELAFLVAEELAAR",
      "product": ""
     },
     {
      "start": 48225,
      "end": 50147,
      "strand": -1,
      "locus_tag": "ctg14_49",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_49</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_49</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 48,225 - 50,147,\n (total: 1923 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Pkinase<br>\n \n  regulatory (smcogs) SMCOG1030:serine/threonine protein kinase (Score: 260.6; E-value: 2.7e-79)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_49 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00069.28 (Protein kinase domain): [9:281](score: 174.0, e-value: 4.1e-51)<br>\n \n  PF03793.22 (PASTA domain): [369:430](score: 48.9, e-value: 4.6e-13)<br>\n \n  PF03793.22 (PASTA domain): [508:569](score: 46.5, e-value: 2.6e-12)<br>\n \n  PF03793.22 (PASTA domain): [574:633](score: 39.5, e-value: 4.1e-10)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_49 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00069.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004672' target='_blank'>GO:0004672</a>: protein kinase activity<br>\n  \n   PF00069.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00069.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006468' target='_blank'>GO:0006468</a>: protein phosphorylation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_49\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_49_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCGGCCGTCTCATCGACGGCCGCTATCAGGTGCGCTCCCGGATCGCCCGCGGCGGTATGGCCACCGTGTACCTCGCCACCGACCTGCGCCTGGAGCGTCGGGTGGCGATCAAGATCATGCACGGCCACCTGGCCGACGACAACGCGTTCCGCAGCCGCTTCATCCAGGAGGCCCGTTCGGCGGCCCGCCTGGCGCACCCGAACGTGGTGAACGTCTTCGACCAGGGCCAGGATGCCGACATCGCCTACCTAGTGATGGAACACCTGCCCGGCATCACGCTGCGCGACCTTCTCAAGGACTACGGCCGGCTCACGCCGGAGCAGACCATGGACATCCTCGAGGCCGTGCTGTCCGGTCTCGCCGCCGCCCACAAGGCCGGCATCGTGCACCGCGATGTGAAGCCCGAGAACGTGTTGCTGGCCGATGACGGCCGCATCAAGATCGGCGACTTCGGGCTGGCCCGGGCCGTGAACAACAACACCGCCACCGGCCAGGCGCTGCTGGGCACTGTCGCGTACCTCTCCCCCGAACTCGTCACCCGCGGCATCGCGGATGCCCGCAGCGACATCTACGCCCTCGGCATCATGACCTACGAGATGCTCACGGGCGAGCAGCCCTACGTGGGCGAGGCACCCATGCAGGTGGCCTACCAGCACGCCAATGACACCGTTCCGATGCCCAGCCTCGTCGCCCCCGGCGTGCCGCAGGAGCTGGACGAGCTGGTGCTCTGGGCCACGGCCCGCGACCCCGAAGAGCGTCCGCGCGACGCCCGGGTGATGCTGGACCAGCTCCTGGACGTGGAGAAAATGGTGCGGCCGCACGACCAGAGCGCCCTGCAGGCCACCATGGTGCTTCCGCGCGACACGGTCGCCGCATCGGCCGACGCCGAGACGCAGATCCTCGGGCGCGCCCCGCTGGCGCCCGCGGCCACCCTGGCCGCTCCGGCGCCGGAGGCCGACGAACCGGACAGCACCGACCAACTCGCCGGAACGGCACGGAAGCGCCGCCGCCGCGGCTACGGGCTGTTCGCGCTGATCGTGCTCCTGGCCGCCCTCGCGGGCGGTGCCGGCTGGTACTTCGGCGTCGGCCCCGGTTCGGAGATCGCCGTGCCCAGCCTGACCTCGGCCTCCCCCGAGGATGCGGCCGCGCAGTTGGAGGCTCTCGGACTCGTCGCGGCCACCGGCACGGCCTACAGCACCGAGATCCCCTCGGGGCTCGTGGTCGACACCGACCCGGGAGACGGGGCCCGGGTGGCCAAGGGCAGCACGGTGACCGTCAACGTGTCGCAGGGGCCCGCACCGATCGTGCTGCCGGTCCTGGCCGGCCTCACCCCGGATGCCGCCGCCACAGCCATCACCGATGCCCTGGCCGTTCCGGGCACGGCGGACGAGATCTTCTCGAACACGGTCAAGAAGGGTCTGGTCATCTCCGCCACCCGGGACAGCGACGGCGGCGACGTCTCGCAGGGCGGGGACTCCTTCGAGGGGGCGACCATCAACTACACGGTCTCCCTCGGCGACGTGACCGACGTCACCGGCGAGAGCCTCGACGATGCCATCGACACCCTCGCCGAGCAGGGCCTCGAGGGCCGCTCAGGGCCGGAGACCTACAGCGAGACCGTGGCCAAGGGCAAGGTCATCTCGGCCGCGCCGGCCAGCGGCGGGCCGCTCCGGCAGGGCTCCGTCATCACGCTCACGGTCTCCCGCGGACCCGAACCCGTCGAGGTGCCCGATGTGGTCGGCAAGGGCTGGTCGGACGCCAAGGCGATCCTGACCGACCTCGGTTTCAAGCTGAGCTACAACCCCGGCGCCGACGCCATCGCAGCCCTGCTGAGCGTGGACTCGACCGACCCCGTCGCCGGCACCTCGCTGCCCAAGGGCAGCACCATCACCCTGAAGCCGACGAACCCGTTCGGCTGA",
      "translation": "MIGRLIDGRYQVRSRIARGGMATVYLATDLRLERRVAIKIMHGHLADDNAFRSRFIQEARSAARLAHPNVVNVFDQGQDADIAYLVMEHLPGITLRDLLKDYGRLTPEQTMDILEAVLSGLAAAHKAGIVHRDVKPENVLLADDGRIKIGDFGLARAVNNNTATGQALLGTVAYLSPELVTRGIADARSDIYALGIMTYEMLTGEQPYVGEAPMQVAYQHANDTVPMPSLVAPGVPQELDELVLWATARDPEERPRDARVMLDQLLDVEKMVRPHDQSALQATMVLPRDTVAASADAETQILGRAPLAPAATLAAPAPEADEPDSTDQLAGTARKRRRRGYGLFALIVLLAALAGGAGWYFGVGPGSEIAVPSLTSASPEDAAAQLEALGLVAATGTAYSTEIPSGLVVDTDPGDGARVAKGSTVTVNVSQGPAPIVLPVLAGLTPDAAATAITDALAVPGTADEIFSNTVKKGLVISATRDSDGGDVSQGGDSFEGATINYTVSLGDVTDVTGESLDDAIDTLAEQGLEGRSGPETYSETVAKGKVISAAPASGGPLRQGSVITLTVSRGPEPVEVPDVVGKGWSDAKAILTDLGFKLSYNPGADAIAALLSVDSTDPVAGTSLPKGSTITLKPTNPFG",
      "product": ""
     },
     {
      "start": 50265,
      "end": 51623,
      "strand": -1,
      "locus_tag": "ctg14_50",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 50,265 - 51,623,\n (total: 1359 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_50 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01476.23 (LysM domain): [108:151](score: 37.0, e-value: 2.7e-09)<br>\n \n  PF01476.23 (LysM domain): [171:215](score: 42.4, e-value: 6e-11)<br>\n \n  PF01476.23 (LysM domain): [241:285](score: 37.4, e-value: 2.2e-09)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_50\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCGGTCAGAGCCAGCAAAATCGAATCGGGGACGGTCGCCGCCGACTCCCCCGGTGCTGACTCCCCCGTCGAGTCGGCGGTCGGCCGCCCGGCGGCCCGGCGCCGCCCGGCGAAGACCGGTGTGCGCCGATCCTGGGGCGCGGTGGCGAGCCTTCCCCTTGTCGTGGTGAGCACCATGGCCATCGTGTTCAACCTGGCCTCTCCCGCCCAGGCAGCGACGGCCCTGAAGAAGCCGTTGAAGAGCCGCACGACACTGCCGCAGTCGGCCGTCAAGCCGGTGCAGACCGTTCGGCCGGCCACGGCGACCCCCGCGCCGAACCAGTACACCGTCGTCGACGGGGACACCATCAGCGCCATCGCCGGCAAGTTCGGCCTCTCCACCGCCTCGGTCCTCGCCCTCAACGGCCTGGGCTGGACCGCCGTGATCTTTCCCGGCCAGGTCCTCACCCTCTCGACCTCCCCGGTCACGGCGGCCGCCGCGCCGGCAGCCGTCGCCAGCGAACTCACCCGGTACACCATCCGCTCCGGCGACACCCTGAGCGGGATCGCGGCCGCGAACGGCGTGAGCTCCGATGCCGTCTTCCGCGCCAACGGCCTCGGCCGGGACAGCATCATCTTCCCCGGCCAGACCATCGTGCTGCCCGCCGCCGGGTCCTCGGCCGCCGTGGCCGGTGGGGCGCAGATCTCCCTCGCCTCGGCCTCGTCGGCCACGCCGGGCAGCCACACCGTGGTCGCCGGCGACACCGTCGACAAGGTCGCCGGTGCTGCCGGCGTCTCGGTGCAGTCGGTTCTGGAGGCGAACGGCCTGGGCTGGTCGAGCGTCATCCACCCCGGCCAGGTCCTGAAGATCCCCGGCGCCGCGACTGTTCTCGACGCTGCCCCTGCCGTCGTCGTGACCCCGAACACGCCCGCGACGCCCGCACCGACGGCCGTGCGCGACACCGTGACACCCCTCACCTCGGAGATGGCCGCGAACGCCCGGCTCATCATCGCCGTCGGTCGGCAGGCCGGGGCGAACGATGCCGCCCTCGTCATCGCCCTCGCCGCCGCCGCCCAGGAATCGGGCCTGCGCAACATCGATTACGGCGACCGGGATTCGCTCGGGCTCTTCCAGCAGCGCCCGAGTTCCGGCTGGGGAACCGCCGAGCAGGTCATGGACGCCGAGCGTGCCAGCCGCGCCTTCTTCGGCGGCCCGGTCAACCCCAACCCGGGCGTCACCCGCGGGCTGCTGGACATCCCGGGCTGGGAGAGCATGACGGTCACGCAGGCCGCCCAGGCCGTGCAGATCTCCGCCTACCCCGACTACTACGCCAAGTGGGAGACCTCCGCGCGGAGCTGGCTCGCCGAACTCGGCTGA",
      "translation": "MPVRASKIESGTVAADSPGADSPVESAVGRPAARRRPAKTGVRRSWGAVASLPLVVVSTMAIVFNLASPAQAATALKKPLKSRTTLPQSAVKPVQTVRPATATPAPNQYTVVDGDTISAIAGKFGLSTASVLALNGLGWTAVIFPGQVLTLSTSPVTAAAAPAAVASELTRYTIRSGDTLSGIAAANGVSSDAVFRANGLGRDSIIFPGQTIVLPAAGSSAAVAGGAQISLASASSATPGSHTVVAGDTVDKVAGAAGVSVQSVLEANGLGWSSVIHPGQVLKIPGAATVLDAAPAVVVTPNTPATPAPTAVRDTVTPLTSEMAANARLIIAVGRQAGANDAALVIALAAAAQESGLRNIDYGDRDSLGLFQQRPSSGWGTAEQVMDAERASRAFFGGPVNPNPGVTRGLLDIPGWESMTVTQAAQAVQISAYPDYYAKWETSARSWLAELG",
      "product": ""
     },
     {
      "start": 51796,
      "end": 52164,
      "strand": 1,
      "locus_tag": "ctg14_51",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 51,796 - 52,164,\n (total: 369 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_51 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF18367.4 (Rv2175c C-terminal domain of unknown function): [68:122](score: 74.9, e-value: 4.4e-21)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_51\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACCGATTCGTCTTCCGCACCGCAGCAGTCCGTTCCTTCCTCCACCCCCGAGTGGTACTCCATCCCCGACCTCGTCGAGGTCCTCGGGATCAGCCACAGCCGGGTGCGCCAGCTCATCGAAGACAAGCACCTGCTCGCCGTCCGGCGCGACGGCCGGGTCAGTGTTCCCGCGTCCTTCATCCGCGACGGGGCGCCGCTGGGCGAGCTCCGCGGCACTCTCATCGTGCTCTCCGATGACGGGTTCACCGACGAGCAGGCCATGGAGTGGCTGCTCGAGGTGGACGACAGCCTCGGCGTTCCCCCCATCGACGCGCTGCTGGCCGGACGCAAGGCCGAGGTTCGGCGCGTGGCCCAGGCCCTGGCCTGA",
      "translation": "MTDSSSAPQQSVPSSTPEWYSIPDLVEVLGISHSRVRQLIEDKHLLAVRRDGRVSVPASFIRDGAPLGELRGTLIVLSDDGFTDEQAMEWLLEVDDSLGVPPIDALLAGRKAEVRRVAQALA",
      "product": ""
     },
     {
      "start": 52246,
      "end": 53253,
      "strand": -1,
      "locus_tag": "ctg14_52",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 52,246 - 53,253,\n (total: 1008 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1182:Polyprenyl synthetase (Score: 227.8; E-value: 2.6e-69)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_52 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00348.20 (Polyprenyl synthetase): [5:283](score: 158.3, e-value: 2e-46)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_52 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00348.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_52\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_52_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCTGGTGGACTTCTCACGGCAGTTTCTCAGCGGCGGGAAGCGCTTCCGGGCCCAGTTCGCACACCTCGGTTGGCAGAGCGTCCCGGCCCCCATTGCGGCCGAGCCGGACGGGGTCTCCGCCGGTCTGGCCGGACTGGTCTCCGCGGCCTCCGCCCTGGAGGTTTTCCACGCGGCCGCCCTCGTCCACGACGACATCATCGACAATTCGGACACCCGCAGAGGCGCTCCGTCCGCGCACCGCCGCTTCGAAAGTCTGCACGGCGCCAACGGGTGGGCGGGCAGCCCAGCCGACTTCGGCCGGGCCTCGGCGATCCTGCTCGGCGACCTCCTGCTCGGCTGGAGCGACGAGCTGCTCGACGACGGCCTCGACGGCGCGGCCGACCGGGTGAGCGCCCGGCGTGCGCGCGCCGAATTCAACCGCATGCGCACCGAGGTCACGGCGGGCCAGTATCTGGACATCCTCGAGGAGCGGGCCTGGCTCACCCAGCCGGAGTCCGAGCTCCTCGACCGCGCGGTGCGGGTCATCGTCTTCAAGTCCGCCAAGTACAGCGTGCAGGCCCCGCTGGTGATCGGCGCAGCCCTGGCCGGCGCGGACGACGCCCAGCTCGACGTCCTGCGGGCGTTCGGCCTGCCGCTCGGCATCGCCTACCAGCTTCGTGACGATCTGCTCGGGGTCTTCGGCGATGCCGCCGTCACGGGCAAGCCCAGCGGAGACGACCTGCGGGAGGGCAAGCGCACCGTGCTGATCGCGCTGGCGCGGGAGAACCTGGACGCTGTGGCCCTGGGCACCGTCGACCGTCTGCTCGGGCGCCCCGACCTCACGCCGGAGCAGATCTCGTCACTGCAGCAGATCATCGTCGACAGCGGCGCCGTCGACAGGGTCGAGACCCTGATCCAGCAGAACGTGGCCCAGGCTCTCGCCGCGCTGGACGGTTCCCGCGTCGAACAGGGCGTTCTGAACGCCCTGACCGACTTCGCCGGCACGGTCACCCGCCGGGTCTTCTAA",
      "translation": "MLVDFSRQFLSGGKRFRAQFAHLGWQSVPAPIAAEPDGVSAGLAGLVSAASALEVFHAAALVHDDIIDNSDTRRGAPSAHRRFESLHGANGWAGSPADFGRASAILLGDLLLGWSDELLDDGLDGAADRVSARRARAEFNRMRTEVTAGQYLDILEERAWLTQPESELLDRAVRVIVFKSAKYSVQAPLVIGAALAGADDAQLDVLRAFGLPLGIAYQLRDDLLGVFGDAAVTGKPSGDDLREGKRTVLIALARENLDAVALGTVDRLLGRPDLTPEQISSLQQIIVDSGAVDRVETLIQQNVAQALAALDGSRVEQGVLNALTDFAGTVTRRVF",
      "product": ""
     },
     {
      "start": 53429,
      "end": 53809,
      "strand": 1,
      "locus_tag": "ctg14_53",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_53</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_53</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 53,429 - 53,809,\n (total: 381 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_53 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF11239.11 (Protein of unknown function (DUF3040)): [0:79](score: 88.1, e-value: 3.7e-25)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_53\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCGCTTTCAGAACAAGAGCAGCGACTCCTCGAAGAGATGGAGCGCAGTCTCTATCACAACGATGCCGAATTCGTGGCGAGCGTCGGGGGCACGCGTCTCCGCCCCAATTACCGATCGATAGTCCTCGGGGTGCTCGCGGGCGTCGTGGGGATCGCGACTCTTGTGGCCGGTGTTGCGGTGCAGCAGCTCTGGTTGGGCATCATCGGATTCATCATCATGTTCGGCGGCGTGCTCCTGGCCATCACGCCGGGTCGCACCGCCCGGGCGACGCGGCCGTCGTCCTCCCAGGCCCGCCGCCCCGCGCAGGCACGCAGTCAGCAGGGCTTCATGGACAAGTTGAACGACCGCTGGGACCGTCGCCAGGACGGCCAGCAGTAA",
      "translation": "MPLSEQEQRLLEEMERSLYHNDAEFVASVGGTRLRPNYRSIVLGVLAGVVGIATLVAGVAVQQLWLGIIGFIIMFGGVLLAITPGRTARATRPSSSQARRPAQARSQQGFMDKLNDRWDRRQDGQQ",
      "product": ""
     },
     {
      "start": 54179,
      "end": 54610,
      "strand": 1,
      "locus_tag": "ctg14_54",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_54</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_54</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 54,179 - 54,610,\n (total: 432 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_54 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02381.21 (MraZ protein, putative antitoxin-like): [0:69](score: 60.4, e-value: 1.4e-16)<br>\n \n  PF02381.21 (MraZ protein, putative antitoxin-like): [71:137](score: 65.7, e-value: 2.9e-18)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_54\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTCCTCGGGACCTATGCCCCCAAGCTCGACGAAAAAGGACGCGTCATCCTGCCGGCCAAATTCCGCGACGAACTCTCGACCGGCATCGTGATGACCCGCGGCCAGGAACGGTGCCTCTACGTCTTCACCACGCGTGACTTCGACGAGGTGAACGAGAAGATCCGCCAGGCGCCCATCACCAGCAAGGAGGGGCGCGACTTCTTCCGCGTCTTCCTGTCGGGAGCCAGCGCCGAAACACCCGACAAGCAGAACCGCGTCAGCATCCCGGCCAACCTCAGGGCCTACGCCGGACTCGACCGTGACCTGACGGTCATCGGCGTGGGCAACCGCGTGGAGATCTGGGACACCGAGGTCTGGGACGCGTACCTCACCGAGCAGGAAACCTCGTTCGCCAACATCACGGAGGAGGTGATTCCGGGACTCTTCTAG",
      "translation": "MFLGTYAPKLDEKGRVILPAKFRDELSTGIVMTRGQERCLYVFTTRDFDEVNEKIRQAPITSKEGRDFFRVFLSGASAETPDKQNRVSIPANLRAYAGLDRDLTVIGVGNRVEIWDTEVWDAYLTEQETSFANITEEVIPGLF",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 14041,
      "end": 54778,
      "tool": "",
      "neighbouring_start": 14040,
      "neighbouring_end": 54779,
      "product": "CC 1: neighbouring",
      "kind": "candidatecluster",
      "prefix": "",
      "height": 0
     },
     {
      "start": 14041,
      "end": 34948,
      "tool": "",
      "neighbouring_start": 14040,
      "neighbouring_end": 34949,
      "product": "CC 2: single",
      "kind": "candidatecluster",
      "prefix": "",
      "height": 1
     },
     {
      "start": 27444,
      "end": 54778,
      "tool": "",
      "neighbouring_start": 27443,
      "neighbouring_end": 54779,
      "product": "CC 3: single",
      "kind": "candidatecluster",
      "prefix": "",
      "height": 2
     },
     {
      "start": 24040,
      "end": 24949,
      "tool": "rule-based-clusters",
      "neighbouring_start": 14040,
      "neighbouring_end": 34949,
      "product": "terpene",
      "category": "terpene",
      "height": 4,
      "kind": "protocluster",
      "prefix": ""
     },
     {
      "start": 37443,
      "end": 44779,
      "tool": "rule-based-clusters",
      "neighbouring_start": 27443,
      "neighbouring_end": 54779,
      "product": "betalactone",
      "category": "other",
      "height": 6,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [
      {
       "start": 26589,
       "end": 26591,
       "strand": 1,
       "containedBy": [
        "ctg14_30"
       ]
      },
      {
       "start": 29633,
       "end": 29635,
       "strand": -1,
       "containedBy": [
        "ctg14_34"
       ]
      }
     ],
     "bindingSites": []
    },
    "type": "betalactone,terpene",
    "products": [
     "terpene",
     "betalactone"
    ],
    "product_categories": [
     "terpene",
     "other"
    ],
    "cssClass": "hybrid",
    "anchor": "r14c1"
   }
  ]
 },
 {
  "length": 74444,
  "seq_id": "NODE_30_length_74444_cov_27.391262",
  "regions": []
 },
 {
  "length": 73760,
  "seq_id": "NODE_31_length_73760_cov_25.362377",
  "regions": []
 },
 {
  "length": 73151,
  "seq_id": "NODE_32_length_73151_cov_22.608657",
  "regions": []
 },
 {
  "length": 71977,
  "seq_id": "NODE_34_length_71977_cov_28.263352",
  "regions": []
 },
 {
  "length": 71078,
  "seq_id": "NODE_36_length_71078_cov_25.486373",
  "regions": []
 },
 {
  "length": 67076,
  "seq_id": "NODE_38_length_67076_cov_29.227003",
  "regions": []
 },
 {
  "length": 66680,
  "seq_id": "NODE_39_length_66680_cov_26.426723",
  "regions": []
 },
 {
  "length": 62991,
  "seq_id": "NODE_41_length_62991_cov_29.708825",
  "regions": []
 },
 {
  "length": 62586,
  "seq_id": "NODE_42_length_62586_cov_23.308420",
  "regions": []
 },
 {
  "length": 58628,
  "seq_id": "NODE_45_length_58628_cov_30.085430",
  "regions": []
 },
 {
  "length": 57811,
  "seq_id": "NODE_46_length_57811_cov_26.951519",
  "regions": []
 },
 {
  "length": 54771,
  "seq_id": "NODE_47_length_54771_cov_27.915530",
  "regions": []
 },
 {
  "length": 53854,
  "seq_id": "NODE_48_length_53854_cov_26.648846",
  "regions": []
 },
 {
  "length": 52734,
  "seq_id": "NODE_49_length_52734_cov_28.170538",
  "regions": []
 },
 {
  "length": 51924,
  "seq_id": "NODE_50_length_51924_cov_24.099080",
  "regions": []
 },
 {
  "length": 51507,
  "seq_id": "NODE_51_length_51507_cov_28.350846",
  "regions": []
 },
 {
  "length": 50658,
  "seq_id": "NODE_53_length_50658_cov_24.716811",
  "regions": []
 },
 {
  "length": 49876,
  "seq_id": "NODE_55_length_49876_cov_25.020884",
  "regions": []
 },
 {
  "length": 49617,
  "seq_id": "NODE_56_length_49617_cov_28.769883",
  "regions": []
 },
 {
  "length": 49462,
  "seq_id": "NODE_57_length_49462_cov_29.027458",
  "regions": []
 },
 {
  "length": 46936,
  "seq_id": "NODE_58_length_46936_cov_25.860283",
  "regions": []
 },
 {
  "length": 46916,
  "seq_id": "NODE_59_length_46916_cov_24.695617",
  "regions": [
   {
    "start": 17644,
    "end": 46916,
    "idx": 1,
    "orfs": [
     {
      "start": 17673,
      "end": 18467,
      "strand": 1,
      "locus_tag": "ctg36_19",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,673 - 18,467,\n (total: 795 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 233.3; E-value: 5e-71)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_19 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00005.30 (ABC transporter): [30:189](score: 114.2, e-value: 6.7e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_19 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00005.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_19_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSDTTVGGVAFDVPMVLAEQVTKSFGSHEVLKGITLEVKRGEVMCLVGPSGSGKSTFLRCINHLEVLSAGRLSVDGELIGYREANGKLYEMAPKEAAKQRRDIGMVFQRFNLFPHMTALQNVMEAPLRVKGLPKAQVERTARDLLARVGLADRADYYPAHLSGGQQQRVAIARALAMEPKLMLFDEPTSALDPELVGEVLDVMKALAKEGMTMIVVTHEMGFAREVADSLVFMDAGVVVESGLPSEVLANPRHARTQAFLSKVL\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGACACGACAGTGGGGGGCGTCGCATTCGACGTGCCGATGGTGTTGGCCGAGCAGGTGACCAAGAGCTTCGGCTCGCACGAGGTGCTCAAGGGCATCACCCTCGAGGTCAAGCGCGGTGAGGTGATGTGCCTGGTCGGGCCCTCGGGCTCCGGCAAGTCCACGTTCCTGCGCTGCATCAACCACCTCGAGGTGCTCTCGGCCGGCCGGCTCAGCGTGGACGGCGAACTGATCGGCTACCGCGAGGCGAACGGCAAGCTCTACGAGATGGCGCCGAAGGAAGCGGCCAAGCAGCGCCGCGACATCGGCATGGTCTTCCAGCGCTTCAACCTGTTCCCGCACATGACCGCGCTGCAGAACGTGATGGAGGCGCCGCTGCGCGTCAAGGGCCTGCCCAAGGCGCAGGTCGAACGCACCGCGCGCGACCTGCTCGCCCGGGTGGGGCTGGCCGACCGGGCCGACTACTACCCGGCGCACCTCTCCGGCGGTCAGCAGCAGCGGGTGGCCATCGCCCGGGCGCTGGCCATGGAGCCCAAGCTGATGCTCTTCGACGAGCCCACCAGCGCGCTCGACCCCGAGCTCGTCGGCGAGGTGCTCGACGTGATGAAGGCCCTGGCCAAGGAGGGCATGACCATGATCGTGGTCACCCACGAGATGGGCTTCGCCCGTGAGGTCGCCGACTCCCTGGTCTTCATGGACGCCGGCGTCGTCGTCGAATCCGGCCTCCCCTCGGAGGTCCTGGCGAACCCGCGGCACGCCCGCACCCAGGCGTTCCTCTCCAAGGTGCTTTAA",
      "translation": "MSDTTVGGVAFDVPMVLAEQVTKSFGSHEVLKGITLEVKRGEVMCLVGPSGSGKSTFLRCINHLEVLSAGRLSVDGELIGYREANGKLYEMAPKEAAKQRRDIGMVFQRFNLFPHMTALQNVMEAPLRVKGLPKAQVERTARDLLARVGLADRADYYPAHLSGGQQQRVAIARALAMEPKLMLFDEPTSALDPELVGEVLDVMKALAKEGMTMIVVTHEMGFAREVADSLVFMDAGVVVESGLPSEVLANPRHARTQAFLSKVL",
      "product": ""
     },
     {
      "start": 18548,
      "end": 18925,
      "strand": -1,
      "locus_tag": "ctg36_20",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,548 - 18,925,\n (total: 378 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_20 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13564.9 (DoxX-like family): [6:112](score: 86.6, e-value: 1.1e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACATCGCCATCTGGATCATCACCGGTCTGCTCGCCCTCGCCTTCATCGGTGCCGGGATCATGAAGGTGGCCCAGCCGCGCGCCAAGCTCGCCGCGAGCGGCATGGCCTGGACCAACGACTTCTCGGATACGGGCGTCAAGCTCGTCGGCCTCGCCGAACTGCTCGGCGGGCTCGGGCTGATCCTTCCCGCGGTCACCGGCACAGCGCCCATCCTCGTGCCCATCGCCGCGGCCGCCCTCACCGTGATCATGATCGGCGCGGTCGTCTGGCACGTGCGCGCCGGCGACGGCGCCAAGGAGACCATGCCCAGCGTGATCCTCGGCATCCTGTCTCTCGTCGTGGCCATCACCCGCTTCGGCCCCTGGGCGTTCTAG",
      "translation": "MNIAIWIITGLLALAFIGAGIMKVAQPRAKLAASGMAWTNDFSDTGVKLVGLAELLGGLGLILPAVTGTAPILVPIAAAALTVIMIGAVVWHVRAGDGAKETMPSVILGILSLVVAITRFGPWAF",
      "product": ""
     },
     {
      "start": 19047,
      "end": 19523,
      "strand": 1,
      "locus_tag": "ctg36_21",
      "type": "regulatory",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,047 - 19,523,\n (total: 477 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1135:MarR family transcriptional regulator (Score: 78.3; E-value: 7.1e-24)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_21 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01047.25 (MarR family): [40:99](score: 46.7, e-value: 2.4e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_21 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01047.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity<br>\n  \n   PF01047.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_21_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGAACCGGAGTGGCTGACCCCCGTGGAGCACGACGCCTGGATGGCCCTGGCGGAGGTGTTGTTCCTGCTGCCGGCCAGGCTCGAGTCGCAGTTGCAGCGGGACGATGGGCTCGCGATGGCGGACTACATGGTGCTGGTGATGCTCTCCGAACGGGACGACCACAGCATGCGCATGAGCGACCTGGCGACCTCGGCGAGCACGTCGCAGTCGCGGCTGTCACGCATCGTGGCCCGGCTCGAGGCCGCGGGGTATGTGACCCGGGAGATGGCACCGGATGATCGCCGTGCGGTGATCGCGACCCTCACCGAGCCGGGCCTGGCCAAGTTAGTCGCCGCGGCGCCGGGCCACGTCGCCCAGGTGCGCCGCCTGGTCTTCGATCGCCTCACGCCCGCCCAGGTTCTCTCGCTCACCGAGGTCGCCCGCGCCCTCGCGCACCCCGACGACCCCGCCGCCTGCGACGGGGCTCCCTAG",
      "translation": "MAEPEWLTPVEHDAWMALAEVLFLLPARLESQLQRDDGLAMADYMVLVMLSERDDHSMRMSDLATSASTSQSRLSRIVARLEAAGYVTREMAPDDRRAVIATLTEPGLAKLVAAAPGHVAQVRRLVFDRLTPAQVLSLTEVARALAHPDDPAACDGAP",
      "product": ""
     },
     {
      "start": 19793,
      "end": 23869,
      "strand": -1,
      "locus_tag": "ctg36_22",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,793 - 23,869,\n (total: 4077 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_22 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13245.9 (AAA domain): [25:138](score: 25.4, e-value: 1.4e-05)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [229:361](score: 40.5, e-value: 3.2e-10)<br>\n \n  PF04408.26 (Helicase associated domain (HA2)): [487:547](score: 40.8, e-value: 2.3e-10)<br>\n \n  PF07717.19 (Oligonucleotide/oligosaccharide-binding (OB)-fold): [625:702](score: 67.0, e-value: 1.5e-18)<br>\n \n  PF11898.11 (Domain of unknown function (DUF3418)): [715:1357](score: 674.6, e-value: 1.4e-202)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_22 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04408.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004386' target='_blank'>GO:0004386</a>: helicase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_22\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_22_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTCCCGTGAAAATCACCTTCCCGCCCGAGTTGCCGATCAGCCAGCGCCGCGACGACATCGCGCGCGCCATCCGCGACAACCAGGTCGTGATCGTGGCCGGGTCCACCGGTTCGGGCAAGACCACGCAGCTGCCCAAGATCTGCCTGGAGCTCGGCCGGGAGTCGATCGGGCACACCCAGCCACGCCGGCTCGCCGCGCGCACCATCGCCGAGCGCATCGCCGAGGAACTCGGCCAGGAGGTGGGCGAACTCGTCGGCTACCAGGTGCGCTTCACCGACCGCGTCGGCGCCGACACCCGCATCAAGCTGATGACCGACGGCATCCTGCTCAACGAGATCCACCGCGACCGGATGCTGCGCAAGTACGACACCATCATCATCGACGAGGCGCACGAGCGCAGCCTCAACATCGACTTCCTGCTCGGCTACCTGCAGCAGCTGCTCCCCCAACGGCCCGACCTCAAGCTGATCATCACGTCGGCCACCATCGACCCGGCCAGCTTCGCGAAGCACTTCGCGGCCGCCGACGGCACCCCGGCGCCCATCATCGAGGTCTCCGGCCGCACCTACCCGGTCGAGATCCGCTACCGCCCGCTCGTGGCCGAGGCCGCGATCGACGACGATGACGAGATCTCGGATGCCGCGCCCAGCGTCGACCGCGACTACATCGAGGGCATCTCCGCCGCGCTCGACGAGCTCGAGCGGGAGTCCAACGGCGACGTGCTCGTGTTCCTCTCCGGCGAGACCGAGATCCGAGACGCCGCCGACGCGCTGCAGGGCAAGTTCTCCGGCGGCGGCAACACCAGCCCCACCGAGGTGCTGCCGCTCTACGGCCGGCTCTCCTCCGCCGACCAGCACAAGGTGTTCCAGCCTTCCACCGTGCCCGGGGTGCGCCGCCGCATCGTGCTGGCCACCAACGTGGCCGAGACCAGCCTCACCGTTCCGGGCATCCGTTACGTCATCGACGCCGGCACCGCCCGCATCAGCCGCTACAGCGTGCGCTCGAAGGTGCAGCGGCTGCCCATCGAGGCCATCGCGCAGGCCTCCGCCAACCAGCGCTCGGGCCGGTCCGGCCGCACCAGCGACGGCGTCGCCATCCGCCTGTACAGCGAAGAGGACTTCACCCGCCGGCCCGAGTACACCGAGCCGGAGATCCTGCGCACCAACCTGGCCGCGGTCATCCTGCAGATGATCTCCCTGGGCCTGGGCGACATCGCCCAGTTCCCGTTCCTCACGCCGCCGGACTCGCGCAACATCAAGGACGGCCTCGACCTGCTCACCGAGCTCGGCGCGGTCAAGGCCGTCGTGGCTCCCACCGGCACGCCCACCGAAGACCCGAGTCAGGCCGGTGCTCGCGAGAACGGCCGCTCCGGTCGCGATGGCGGGCGTGGCCGCGGCGGCCGTGACGGCCGTGAGGGCAACCGTGGCGGCGGGCGGATGACCGTGACGGCCGGCACGCACAGCCTCACCCGGGTGGGCCAGCAGCTTGCCCAGCTGCCCATCGATCCCCGGTTCGGCCGCATGGTGATCGAGTCGAAGACGCAGGGCACCAGCCGGGAGGTGATGGCCATCGTGGCCGGCCTCACCATCCAGGACGTGCGCGAGCGTCCGCTCGAGCGCCGCGGTTCCGCCGACGAGAAGCACGCCCGGTTCGCCGACCCCACCAGCGATTTCCTCTCGCTGCTCAACCTCTGGAACTACCTCGAGACGCAACAGAAGGAACTCGGCTCCAGCGCTTTCCGGCGCCTGTGCAAGAACGAGTACCTCAATTACCTGCGGGTGCGCGAGTGGCAGGACGTCTACAAGCAGCTCCGCCAGTTGGCCAAGCCGCTCGGACTGCACATCGGCGACCCGAGCGTGAACCCCGACGGCATCCACCGGTCGATGCTCTCCGGCCTGCTCTCCCACATCGGTCTGAAGGACGTGGCGAAGAAGGACTACATCGGCGCCCGGCAACAGCGCTTCGTGCTGTTCCCCGGCTCGGCGCTGGCCAAGAAGCAGCCCAACGCCGTGATGAGCGCCGAGCTGGTGGAGACCAGCCGGCTGTTCGCCCGGATGAACGCCGTCGTCGACCCGGCCTGGGCCGAACAGCTCGCCGGCGACCTCTGCAAGCGCAGCTACTCCGAGCCGCACTGGGAGAAGAAGCAGGGCGCCGTGGTCGCCTACGAGCGGGTCACCCTCTACGGGGTGCCGATCGTGCCGCGCCGCCGGGTGCAGTTCTCCCGGGTGGATCCAGCCTATGCGCGCGAGCTGTTCATCCGGCACGCCCTCGTCGACGGCGAGTGGGACCTCGACCGGGTCGACCAGCGGGTCACCGCGTTCGACCGGGCCAACACGGCGCTCCGCAAGGAGCTCGCCGAGCTGGAGGAGCGCACCCGGCGCCGCGACATCCTCTTCGACGACGAGGCCGTCTTCGAGTTCTACCACCGCCGCATCCCCGCCGAGGTGCACAGCACCCGCACCTTCGAGACCTGGTGGCGGGTCGCCCGCGCGAAGACGCCCGACCTGCTCACCATGACCGCCGAGGCGCTCGTGCCCGAGGATGCGCCGGAGATCGACGAGTCGCTGTTCCCGCCGTCCTGGCAGCAGCGCGACCAGCGCTTCGCGCTGAGCTACCGGTTCGAGCCCGGTGCGGAGGACGACGGCGTCACCGTGCAGGTGCCTCTCGCCCTGCTTGCGCGGGTCTCCCCCACCGGTTTCGACTGGCAGGTGCCGGGCCTCCGCGCAGACCTCGTCACCTCGCTGATCAAGTCGCTGCCCAAGGCCATCCGCCGCAACGTGGTGCCCGCCGCAGACTGGGCCGTGCGCCTGCTCGCCGAGCTGCCGCCCGCCCCCGGTGTGGTGCGTTCGTCGGTCGAGCCTGTCGAGACCTCGCGAGGTGCCTCGAATCGCGCCCACTCGTCGGTCGAGCCTGTCGAGACCTCGCGGGGTGCCTCGAATCGCTCCAACGCTCACGGGGACTCGGCCGACCCCTCCTTCGCCGAAACCCTCGCCGCCCTCATCCAGCGCCTCACCTACGTGCCCGTCACCGTGCGCGACTTCGACCTCTCCCGGGTCCCCGCGCACCTGCGCATGACCTTCCGGGTCGTCGACGAGCACGGCAAGAGCGTCGCCAGCGGCAAGGACCTCGGCGACCTGCAGCGGCGCCTCGGCAACAAGGTGCGCGAGTCCGTCGCCAAGGCCTCCGCCGCCGTGCCCACGAACGCCATCGAGCGCAGCGGCCTCACCACCTGGGACTTCGTCGAGCTGCCCCGCTTCATCGACACCAAGCAGGGTGACAACACCATCCGCGGTTACCCCACGCTGATCGACGACGGCGCCTCGGTGAGCATCCGCCTGATGAGCACCGCCGAGGAACAGGCCCGCACCCTGCCCCACGGGGTGCGCCGGCTGCTGCTGCTCGCGACCCCGTCGCCCGTGGCCTATGTGCAGCAGCACCTCACGGGCGGCGAGAAGCTCTCGCTGGCCACGAGCCCGTACCGGTCCACCCAGGCCCTGTTCGACGACTGTCTCGCCGCCGCCGTCGATGACGTGCTCTACCGGGTGCGCCCCGACGGCCAGGTGTTCATGAAGGCCGAGTTCGACACCATCCGCGACCGGGTCTCGGGCGTGGTGATGGACTCGATGTTCGAGACCGTCGGCCTCGTCGCCCGCATCCTCACCGCGTCGCGCGCGGCCGACAAGGCGCTCAAGGCCTCCACCAGCATGGCCCTGCTGGCCGCTCTCACGGATGCCCGCGAGCAGCTGAACGGGCTGGTCCACCCGGGTTTCGTCAGCGCCACCGGCCTCGCCCAGCTGCGGCACCTGCCGCGCTACCTCGGCGGCATCACGGCCCGCATCGACAAGCTCCTCGACAACCCCAACCGCGACCGGGTGTGGATGAACGAGGTGCAGTCCGCCACGGCGAAGTTCACCGACGCCGGTGGGCGCATCCCGCTGCCGGCGGATGCGGCGGCGAACCTGGTGCGCGCCCGCTGGATGATCGAGGAGCTGCGCATCAGCCTCTTCGCCCAGGAGCTGCGCGCCGCCGAGTCCGTCTCCCTCCAGCGCATCCAGAAGGTCCTCGCCTCCTAG",
      "translation": "MIPVKITFPPELPISQRRDDIARAIRDNQVVIVAGSTGSGKTTQLPKICLELGRESIGHTQPRRLAARTIAERIAEELGQEVGELVGYQVRFTDRVGADTRIKLMTDGILLNEIHRDRMLRKYDTIIIDEAHERSLNIDFLLGYLQQLLPQRPDLKLIITSATIDPASFAKHFAAADGTPAPIIEVSGRTYPVEIRYRPLVAEAAIDDDDEISDAAPSVDRDYIEGISAALDELERESNGDVLVFLSGETEIRDAADALQGKFSGGGNTSPTEVLPLYGRLSSADQHKVFQPSTVPGVRRRIVLATNVAETSLTVPGIRYVIDAGTARISRYSVRSKVQRLPIEAIAQASANQRSGRSGRTSDGVAIRLYSEEDFTRRPEYTEPEILRTNLAAVILQMISLGLGDIAQFPFLTPPDSRNIKDGLDLLTELGAVKAVVAPTGTPTEDPSQAGARENGRSGRDGGRGRGGRDGREGNRGGGRMTVTAGTHSLTRVGQQLAQLPIDPRFGRMVIESKTQGTSREVMAIVAGLTIQDVRERPLERRGSADEKHARFADPTSDFLSLLNLWNYLETQQKELGSSAFRRLCKNEYLNYLRVREWQDVYKQLRQLAKPLGLHIGDPSVNPDGIHRSMLSGLLSHIGLKDVAKKDYIGARQQRFVLFPGSALAKKQPNAVMSAELVETSRLFARMNAVVDPAWAEQLAGDLCKRSYSEPHWEKKQGAVVAYERVTLYGVPIVPRRRVQFSRVDPAYARELFIRHALVDGEWDLDRVDQRVTAFDRANTALRKELAELEERTRRRDILFDDEAVFEFYHRRIPAEVHSTRTFETWWRVARAKTPDLLTMTAEALVPEDAPEIDESLFPPSWQQRDQRFALSYRFEPGAEDDGVTVQVPLALLARVSPTGFDWQVPGLRADLVTSLIKSLPKAIRRNVVPAADWAVRLLAELPPAPGVVRSSVEPVETSRGASNRAHSSVEPVETSRGASNRSNAHGDSADPSFAETLAALIQRLTYVPVTVRDFDLSRVPAHLRMTFRVVDEHGKSVASGKDLGDLQRRLGNKVRESVAKASAAVPTNAIERSGLTTWDFVELPRFIDTKQGDNTIRGYPTLIDDGASVSIRLMSTAEEQARTLPHGVRRLLLLATPSPVAYVQQHLTGGEKLSLATSPYRSTQALFDDCLAAAVDDVLYRVRPDGQVFMKAEFDTIRDRVSGVVMDSMFETVGLVARILTASRAADKALKASTSMALLAALTDAREQLNGLVHPGFVSATGLAQLRHLPRYLGGITARIDKLLDNPNRDRVWMNEVQSATAKFTDAGGRIPLPADAAANLVRARWMIEELRISLFAQELRAAESVSLQRIQKVLAS",
      "product": ""
     },
     {
      "start": 23956,
      "end": 24612,
      "strand": 1,
      "locus_tag": "ctg36_23",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,956 - 24,612,\n (total: 657 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_23\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGATGACCTCAGAACCCCCGCCACAGACCTCGACGAGCCCCTGGGTGACCCGCGCGAGATGCTCGCACTGCTCGAAAAGCAGCAGCGCCAGGTGACGGATGCGCAGATCGCGCCCGTCGTCTGGCTCTACTTCATCTGGGGCATCGCCTGGTTCGTGGGCTTCCTCGCCCTCTGGTCGGGCGACGCCGACGGCAACCCCTGGTTCGCGATTCCGGCCGGGGTGGCGACACCGCTGTTCGTCGTGCTGCTGGTCATCTCGATCGTGTCCTCCGCCGTGATCGGTATGCGGATCAACCGGGGGGTGCGCGGAATCTCCAGCTTCTCCGGCGCCGTCTACGGGTTGTCCTGGTCGGTCTGCGGAACCGCGTTCGCGATGCTCGGGGTCGGCCTTATTCGCCAGGGTCTCTCCCCAGAACTGGCCAACCTCTACTTCCCGTCCGGCTATGCGCTGATGTGCGGAACCATCTACCTCGGCGGCGCGGCCCTCTGGCGCGACAAATCCCAGCTCATCCTCGGCCTGATCATGCTCACCGTCGGTGCGGCCGCCCCGTTCGCCGGTTCGCCTGGCAACGACCTGGTCTTCGCCCTCGCCGGCGGTGGTGCCTTCCTGGTTACCTCCGCCGTCATGGCCGTGCGGCTGCGCCGGAACCGCTGA",
      "translation": "MDDLRTPATDLDEPLGDPREMLALLEKQQRQVTDAQIAPVVWLYFIWGIAWFVGFLALWSGDADGNPWFAIPAGVATPLFVVLLVISIVSSAVIGMRINRGVRGISSFSGAVYGLSWSVCGTAFAMLGVGLIRQGLSPELANLYFPSGYALMCGTIYLGGAALWRDKSQLILGLIMLTVGAAAPFAGSPGNDLVFALAGGGAFLVTSAVMAVRLRRNR",
      "product": ""
     },
     {
      "start": 24612,
      "end": 24908,
      "strand": 1,
      "locus_tag": "ctg36_24",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,612 - 24,908,\n (total: 297 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_24 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13601.9 (Winged helix DNA-binding domain): [12:94](score: 76.7, e-value: 1.2e-21)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_24\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_24_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACGAACTCGACCCGGTGATCCACGCATCCGCGCGGCTCAAGATCACTGCTACGTTGGCCACGCTGCCGGTGGGCGACCAGATCGCCTTTCCCCGCCTCCAGGAACTGCTCGGCATGACCGCCGGCAACCTGTCTACACATCTGCGCAAGCTCGAAGACGCCGGCTATGTCGACGTCGTGAAGTCGCACCAGGGCCGCACCCCGGCCACGTACCTCGCGCTGTCCCGTTCGGGCCGACGCGCCTTCGAGGACTATCTGGAAGCCCTCCGTGCACTGTTGGGAGAATCCGCATGA",
      "translation": "MDELDPVIHASARLKITATLATLPVGDQIAFPRLQELLGMTAGNLSTHLRKLEDAGYVDVVKSHQGRTPATYLALSRSGRRAFEDYLEALRALLGESA",
      "product": ""
     },
     {
      "start": 24905,
      "end": 25912,
      "strand": 1,
      "locus_tag": "ctg36_25",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,905 - 25,912,\n (total: 1008 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 181.7; E-value: 2.9e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_25 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00005.30 (ABC transporter): [20:156](score: 97.9, e-value: 7.5e-28)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_25 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00005.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_25\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_25_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMTVLARLDHVSRRFGEVLAVDDVTLDIHSGSILGLLGPNGAGKSTVLTMLQGLRKPSSGTVSLFGGSPGDYRMRQKLGGTPQETALPPTLRVGEVIDFVGRHFEEPLTTAAVAEEFGLEELLKRQTGALSGGQKRRLSVALAFVGQPSLVLLDEPTTGLDVDARRTLWDAVRRQHDRGATVVVTSHYLEEIEALAERVVVMGHGRVIADDTVAAVINQVSLRQVRLVTDQPDRVSGLPGVVGRDRGDDGSTTFYANDSDRLIVELVRSGIPFTDLTVRGATLEEAFLTLTGATDAATGQPARPPHDAEPLETADVRTRTGSAPSAVPAVQKEMNR\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGTTCTGGCCCGGCTCGATCACGTCAGCCGCCGCTTCGGCGAGGTGCTCGCCGTCGACGATGTCACCCTCGACATCCACTCCGGCAGCATCCTGGGCCTGCTCGGGCCCAACGGTGCCGGCAAGTCCACCGTGCTCACCATGTTGCAGGGGCTGCGGAAGCCGAGCTCCGGCACGGTCTCGCTGTTCGGCGGGTCGCCCGGCGACTACCGGATGCGCCAGAAGCTCGGCGGCACCCCGCAGGAGACGGCCCTGCCGCCCACCCTGCGCGTGGGCGAGGTCATCGACTTCGTCGGCCGGCACTTCGAGGAGCCGCTGACCACCGCGGCCGTGGCGGAGGAATTCGGGCTGGAGGAGCTGCTCAAGCGGCAGACCGGCGCGCTCTCCGGCGGCCAGAAGCGCCGGCTCAGCGTGGCGCTCGCGTTCGTCGGCCAGCCCAGCCTGGTGCTGCTCGACGAGCCCACCACCGGGCTCGACGTGGATGCCCGCCGCACCCTGTGGGACGCCGTGCGCCGGCAGCACGACCGCGGCGCCACCGTGGTGGTGACCAGCCACTACCTCGAGGAGATCGAGGCGCTGGCCGAACGTGTCGTGGTGATGGGGCACGGGCGGGTGATCGCCGACGACACTGTCGCGGCGGTGATCAACCAGGTCTCACTGCGCCAGGTGCGCCTGGTCACCGACCAGCCCGACCGGGTGAGCGGGCTGCCCGGCGTGGTCGGCCGCGACCGGGGCGACGACGGCAGCACGACCTTCTACGCCAACGACAGCGACCGGCTGATCGTCGAGCTGGTGCGCTCGGGCATCCCGTTCACCGACCTCACCGTGCGCGGCGCCACCCTCGAAGAGGCGTTCCTCACCCTCACCGGGGCGACGGATGCGGCCACCGGGCAACCGGCGCGGCCCCCGCACGATGCCGAACCACTCGAGACCGCCGACGTGCGAACCCGCACCGGCTCGGCCCCGTCTGCTGTGCCCGCCGTCCAGAAGGAGATGAACCGATGA",
      "translation": "MTVLARLDHVSRRFGEVLAVDDVTLDIHSGSILGLLGPNGAGKSTVLTMLQGLRKPSSGTVSLFGGSPGDYRMRQKLGGTPQETALPPTLRVGEVIDFVGRHFEEPLTTAAVAEEFGLEELLKRQTGALSGGQKRRLSVALAFVGQPSLVLLDEPTTGLDVDARRTLWDAVRRQHDRGATVVVTSHYLEEIEALAERVVVMGHGRVIADDTVAAVINQVSLRQVRLVTDQPDRVSGLPGVVGRDRGDDGSTTFYANDSDRLIVELVRSGIPFTDLTVRGATLEEAFLTLTGATDAATGQPARPPHDAEPLETADVRTRTGSAPSAVPAVQKEMNR",
      "product": ""
     },
     {
      "start": 25909,
      "end": 26736,
      "strand": 1,
      "locus_tag": "ctg36_26",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_26</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_26</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,909 - 26,736,\n (total: 828 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_26 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01061.27 (ABC-2 type transporter): [38:232](score: 28.8, e-value: 8.3e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_26 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01061.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0140359' target='_blank'>GO:0140359</a>: ABC-type transporter activity<br>\n  \n   PF01061.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_26\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCACCCTCACCCCCACCCCGGCCGGCACCGCCCCCGGAACCGGGAGCCGCGTCCCGGCTCTCGGCGGGAGGACGGGCATCCTCGCCCTCACCTTCGTGCACGCCCGCATCAACCTCGTCGAGACGTTCCGCATCCCGGCCGCCCTGATCGGGTCGCTCGTCTTTCCCGGGCTGTCGCTGCTGTTCTTCGTGGTGCCGCAGCGCACCGTGGCCGACAACCCGGAGTTCGCCACCCAGGCGGTGATCGCGTTGAGCGTGTTCGCGCTGATGTCGAACTCGCTGTTCAGCTTCGGCCTGAACATCTCCGCCAACCGCGAGCAGCCCTGGGACCCGTACCTGCGCACCCTGCCGGTACCGGGCGTCTCCCGGGTGCTCGGCCAGATCTTCTCGACCGGCCTGATGGGGCTGGTCTCGATCCTGCCGGTGATCGCGATCGGTGCCCTGTTCACGGCGGCAGAGGCATCCGTTCTCGGTGTTCTCGGCGGGCTGGTGGCGCTGGGCATCTCGGCGCTGCCGTTCATGTTCATCGGCATCTCGATCGGCTACTCGATGTCGTCCAAGGCGGCGATCGCGGTGGTGCAGATCGTGATGTTCGCCCTGGCGTTCGCGGGCGGGCTGTTCCTGCCGCCGTACCTCTTCGCCGACTGGCTCGACACGCTGTCGAAGTTCCTGCCCTCCCGGCAGGCTCGGGAGTTCGTGATCTGGGCCGTGCAGGGCGGCGAGCTCGAGCCGTGGGTGTGGATCGGCATTCTGGTCTGGACCGCGGTGACCTTCGCCCTGGCCTTGCGGCTCTTCCGCCGCGACGAGGGCCGACGGTACCACTAG",
      "translation": "MSTLTPTPAGTAPGTGSRVPALGGRTGILALTFVHARINLVETFRIPAALIGSLVFPGLSLLFFVVPQRTVADNPEFATQAVIALSVFALMSNSLFSFGLNISANREQPWDPYLRTLPVPGVSRVLGQIFSTGLMGLVSILPVIAIGALFTAAEASVLGVLGGLVALGISALPFMFIGISIGYSMSSKAAIAVVQIVMFALAFAGGLFLPPYLFADWLDTLSKFLPSRQAREFVIWAVQGGELEPWVWIGILVWTAVTFALALRLFRRDEGRRYH",
      "product": ""
     },
     {
      "start": 26914,
      "end": 27747,
      "strand": 1,
      "locus_tag": "ctg36_27",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_27</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_27</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,914 - 27,747,\n (total: 834 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1039:aldo/keto reductase family oxidoreductase (Score: 227.4; E-value: 3.7e-69)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_27 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00248.24 (Aldo/keto reductase family): [24:264](score: 163.2, e-value: 7.5e-48)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_27\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_27_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGAATTCTGTACCCCTCATCACCCTGAACGACGGCCACACCATCCCGCAGCTCGGCTTCGGTGTCTTCCAGGTCGACCCGACCGAGACCACTCGCATCGTGACCGACGCGCTCGAGGTGGGCTACCGCCACATCGACACCGCTGCCATCTACGGCAACGAAGAGGGTGTGGGCCAGGCACTGGCCTCCTCCGGCATCGACCGTTCCGAGCTCTTCATCACGACGAAGCTCTGGAACGACAAGCAGGGCACGCAGTCGGCGCTGGATGCGTTCGACGTGAGCCTGGAGAAGCTCGGCCTGGACTACGTCGACCTCTACCTCATCCACTGGCCGGCGCCCGCGAACGACAAGTTCGTGGAGAGCTGGAAGACCCTCGAGAAGATCCGCGAGTCGGGCCGTGCCCGCTCCATCGGCGTCTCGAACTTCCTGGTGCCCCAGTTGGAGCGTCTGCTCGCCGAGACCGACGTCGTGCCCGCGGTCAACCAGATCGAGCTGCACCCCGCCCTCCAGCAGACCGAGCTGACCACCTTCGCGCGCGAGCAGGGCATCCACATCGAGGCCTGGGGACCGCTCGGCCAGGGCAAGTACCCGCTGCTCGAGGAGGACGTCGTGCTCGCCGCCGCCGAAGCACACGGCAAGACCCCCGCGCAGGTGGTCATCCGCTGGCACCTGCAGAGCGGCAACATCGTCTTCCCCAAGTCGAACCGCCGCGAGCGGATGGCCGAGAACTTCGACGTTCTCGACTTCGAGCTCAGCCACACCGAACTCGCCACGATCACGGCGCTCGAGCGCGGCGGCCGGGTCGGCTCGCACCCCAACGACGTCAACTAG",
      "translation": "MTNSVPLITLNDGHTIPQLGFGVFQVDPTETTRIVTDALEVGYRHIDTAAIYGNEEGVGQALASSGIDRSELFITTKLWNDKQGTQSALDAFDVSLEKLGLDYVDLYLIHWPAPANDKFVESWKTLEKIRESGRARSIGVSNFLVPQLERLLAETDVVPAVNQIELHPALQQTELTTFAREQGIHIEAWGPLGQGKYPLLEEDVVLAAAEAHGKTPAQVVIRWHLQSGNIVFPKSNRRERMAENFDVLDFELSHTELATITALERGGRVGSHPNDVN",
      "product": ""
     },
     {
      "start": 28080,
      "end": 28661,
      "strand": 1,
      "locus_tag": "ctg36_28",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_28</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_28</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,080 - 28,661,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_28 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03358.18 (NADPH-dependent FMN reductase): [5:149](score: 100.4, e-value: 8.5e-29)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_28 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03358.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_28\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_28_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCGTACACCCTGAACGTCGTCGCCGTCTCCGGCAGCCTGCACGCGCCCTCGAAAACCACCGCGCTGGTGCGGGCGATCCTCGCCGCGCTCGAGCGCGAACTGTCGATCGATGTGCACCTGATCGAGCTCAGCCAGGTGGGCCGGGAGTTCTCCGGGGCGCTGCGCCGGGACGAGCTGTCCGCCGCGGCCGAGGCCGACCTCAAGCGCATCGAGGGCGCCGACCTGCTCATCGTGGCGTCGCCCGTCTACCGGGCCTCGTTCACGGGCCTGTTCAAGCACGTCTTCGACTTCGTCGACCAGTACTCGCTCGTCGACAAGCCCGTGCTGCTGGCCGCGACCGGGGGCAGCGACCGGCACGCCCTCATTCTCGAGCACCAGTTCCGGCCGCTGTTCAGCTTCTTCCAGGCGCTCACCCTGCCCATCGGTGTGTACGCCAAGGACGCCGACTTCACGAACTACGTGGTGACCAGCGACGAGCTGAACGACCGCATCGACCAGGCCATCCGCCGCGGCCTGCCGCTCGTGCGGGCGAGCCTGCCGGCGGTGCTCTCCGCGGACTCCGCCGCGATCGTCTGGTGA",
      "translation": "MSYTLNVVAVSGSLHAPSKTTALVRAILAALERELSIDVHLIELSQVGREFSGALRRDELSAAAEADLKRIEGADLLIVASPVYRASFTGLFKHVFDFVDQYSLVDKPVLLAATGGSDRHALILEHQFRPLFSFFQALTLPIGVYAKDADFTNYVVTSDELNDRIDQAIRRGLPLVRASLPAVLSADSAAIVW",
      "product": ""
     },
     {
      "start": 28713,
      "end": 29411,
      "strand": 1,
      "locus_tag": "ctg36_29",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_29</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_29</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,713 - 29,411,\n (total: 699 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_29 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04973.15 (Nicotinamide mononucleotide transporter): [30:218](score: 169.2, e-value: 9.3e-50)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_29 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04973.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0034257' target='_blank'>GO:0034257</a>: nicotinamide riboside transmembrane transporter activity<br>\n  \n   PF04973.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0034258' target='_blank'>GO:0034258</a>: nicotinamide riboside transport<br>\n  \n   PF04973.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_29\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGAACCATCCGGGAGAGAAGTATCGCTGTGTCCCTGATCACCTGGTTGTTCGACGCCCAACTCCACATCGGCACCCAGACCATCCTCTGGCGGGAGATCATCGGCAACGTCTTCGGCATCGCAAGCGCCGTCGGCGGGATGCGCCGCAAGCTCTGGGCCTGGCCCGTGGGCATCATCGGCAACGCGCTGCTCTTCACGGTGTTCCTCGGCGCCGTCTTCGGCACCCCCAACCCGGTGAACCTGCTCGGCCAGGCCGGGCGCCAAATCATGTTCATCGTGGTGTCCATCTACGGCTGGGTGCAGTGGTCGCGCAGCCGCTCCACCGGCGCGGTCGCCGTGGCCCCGCACTGGGCGGGCACCCGCGCGCGCATCGGCCTCGGTGTGGGCCTGATCGCCGGCACCCTCGTGCTCACGCCGATCTTCCGGGCGCTCGGTTCGTTCGAACCGGTCTGGGCGGATGCCTGGATCTTCACCGGATCGCTGCTGGCCACCTACGGCATGGCCCGGGGTTGGACCGAATTCTGGCTGATCTGGGTGGCCGTCGACATCGTGGGGGTGCCTCTGCTGATCAGCGCCGGCTACTACGCCTCGGCCGTCCTCTACCTCTTCTACGGCGCGTTCACTATCACCGGGTTCGTGATCTGGGCCCGCGTGCAACGCCGCCGGCAGCTCCTCCCCGAGGGTGCGGCGGTCTGA",
      "translation": "MRTIRERSIAVSLITWLFDAQLHIGTQTILWREIIGNVFGIASAVGGMRRKLWAWPVGIIGNALLFTVFLGAVFGTPNPVNLLGQAGRQIMFIVVSIYGWVQWSRSRSTGAVAVAPHWAGTRARIGLGVGLIAGTLVLTPIFRALGSFEPVWADAWIFTGSLLATYGMARGWTEFWLIWVAVDIVGVPLLISAGYYASAVLYLFYGAFTITGFVIWARVQRRRQLLPEGAAV",
      "product": ""
     },
     {
      "start": 29511,
      "end": 30218,
      "strand": -1,
      "locus_tag": "ctg36_30",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_30</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_30</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,511 - 30,218,\n (total: 708 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_30\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATGACCCTCGCCGAAGCCGCGGCCTTGCTCGAGGTCGCGGTCGATGCGCATCCCGAGCAGGTCGAACGCGCCTACCGCTACCAGGCCCAGCGATCGCACCCGGACCGGATGACCTCGGCCAGTCCGGCGGAGCTCGCCGCCGCCGCTGCCCGGTTCGACAGGTTCACCCAGGCGCGCGCGCTGCTGCGCGAGGCCGACGCCGAGCGGATGCGCCCCGCCGCCGACGCATCGCCGGGGCACCCTGCCGCGTCGGGCGCATCCGCTGCACCGGGCCGGCGGCCGGCCGACAGCTCCGCCTGGGCGGATCCGAACTGGGCGGCCGACGAGCCCTACGAACCTGCGCTACCGGCCGGGCCGTGGCTGTTCTGGGTGTGGACGGGCCTGTTCGTGCTCGCGGCCGGGATCTCGTACCTCGGCGGGCCGCTGCCGCAATCGGCGGCGGACCTGTGGCTGCGGGTAGTGCCGCTCGGGCTGGCCAGCGTGGCCTTCGCCCGCACGGGCCGGCCGGTGTTCCTCGCTGGAGTCCTGGTGTTCGGGGCGGCGACGGCGGTGCTCACCGTGCTGTTCGCGTCGTTCGGTCCGCTCGTGACGCTGCAGTTGCTCATCGCGCCCGTGCTGGGGCTCGTGGCGCTCGGCCGGCCCAAGCAGCTGCGCCGCCGCCTCGGCCCGGTCGCGCCGGCTCCCCCGCCGCGTCCCGCCGCCTGA",
      "translation": "MMTLAEAAALLEVAVDAHPEQVERAYRYQAQRSHPDRMTSASPAELAAAAARFDRFTQARALLREADAERMRPAADASPGHPAASGASAAPGRRPADSSAWADPNWAADEPYEPALPAGPWLFWVWTGLFVLAAGISYLGGPLPQSAADLWLRVVPLGLASVAFARTGRPVFLAGVLVFGAATAVLTVLFASFGPLVTLQLLIAPVLGLVALGRPKQLRRRLGPVAPAPPPRPAA",
      "product": ""
     },
     {
      "start": 30215,
      "end": 30307,
      "strand": -1,
      "locus_tag": "ctg36_31",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_31</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_31</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,215 - 30,307,\n (total: 93 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_31\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGAGCTGGGCACTGGTTCCGGGCAGCCGCACGACTTCCGAGGCGCACTCCCGGCACGGCGCGGCCGGCCGGATCGAGCGCCGTCGATGA",
      "translation": "MKSWALVPGSRTTSEAHSRHGAAGRIERRR",
      "product": ""
     },
     {
      "start": 30538,
      "end": 32424,
      "strand": 1,
      "locus_tag": "ctg36_32",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_32</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_32</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,538 - 32,424,\n (total: 1887 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_32 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03190.18 (Protein of unknown function, DUF255): [1:163](score: 222.3, e-value: 3.4e-66)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_32\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_32_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGAATCGCCTCGCCGACGCCATCAGCCCGTACCTGCGCTCGCACGCCGAAAACCCGGTGGACTGGCAGCCCTGGGGCGCGGCCGCGTTCGACGAGGCCCGCGCCCGCGACGTGCCGGTGCTGGTGTCGATCGGCTACTCCACCTGCCACTGGTGCCACGTCATGGCCCGCGAGAGTTTCAGTGATCCTGCGATCGCCGCCTACCTCAACGAGCACTTCGTGAGCATCAAGGTGGACCGCGAGGAGCACCCCGACGTCGATGCCAGCTACCTCGCCGCCGCCGGAGCCTTCACGCAGAACCTCGGCTGGCCGCTCAACGTGTTCGTCACCCCGGCCGGCCGGCCGTTCTACGCCGGCACCTATTCCCCGCCCGCGCCGCTGCCCGGGCATCCGGCGTTTCGCGAGGTGCTCGCCGCCGTGACGGATGCCTGGACCACCCGCCGCGACGCCGTGGAGGACAGCGCCGCCGGGCTGGCCGAGGCCCTCGCCCAGGCCGCGCCCGCCGCGGGGGCCGGGGAGCTGCCCGGCCAGGACCGGCTCGCCGAGACCGTGGACCTGCTCGCGACCGCCGAAGACCCGGTCTACGGGGGTTTCGGCACCGCCCCCAAGTTTCCGGCCTCACCCACCCTGGCGCTGCTGCTCGACCGTGCCGACGGACGCGACCTGGCCCTGCGCACCCTCAAACGGCTGGGCGCGACGCCGCTCCGCGACCCCGTCGAGGGCGGGTTCTTCCGGTACGCCGTCAACCGGGACTGGAGCGAACCGCACTACGAGCGGATGCTCTACGACAACGCCCAGCTGCTCGAGCTGTACACCCGGGCGTGGATGCTCACCGGCGAAGCCTGGGCCCGGCTGGTGAGCGAGGGGCTGGTGCGGTTCCTCGGCGCGGTGCTGCAGCTGCCGGACGGCGGATTCGCCAGCGCCCAGGACTCGGAGAGCACCGTGGACGGGGTGCGTGTGGAGGGCGGCTACTACGCCCTCGACGAGGACAGCCGCCATGACCAGGTGCCGCCGGCCCTGGACACCAAGATGCTCACCGGCTGGAACGGTCTTGCGATCGGCGCCCTCGCGCTCGCCGGGTCGGCCTTCGGCGACGACACCGCGCTCAGCCTGGCCCGCCGGGCGGCGGACCGGCTGCTGCAGCTGCACCGGCGGGACGACGGCGCCCTGGTGCGCGCCTCCATCGACGGCCGGCTCTCGACCGCCGTGGCCACGCTCGAGGACTACGGGATGTTCGCCGGCGGTCTGCTCGACCTTGCGACCGCCACCGGCGAGGTGCGCTACGCCGTCGCGGCGCGCGACCTCGTCGACCGCACCCTGCCCGGCCCGGCACCGGCCGGTTTCGCCGCGCCGGAGGGCGCCGATCCGGTGCTCACCGGCCACGGCCTCGACCTGGCGACCGACCCGTCCGAGGGCGCCTATCCCTCCGGGCTCAGCGCCATCGCCGCCGCGGCCTGGCGGCTCTACCTGCTCACCGGCAGCACCCGGTACCGGGAGGCGGCGACGGCGGCCATGGTGCGGCTGGTCGGAACCGGAACGCTCAACCCACTCGCGTTCGGCGCCGCCCTGCGCCTGGTGGACGCGCTCACCTCGCCGGTTCGGCAGCTCGTGGCGGTCACCCCGGAGACGCCGGCGGGCACCCGCGCCGGCGAACCCGAGAGCGGTGGCACGCCATCCGCCGCCTCGCCCGGCAGCCTGGTCGGCGCCGCCCGGCGCCGGAGCGGCCTCGTGGCCGTCGTCACCGAAGACCAGGGCCGCGCCTGGGCGGCGGCCGGCTTCGACCTCTTCGCCGACCGCGGCGTGCGCGACGGCCGGCCCACCGCCTACCAGTGCCGGGATTTCGTCTGCCGGCTGCCCGTCACGGAGCCCGCAGACCTGGCCTGA",
      "translation": "MTNRLADAISPYLRSHAENPVDWQPWGAAAFDEARARDVPVLVSIGYSTCHWCHVMARESFSDPAIAAYLNEHFVSIKVDREEHPDVDASYLAAAGAFTQNLGWPLNVFVTPAGRPFYAGTYSPPAPLPGHPAFREVLAAVTDAWTTRRDAVEDSAAGLAEALAQAAPAAGAGELPGQDRLAETVDLLATAEDPVYGGFGTAPKFPASPTLALLLDRADGRDLALRTLKRLGATPLRDPVEGGFFRYAVNRDWSEPHYERMLYDNAQLLELYTRAWMLTGEAWARLVSEGLVRFLGAVLQLPDGGFASAQDSESTVDGVRVEGGYYALDEDSRHDQVPPALDTKMLTGWNGLAIGALALAGSAFGDDTALSLARRAADRLLQLHRRDDGALVRASIDGRLSTAVATLEDYGMFAGGLLDLATATGEVRYAVAARDLVDRTLPGPAPAGFAAPEGADPVLTGHGLDLATDPSEGAYPSGLSAIAAAAWRLYLLTGSTRYREAATAAMVRLVGTGTLNPLAFGAALRLVDALTSPVRQLVAVTPETPAGTRAGEPESGGTPSAASPGSLVGAARRRSGLVAVVTEDQGRAWAAAGFDLFADRGVRDGRPTAYQCRDFVCRLPVTEPADLA",
      "product": ""
     },
     {
      "start": 32819,
      "end": 34534,
      "strand": 1,
      "locus_tag": "ctg36_33",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_33</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_33</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,819 - 34,534,\n (total: 1716 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_33 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17101.8 (Stealth protein CR1, conserved region 1): [209:237](score: 35.5, e-value: 6.4e-09)<br>\n \n  PF11380.11 (Stealth protein CR2, conserved region 2): [247:352](score: 131.6, e-value: 1.3e-38)<br>\n \n  PF17102.8 (Stealth protein CR3, conserved region 3): [397:444](score: 65.0, e-value: 4.7e-18)<br>\n \n  PF17103.8 (Stealth protein CR4, conserved region 4): [473:521](score: 52.9, e-value: 2.8e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_33 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF11380.11: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016772' target='_blank'>GO:0016772</a>: transferase activity, transferring phosphorus-containing groups<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_33\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_33_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCCATCCTCTCGCTGAGCAGCGAACCCGAACCGGTGCTGCTCTCCCTCGACGAGCGCACCCGCCGTTTCGACCGCGACGACGTCGTCGTGCGCAAGGGCGAGATCGCCTTGATCAACGGGCACTTCACCCCGCACGAGTCCATGGTCAGCGACCTGCTCGCCCTGAGCGCCGCGCTCGACAACGCCGGCATCGAGTACTTGCTCGTGCGCGGCGACCACGACCGCCCGGTCATCGCGGTCAACCGCAAACGGCGCAAGCAGATCAGCAAGATCCTGAGCAGCGCCTTCTCCGACACCCCGTTCTACATCAAGCCGCTCGACAACGACGAGGCCCGGGCCGGCCTGCTCGCCGACGGCGCCCTCGCCCAACTGCGCAAGTCCGATGTCTTCCGCGCATACCAGCCGCGCATCGAACCCATCGGCCGGCTCCGCTACGGCGCCGAGACCGCCTTCCAGCTCGAGCTGTGGACCTTCGGCGAAGACGAGATCATCGCCCCCGTCGAGAACGTGCTGATGCGCAAGCGCCTGCCCCGCTCCGAGGCGCGGGAGACCACGGTGGAGCTGTTCGGCCGCAGCTGGCGCACCCTGCAGAACATGTTCGACGACCTGGTCAGCGACATCAGCTTCGACATCGACCTGGTCTTCTCCTGGGTCGACGGGTCCTCCACCGACTTCCAGAAGGCCCGCGCCGCCCGCATGAAGTCCTACGTGGTGGGCGAGGGCGACGACTCGGATGCCCGTTTCCGGCAGATCGACGAACTCAAGTACGCCCTGCGCAGCGTGTACATGTTCGCGCCGTGGGTGCGACGCATCTTCATCGCCACCGACTCGCCGGCCCCCGAATGGCTGGTCGAGCACCCCCGGGTGACCATCATGAACAGCGAAGACTTCTTCCCCGACACCAGCGGGCTGCCCACCCACAACTCGCACGCCGTGGAGAGCCAGCTGCACCACATCCCGGGGCTCGCGGAGCACTTCATCTACTCCAACGACGACATGTTCTTCGGCCGCCCGGTGGGCCCGGAGCTGTTCTACTCGCCCGGCGGCATCACCAAGTTCATCGAGGCGGCGACCCGCATCGGCCTGGGCGACAACGACCCCAGCCGCAGCGGGTTCGAGAACGCCGCCCGGGTCAACCGGGCCCTGCTGCGCGAGCGGTTCGGCAAGGTGACCACCCGGCACCTCGAGCACACCCCTGCGCCCCTGCGCAAGAGCGTCATGCAGGAGATGGAGGCGGAGTTCCCCGAGGACTTCACCCGCACCATGAAGAGCCGGTTCCGCTCCGCCACCGACATCTCGGTGACGAACTCGCTGTACCACTACTACGCCCTGGCCACCGGCCGGGCGGTGGAGCAGACCCAGGCGCGGTCGCTCTACGTGGAGACCACCCTCAAGCTGGCGCTGCGCCAGATGAGCAAGCTGCTCAAGCGCCGCGACCAGGACATGTTCTGCCTCAACGACGGCAGCTTCCCCGAGATCTCCGACGAGGTGCGCACCGAGGCCGTCACTGACTTCCTCGAGCGCTACTTCCCGATCGTGGCTCCGTGGGAACGCGAAAGCGTCATCGCGGAGAGCCAGCACGGCGAGGACACCCTCATCGAGAGCGTCCTCGGCACCGGCTCCGCCGCGATGGCGGCCGACGTCAGCGCAGAACCGGGATCGGCCTGGTCATTGGGGGCTCGCGGTACGCGGGCAGAGACCCAGCAGGCATGA",
      "translation": "MPILSLSSEPEPVLLSLDERTRRFDRDDVVVRKGEIALINGHFTPHESMVSDLLALSAALDNAGIEYLLVRGDHDRPVIAVNRKRRKQISKILSSAFSDTPFYIKPLDNDEARAGLLADGALAQLRKSDVFRAYQPRIEPIGRLRYGAETAFQLELWTFGEDEIIAPVENVLMRKRLPRSEARETTVELFGRSWRTLQNMFDDLVSDISFDIDLVFSWVDGSSTDFQKARAARMKSYVVGEGDDSDARFRQIDELKYALRSVYMFAPWVRRIFIATDSPAPEWLVEHPRVTIMNSEDFFPDTSGLPTHNSHAVESQLHHIPGLAEHFIYSNDDMFFGRPVGPELFYSPGGITKFIEAATRIGLGDNDPSRSGFENAARVNRALLRERFGKVTTRHLEHTPAPLRKSVMQEMEAEFPEDFTRTMKSRFRSATDISVTNSLYHYYALATGRAVEQTQARSLYVETTLKLALRQMSKLLKRRDQDMFCLNDGSFPEISDEVRTEAVTDFLERYFPIVAPWERESVIAESQHGEDTLIESVLGTGSAAMAADVSAEPGSAWSLGARGTRAETQQA",
      "product": ""
     },
     {
      "start": 34464,
      "end": 35402,
      "strand": -1,
      "locus_tag": "ctg36_34",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_34</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_34</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,464 - 35,402,\n (total: 939 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Metallophos_2<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_34 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00149.31 (Calcineurin-like phosphoesterase): [15:209](score: 63.1, e-value: 5.6e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_34 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00149.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_34\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGCATTCGAACGGCCGAATACCCCAGGCCGGATTATTTCCTTCTCCACCTCAGTGACACGCACCTGCTCGCAGACGGTAACCGTCTGTACGGCAGCGTCGACAGTGCCGCACACGTGCAACGGTTGTTTGCGGATGTGGAGGCGTCGGGCAGCAGGCCGGACGCCATCATCATCACCGGCGACCTGGCCGACAAGGGCGAACCACATGCCTACGCGCAGCTGCGCGACATCGTGGAACCCGCGGCCGCACGCATCGGCGCCAAGGTGCTCTGGGTGATGGGCAACCACGACAACCGGGCGAACTTCCGCACCGAGTTGCTCGGCCAGGAGCCCAGCCTCGCCCCGATCGACCACGTCGACTATGTCGGCGGGCTGCGCATCATCACCTTCGACACCACCGTTCCGGGCAGCCACTACGGTGAGATCTCCGATCGCCAGCTCGAATGGCTCAGCGAGCAGCTGAGCTTCCCGGCGCCGGACGGCACCATTCTGGCCATGCACCACCCGCCCGTGCCGAGCATGCTCGACCTGTCGGTGGCGGTGGAGCTGCGCGACCAGGCCAGCCTCGCGCAGGTGCTGCGCGGCACGGATGTGCGCAGCATCCTGGCCGGGCACCTGCACTACTCGTCCACCGCGACCTTCGCCGGCATCCCCGTGTCCGTGGCCTCGGCCACCTGCTACACGCAGGACCTCAACGTTCCCGTCGGGGGCACCCGGGGCCGCGACGGCGCCCGGGCGTTCAACCTCGTGCACGTCTACGCGGACACCGTGCTGCACTCGGTGGTGCCGCTGGGCGAATACGAGGCGCTGGACTACATCGACGCGGCCGAAAGCGCCCGCCGCTTGGCCGCATCCGGCATCGAGATCATGCCTGCTGGGTCTCTGCCCGCGTACCGCGAGCCCCCAATGACCAGGCCGATCCCGGTTCTGCGCTGA",
      "translation": "MSIRTAEYPRPDYFLLHLSDTHLLADGNRLYGSVDSAAHVQRLFADVEASGSRPDAIIITGDLADKGEPHAYAQLRDIVEPAAARIGAKVLWVMGNHDNRANFRTELLGQEPSLAPIDHVDYVGGLRIITFDTTVPGSHYGEISDRQLEWLSEQLSFPAPDGTILAMHHPPVPSMLDLSVAVELRDQASLAQVLRGTDVRSILAGHLHYSSTATFAGIPVSVASATCYTQDLNVPVGGTRGRDGARAFNLVHVYADTVLHSVVPLGEYEALDYIDAAESARRLAASGIEIMPAGSLPAYREPPMTRPIPVLR",
      "product": ""
     },
     {
      "start": 35571,
      "end": 36023,
      "strand": -1,
      "locus_tag": "ctg36_35",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_35</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_35</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,571 - 36,023,\n (total: 453 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_35 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00011.24 (Hsp20/alpha crystallin family): [33:129](score: 78.0, e-value: 5.4e-22)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_35\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_35_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTATGAACTACGATCCCTTCCGCGAACTGGATCGCGTCGCCGGTGCCCTGATGGATGTGCGCGGGCCGCGCGTGATGCCCATGGACCTGTACCGGTCCGGCGACGTGTACGTGCTCGACGCCGATATGCCCGGCATCGACCCCGGCTCGGTCGACATCGATGTGGACGGTCAACTGCTCACGATCCGGGGCGAGCGCACCCTGGCCAGCCACGACAACGTGAAGTGGCTCACCCGGGAGCGCACGGCGGGGTCGTTCCTCCGCCAGCTGAACCTCGGGCAGGGCATCGACCTCGACAACATCAGCGCCAAGTACGCCAACGGCGTGCTCTCGGTGACGATCCCGGTGAGCGAGGCGGCCAAGCCGCGCAAGATCGAGGTGAGCACCGAAAACGCCGACCGGCAGGAGACCCTGACGGTCAAGGAAGGCGAGAAGCACCTGGAGAAGTAG",
      "translation": "MAMNYDPFRELDRVAGALMDVRGPRVMPMDLYRSGDVYVLDADMPGIDPGSVDIDVDGQLLTIRGERTLASHDNVKWLTRERTAGSFLRQLNLGQGIDLDNISAKYANGVLSVTIPVSEAAKPRKIEVSTENADRQETLTVKEGEKHLEK",
      "product": ""
     },
     {
      "start": 36259,
      "end": 36486,
      "strand": -1,
      "locus_tag": "ctg36_36",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_36</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_36</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,259 - 36,486,\n (total: 228 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_36\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCACTAAGAAGACGAAGCAGGCACGTGCCGACCGCGCGGCCGAGCGACGTCGGGAGCCCGATGACCCCCGCGATCGCGGCGGCTTTCCCGGGCTCGAGGGCGACTTCGAGTCCGAGCGCCGCCGCGCGGTGAGCGCCAGCCACGAACATGCCGAGCCCTACGAGCACGGCGAGGGCGAGACCCCGGTTCTGCCCTCCACGACACCGGGCCTCACCCACCCCTGA",
      "translation": "MSTKKTKQARADRAAERRREPDDPRDRGGFPGLEGDFESERRRAVSASHEHAEPYEHGEGETPVLPSTTPGLTHP",
      "product": ""
     },
     {
      "start": 36614,
      "end": 37450,
      "strand": 1,
      "locus_tag": "ctg36_37",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_37</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_37</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,614 - 37,450,\n (total: 837 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_37 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01569.24 (PAP2 superfamily): [97:191](score: 34.3, e-value: 2e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_37\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGTCTTCGTCTTCCCGCCTCACGCCCGCCCGTTATGTGGGCGCCGCCGTGCTCTGCGCCGCCGCGTTCCTGGTGCTGTACCTGTTCTTCGTCCGTGACGAGACCGGGCAGGCCATCGACCAACTGGCATTCAACGGCGCCGAGAACGAGACCACGGGCACCCAGGTCACGCTGAGCCTGCTCGACCTGATCCCCTCGGTGATGGTCGGCGTCGGCGCGATCGTGAGCCTGGCCATCGCCGCCGTGCGGCGCGCCTGGTTCCCTCTTCTCGTGGCGGTCGGCAGTGCGATGGCCGCCGTCGTCACCACCCAATTGCTCAAGAACATCGTGCTCACCCGCCCGGATCTCGGGGTGGAGGGCTACGTGTCCAACTCCTTCCCGTCCGGGCATACGACCGTCGCTGCGGCATCCGCCCTCGTCGTGTTCCTGGTGGCCAGCCCGCACACGCGCTGGCTGGCCGGCACGATCGGCGCCGCCTTCGCCGTGGCCGCCGGGGTGTCCACGCTGGTCAGCCTCTGGCACCGGCCCAGCGACGTGATCGCCGCCCTGCTCGTGGTCTCCTTCTGGGGCTGCGTGGGCGGCGCCGTGCTCACCCGGTCCGGCGGTCGCCAGCGCACCGCACGCACGCCCACCCCGGCGCGAGTGGGGCTGCGCCTGCAGACCTGGATCGCCGTGCTCGCCGCGATCGTGACCGCCGTGGCCGTGGGGATCGGCGCCACCGGGGCGTTCGGCACCTCCGCCGCCCCCGCCGCGTACCTCGGCGCGGTCACCGCCATCGTGGCCGTGGGATTCGCGCTCGCCATCACCGCGACCCGGCTGTTCGACCGGCTGCCGTAA",
      "translation": "MSSSSRLTPARYVGAAVLCAAAFLVLYLFFVRDETGQAIDQLAFNGAENETTGTQVTLSLLDLIPSVMVGVGAIVSLAIAAVRRAWFPLLVAVGSAMAAVVTTQLLKNIVLTRPDLGVEGYVSNSFPSGHTTVAAASALVVFLVASPHTRWLAGTIGAAFAVAAGVSTLVSLWHRPSDVIAALLVVSFWGCVGGAVLTRSGGRQRTARTPTPARVGLRLQTWIAVLAAIVTAVAVGIGATGAFGTSAAPAAYLGAVTAIVAVGFALAITATRLFDRLP",
      "product": ""
     },
     {
      "start": 37644,
      "end": 38798,
      "strand": 1,
      "locus_tag": "ctg36_38",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_38</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_38</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 37,644 - 38,798,\n (total: 1155 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T3PKS: Chal_sti_synt_N<br>\n \n  biosynthetic (rule-based-clusters) T3PKS: Chal_sti_synt_C<br>\n \n  biosynthetic-additional (smcogs) SMCOG1024:chalcone and stilbene synthase domain protein (Score: 365.7; E-value: 3.1e-111)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_38 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00195.22 (Chalcone and stilbene synthases, N-terminal domain): [45:183](score: 96.7, e-value: 1.4e-27)<br>\n \n  PF02797.18 (Chalcone and stilbene synthases, C-terminal domain): [300:380](score: 69.5, e-value: 3.3e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_38\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_38_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGGCGCAGCGGTTGGTGACGGCATCCTTCAATCTGTCCGGCATCGACACCCGGCATACCGTGATCGAGGAACTCACCCTCGATTCCACCGTGGCCGAGCCGCAGTTCTTCGACGCCGCCACCCAGCGGCTGCTCGTTCCCGGCACCAAGGTGCGCAACGAGCTCTACATCGAGCAGGCCACGAAGCTGTTCGTGGAGGCCGGCCGGCGCGCCATCGCCGCCTGCCCGGGGCTGGAGGCCGCGGACATCACCCACGTCGTGACCGTCTCGTGCACCGGGTTCTACGCGCCCGGACCCGACTACATGCTCGTGCGCGAGCTGGGCCTGTCCCCGTCGACGCAGCGGTACCACCTGGGCTTCATGGGCTGTTACGCGGCGATGCCGGCCCTCCGCACCGCCAAGCAGTTCGTGGAGGCCGACCCGAACGCCGTCGTGCTCGTCGTCAGTGCCGAGCTGTGCTCGCTGCACCTGCGCACCTCGAGCGACCCCGACACCATCGTGGCCTCCTCCCTCTTCTCGGATGGCGCGGCCGCGGGCATCGTGAGCAGCCGCCGGCCGTCCGCCGGCGAGAACGCCCTCAACCTCGACCACTTCGAGACCGTGATCACCCCCGTGGGCGAGGGCGACATGGCCTGGAAGATCGGCGACGAGGGGTTCGAGATGATCCTCAGCTCATACGTGCCGCACATCATCGACGAGCACATCGAGTCGGCCCTGGCGCCGCTCTTCGGCCGCGACGACGCGCTGACCCGGGCCCTCGCGGCTGGCGTGCTCGCCGAGGCCGGCGCCGTGACGGCGCAGGCACAGGACGACGGGGCGGATGCCGCCTCCGCCGCTGCCGAACCCGGCCAGGTGCTCACCGCCGCGGCACCCGGCTCCCCGCTGAGCACGGCGATCGCGCACTGGGCGATCCATCCGGGCGGGCGCAGCATCCTCGACAAGACCGAGACCAAGCTCGGGCTCACCGAGGCGCAGCTGGTTCCCTCCCGGGAGACCCTGCGCACGAACGGCAACATGTCCAGCGCCACCATCCTCTTCGTCATGAAGGCGATTCTCGAACAGGAGAACGCCGCGGACGGGGACCGGGTCTGCGCCATGGCGTTCGGGCCGGGGTTGACCGTGGAGTCGAGCCTGATGACCGTGCTGCGCGGCTGA",
      "translation": "MAQRLVTASFNLSGIDTRHTVIEELTLDSTVAEPQFFDAATQRLLVPGTKVRNELYIEQATKLFVEAGRRAIAACPGLEAADITHVVTVSCTGFYAPGPDYMLVRELGLSPSTQRYHLGFMGCYAAMPALRTAKQFVEADPNAVVLVVSAELCSLHLRTSSDPDTIVASSLFSDGAAAGIVSSRRPSAGENALNLDHFETVITPVGEGDMAWKIGDEGFEMILSSYVPHIIDEHIESALAPLFGRDDALTRALAAGVLAEAGAVTAQAQDDGADAASAAAEPGQVLTAAAPGSPLSTAIAHWAIHPGGRSILDKTETKLGLTEAQLVPSRETLRTNGNMSSATILFVMKAILEQENAADGDRVCAMAFGPGLTVESSLMTVLRG",
      "product": ""
     },
     {
      "start": 38830,
      "end": 39543,
      "strand": 1,
      "locus_tag": "ctg36_39",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_39</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_39</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38,830 - 39,543,\n (total: 714 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1269:hypothetical protein (Score: 223.1; E-value: 5.3e-68)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_39 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08241.15 (Methyltransferase domain): [54:146](score: 40.3, e-value: 4e-10)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_39 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF08241.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008757' target='_blank'>GO:0008757</a>: S-adenosylmethionine-dependent methyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_39\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGACGCCGTCGAGATCATGGACGATCCGGACTGCGACCCCGACAAGCTCCGCCGCACCTACGCGAACTTCCGGTATGTCAACGCCGTCGTGTCCGGCCTCCGGCACACCTACCGGCACGATATCCGGCCGTTGCTCTCGCCCGACGTGCCGCGCACGCTGCTCGACATCGGCTCGGGCGGCGGCGATGTGGCCCGGTCGCTGGCACGCTGGGCGGCCAGGGACGGACTGCGCCTGACCGTGACGGGCATCGACCCGGACGCCCGCGCCCACGACTACGCCACCAGCCTGCCGCCGCTGGCCGGGCTCACCTTCCGCCGGGCATTGAGCAGCGACCTCGTCGCGGCGGGGGAGCGATTCGACGTCGTGCTGTCCAACCATGTGCTGCACCACCTCGCCGCCGCGGACCTCGGCGCGCTGCTGGTCGACTCCGAACGGCTCAGCCGTGCCCTGGTGCTCCACGGCGACATCGAACGGGCCCCGTTGGCGTACCTCGGCTTCGGGCTGGGCACGTGGCCGTTCTTCCGGCGCTCGTTCATCCGCGCCGACGGACTCACCTCGATCCGGCGCAGCTTCACCCGCGCGGAGCTGGCCGCGGCGGTGCCGCCGGGCTGGACCGTGCACCGGGAGGTGCCGTACCGGCTGATGTTGCGCTGGAGCGCGCCACCGGTGGCACCGACCTCGGCACGACAGGCGAGCCGGGCCCATGCGTGA",
      "translation": "MDAVEIMDDPDCDPDKLRRTYANFRYVNAVVSGLRHTYRHDIRPLLSPDVPRTLLDIGSGGGDVARSLARWAARDGLRLTVTGIDPDARAHDYATSLPPLAGLTFRRALSSDLVAAGERFDVVLSNHVLHHLAAADLGALLVDSERLSRALVLHGDIERAPLAYLGFGLGTWPFFRRSFIRADGLTSIRRSFTRAELAAAVPPGWTVHREVPYRLMLRWSAPPVAPTSARQASRAHA",
      "product": ""
     },
     {
      "start": 39536,
      "end": 40699,
      "strand": 1,
      "locus_tag": "ctg36_40",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_40</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_40</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 39,536 - 40,699,\n (total: 1164 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1050:monooxygenase FAD-binding (Score: 284.5; E-value: 2.9e-86)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_40 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01494.22 (FAD binding domain): [2:342](score: 163.6, e-value: 7.7e-48)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_40 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0071949' target='_blank'>GO:0071949</a>: FAD binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_40\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_40_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGTGACGTGATCGTGGTGGGCGGCGGGCCCGTGGGCATCCTGCTGGGGTGTCTGCTGGCCGAACGCGGGGTGGATGTGGAGGTGCTCGAACGGCGCACCGAGCCGTCGATGCACGCCAAGGCCATCGGCATCCACCCGCCGTCGATGCGGGTGTTGCGGCAGGCCGGGGTGGCCGACGAGGTGTTGTCCCGGGCGGTGCGCATCGTGACCGGCAGCGTGCAGAGTGGCGGGCGCACCCTGGGCCGGCTCTCGTTCTCCCAGGTCACCGGCCGGTTCCCGTTCGTGGTGACGCTGCCGCAGCACGAGACCGAGGCTGTGCTTCGGGAGCGGTTCGCGGCCCTCCGGCCCGACGGCCTGCGCTCCGGCGTGGGCGTGGGCATGCTGCAGGACCGCGGCGACCACGTGGACGTGCTCGCGGAGTCCGGTGCGGCTGAGGCCGAATCCGGTGACGGCGGCCGGGAGATCGTGGCTCAGGCCCGGTATGTGGTCGTCGCCGACGGGGCCCGAGGGCTGTTGCGTGACGCCGTGGGCATCGAATCCCGCGAGCTGGGCGGTGCGGGCACCTACCTGATGGCCGACTACCCCGACACCGGCGAGCACGGCGAGGAGGCGGTGTTGTTCTTCGAGGAGGGCGGTGTCGTCGAGTCGTTCCCGCTGCCGGGCGGCCGACGCCGGTGGGTGGCGGCGACGCCCACCCTGGTGACGGATGCGTCCATCGACGCCCTGGCGGCGCTCATCCTGCAACGCACGGGCGTGCGGTTGCCGCCCTCGGCGGCGGTGCCCAGCTCGTTCACGGTGCGGCAACGGCTCGCGTCGACCATGGTGCGCGGGCGGGTGCTGCTGGCGGGGGATGCGGCGCACGAGATCAGCCCGATCGGCGGGCAGGGCATGAATCTGGGCTGGCTCGACGCCGTGGCGCTCGCTCCGGCCCTCAAACACGCGCTGGCGCAGCCCATCGAGGCGGCGGTGACGCTGGCCGGGTACGACCGGCGCCGGCGCCGCAGCGCTCGCATGGCGGCCCGGCAGGCCGGGTTCAACATGGCGATGGGCCGGCCGGTGCGCGGGCTGCGCCTGCGGATGCGGAACGTCCTCGTGCGCGCCCTGGCGCTGCCGCCCCTGAACGCGCTCCTCTCCCGCGCGTTCACCATGCGCTGGCTCTAG",
      "translation": "MRDVIVVGGGPVGILLGCLLAERGVDVEVLERRTEPSMHAKAIGIHPPSMRVLRQAGVADEVLSRAVRIVTGSVQSGGRTLGRLSFSQVTGRFPFVVTLPQHETEAVLRERFAALRPDGLRSGVGVGMLQDRGDHVDVLAESGAAEAESGDGGREIVAQARYVVVADGARGLLRDAVGIESRELGGAGTYLMADYPDTGEHGEEAVLFFEEGGVVESFPLPGGRRRWVAATPTLVTDASIDALAALILQRTGVRLPPSAAVPSSFTVRQRLASTMVRGRVLLAGDAAHEISPIGGQGMNLGWLDAVALAPALKHALAQPIEAAVTLAGYDRRRRRSARMAARQAGFNMAMGRPVRGLRLRMRNVLVRALALPPLNALLSRAFTMRWL",
      "product": ""
     },
     {
      "start": 41623,
      "end": 43287,
      "strand": 1,
      "locus_tag": "ctg36_41",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_41</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_41</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 41,623 - 43,287,\n (total: 1665 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_41 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05175.17 (Methyltransferase small domain): [173:299](score: 54.8, e-value: 9.5e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_41 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05175.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008168' target='_blank'>GO:0008168</a>: methyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_41\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_41_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCAGTTGAATGGAGGGGTGACTGCACCCCTGATCGACCAGCTCCGCGCCGACCTGACCGCCGCCAACTTCTCGGTGACGGCCCTGACCGGCCTGTGGGGCATCGACGCCGATGCGGCCCTGCACCGCAACCAGCGGGTGCCGGCCCTTCGGGCGCTCGCCCGGCTGCGCGGCTCCCTCATCGTGCTCGAACCGAATGTAGTGCTCGCCCAGCTCTTCGTGCTCGGCCTGCCCGTGGAGCGGGACGAGCTGGACACCGCCCTGCCCACCCTCGGTGCGGCCGGCGCCGAGCTCCTCGGCCTGGTCACCGCGCACCACGCGCACGCCGGAACCGACGAGAACCCCACCGTGGACACCGGTCCCCGTCAGGTGGAACCGCTGGTGGACCTGCGCCCGTACAGCTTCGTCGACGCGCACGGGGCCGGCAGTTGGTGGATCACCTCGGACCTGGGCGAACTGGCCCTCGGGCATCCGCTCGGCGAGAACCACGTGCTCGGCGTCGGCGGTGCCTCCCTCACGCTCAGCGCCCTGATGATCCCCGCCCCGGTCGACAGCGCGCTCGACCTGGGCACCGGCTGCGGCATCCAGGCGCTGCACGCCTCCCGGCACGCCGCCCGGGTGGTGGCCACCGACATCTCCGAGCGGGCCCTCGAGCTCGCGGCCCTGAACGCCCGGCTGAACCAGGTCGAGAACATCGAGTTCCGGCTCGGCAGCCTGTTCGAGCCCGTCGCCGGGGAGCGCTTCGACCACATCATCTCCAACCCGCCGTTCGTGATCACCCCGCGCGTCGAGGGCGTGCCCAGCTATGAGTACCGGGACGGCGGCCTGGTCGGCGACGCCCTCGTCGAGGCCGTGGTGCGCGGCGCATCCGCCCACCTCAGGCCCGGCGGGATCGCGCAGTTGCTCGGCAACTGGGAGTACCACGACGAGGCCGACGCCTTCGCCCGGCTCACCGGCTGGATCGACGCCCCGTACCCCGACGCCGATGCGGGCGACGCGGCATCCGCCCCGCTGGACGCCTGGATCATCGAGCGTGAGGTGCAGGCGCCCACCGGCTACGCCGAAACCTGGATCCGCGACGGCGGCACCCGCCCGGAGACCCCCGACTTCGACAGGCTCTACGGCGCCTGGCTCGACGACTTCGAGGCCCGCGGGGTGCGGCAGGTGGGCTTCGGTTACATGCTGCTGCGCCGTCCGGCCACGGATGCGGCGGGCCGCCGCTCCGAGCGCGTGCGGCCCCGCCTGCTGCGGCTCGAACGGCTGCCCGAGGCCCTCGGACACAACGCGGCCGGCATCGGCAGCCACCTCGCCGAGTGCCTCGCCGCCCACGACTGGCAGGCCGGGCTCGACGACGACGCGCTCTCCCGCAGCACCCTCACGGTGGGCTCGGACGTCACCGAAGAACGGCATTTCTGGCCCGGCCAGGAGGATCCGACGCTGATGACCCTGCACCAGGGCGGCGGCTTCGGCCGCTCGGTGCCGCTGGACACCGCCCAGGCCGCCCTGATCGGCGCCTGCGACGGTGAACTGCCGGTGGGCGCGATCATCGACGCGATCGCGCAGTTGCTCGACGCCGACGCCACCGCCCTCCGCGCCGAGCTGCTCCCGCGCGTGCGGGTCCTGCTCGACGACGGCTTCCTCGAGCCGCCCGCCTCCGGCGCCTGA",
      "translation": "MQLNGGVTAPLIDQLRADLTAANFSVTALTGLWGIDADAALHRNQRVPALRALARLRGSLIVLEPNVVLAQLFVLGLPVERDELDTALPTLGAAGAELLGLVTAHHAHAGTDENPTVDTGPRQVEPLVDLRPYSFVDAHGAGSWWITSDLGELALGHPLGENHVLGVGGASLTLSALMIPAPVDSALDLGTGCGIQALHASRHAARVVATDISERALELAALNARLNQVENIEFRLGSLFEPVAGERFDHIISNPPFVITPRVEGVPSYEYRDGGLVGDALVEAVVRGASAHLRPGGIAQLLGNWEYHDEADAFARLTGWIDAPYPDADAGDAASAPLDAWIIEREVQAPTGYAETWIRDGGTRPETPDFDRLYGAWLDDFEARGVRQVGFGYMLLRRPATDAAGRRSERVRPRLLRLERLPEALGHNAAGIGSHLAECLAAHDWQAGLDDDALSRSTLTVGSDVTEERHFWPGQEDPTLMTLHQGGGFGRSVPLDTAQAALIGACDGELPVGAIIDAIAQLLDADATALRAELLPRVRVLLDDGFLEPPASGA",
      "product": ""
     },
     {
      "start": 43573,
      "end": 45021,
      "strand": 1,
      "locus_tag": "ctg36_42",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_42</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_42</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 43,573 - 45,021,\n (total: 1449 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) DAO<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_42 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01593.27 (Flavin containing amine oxidoreductase): [41:116](score: 65.0, e-value: 8.4e-18)<br>\n \n  PF01593.27 (Flavin containing amine oxidoreductase): [134:468](score: 137.0, e-value: 1.2e-39)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_42 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01593.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_42\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_42_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAACGTCGGACCTTCTTGCTCAGTTCCCTCACCGGACTCTCGTTGCTCGCGCTCAGCGGATGCGTGCCGCCCAAGCCCACCCCCACGGGGACGCCCAGTCCCTCGGCCACACCGGCGCCGTCCCTCGTGCCGCAACCGGCGGGCATGCTCCGCACCTCCTGGTCGGAGGATCCGTTCGCCCGCGGTTCCTACAGCTTCGCCACGGTGTCGTCGACGCCCCAGCAGCGCGATGACCTCGCCGAACCCGTCCTCGACCGGCTTTTCTTCGCCGGCGAAGCGGTCTCTGCCGATGCGCCGGGCACCGTGCAGGGCGCCCGGGCTTCCGGCCAGCGTGCCGCCCGACTGCTGCAGGCCGCCGCGGAGCCGGCGGAGCGGGTGGCCGTGATCGGCGCCGGCGCCGCCGGACTCGCCGCCGCCCGCCAGCTCGCCGCCGCCGGGTTCTCGGTGATGGTGATCGAGGCGCGCGACCGGTTGGGCGGCCGCATCGACACCGTCACGGACGACGCCTGGCCCATCCCGGTGGAGCTCGGTCCGTCATTCATCGTGGGCTCCGACGGCAGCTCCCTCGACGAGGAACTCACCGGCCTCGAGATCTCCCACGCGCCGTTCCCGCTCACGCCGGAGGCGCGCACCTCGGCCGGCACGGTGACCGAGGTGTCCACGGTCGGTGCCGACTCCGTCACGGCCGCGCTCACCTGGGCCGCCGCCCAGGCGCAGGACACCTCCCTGGCCAAGGCCCTGGTCGCAACCGGCTCGGCCACGCTCTCCCAAACGGATGGCGACACCGGCGTCTCCGACGCCGACTGGCTGGACTACCAGCTCGCGACCTCCACCACCCTGGAGTCCGGCGCTCCCACCGACGAGATGTCCGGCTGGTACACCGCCACCCCCGCGGCCAGCGCCGGCGCCGACGTGCGCATCGTGCTGGGCGGCTACGGCGGCCTGATCAAGGACGATTCGACCGACCTCGACGTGCTCTACTCCAGTGTGGTGACCCGGGTGGCGTACACCGACGCATCCGTCAGTTTGCGCCTGGGCACCGGCGAATCGCTCACCGTGGACCGCGCCATCGTGACCGTGCCGCTCGGTGTGCTGCAGGGCGACGTGATCGAATTCGACCCGGCGCTGCCGTTCGCGCATCGCGGGGCGATCGCCGCGCTGGGCATGGGCACGCTCGACAAGATCTGGTTGCGCTTCGACGAGCCGTTCTGGGACACCGACGCCGCCCTGTGGACCACAGTGGGCGACGACACCCTCGATTTCAGGGTCTGGGTGAATATGATGCCGCTTACGAATGAGCCGATCCTGGTGGGTTTCGTCAGCGGCGATCACGCCCTCAAGCTGGCGAAATCCGGTAATACCGAGTTCACCGACGCCGCGTTGCGCAGCCTCGAGCCGTTCGCGGCCCTGCCCACAGACAGTGCCAGCCCGAGCCCTGCGGCCTGA",
      "translation": "MERRTFLLSSLTGLSLLALSGCVPPKPTPTGTPSPSATPAPSLVPQPAGMLRTSWSEDPFARGSYSFATVSSTPQQRDDLAEPVLDRLFFAGEAVSADAPGTVQGARASGQRAARLLQAAAEPAERVAVIGAGAAGLAAARQLAAAGFSVMVIEARDRLGGRIDTVTDDAWPIPVELGPSFIVGSDGSSLDEELTGLEISHAPFPLTPEARTSAGTVTEVSTVGADSVTAALTWAAAQAQDTSLAKALVATGSATLSQTDGDTGVSDADWLDYQLATSTTLESGAPTDEMSGWYTATPAASAGADVRIVLGGYGGLIKDDSTDLDVLYSSVVTRVAYTDASVSLRLGTGESLTVDRAIVTVPLGVLQGDVIEFDPALPFAHRGAIAALGMGTLDKIWLRFDEPFWDTDAALWTTVGDDTLDFRVWVNMMPLTNEPILVGFVSGDHALKLAKSGNTEFTDAALRSLEPFAALPTDSASPSPAA",
      "product": ""
     },
     {
      "start": 45209,
      "end": 45529,
      "strand": -1,
      "locus_tag": "ctg36_43",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,209 - 45,529,\n (total: 321 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_43\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCCGAGACCCGGGGCGAGCACTGGATCACCTTGGGGCCGCAGCACGGGGAGATCACCATGAAGGCGCCCGGCTCGGCCGCGGCGTGTCCGCTCAGGCTGCGGTGGTGGTGGCTGCCCTCGCAGGGCAGGTTGGTGTCGAAGTCGAGTAACGACATCGCATCGAGATTTGTCAGGATATACATGGTTCTCACGGTCAATCAGGAGAGGCACTGGCCGCGGTGCAAGAGGACGTCGGGATCGCGACCACACCCGACGGCCGACGGCGGAAGGCACTGCGTCCGCGAAACCGGGCTTGTCGGACCGGCACCGCTGAACTGA",
      "translation": "MAETRGEHWITLGPQHGEITMKAPGSAAACPLRLRWWWLPSQGRLVSKSSNDIASRFVRIYMVLTVNQERHWPRCKRTSGSRPHPTADGGRHCVRETGLVGPAPLN",
      "product": ""
     },
     {
      "start": 45731,
      "end": 46459,
      "strand": -1,
      "locus_tag": "ctg36_44",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,731 - 46,459,\n (total: 729 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_44\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCGCGACTCCCCCGATACCCGGGCGGATCCAACAGCGCGCAAGCCGTTGCGCGCGCCCCGACGCCTCACCCTGCGCGCCGGCTACGGCTACGGCCGGCTGGTCCTGGCCGCCGCGGGCATCGTCGGGCTGGTCGGCAACTACGAGTACGTGCTGCTGTTTCCGACCTTCGCCGCGTACAACGTGTTCACCTACTTCACGGTGCAGAGCGCCATTGCCGCGGTCGTCGCGTTCATCCTCGGCGCCGTCGTCGCGTTCCGGCACGAGAAGGACCCGCAATGGCTCGACACGTTCCGGGCCCTCGTCACGACGTACATCATCGTGTCGGGCATCGTGTTCCTCACCATCGTCATCCAGTCGTCGTCTCGCGACTACACGATCGAGGTGCCCTGGCCGAGCCAGGTGCTGCACTTCTACATCCCCACGATCGCGCTGCTGGACTGGCTGACGGACACCGGGAAGGCCCGGTTGTCCTGGCGCTTCCTGCGCTGGATCCTGCCGTACCCGTTCGCCTGGGGCATCTTCACACTCGTGCGCGGGTCGTTCGTGGGCTGGTACCCGTACTTCTTCCTCGACCCCGCCCAGGTCAGCGGCCCGCTCGAGACGGTGCTCTACTGCCTGATCGCGGTGGCCCTGTTCCTCGGCATCGCCTCGGTACTCGTGGCCACGTCCCGGCTCAGCTGGCGGCCGCGCACGCGCGGCGACCGCAGTTCGTCGGTCCCCAACTAG",
      "translation": "MRDSPDTRADPTARKPLRAPRRLTLRAGYGYGRLVLAAAGIVGLVGNYEYVLLFPTFAAYNVFTYFTVQSAIAAVVAFILGAVVAFRHEKDPQWLDTFRALVTTYIIVSGIVFLTIVIQSSSRDYTIEVPWPSQVLHFYIPTIALLDWLTDTGKARLSWRFLRWILPYPFAWGIFTLVRGSFVGWYPYFFLDPAQVSGPLETVLYCLIAVALFLGIASVLVATSRLSWRPRTRGDRSSSVPN",
      "product": ""
     },
     {
      "start": 46614,
      "end": 46868,
      "strand": -1,
      "locus_tag": "ctg36_45",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 46,614 - 46,868,\n (total: 255 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_45 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00708.21 (Acylphosphatase): [1:82](score: 92.5, e-value: 1.7e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_45\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGATCGTCAACGGGATGGTGCAGGGCGTGGGCTTCCGGTACTACACCGAGGCTCAGGCCAGTTCCCTCGGCCTGGGCGGGTACGTGCGCAACCGATCCGACGGGGCCGTGGAGACCGAGATCGAGGGCGACGACGAGGCCGTCGAGCGGATGCTCACCTGGCTGCACCAAGGACCCCGCTCGGCGAGCGTGGAGTCGGTGCAGGTGACCGACCTGGCCGAGCACGGCGAGGCGGGTTTCAGCATCCGCATCTGA",
      "translation": "MIVNGMVQGVGFRYYTEAQASSLGLGGYVRNRSDGAVETEIEGDDEAVERMLTWLHQGPRSASVESVQVTDLAEHGEAGFSIRI",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 37643,
      "end": 38798,
      "tool": "rule-based-clusters",
      "neighbouring_start": 17643,
      "neighbouring_end": 46916,
      "product": "T3PKS",
      "category": "PKS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [
      {
       "start": 19377,
       "end": 19379,
       "strand": 1,
       "containedBy": [
        "ctg36_21"
       ]
      }
     ],
     "bindingSites": []
    },
    "type": "T3PKS",
    "products": [
     "T3PKS"
    ],
    "product_categories": [
     "PKS"
    ],
    "cssClass": "PKS T3PKS",
    "anchor": "r36c1"
   }
  ]
 },
 {
  "length": 46556,
  "seq_id": "NODE_60_length_46556_cov_22.160954",
  "regions": []
 },
 {
  "length": 45234,
  "seq_id": "NODE_61_length_45234_cov_22.877228",
  "regions": []
 },
 {
  "length": 42385,
  "seq_id": "NODE_62_length_42385_cov_25.224898",
  "regions": []
 },
 {
  "length": 41932,
  "seq_id": "NODE_63_length_41932_cov_28.053733",
  "regions": []
 },
 {
  "length": 41182,
  "seq_id": "NODE_64_length_41182_cov_27.092908",
  "regions": []
 },
 {
  "length": 39829,
  "seq_id": "NODE_66_length_39829_cov_25.318022",
  "regions": []
 },
 {
  "length": 39752,
  "seq_id": "NODE_67_length_39752_cov_24.776282",
  "regions": []
 },
 {
  "length": 38680,
  "seq_id": "NODE_68_length_38680_cov_23.339248",
  "regions": []
 },
 {
  "length": 38420,
  "seq_id": "NODE_69_length_38420_cov_28.412931",
  "regions": []
 },
 {
  "length": 37582,
  "seq_id": "NODE_70_length_37582_cov_27.143261",
  "regions": []
 },
 {
  "length": 37277,
  "seq_id": "NODE_72_length_37277_cov_26.559597",
  "regions": []
 },
 {
  "length": 36972,
  "seq_id": "NODE_73_length_36972_cov_25.722727",
  "regions": []
 },
 {
  "length": 34807,
  "seq_id": "NODE_74_length_34807_cov_26.088166",
  "regions": []
 },
 {
  "length": 33348,
  "seq_id": "NODE_76_length_33348_cov_24.823780",
  "regions": []
 },
 {
  "length": 31629,
  "seq_id": "NODE_77_length_31629_cov_26.391829",
  "regions": []
 },
 {
  "length": 31295,
  "seq_id": "NODE_79_length_31295_cov_24.414665",
  "regions": []
 },
 {
  "length": 29366,
  "seq_id": "NODE_81_length_29366_cov_23.105569",
  "regions": []
 },
 {
  "length": 28904,
  "seq_id": "NODE_82_length_28904_cov_26.524751",
  "regions": []
 },
 {
  "length": 28840,
  "seq_id": "NODE_83_length_28840_cov_24.399750",
  "regions": [
   {
    "start": 1,
    "end": 19200,
    "idx": 1,
    "orfs": [
     {
      "start": 3,
      "end": 167,
      "strand": 1,
      "locus_tag": "ctg55_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 167,\n (total: 165 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTATGCGCATCGCCGGGCGGGATGGGGCGGGGTGGGAGGACAATGTGCCTGTGTGACGCGCGTTCACCCGCCGGTTACCTGATCGCCCTAGGGTGGCCGCGTCGCGGTTTGTCGCGAAAGCCGGACAGGAGCGTGCGTGACCTCGAACCATCCAGAGCCCGATAA",
      "translation": "MCASPGGMGRGGRTMCLCDARSPAGYLIALGWPRRGLSRKPDRSVRDLEPSRAR",
      "product": ""
     },
     {
      "start": 139,
      "end": 4200,
      "strand": 1,
      "locus_tag": "ctg55_2",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 139 - 4,200,\n (total: 4062 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NAPAA: TIGR02353<br>\n \n  biosynthetic (rule-based-clusters) NAPAA: AMP-binding<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 249; E-value: 1.3e-75)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_2 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [62:452](score: 219.0, e-value: 9.2e-65)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [572:634](score: 44.3, e-value: 1.8e-11)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg55_2_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACCTCGAACCATCCAGAGCCCGATAAGCGCTCGGCCGACTCACTCGCCAGCACCGTTTCCATGCCGGCCACCACCTCGGCTCCCAGCAGCACGGTCTCAAGCCCGTACACGCAGGCGCACGACCAGCGCGTGCTGGATGCCGGTCATCTGGTGCACCCGGAGCGCACCCTCGTCGACATCCTGCGGGCCAGCGCCGAGGAAGACCCCACCGCTCTCGCGCTCGAAGACGCCGCCGGGGCCCTGAGCTACCGCCGCCTGCTGCGGCTGGTCAACGACCAGGCCGTGCAGCTGAGCCGCGCGGGTGTGCGCCGCGGCGACACTGTCGGCATCCGCATCCCGTCGGGCACCCGGGAGCTGTACCTGTCGATCCTCGCGACCCTCAGCGTGGGCGCCGCCTACGTGCCGGTGGACGCCGACGACCCCGAGGAGCGGGCCCGGCTGGTGTTCGGTGAGGCCCACGTCGTGGGCGTGATCGGCGCCGGGGGCCGGTTCGCGGTGCGTGACGGCCTCGACGCCGGTGTGCTCACCGAGCGGCCCGTTCCGGCCGGGGAGGATCCGTCGCTGGCGCACTGGGGCGAGCCGATGCCGGGCCCCGACGACGACGCCTGGATCATCTTCACCTCCGGCTCCACCGGCGTGCCCAAGGGTGTCGCCGTGACGCACCGGTCCGCCGCGGCTTTCGTCGACGCCGAGGCCGGCCTGTTCCTCAGCGCCGACCCGATCGCGCCGGGCGACCGGGTGCTGGCTGGCCTCTCGGTGGCGTTCGATGCCTCCTGCGAGGAGATGTGGCTGGCCTGGCGGAACGGCGCGTGCCTGGTGCCGGCCCCGCGCTCCCTCGTGCGCAGCGGCGCCGACCTCGGCCCCTGGTTGATCGCCCACGGCATCACCGTGGTCTCCACCGTGCCCACCCTCGCCGCGCTCTGGCCCGAGGAGGCGCTGGAGAACGTGCGCCTGGTGATCTTCGGCGGCGAGGCGTGCCCACCCGAACTGGCCGCCCGCATCAGCGGCCGCGGCCGCGAGGTCTGGAACACGTACGGCCCCACCGAGGCCACCGTCGTGGCCTGCGGCGCCCTGCTCGACGGCAGCGACCCCGTGCGCATCGGCCTGCCGCTGGACGGCTGGAGCCTCGCCGTGGTCGACGCCGACGGCGCTCGGGTGCCCGCCGGCGGCACCGGTGAGCTGATCATCGGCGGCGTGGGCCTGGCCCGCTACCTCGACGCCGCGCAGGATGCCGTGAAATACGCCCCGCACGCCGGCCTCGGCTGGGACCGCGCCTACCGCAGCGGCGACCTGGTGCGCTTCGACCCCGAGGGGCTGGTCTTCGTGGGCCGCGCCGACGACCAGATCAAGCTCGGCGGCCGCCGCATCGAGCTCGGCGAGATCGACGCCGCCCTCCAGGCGCTGCCCGGCGTCGCCGGCGCCGCCGCGGTGGTGCAGACCACCCCGGCCGGCAACCAGGTTCTGGTCGGCTACCTCTCCCTCGTCGAGCCGGCGCCGGTCGGTAGCGACCCGGTCACGTCGCCCTTCGACCTCCCCGCCGCCACCGAGGCCCTGCGCATCGCCCTGCCGGCCGCCCTCGTGCCGCTCCTCGCCGTGGTCGACACGATCCCCACCCGCACCTCCGGCAAAGTCGACCGGGCCGCGCTGCCCTGGCCGCTGCCCAGCCTGGCCGGCGGCAGCACCGACACGGATGCGCTCAGCCCCACCGCCGCCTGGCTCGCCGAACACTGGGCCGCGATCCTCGGGCTGCCCGTGACCGACGCCGACAGCGACTTCTTCGCCTACGGCGGGGGCTCCCTCTCGGCCGCCCAGTTCGTCTCCGCGATCCGGGAACGCTACCCCGACACCCGCGTCAGCGACATCTACGACCACCCGCGCATCGGCGCCCTGGCCGCCGAACTCGACGGCCGCACCCCGCCGGCGGCCCGCCGCAGCCGCACGGTGCTGCCCACCCCCGCACGCAGCGGTCTGCTGCAGAGCCTGCTCGGCATCCCCCTGCACCTGCTCGTGGGCGCCAAATGGCTGGTCTACCTGGCCGCGGCCAACAACGTGCTCGCCGCCGCCGGCGCATCCTTCGCCCCCACCGTGTCGTGGTGGTGGGTCCTAGCCGGGTTCCTCCTGCTCGTCACCCCGCTGGGCAAGATGGGCATCTCGGTGGTCGCGGCCCGGCTGCTGCTCCGGGGCCTGAAACCGGGCGCCTACCCGCGCGGCGGCTCGGTGCACCTGCGGCTCTGGCTGGCCGAGCAGGTGGCCCAGTTCGTCGACGCCGCCAGCCTGGCCGGGGCGCCGTGGATCAGCTACTACGCCCGCCTGCTCGGCGCCCGCATCGAACCGGGCGTGGACCTGCACTCGGTGCCCCCGGTCACCGGGATGCTCAGCATCGGGGCACGCGCCGCGATCGAACCCGAGGTGGACCTGGCCGGCTACTGGCTCGACGGCGACACCCTGCGCCTGGGCCAGGTGCGCATCGGCGAGGAGGCCGTGGTCGGTTCCCGCAGCACCCTGCTCGGCGGCGCGAAGATCGGCGCCGGCGCCGAGATCGAGCCGGGCTCCGCGGTCTCCGGCCGCGTCCCGGCCGGCGAACGCTGGGCCGGTTCACCCGCGACCCGGGTCGGGTCGGCCCGCCACACCTGGCCGGCCGAACGTCCGCCGAGCGCCCGCCGTTGGCTGCTCGCCTACGGCGCCGGCTCCGTCGGCCTCACCGCCATCCCCACCGTCGCCGTGCTGCTCGGCGTGCTCATCGTCGGGCTGTTCGTGGGGGAGGCCGGCAGTCTCGGCACCGCCGTCGGCCGGGCCGCCCTGGCCGTGCCGCTGGCCGTGCTCGCCGCCGGCCTGCTCTACGCGGGCGCCGTGATCGGCGCGGTGCGCCTCCTCGGCCTGGGCCTGACCGAGGGGCACCATCCGGTGCGCAGCCGCGTGGGCTGGCAGGTCTGGATGACCGAACGCCTGCTCGACGGCGCCCGCACCCTGCTCTTCCCGGTCTACGCGAGCCTGATCACGCCAGTCTGGCTGCGGTTGCTCGGTGCGAAGGTCGGCTCCGGCGTGGAGGCCTCCACCGTGCTGCTCGTGCCCGCACTCACCACCATCGCGCCGGGCGCATTCCTCGCCGACGACACCATGGTCGCCTGTTACGAGCTCGGCGGCGGCTGGATGCGCATCGACCGGGCCAAGATCGGCCGCCGGGCGTTCCTGGGCAACAGCGGCATCGCCGGCCCCGGCCGCACCGTGCCGCGGGACGGCCTCGTGGCCGTGCTCTCCTCCACCCCGCGGAAGGCCAAACGCGGGTCCTCCTGGCTGGGCAACCCGCCGGCGCGGCTGCGCCGCCGGGTCACCGACATCGACGAGGCCCGCACCTTCCACCCGCACGCCCGGCTGCGCCTGGCCCGGTCGCTCTGGGAACTCCTCCGCCTGGTGCCGGTGTTCGTCTCCGCCTGGATCGCGCTCGGCGTCCTCGCCGCCCTCGAGGCGCTCTGGCTCACCGCCGGGCCCGGCTGGGCGCTGCTGCTCTCCGGGTTCGTGCTCATCGGCGCGGGAGTGATCGCGGCAGCGGTCAGCACGGCCGCAAAATGGCTGCTGGTGGGCCGCATCCGCGCCACCGAGCATCCGCTCTGGTCGTCGTTCATCTGGCGCAACGAGGTGTCGGACACCTTTGTGGAGATGGTGGCGCGGCCGTGGTTCGCGCAGAACGCGTCGGGCACGCCGGCCCTGGCGCTGTGGCTGCGCTCGCTCGGCGCCCGGATCGGCCGGGGCGTGTGGTGCGAGTCGTACTGGCTCCCAGAGGCCGACCTGGTCACCCTCGCCGCCGGCAGCAGCGTCAACCGCGGCTGCGTGGTGCAGACCCACCTGTTCCACGACCGGATCATGCAGCTGGACACCGTGCACATCGGCGCCGGCGGCACCCTGGGGCCCAACAGCGTGATCCTGCCCGCGGCGCGGATCGACGACCACGCCACCGTCGGGCCGGGCTCCCTGGTGATGCGCGGCGAGCGGGTGCCCACCGATTCGCTGTGGGCCGGCAACCCGATTGCGCCCTGGCACCGCCCGCCATGGAAGACTTGA",
      "translation": "MTSNHPEPDKRSADSLASTVSMPATTSAPSSTVSSPYTQAHDQRVLDAGHLVHPERTLVDILRASAEEDPTALALEDAAGALSYRRLLRLVNDQAVQLSRAGVRRGDTVGIRIPSGTRELYLSILATLSVGAAYVPVDADDPEERARLVFGEAHVVGVIGAGGRFAVRDGLDAGVLTERPVPAGEDPSLAHWGEPMPGPDDDAWIIFTSGSTGVPKGVAVTHRSAAAFVDAEAGLFLSADPIAPGDRVLAGLSVAFDASCEEMWLAWRNGACLVPAPRSLVRSGADLGPWLIAHGITVVSTVPTLAALWPEEALENVRLVIFGGEACPPELAARISGRGREVWNTYGPTEATVVACGALLDGSDPVRIGLPLDGWSLAVVDADGARVPAGGTGELIIGGVGLARYLDAAQDAVKYAPHAGLGWDRAYRSGDLVRFDPEGLVFVGRADDQIKLGGRRIELGEIDAALQALPGVAGAAAVVQTTPAGNQVLVGYLSLVEPAPVGSDPVTSPFDLPAATEALRIALPAALVPLLAVVDTIPTRTSGKVDRAALPWPLPSLAGGSTDTDALSPTAAWLAEHWAAILGLPVTDADSDFFAYGGGSLSAAQFVSAIRERYPDTRVSDIYDHPRIGALAAELDGRTPPAARRSRTVLPTPARSGLLQSLLGIPLHLLVGAKWLVYLAAANNVLAAAGASFAPTVSWWWVLAGFLLLVTPLGKMGISVVAARLLLRGLKPGAYPRGGSVHLRLWLAEQVAQFVDAASLAGAPWISYYARLLGARIEPGVDLHSVPPVTGMLSIGARAAIEPEVDLAGYWLDGDTLRLGQVRIGEEAVVGSRSTLLGGAKIGAGAEIEPGSAVSGRVPAGERWAGSPATRVGSARHTWPAERPPSARRWLLAYGAGSVGLTAIPTVAVLLGVLIVGLFVGEAGSLGTAVGRAALAVPLAVLAAGLLYAGAVIGAVRLLGLGLTEGHHPVRSRVGWQVWMTERLLDGARTLLFPVYASLITPVWLRLLGAKVGSGVEASTVLLVPALTTIAPGAFLADDTMVACYELGGGWMRIDRAKIGRRAFLGNSGIAGPGRTVPRDGLVAVLSSTPRKAKRGSSWLGNPPARLRRRVTDIDEARTFHPHARLRLARSLWELLRLVPVFVSAWIALGVLAALEALWLTAGPGWALLLSGFVLIGAGVIAAAVSTAAKWLLVGRIRATEHPLWSSFIWRNEVSDTFVEMVARPWFAQNASGTPALALWLRSLGARIGRGVWCESYWLPEADLVTLAAGSSVNRGCVVQTHLFHDRIMQLDTVHIGAGGTLGPNSVILPAARIDDHATVGPGSLVMRGERVPTDSLWAGNPIAPWHRPPWKT",
      "product": ""
     },
     {
      "start": 4208,
      "end": 5542,
      "strand": 1,
      "locus_tag": "ctg55_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,208 - 5,542,\n (total: 1335 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_3 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17900.4 (Peptidase M1 N-terminal domain): [29:201](score: 60.0, e-value: 3.7e-16)<br>\n \n  PF01433.23 (Peptidase family M1 domain): [291:433](score: 95.7, e-value: 3.1e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg55_3 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01433.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008237' target='_blank'>GO:0008237</a>: metallopeptidase activity<br>\n  \n   PF01433.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg55_3_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCGTCACCCACGCCTCCGATCCTCGGCTCCGCATCCGCGGGCGACCCCTACCTGCCGGCGAGTGGGAACGGCGGCTACCAGGTCGAGCACTACGACCTGGTGCTGGACTACCGGGTCTCCTCCAACCGGCTGAGCGCCACCGCCACGATCACCGCGCGCGCCCTCACCCGGCTCGACCGGTTCAGCCTCGACCTGGCCGGCCTCAGCGTCGACAAGGTCACCGTGGCCGGGCGGATGCCCACCAAGACCACGCACACCGCCCGCAAGCTGGTGCTCACTCCGGCCGTGCCGCTGCAGGCCGGCGAGCGGTTCGACGTCGTCGTGGCCTACCGCGGCGCACCGCGCCCGGTGCGCAGCCACTGGGGCGAGGTGGGCTGGGAAGAGCTCACCGACGGCGTGCTCGTCGCCGGACAGCCCAGCGGCGCCCCGTCCTGGTTTCCCTGCAACGACCACCCGAGCGACAAGGCCACCTTCCGCATCCAGCTCAGCTGCGAGGCCCCGTACACGGTCGTGAGCAACGGCCCGCTCGTGGCCAAGAGCAGCCGGTCCGGCCGCACCACCTGGACCTTCGAGGTGCGCGAGCCCATGGCCGCGTACCTGGCCAGCGTGCAGATCGGCCGGTACCGCCGGCAGGACGTGACGGCCACCCCGGTGGCGTACAGCCTGTTCTACCCGCCTGCCCTGGCGCGGCCGGTGGCGGTGGACTTCGCCCGGCTGGGCGACATGATCGCCGTGTTCGGCGAGGCTTTCGGCCCCTACCCGTTCCCGGCGTTCTCGGTGATCGTGACGGCCGACGAGCTGGAGATCCCGCTCGAGGCGCACGGGCTGGCCGTCTTCGGCCGCAATCACGTGGACGGGCTGCACGGCAGCGACCGGCTCATCGCCCACGAGTTGGCGCACCAGTGGTTCGGCAACAGCCTCACCCTCACCCGGTGGCAAGACATTTGGCTGCACGAGGGCTTCGCCTGCTACGCCGAGTGGATCTGGGCGGAGGCCAGCGGCGGCCTCACCGCGCACGAGAGCGCCGTGCTGCACCGGGCCGAGGTGGACCTGCTGCCCAAGAACATCGTGGTGGGCGACCCCGGACCACCGGACATGTTCGACGACCGGGTCTACAAGCGCGGCGCCCTGGCCCTGCACGCCGTGCGCCAGGCCATCGGCGACGAGGCCTTCTTCACGGCGCTCCGCGCGTACACCCGCACCCACCGGCACGGCAGCGTCACCACCGACGACCTGCTCGGCTGCTTCGATGCGGCCTCCGGCACGCGGGCCGCCGACAAGATCATCGCCCGCTGGGTGTCAGGCAAGAGCCTGCCGCCGCTGGTCGCCTAG",
      "translation": "MSSPTPPILGSASAGDPYLPASGNGGYQVEHYDLVLDYRVSSNRLSATATITARALTRLDRFSLDLAGLSVDKVTVAGRMPTKTTHTARKLVLTPAVPLQAGERFDVVVAYRGAPRPVRSHWGEVGWEELTDGVLVAGQPSGAPSWFPCNDHPSDKATFRIQLSCEAPYTVVSNGPLVAKSSRSGRTTWTFEVREPMAAYLASVQIGRYRRQDVTATPVAYSLFYPPALARPVAVDFARLGDMIAVFGEAFGPYPFPAFSVIVTADELEIPLEAHGLAVFGRNHVDGLHGSDRLIAHELAHQWFGNSLTLTRWQDIWLHEGFACYAEWIWAEASGGLTAHESAVLHRAEVDLLPKNIVVGDPGPPDMFDDRVYKRGALALHAVRQAIGDEAFFTALRAYTRTHRHGSVTTDDLLGCFDAASGTRAADKIIARWVSGKSLPPLVA",
      "product": ""
     },
     {
      "start": 6280,
      "end": 6678,
      "strand": -1,
      "locus_tag": "ctg55_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,280 - 6,678,\n (total: 399 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGCCGCCATGGATACAAACCGCTCCACCGCGCCCGCCCCGGCGGAGGTGCAGGACTGCATCGACGCCTGCACCGAGCTGGAGCGGGCGAGCGAGGATTGCGCGGAGGCGTGCCTGCGGCTGGGCGGCGACGGCGACGTCACGGACTGCTTCCTGGCCGACCTGGACTGCACAGAGGTCTGCGCGGCGACCAACCGTCTGCTCGGGTGGCGCTCCCGCACCGACGGGCCCACGACCCAAGCGATGCTGCTGGCCTGCCGGGAGGCCGCGTCCGTTTCGATCGCGGCCTGTGAACGGATGCGGCCGGGCCGCCCGAACTGGACCTCCTGCGCGCCCGCCGCCCACCGGGCCATCGCGGCCTGCACGGCACTCCTCGAGGCGTACGAGCCGAACGGCTAG",
      "translation": "MAAMDTNRSTAPAPAEVQDCIDACTELERASEDCAEACLRLGGDGDVTDCFLADLDCTEVCAATNRLLGWRSRTDGPTTQAMLLACREAASVSIAACERMRPGRPNWTSCAPAAHRAIAACTALLEAYEPNG",
      "product": ""
     },
     {
      "start": 6722,
      "end": 7411,
      "strand": -1,
      "locus_tag": "ctg55_5",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,722 - 7,411,\n (total: 690 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1012:4&#39;-phosphopantetheinyl transferase (Score: 70; E-value: 2.8e-21)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_5 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01648.23 (4&#39;-phosphopantetheinyl transferase superfamily): [100:185](score: 40.5, e-value: 2.8e-10)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg55_5 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01648.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000287' target='_blank'>GO:0000287</a>: magnesium ion binding<br>\n  \n   PF01648.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008897' target='_blank'>GO:0008897</a>: holo-[acyl-carrier-protein] synthase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg55_5_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGTCCGGCCTGCCGGGCAGCAGCTCGTCGGCAGTCGACCTGTCGCGCACCGTGGTCGTCGCGATCGGTCACCGGGCGGAGACCAAGGCCGGGGACCATGCCCTGCTCGCCCGCCTCGTGGCCCGGCTGACCGGGGTGGGCGCCGCATCCGTCGCCCTGACCCAGCGCTGCCCCCAGTGCGGTGCGCCCGGTCACGGCCCGCTGCGGGTGGTCATCGACGGGTCCGGCACGGGCACCCCTCGGGTGAGCCTGGCCCGGGCGGGCGGACTGCTGGCCGTCGCGGTCACCGCGGCCGGCCCGATGGGCATCGATCTGGAGTCCCGCGCCGACCTAGCCCGCGCTCCGCTGAACGATGTGGCGCTCTCCCCCGCCGAGGCCGCGACCCTCGCCACGCTGCGTCCGGCCGATGCGGCCGCGGCGCTGGCCGCCCTGTGGACCTCGAAGGAGGCCGTGCTCAAGGCGGCCGAGGTCGGTCTCCGCGTGGACCCGTCCGAGCTCACGGTGACCCTCGACGCGGCCGGCCCGCCCGCATCCGCCAGGCACCGGATGCTCACCGACTGGCCCCAGGCCCCGTTCGCCCTGGGCGAGCTGCACCTGTTCCCCGTCGCCGGCCGCGCCGGCTTCACCTCTGCTCTCGCCGTCATCAGCTCCCGACGCCCGATGCTGCGGTTCCTCCCCCTCGACGACTAG",
      "translation": "MSGLPGSSSSAVDLSRTVVVAIGHRAETKAGDHALLARLVARLTGVGAASVALTQRCPQCGAPGHGPLRVVIDGSGTGTPRVSLARAGGLLAVAVTAAGPMGIDLESRADLARAPLNDVALSPAEAATLATLRPADAAAALAALWTSKEAVLKAAEVGLRVDPSELTVTLDAAGPPASARHRMLTDWPQAPFALGELHLFPVAGRAGFTSALAVISSRRPMLRFLPLDD",
      "product": ""
     },
     {
      "start": 7634,
      "end": 8251,
      "strand": 1,
      "locus_tag": "ctg55_6",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,634 - 8,251,\n (total: 618 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAAGCGGTTCGAAGGTCTGGCCAGGCCATCCACACTCGCCGCCGGGGCGGTCTTCCTGATCGGCGGCCTCCTCGACCAGGCCTTGCGCCTCACCGGCGACCCGGCGAGCAACCTTGTCCAGACTCCGCTCTACGCCGTGCGCTCCATCGCCCTGCTCGGCGGGGCGCTGCTGCTGATCCTGTCTCTCGTGTCGATCTACGAGCGGCACGCCAAGCAGATCGGCCCGTTCGGGTTCTCCGCGGCGATCGTCGCCGGAACCGGCACCATCCTGATCAGCGGCCAGTTCTGGGCCGAGTCCTTCCTGTATCCGACCCTGGGCCGTGTGGCCCCTGGCCTGCTCGACGGCACCGACCGGCCCGGCTCCTACGCGTTCGGGCTGCTGCTCACCGCGGCGGTGTTCGGGGTGGGCTGGCTGCTGCTCGGCAGCGCCATCCTGCGCGCACGGGTCTACCGGGTGCTTCCCGCCGTCGTGATCCTGGCCGGCGGAGCGGTGTCACTACTCCCCGGCAACGCGCTCGGCCAGGCGGTGCTAGGCGCCGGCCTGGTGCTGCTCTCCTTCAGCCCCACCTACCGCAAGCACGAGGGCCCCCAGCGGCAGGCCAGCCCGGCTCGCTGA",
      "translation": "MKRFEGLARPSTLAAGAVFLIGGLLDQALRLTGDPASNLVQTPLYAVRSIALLGGALLLILSLVSIYERHAKQIGPFGFSAAIVAGTGTILISGQFWAESFLYPTLGRVAPGLLDGTDRPGSYAFGLLLTAAVFGVGWLLLGSAILRARVYRVLPAVVILAGGAVSLLPGNALGQAVLGAGLVLLSFSPTYRKHEGPQRQASPAR",
      "product": ""
     },
     {
      "start": 8315,
      "end": 9331,
      "strand": 1,
      "locus_tag": "ctg55_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,315 - 9,331,\n (total: 1017 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_7 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01544.21 (CorA-like Mg2+ transporter protein): [31:334](score: 208.4, e-value: 1.5e-61)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg55_7 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046873' target='_blank'>GO:0046873</a>: metal ion transmembrane transporter activity<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030001' target='_blank'>GO:0030001</a>: metal ion transport<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGGCGCTGATAGATGACGCGATCTACGTAGATGGCCGTCGGGTGGCAACCCCGGAAACGTTGCAGGACGTGTTCGAGGTACTCAAAGAGAAGGACGGCTTCGCCTGGATCGGACTGTACCGGCCGACCGACGACGAGATCAGGTCGGTGGCGGACGAGTTCACGCTGCACCACCTCGCGATCGAGGACGCCCTCAAGGGGCACCAGCGCGCCAAGATCGAACGCTACTCCGACACCCTGTTCCTCGTACTCCGCCCGGCCCGGTACCTCGACTCCGAGGAACGCGTCGAGTTCGGTGAGCTGCACGTCTTCGTGGGCCCCGATTTTGTCGTGACCATCCGGCACGCGGAATCACCCGACCTCGCCTCGGTGCGGCACCGGCTGGAAAGCACCCCCAAACTCCTCGCCTTCGGCCCCCAGGCGGTGCTGTACGCGATCCTCGACCAGGTGATCGACGAGTACGCGCCCGTCGTGGCCGGCCTGGAGAACGACATCGACGAGATCGAGGACCAACTCTTCGACGGCGATCAGGCGGTGTCCCGGCGCATCTACGCGCTCTCCCGGGAGGTCATCGAGTTCCAGCGCGCCACCCAGCCGCTGATCGGCATGCTCGAATCCCTGCAGGAGGGGTTCGAGAAGCACAACGTGGATGTGGAGCTGCACCGGCACCTGCGCGACGTGCTCGACCACACCATCCGGGTCGTCGAGCGGGGGGATGCGTTCCGCCAGCTGCTGCAGAACGCCCTCACTGTGCACAGCACCCTCGTGGCGCAGAGGCAGAACGACGAGACCCGCCGGCTCTCCGAGACGGGCCTGGCGCAAAGCGAAGAGGTCAAGAAAATCTCCAGTTGGGCGGCGATTTTGTTCGCCCCCACCCTGGTCGGCACCATCTACGGCATGAATTTCACCCATATGCCGGAGCTAAAATGGCAGTTCGGCTATCCGTTCGCGATCACTCTGATGATCGCCATGGGGTTCGGGCTCTACGCCGTCTTCAAGCGCAAGAACTGGCTGTAG",
      "translation": "MALIDDAIYVDGRRVATPETLQDVFEVLKEKDGFAWIGLYRPTDDEIRSVADEFTLHHLAIEDALKGHQRAKIERYSDTLFLVLRPARYLDSEERVEFGELHVFVGPDFVVTIRHAESPDLASVRHRLESTPKLLAFGPQAVLYAILDQVIDEYAPVVAGLENDIDEIEDQLFDGDQAVSRRIYALSREVIEFQRATQPLIGMLESLQEGFEKHNVDVELHRHLRDVLDHTIRVVERGDAFRQLLQNALTVHSTLVAQRQNDETRRLSETGLAQSEEVKKISSWAAILFAPTLVGTIYGMNFTHMPELKWQFGYPFAITLMIAMGFGLYAVFKRKNWL",
      "product": ""
     },
     {
      "start": 9488,
      "end": 13180,
      "strand": 1,
      "locus_tag": "ctg55_8",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,488 - 13,180,\n (total: 3693 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGTCCTCGCCCGGCTCGCGTCAAGCGACCTCCCCGGACTCGGTGAGCCTGGGGGACCCGTCGCTGGTCGCCGGGAACATCGCCGAACCCACCTGGCAACGCTGGCGGGACGAACTCGCCCTGGTCGGCGGGCACTCCCCGCTGCTGCACTTCGGTGACAGCCCGCGCTCCCGCATCGAGCTCTCCGCCACCCACCCGGGCGGACTGCCGCAGTTCATCACCGGCAAGACCACTCTGCTGTCCAACCTGATCCGCGACGAACTGGCGCTTCGCAACGCCCGCCTGGCCGCCAACGAGATCACCCAGAAGGGCATCGAACTGCGCTCCATGCGCGGCATCGAGTCGGTGCACCTGGCCATCGGCCTGGCCCAGTGGCGTCACGGCGACGTGGAGTTCACCGCGCCGGTGCTGCTGCGGCCCCTCGCCATCCGCCGTTACGGCCGGGACTTCGAACTCAAGCTCAAGGGCCAGCCGTTCCTCAACCCCGAACTGGCCCGCGCCCTGCACGACCAGTTCCAGATCACCCTCGACGCCGACGCGTTCGTGGCCCTCGCCGTGACCAACGGCGCGTTCAAGCCGCAACCCGTCATCGACCGCCTGCGCGGCCTCACCTCGCACCTGCCCTGGTTCAACGTGGTACCCCGCCTGGTCGCGTCCTCCTTCGCCGACGTCGGCCGCGCCATGGCCGTCGACGCGCAGAAGCTCACGCATCCGGTGCTCGACGCCGTCGCCGGCAACCCCACCGCCCGCCGCGCCATCGAAATGGCGTACAACCCGGTGCTACCGATCGGCCAGGACGTGCGCCCGCCCGGCACCGACACGCTGCTGCTGGATGCCGACGCCGAGCAGGAGAACGTCGTCGCGCAGATCAGCGCCGGCAACTCCCTCGTCGTGAAGACCCTGCCCGGAACGGGCGGCACCCAGACCATCGTGAACGCCATCGGCTCGCTCGTCGCCCAGCACAAGCGCGTGCTCGTGGTCAGCGCCCGGCGGTCCAGCCTCGACGGCATCGCGCACCGGCTCGTGCAGGTGGGCCTGCCCGGCGTGGCCGTCACCCCGCGCACGCTGCGCCGCGACCTGATCCAGTCGATCACCCGCAACGAGAAGGCCGCCCAGCCGCGCGTCGGCGACGTCGACGACGCTCTCGTGCGCCTCCGCAAGGTACTGCTCGACTACCGCTCCGCCCTCACCCGCAAGGACGCCGCCCTCGGCGTCTCGGTGCTCGACGCGCTCGGCGAACTCGCCCGCCTCGCCCAGCTGCCGGCGCCGCCGTCGACCACCGCCCGGCTCGACCGGGTGGCCCTCGAACGCCTCGCCCACGACCGGGCCAGCGCCGCCGCGATCCTGATCAAGGCCGCCGTCCTCGGCCAGTTCCGCTACGGCCCGGGCGACTCGCCCTGGTACGGGGCCTCCTTCGCCTCCACGGCGGATGCCGGCGCCTCGCACGAACTCGCCAAGCGGCTCAGCCAGACCGACGTGCCCCGGCTGCTCGAGCGCGCCGGCCACCTGGTCGGCCAGACCCGGCTGCGCCCGTTCGAGACGGTGCACGAGTTGGGCATCTACCTGCGCCTGCTCCTGGACATCCGCGAGACCCTGGACAAATTCCAGCCCGCCGTGTTCGACCGCTCACTGACCGAACTCATCGCCGCCACCTCGGCCCGCCGCGACTCGCCCGAGATGACCTCGAGCAACCGTCGCCGGCTCCGCAAACTCGCCGACGAGTACCTGCGACCCGGCGTGCACGTGAGCGACATGAACGAGAGCCTGCGGCGCATCCAGCAGCAGCGCACCCTGTGGCAGCGGTACGCCGCCGCGGGCGTCACCCCCGAGGTCCCGGTGGGCATCAACGATGTGCACGTGGCCTTCCAGCGGGTCTCCGAAGACCTCGGCAAGCTCGATGTGCCGCTGGGCAACGCCGGCACCCCGCGCCAGCTGGTCTCCCGGCCGGTGAAGGAACTGCTGCGCACCCTGGCCGGCCTCGCCGCCGACAGCGAGGTGCTCGCCAACCTGCACGAGCGCACCGCCCTGCTCGCCACCCTGCGCGAGCACAACCTCGACCCGCTGATGACCGACCTGTCCCAGCGACACGTGTCGGAAGAGAACGTGGCCGCCGAACTCGAACTCGCCTGGTGGCAGTCCGTGCTCGAGGTCATGCTCAGCGGTGACCGGGCCCTGCTCAACGCCAACACCCAGGTACTCGACCGGCTCGAGGCCGACTTCAAGCTCGTCGACGAGGCGCACGCCTCCACCACCGGGCAGATCCTGGCCTGGCTGCTCGCCGAGACCTGGAAGATCGGCGTGGTCGACTGGCCCGACGAAGCCGACCAGCTGCGCCGGCTGCTGCGCGCCGACCGGGCCACCCCCTCCCGCATCAACGAGGTCGCCCCGCACCTGGGTCGTGTGCTCGCCCCGGTCTGGCTGGCCTCGCCGTACGAGGTCGCCGGACTCGACGACAAGATGACCTTCGACGCTGTGCTGCTCGTCGACGCCGGGGCCACCACCCTGGCCGAGAACGTCGGTGCGATCCGCCGCGCCAAGCAGGTCGTGGCCTTCGGTGACCCGGTCACCCAGACGCCCTCGGGCTTCGAGACCGGCATCGTGGAGCCGGCCGATGTGCCCCGCCCGCAGGAGACCAACGTCGACGCGTTGCACGCCGACTCGGCGCTGGCACGCCTGGGCGAGCTGCTGCCCACCCTCACTCTCACCCGCAGCTACCGGGCCGGCGGCGAGGACCTCGCCGAGCTGGTCAACCACCGCTTCTACGGCGGCCGGATCGACTCGCTGCCCTGGGCGGGCAGCTTCCTCGGCCACGGCAGCCTCACCCTCAACTACGTCAAGGGCGGCCACGGCATGCCCGACGTCGACAGCGGCGCCGTCGAGAGCGTCGATGCCGAGGTATCCAAGGTCGTCGACCTGGTCATGGACCACGCCGTCAAGCGCCCCCGCGAGTCGCTCATGGTGATCACCGCCAGCGCCCGGCACGCCGTGCGCGTGCACCAGGCCGTGCTCGCCGCGTTCGCCAAGCGCACCGACCTGAGCGACTTCATCCTCAAGGACCGTGCCGAACCGTTCACGGTGCTCACCCTCGAGCAGGCCGTCGCGCAGAGCCGCGACCGGGTGATCTTCTCCATCGGCTACGGCCGCACCCCGCACGGCCGGCTGCTGAGCAACTTCGGTTCGCTCGGCGAACCCGGCGGCGAACGCCTGCTCGCGATCGGCATGACCCGCGCCCGCCGCGCCATGGACATCGTCTCCTGCTTCCGCCCCATCGACATCGACGCCGACCGCCAGCGGCACGGCATCCTGGCCCTGTCGCAGGTGCTCACCGAGACCGAGGCGCGCCGCAACGAGGTGGCGGTGCCGGATGCGCGCGAGGCCATGCTCGTCGACCTCGCCCGCCGTCTGGAACGCCAGGGCCTCACCGTCTCGCTCGGGCACCGCGGCAAGCTCGCGCTGGCCGCCTCCCACGCCGGCCGCGCCGTCGTGGTGGAGACCGACGCCGTGGTCAACCGGGCGAGCCTGCGCGAATCGCTGCGCCTCCGCCCCGAAGTGCTGCGCCGCCTCGGCTGGCACTACCTGCGGGTGCACAGCTTCGAGCTGTTCAGCAACCCGGATGCCGTCGCCGCCCGCGTCGCCGCCCTCGCGGGCGTCGTCCCGGCCGAAGGGTCTGGCGGTCCGGCGCACCGTGCCTGA",
      "translation": "MSSPGSRQATSPDSVSLGDPSLVAGNIAEPTWQRWRDELALVGGHSPLLHFGDSPRSRIELSATHPGGLPQFITGKTTLLSNLIRDELALRNARLAANEITQKGIELRSMRGIESVHLAIGLAQWRHGDVEFTAPVLLRPLAIRRYGRDFELKLKGQPFLNPELARALHDQFQITLDADAFVALAVTNGAFKPQPVIDRLRGLTSHLPWFNVVPRLVASSFADVGRAMAVDAQKLTHPVLDAVAGNPTARRAIEMAYNPVLPIGQDVRPPGTDTLLLDADAEQENVVAQISAGNSLVVKTLPGTGGTQTIVNAIGSLVAQHKRVLVVSARRSSLDGIAHRLVQVGLPGVAVTPRTLRRDLIQSITRNEKAAQPRVGDVDDALVRLRKVLLDYRSALTRKDAALGVSVLDALGELARLAQLPAPPSTTARLDRVALERLAHDRASAAAILIKAAVLGQFRYGPGDSPWYGASFASTADAGASHELAKRLSQTDVPRLLERAGHLVGQTRLRPFETVHELGIYLRLLLDIRETLDKFQPAVFDRSLTELIAATSARRDSPEMTSSNRRRLRKLADEYLRPGVHVSDMNESLRRIQQQRTLWQRYAAAGVTPEVPVGINDVHVAFQRVSEDLGKLDVPLGNAGTPRQLVSRPVKELLRTLAGLAADSEVLANLHERTALLATLREHNLDPLMTDLSQRHVSEENVAAELELAWWQSVLEVMLSGDRALLNANTQVLDRLEADFKLVDEAHASTTGQILAWLLAETWKIGVVDWPDEADQLRRLLRADRATPSRINEVAPHLGRVLAPVWLASPYEVAGLDDKMTFDAVLLVDAGATTLAENVGAIRRAKQVVAFGDPVTQTPSGFETGIVEPADVPRPQETNVDALHADSALARLGELLPTLTLTRSYRAGGEDLAELVNHRFYGGRIDSLPWAGSFLGHGSLTLNYVKGGHGMPDVDSGAVESVDAEVSKVVDLVMDHAVKRPRESLMVITASARHAVRVHQAVLAAFAKRTDLSDFILKDRAEPFTVLTLEQAVAQSRDRVIFSIGYGRTPHGRLLSNFGSLGEPGGERLLAIGMTRARRAMDIVSCFRPIDIDADRQRHGILALSQVLTETEARRNEVAVPDAREAMLVDLARRLERQGLTVSLGHRGKLALAASHAGRAVVVETDAVVNRASLRESLRLRPEVLRRLGWHYLRVHSFELFSNPDAVAARVAALAGVVPAEGSGGPAHRA",
      "product": ""
     },
     {
      "start": 13752,
      "end": 14009,
      "strand": 1,
      "locus_tag": "ctg55_9",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,752 - 14,009,\n (total: 258 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCGCAAGTCGGCACGACGCAACTCGGCGAGATGCAGCAAAGTGCCCCCTCCGGCGCCCTGAAAGGTGCTTCTGCGGCAAGTCGGCGACGTGAGAGTCTTTGCGTCTTTGCGTCTTTGCGTCTTTGCGTCTTTGCGTCTTTGCGTCTATGCAGCGGATGCAGCGGATGCAGCGGATGCAGCAGATGCAGCGGATGCAGCGAGGGGTGCCGGGAGGCGCTGCTGCGGGTGCGACGGGGGGAGAGGCGTGACGGCTAG",
      "translation": "MPQVGTTQLGEMQQSAPSGALKGASAASRRRESLCVFASLRLCVFASLRLCSGCSGCSGCSRCSGCSEGCREALLRVRRGERRDG",
      "product": ""
     },
     {
      "start": 14006,
      "end": 14890,
      "strand": -1,
      "locus_tag": "ctg55_10",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,006 - 14,890,\n (total: 885 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_10 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01741.21 (Large-conductance mechanosensitive channel, MscL): [130:259](score: 118.5, e-value: 2.2e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGCCCCACCTGCGGCGGCAAGCTGCGCAAGGTCTACTCGTCGATCGGGGTGAGCTTCACCGGCTCGGGCTTCTACCGCAACGACTCGCGCGCCGAGTCGAGCGGCAAGTCATCGCTGTCCGCGGAGAAGAGCGCGGCCAAGTCCGACAGCAAGTCCGACTCCGCCCCGGCCGCGAAAACGGCCGAGAAGTCCGGCGCCGCCGCATCGACGTCGTCGAGCGGGTCGTCGTCAGGCGGATCGTCCTCGTCGTCCTCTTCTTCCTCGTCCTCGAGCTCGTCGCCGACTCCGGCGCCGAAGTCATCCTGACCCTGCCAGGCGCCTCCGCACAACCGCGCACACGCACCGCAGCACAACCGCACCGCAGCACCTCAAGGAGTAATCGAATGGGCATGATCAACGGCTTCAAAGAATTCATCATGCGCGGCAACGTCATCGAACTCGCCGTCGCCGTCGTCATCGGGGCAGCATTCACCGGGGTCGTCAAGGCCATCGTCGACGGCATCTTCAACCCGCTGATCGGGGCGATCTTCAACGCCGAGTCGCTCAACGACTCCATGAACGTGACGCTCGGCGCCAGCACCATCTCGTTCGGACTCGTCCTGGCCGCGCTGATCCAGTTCCTCCTCGTGGCCGCGGTCGTGTACTTCGCCTTCGTGATGCCGCTCAACACGCTCAAGGAACACCAGGCCCGTCGCCGCCAGGCCGGCGAGCCGCTGGACCCGAAGAAGAACCCGATCACCGACCTCGACCTGCTCACCGAGATCCGCGACCTGCTCGCCGCCCAGAACGGTGCCGTCACGCCCTCCGCCGCCACGGATGCCCCCGCTCCGTACACCGCAGGCACCTCGCCCAGTGGGCCCGACGGCGCCAAGCACACCCTCTAG",
      "translation": "MPHLRRQAAQGLLVDRGELHRLGLLPQRLARRVERQVIAVRGEERGQVRQQVRLRPGRENGREVRRRRIDVVERVVVRRIVLVVLFFLVLELVADSGAEVILTLPGASAQPRTRTAAQPHRSTSRSNRMGMINGFKEFIMRGNVIELAVAVVIGAAFTGVVKAIVDGIFNPLIGAIFNAESLNDSMNVTLGASTISFGLVLAALIQFLLVAAVVYFAFVMPLNTLKEHQARRRQAGEPLDPKKNPITDLDLLTEIRDLLAAQNGAVTPSAATDAPAPYTAGTSPSGPDGAKHTL",
      "product": ""
     },
     {
      "start": 15040,
      "end": 15681,
      "strand": -1,
      "locus_tag": "ctg55_11",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,040 - 15,681,\n (total: 642 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_11 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01812.23 (5-formyltetrahydrofolate cyclo-ligase family): [29:207](score: 109.9, e-value: 1.4e-31)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGTAACCATGGCATTAGGTTAGCGGGAACCCGAATGGCTTACGCACCTAGGATGACTTGTATGGATTCTGACATCGAGCACCGAAAGCGGGCGCTCCGCGCAGAGCTGCGGGAGCGACGGCACACCATGACGGCGGCAGAACGCGACGCGGCCACCGCCGGGTTCACCGAAAACCTGCAAAGCATCGTGCTCGACCTGTCCGCCCGGTCGATTTCCTGCTACCTCTCCAGCCCCACCGAGCCCAACACGCGCCCGTTCGTGAACTGGGCCGAGGCCCGCGGCATCCGGGTGCTCTTCCCCGTATCGCGGGATGACGGCCTGCTGGACTGGACCGTCGGCGAGGAGGAAACCGAGGTTCAGGGTCTCTCCGGCGCCCCGGAGCCCCAGGGCGAACTGCTCGGCCCGATCGCCATCAACGATGTCGACCTCATCATCGTTCCCGCCGCGGCCATCGACCACACCGGTCTGCGGATGGGCTGGGGGCGCGGGTATTTCGACAAGACCCTCGGATCGATGGAGAAATGCCCGCCGGTGTACGCCGTCGTCTACGACAATGAGTATGTGGACGAAGTGCCGCGCGAGGTGCACGACCAGCCGGTGAACGGTCTCGTCACGCCCACCCGCATCGTCGTCTTCTAA",
      "translation": "MSNHGIRLAGTRMAYAPRMTCMDSDIEHRKRALRAELRERRHTMTAAERDAATAGFTENLQSIVLDLSARSISCYLSSPTEPNTRPFVNWAEARGIRVLFPVSRDDGLLDWTVGEEETEVQGLSGAPEPQGELLGPIAINDVDLIIVPAAAIDHTGLRMGWGRGYFDKTLGSMEKCPPVYAVVYDNEYVDEVPREVHDQPVNGLVTPTRIVVF",
      "product": ""
     },
     {
      "start": 15745,
      "end": 16563,
      "strand": 1,
      "locus_tag": "ctg55_12",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,745 - 16,563,\n (total: 819 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1064:glucose-1-phosphate adenylyl/thymidylyltransferase (Score: 177.3; E-value: 6.4e-54)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_12 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00483.26 (Nucleotidyl transferase): [1:246](score: 64.3, e-value: 1.4e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg55_12 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00483.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg55_12_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCCAAAGAGATGTTGCCGGTGGTGGACAAGCCCGCCATCCAGTACGTCGTCGAGGAGGCCGTCGCCGCCGGACTGACCGACGTGCTCATGATCACGGGCCGCAACAAGAACGCACTGGAGAACCATTTCGACCGCGTCACCGAGCTCGAGGCGGTGCTCATCCAGAAGGGTGACCGCGATCGTCTCGCCAAGGTGAACGAGTCGACCGACCTTGCCGACATGCACTACGTGCGTCAGGGTGACCCGCTGGGCCTGGGGCACGCCGTGCTCCGCGCCAAGATGCACGTGGGCAACGAGCCCTTCGCCGTGCTCCTCGGTGACGACATCATCGACGCCCGCGACCCGCTGCTCGACAAGATGCTCGCCGAGCAGATCGGCCGCAACACTAGCGTCGTCGCGCTCCTCGAGGTCGACCCGTCGCAGATCCACCTCTACGGCGCCGCCGCGATCGAGAAGACCGACGACCCCGACGTGGTGCGCATCACCGGCCTGGTCGAGAAGCCGTCGGCAGCGGATGCCCCGTCGAACCTGGCCATCATCGGCCGCTACGTGCTGCGCCCCGAGGTGTTCGACGTGCTCGAGCACACCGCGCCGGGCAAGGGCAACGAGATCCAGCTCACCGACGCCCTGCAGGAGATGGCGGTCAACCCGGAGACCACGGGCGGCGTCTACGGCGTCATCTTCCGCGGCCGTCGCTACGACACCGGGGACCGGTTGGACTACATCAAGGCCATCATCCAGCTCGCCGTGGACCGGGACGACCTCGGCACCGAGCTGCGCCCCTGGCTCAAGGAGTTCACCGCCACTCTCGACTAG",
      "translation": "MPKEMLPVVDKPAIQYVVEEAVAAGLTDVLMITGRNKNALENHFDRVTELEAVLIQKGDRDRLAKVNESTDLADMHYVRQGDPLGLGHAVLRAKMHVGNEPFAVLLGDDIIDARDPLLDKMLAEQIGRNTSVVALLEVDPSQIHLYGAAAIEKTDDPDVVRITGLVEKPSAADAPSNLAIIGRYVLRPEVFDVLEHTAPGKGNEIQLTDALQEMAVNPETTGGVYGVIFRGRRYDTGDRLDYIKAIIQLAVDRDDLGTELRPWLKEFTATLD",
      "product": ""
     },
     {
      "start": 16663,
      "end": 17286,
      "strand": 1,
      "locus_tag": "ctg55_13",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,663 - 17,286,\n (total: 624 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1111:GCN5-related N-acetyltransferase (Score: 102.3; E-value: 4.8e-31)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_13 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13302.10 (Acetyltransferase (GNAT) domain): [1:142](score: 70.0, e-value: 3.4e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg55_13 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF13302.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016747' target='_blank'>GO:0016747</a>: acyltransferase activity, transferring groups other than amino-acyl groups<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg55_13_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACCCTGCGCCCGATCCGCCTGCGCGACGCCCGCGCCCTGGAGCGCGAGCTGATGGCCAACCGTTCCTGGCTGCGCACCTGGGAGGCCACCAGTCCCTACGCGCCCATGTCCTTCGATACCCGGGCGAGCATCCGCAGCCTGCTCGCCCACTCGCGCACGGGCAGCGGGCTGCCGTTCCTGATCGAGTACAACGGGGAACTCGCCGGCCAGCTCAACGTGTCGTCGATCACCTGGGGATCGCTCTCCAGCGCGTCGATCGGCTACTGGGTGGGCGAGGAGTTCGCCGGCCGGTCGATCACCCCCACCGCGGTGGCCCTGGCCACCGACTACTGCTTCGCCCAGTTGGGCCTGCACCGCATGGAAATCTGCATCCGCCCGGAGAACGGGCCGTCGTTGCGGGTCGTGGAGAAGCTGGGGTTCCGCTACGAGGGGCTGCGCCGCCGGTTCATCCACATCAACGGCGCCTGGCGTGACCACTTCGCCTTCGGCCTCGTGGCCGAGGAGGTGCGCACCGGGGTGCTGCGACGCTGGCAGGACGGTCTCGTACCGCCCGGGAACGCCACCGTGAACGAGTACGACCGGGCCGCCTCGCAGCATCCGTTGCCGGTGGCCGACAAGTGA",
      "translation": "MTLRPIRLRDARALERELMANRSWLRTWEATSPYAPMSFDTRASIRSLLAHSRTGSGLPFLIEYNGELAGQLNVSSITWGSLSSASIGYWVGEEFAGRSITPTAVALATDYCFAQLGLHRMEICIRPENGPSLRVVEKLGFRYEGLRRRFIHINGAWRDHFAFGLVAEEVRTGVLRRWQDGLVPPGNATVNEYDRAASQHPLPVADK",
      "product": ""
     },
     {
      "start": 17461,
      "end": 18330,
      "strand": 1,
      "locus_tag": "ctg55_14",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,461 - 18,330,\n (total: 870 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGGCTGCAGCAGACCCTGCGCATCCTCGCCGAGACGTCGGAGATTCCCCAGGAGGTACGCGTGGAGACCAACGCGCGCGGTGTGTCCGCCCAACGTAAGCTGCTCGCCCAGGCCGAAGAAGACGCCCGGATCGCCTCCAAGGCCGCCGGAGACGCCGCCACGGCCGCTCGACGTGCCGCGGTGCTGCGCGCCGCCGCCGCCCGCCCCCAGGCGCTCACCCCGGCCGGCAAGGCCAAGCGCCTGCGCGCCATGCGGGCCCTCTCGACCCTGCTGCTGCTCATCGGCCTGGTCAGCGCCGTCGCCGGTCTCACCCTGCTCTCCACCGGCCTGTGGACGTTGCTGGTCGGCGGACTCGTCGCCGCCGGTACCGCGCTCGCCGCGCTCGGTCGTCTCGCCAGCGTGAGCCGGTCGGCCCGTGCGCCGCGCCAGGCAACGGATGCCGAGGCCACCGACACCGCTCGCCGCGTGCCGGCCGGCAGCCGCGGCCAGCGCTTCGAACCCGTGCACTTCGAGGAGGCGCCCGTGGCGGCGCCCACCCCCTGGACGCCGCAGCCGTTGCCCAAGCCCCTGCACCTCTCGCCGGGCTCGATCGCCCAGGCGGCCATGGCGTCGGTGGACGCCGCCGCGCAGCTGCGCCAGGCGGCCGCCGAAGCCGAGCTGCAGCGCCGGGCGCAGGCCCTGGCCGAGGCCATCGCGCCGTCGGAGGTCACCCCGATCACCCGCCCCGTGGCCGCCAGGGCTGCGGCCGCCAAGGCGTCGCCGCAGGCCGCGCCGAGCCGGTTCGCCAGCATGGGCATCGTCGGCGACACCGAACCCGGCATGACCGACCTCGACGATGTGCTGCGCCGCCGCCGGGCCGTCGGCTGA",
      "translation": "MRLQQTLRILAETSEIPQEVRVETNARGVSAQRKLLAQAEEDARIASKAAGDAATAARRAAVLRAAAARPQALTPAGKAKRLRAMRALSTLLLLIGLVSAVAGLTLLSTGLWTLLVGGLVAAGTALAALGRLASVSRSARAPRQATDAEATDTARRVPAGSRGQRFEPVHFEEAPVAAPTPWTPQPLPKPLHLSPGSIAQAAMASVDAAAQLRQAAAEAELQRRAQALAEAIAPSEVTPITRPVAARAAAAKASPQAAPSRFASMGIVGDTEPGMTDLDDVLRRRRAVG",
      "product": ""
     },
     {
      "start": 18392,
      "end": 18481,
      "strand": 1,
      "locus_tag": "ctg55_15",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,392 - 18,481,\n (total: 90 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGCAGTTGGTAGCGCGTCTCGTTCGCAATGAGAAGGTCAGGAGTTCGAATCTCCTTAGCTCCACCACTGATGCAGAAGGACCGTAG",
      "translation": "MAQLVARLVRNEKVRSSNLLSSTTDAEGP",
      "product": ""
     },
     {
      "start": 18596,
      "end": 18898,
      "strand": -1,
      "locus_tag": "ctg55_16",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,596 - 18,898,\n (total: 303 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCGCACCGTGACGCCCTCCACGCCCTCTCCGAGTGGGATGTCCGGCAGGTAGGTGCCCACCGGCGCATCGACATCCAGCAGCCCGTCATCGGCTGCGATCCCGATCGCAAGAACGCAGACGCCCTTGGCAACCGAGTGAACGTCCCGGCGATCATCGGCGCCCCAGTGATGCTCGGCGCTGTCGTCGTCAATGAGGACGTGCACGGAGTGCGCGCTGAAGCCGTCCTCTTCGATGATGCCGACAAGGCGGTCTACGATCGTCTGCGCTCTGCTCATCCCACCATTCTGTCGCGCGAGTAG",
      "translation": "MPHRDALHALSEWDVRQVGAHRRIDIQQPVIGCDPDRKNADALGNRVNVPAIIGAPVMLGAVVVNEDVHGVRAEAVLFDDADKAVYDRLRSAHPTILSRE",
      "product": ""
     },
     {
      "start": 18844,
      "end": 19035,
      "strand": -1,
      "locus_tag": "ctg55_17",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,844 - 19,035,\n (total: 192 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGTACGTGCTCGCGTTGGAGTACTGGAAGACCCGTCCGCGTGATGGACGGCCGAGAAACTCAGCCGCGAGGTCGGGCCAGTCCGTCGTCATCGTCTCCGACCACGGAAGGTCGATACCGCTCGTCATCGTGAGCAGATGCCGCACCGTGACGCCCTCCACGCCCTCTCCGAGTGGGATGTCCGGCAGGTAG",
      "translation": "MYVLALEYWKTRPRDGRPRNSAARSGQSVVIVSDHGRSIPLVIVSRCRTVTPSTPSPSGMSGR",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 138,
      "end": 4200,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 19200,
      "product": "NAPAA",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [
      {
       "start": 3,
       "end": 5,
       "strand": 1,
       "containedBy": [
        "ctg55_1"
       ]
      },
      {
       "start": 15658,
       "end": 15660,
       "strand": -1,
       "containedBy": [
        "ctg55_11"
       ]
      }
     ],
     "bindingSites": []
    },
    "type": "NAPAA",
    "products": [
     "NAPAA"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NAPAA",
    "anchor": "r55c1"
   }
  ]
 },
 {
  "length": 28507,
  "seq_id": "NODE_84_length_28507_cov_25.609884",
  "regions": []
 },
 {
  "length": 27242,
  "seq_id": "NODE_86_length_27242_cov_23.800258",
  "regions": []
 },
 {
  "length": 26478,
  "seq_id": "NODE_87_length_26478_cov_23.384076",
  "regions": []
 },
 {
  "length": 25935,
  "seq_id": "NODE_89_length_25935_cov_27.793990",
  "regions": []
 },
 {
  "length": 25696,
  "seq_id": "NODE_91_length_25696_cov_25.753269",
  "regions": []
 },
 {
  "length": 25654,
  "seq_id": "NODE_92_length_25654_cov_24.209368",
  "regions": []
 },
 {
  "length": 23892,
  "seq_id": "NODE_93_length_23892_cov_24.738820",
  "regions": []
 },
 {
  "length": 23781,
  "seq_id": "NODE_94_length_23781_cov_25.430138",
  "regions": []
 },
 {
  "length": 21441,
  "seq_id": "NODE_95_length_21441_cov_23.337109",
  "regions": []
 },
 {
  "length": 21000,
  "seq_id": "NODE_97_length_21000_cov_24.597237",
  "regions": []
 },
 {
  "length": 20439,
  "seq_id": "NODE_98_length_20439_cov_24.410765",
  "regions": []
 },
 {
  "length": 19494,
  "seq_id": "NODE_99_length_19494_cov_22.877272",
  "regions": []
 },
 {
  "length": 18440,
  "seq_id": "NODE_100_length_18440_cov_24.341883",
  "regions": []
 },
 {
  "length": 17007,
  "seq_id": "NODE_102_length_17007_cov_23.552747",
  "regions": []
 },
 {
  "length": 16790,
  "seq_id": "NODE_103_length_16790_cov_25.358463",
  "regions": []
 },
 {
  "length": 16276,
  "seq_id": "NODE_104_length_16276_cov_26.767517",
  "regions": []
 },
 {
  "length": 15550,
  "seq_id": "NODE_105_length_15550_cov_22.811672",
  "regions": []
 },
 {
  "length": 15207,
  "seq_id": "NODE_106_length_15207_cov_24.967614",
  "regions": []
 },
 {
  "length": 14622,
  "seq_id": "NODE_107_length_14622_cov_25.266552",
  "regions": []
 },
 {
  "length": 14571,
  "seq_id": "NODE_109_length_14571_cov_25.350490",
  "regions": []
 },
 {
  "length": 13791,
  "seq_id": "NODE_110_length_13791_cov_22.322809",
  "regions": []
 },
 {
  "length": 12712,
  "seq_id": "NODE_111_length_12712_cov_26.351484",
  "regions": []
 },
 {
  "length": 11853,
  "seq_id": "NODE_112_length_11853_cov_25.989470",
  "regions": []
 },
 {
  "length": 11763,
  "seq_id": "NODE_114_length_11763_cov_23.432141",
  "regions": []
 },
 {
  "length": 11472,
  "seq_id": "NODE_115_length_11472_cov_25.375516",
  "regions": []
 },
 {
  "length": 10748,
  "seq_id": "NODE_117_length_10748_cov_23.621310",
  "regions": []
 },
 {
  "length": 10463,
  "seq_id": "NODE_118_length_10463_cov_20.744175",
  "regions": []
 },
 {
  "length": 10213,
  "seq_id": "NODE_119_length_10213_cov_25.918015",
  "regions": []
 },
 {
  "length": 10066,
  "seq_id": "NODE_120_length_10066_cov_24.656322",
  "regions": []
 },
 {
  "length": 9656,
  "seq_id": "NODE_121_length_9656_cov_25.786825",
  "regions": []
 },
 {
  "length": 9478,
  "seq_id": "NODE_122_length_9478_cov_26.273801",
  "regions": []
 },
 {
  "length": 9302,
  "seq_id": "NODE_123_length_9302_cov_22.210298",
  "regions": []
 },
 {
  "length": 8332,
  "seq_id": "NODE_124_length_8332_cov_20.034040",
  "regions": []
 },
 {
  "length": 7875,
  "seq_id": "NODE_126_length_7875_cov_24.880867",
  "regions": []
 },
 {
  "length": 7547,
  "seq_id": "NODE_127_length_7547_cov_23.879920",
  "regions": []
 },
 {
  "length": 6986,
  "seq_id": "NODE_128_length_6986_cov_23.606166",
  "regions": []
 },
 {
  "length": 6680,
  "seq_id": "NODE_129_length_6680_cov_22.075875",
  "regions": []
 },
 {
  "length": 6649,
  "seq_id": "NODE_131_length_6649_cov_26.715916",
  "regions": []
 },
 {
  "length": 6340,
  "seq_id": "NODE_134_length_6340_cov_28.323327",
  "regions": []
 },
 {
  "length": 6209,
  "seq_id": "NODE_135_length_6209_cov_26.721624",
  "regions": []
 },
 {
  "length": 6204,
  "seq_id": "NODE_136_length_6204_cov_21.889832",
  "regions": []
 },
 {
  "length": 5971,
  "seq_id": "NODE_137_length_5971_cov_19.606040",
  "regions": []
 },
 {
  "length": 5314,
  "seq_id": "NODE_138_length_5314_cov_20.544778",
  "regions": []
 },
 {
  "length": 5040,
  "seq_id": "NODE_139_length_5040_cov_26.686883",
  "regions": []
 },
 {
  "length": 5030,
  "seq_id": "NODE_140_length_5030_cov_26.918635",
  "regions": []
 },
 {
  "length": 4899,
  "seq_id": "NODE_141_length_4899_cov_25.901908",
  "regions": []
 },
 {
  "length": 4809,
  "seq_id": "NODE_142_length_4809_cov_30.225063",
  "regions": []
 },
 {
  "length": 4767,
  "seq_id": "NODE_143_length_4767_cov_23.380597",
  "regions": []
 },
 {
  "length": 3520,
  "seq_id": "NODE_145_length_3520_cov_24.374383",
  "regions": []
 },
 {
  "length": 3290,
  "seq_id": "NODE_146_length_3290_cov_16.925615",
  "regions": []
 },
 {
  "length": 3103,
  "seq_id": "NODE_149_length_3103_cov_27.330800",
  "regions": []
 },
 {
  "length": 2905,
  "seq_id": "NODE_150_length_2905_cov_20.394272",
  "regions": []
 },
 {
  "length": 2471,
  "seq_id": "NODE_153_length_2471_cov_33.644110",
  "regions": []
 },
 {
  "length": 2439,
  "seq_id": "NODE_154_length_2439_cov_18.259949",
  "regions": []
 },
 {
  "length": 2384,
  "seq_id": "NODE_155_length_2384_cov_22.804075",
  "regions": []
 },
 {
  "length": 2108,
  "seq_id": "NODE_156_length_2108_cov_33.733629",
  "regions": []
 },
 {
  "length": 1988,
  "seq_id": "NODE_157_length_1988_cov_19.880691",
  "regions": []
 },
 {
  "length": 1886,
  "seq_id": "NODE_158_length_1886_cov_21.387507",
  "regions": []
 },
 {
  "length": 1751,
  "seq_id": "NODE_159_length_1751_cov_25.242533",
  "regions": []
 },
 {
  "length": 1643,
  "seq_id": "NODE_160_length_1643_cov_19.806513",
  "regions": []
 },
 {
  "length": 1564,
  "seq_id": "NODE_161_length_1564_cov_26.941493",
  "regions": []
 },
 {
  "length": 1375,
  "seq_id": "NODE_166_length_1375_cov_36.959168",
  "regions": []
 },
 {
  "length": 1319,
  "seq_id": "NODE_169_length_1319_cov_184.837359",
  "regions": []
 },
 {
  "length": 1261,
  "seq_id": "NODE_170_length_1261_cov_18.180743",
  "regions": []
 },
 {
  "length": 1201,
  "seq_id": "NODE_172_length_1201_cov_25.755086",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r8c1",
  "r14c1",
  "r36c1",
  "r55c1"
 ],
 "r8c1": {
  "start": 54463,
  "end": 78843,
  "idx": 1,
  "orfs": [
   {
    "start": 55085,
    "end": 56239,
    "strand": 1,
    "locus_tag": "ctg8_50",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 55,085 - 56,239,\n (total: 1155 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_50\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGTAAGACGCTCACAGAGGTCGCTAGCCAGCTGAGCGCCACAAACAAGCAGGTGCAGCTGATCTACGCCTTCAACGGCACGGGGAAAACCCGCCTTTCCCGCGAGTTCAAGCAGCTCGTTGCACCCAAGAGCGGGGAGATTGAAGAAGGATCCGCCGACAAACTGGCACCGCCTCGCACCAAGATTCTGTACTACAGCGCCTTCACGGAAGACCTCTTTTATTGGGACAATGACCTCGAGATGGATGCTACTCCGAAGCTCTTGATCCAGCCCAACTCATTTACTGACTGGTTGCTCGCACTACTCAGAGATCTCGGACAAGATGGAAATATTGTCAGGAACTTCCAGCATTATGCCAGCAACAAGCTGACCCCATATTTTAACGAAACCTTCTCTGAGATCACTTTCTCACTCGAGCGGGGGGACGATGAAAACTCCGGCAGCCTCAAGATCTCAAAAGGTGAAGAGAGCAACTTCATCTGGAGTGTTTTCTACACGTTGTTGGACCAAGCCATATCTACGCTCAACATTGTCGAAGCAGAGGACCGCGAAACCCCGCAGTTCGATCGGCTTGAGTATGTCTTCATAGACGACCCGGTAAGTTCTCTGGACGAAAACCATTTGATCGAGCTAGCCGTCGATCTTGCGGGTTTGATCAAGACAAGTCCAGATTGTCTGAAGTTTATTGTTACCACCCACAGCCCTTTGTTCTACAACGTGCTTCATAACGAGTTAGGTCTTGCCAAGAGTGCCAAGAGCAAGGGCTGTTATTTACTACGCGGTCTCGAAGACGGTACCTTCGATCTGGATGTTAAACTTGGTGATTCCAACACCAGCTTTTCCTATCATCTGCATCTTAGGAAGACTCTTGAACAGGCGATTTCTGCCGGCCAAGTCGAGCGGTATCACTTCACGCTCCTTCGTAACCTCTACGAGAAAACTGCAAGCTTCCTTGGCTACCGAGACTGGTCGGACCTTTTGCCCGGTGACAAGCAGACCTATTTGAAACGCATTATCAATTTCACCAGTCACAGTAACTTGTCCAATGAGGCGGTTGCCGAACCGACGCCGCAAGAGAAGCAGACAGTTAAGTATCTTCTGGACTATCTGATTGATGAGTACGGCTATCGGCAGGAGCAACAGAATGGTTGA",
    "translation": "MGKTLTEVASQLSATNKQVQLIYAFNGTGKTRLSREFKQLVAPKSGEIEEGSADKLAPPRTKILYYSAFTEDLFYWDNDLEMDATPKLLIQPNSFTDWLLALLRDLGQDGNIVRNFQHYASNKLTPYFNETFSEITFSLERGDDENSGSLKISKGEESNFIWSVFYTLLDQAISTLNIVEAEDRETPQFDRLEYVFIDDPVSSLDENHLIELAVDLAGLIKTSPDCLKFIVTTHSPLFYNVLHNELGLAKSAKSKGCYLLRGLEDGTFDLDVKLGDSNTSFSYHLHLRKTLEQAISAGQVERYHFTLLRNLYEKTASFLGYRDWSDLLPGDKQTYLKRIINFTSHSNLSNEAVAEPTPQEKQTVKYLLDYLIDEYGYRQEQQNG",
    "product": ""
   },
   {
    "start": 56232,
    "end": 59333,
    "strand": 1,
    "locus_tag": "ctg8_51",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,232 - 59,333,\n (total: 3102 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_51 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04313.17 (Type I restriction enzyme R protein N terminus (HSDR_N)): [29:220](score: 188.2, e-value: 1.6e-55)<br>\n \n  PF18766.4 (SWI2/SNF2 ATPase): [275:493](score: 170.5, e-value: 4.5e-50)<br>\n \n  PF12008.11 (Type I restriction and modification enzyme - subunit R C terminal): [722:1026](score: 228.0, e-value: 1.6e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_51 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04313.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF04313.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004519' target='_blank'>GO:0004519</a>: endonuclease activity<br>\n  \n   PF04313.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006304' target='_blank'>GO:0006304</a>: DNA modification<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_51\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTTGAGCAAACCAAGCCGATCGTCGAAGCTAGCAACTTCATCGTTCTTGACAGATACGTCAAAGAATGGACGTCTACGGAAAGCTACCAAACTGAGTCTGACTTGGAACGCGAGTTCCTCCAAGACCTTGTCGATTTGGGGTATGAATATCTACCAGATCTGAGTACACCGCCATTGTTGCTTACCAACGTCCGTGAGCAGCTACAAGCGTTGAACAATGTGGAGTTCTTAGATGGCGAATGGGCGCGATTCGTAGAATCCTGGCTGGATAGGCCGAGTGATGGCGTGGTCGAAAAAACTCGGAAGATTCACGATGACTACGTTCATGACTTTGTGTTCGACGATGGTCGAATCCAGAACATCTATCTGCTCGACAAGAAAAACATTGCTCGCAACAAGGTCCAGGTGATCAAGCAGTTCCAGCAAACCGGCAGCCACGCCAACCGCTACGATGTGACCGTTCTGGTGAACGGTCTGCCTCTAGTCCAAGTAGAGCTGAAGAGGCGTGGCGTAGCCATCCGCGAAGCCTTTAACCAGGTACACCGCTACAGCAAGGAGAGCTTCAACGGCGAGCAGTCCCTGTTCAGGTACTTGCAGCTATTCGTAATCTCCAACGGTACCGACACGCGCTATTTCGCCAACACGACGCAGCGCGGTAAGAACAGCTTTGACTTCACCATGAACTGGGCGCAGGCAGATAACAGCCCGATCAAGGACCTGAAGGACTTTACCGCCACCTTCTTCCAGAAACACACCTTACTCAATGTACTGCTGAGCTATTCCGTCTTCGATGTCGGCAATACGCTGCTGGTGATGCGGCCGTATCAAATTGCCGCGACTGAGCGCATCTTGTGGAAGATCAAGAGTGCGTATCAGGCCAAACACTGGAACAGTACCGAGAGCGGCGGCTACATCTGGCATACGACTGGTTCGGGAAAAACCCTGACCAGCTTCAAGGCCGCGCGCCTTGCGACGGAGCTTGATTTTATCGACAAAGTATTCTTCGTAGTTGACCGCAAAGATCTGGATTACCAGACCATGAAGGAATACCAGCGTTTCTCGCCCGATAGTGTGAACGGTTCGGATAGCACGGCGGCCCTGAAACGCAATCTGGACAAGGACGATAACAAGATCATCGTCACCACCATCCAGAAGCTAAACAACCTAATGAGGAGCGAAAGCGATCTGCCAATCTACGGCAGGCAAGTCGTCTTCATCTTCGACGAATGCCATCGCAGTCAGTTCGGCGAGGCACAAAGGAACCTGACTAAGAGGTTCAAAAAGTTCTACCAGTTCGGTTTCACCGGTACCCCGATCTTCCCGCAAAACGCTCTGGGCGCGGATACCACAGCGAGCGTGTTCGGCAGAGAGCTGCACTCGTACGTCATCACTGATGCTATTCGTGACGAGAAGGTTCTCAAGTTCAAGGTGGACTACAGCGACGTTCGTCCGCAGTTCAAAAGCATCGAAAGCGAGCAGGACGAGAAGAAGCTCAGCGCCGCGGAAAACCGGGAGGCCTTGCTGCACCCGGATCGCATCCGTGAAATCACTCAATACATCCTCGACACCTTCCGGCAAAAGACTCACCGCCTACAAGCGGGGGCCAAGGGCTTCAACGCTATGTTCGCCGTAAGTAGCGTGGACGCCGCGAAGCTTTATTACGAAGCTTTCAAGACCTTACAGAGAAGCCGCGAAAAGCCTTTGAAGGTTGCGACCATTTTCTCGTACGCTGCCAACGAGGAGCAGGATGCGGTAGGTGAGATAGCGGATGAAGTTTTTGAAGTCTCAGCCTTGGGCACCAGCGCCAAAGAGTTCCTGAACGCAGTCGTTGCCGACTATAATTCACTGTTCAAAACCAGCTTCAGCGTGGACAGCAAAGGCTTCCAGAATTACTACCGTGACCTGGCAAAGCGCGTAAAAGACCAGGACGTGGATTTGCTCATCGTTGTTGGGATGTTCCTGACGGGCTTCGACGCGCCCACACTGAACACCTTGTTTGTGGACAAGAACCTGCGCTACCACGGCCTGGTTCAGGCCTATTCGCGTACCAACCGAATTTTCGACTCCACTAAGACCTTCGGCAATGTCGTCACCTTCCGCGACTTGGAAGACGCAACCATCGACGCCATCACCCTATTCGGCGACAAGAACACCCGCAATGTGGTGCTGGAGAAGAGCTATACCGAGTACATGGAAGGCTTCACTGACGTCGCTACAGGAGAGGCACGGCGCGGATTCGTCGACGTGGTCAGCGAACTTGAGCAGAGATTCCCTGATCCCGTGGACATCGTCAGAGAGTCCGATAAGAAGGCATTTGCAAAGCTGTTCGGTGAGTACCTGCGCGTGGAGAACGTGCTGCAGAACTACGATGAATTCGCCAGCCTAAAGGCCTTGCAGAGCATCGACACGGGCGATCCCCAGGCGGTGGAGAATTTCAAGACCAAGCACCACCTGAGCGACGACGACCTAGCTGTACTGCAGAAGATTCGGGTTCCCACCGAGCGGATAATCCAGGACTACCGGTCCACCTACAACGACATCCGCGACTGGCTACGCCGCGAGAAAGCCTCGGAGGAGAAGGCGCGTTCCACTATCGACTGGGATGATGTGGTGTTCGAAGTGGATCTGCTTAGATCGCAGGAGATCAATCTTGATTACATTCTGGAGTTGATCTTCGAGAAGAACAAAAAAACCAGGGACAAGGTGTCTTTGGTCGAGGAAGCGCGCCGGATGATTCGCGCTAGCCTCGGCAACCGGGCTAAGGAAAGCCTTGTGGTGGATTTCATCAATCAGACTGATTTGGACACACTGGCGGATAAGGCCAGCGTAATCGAGGCATTTTTCAGCTTTGCGCAGGTCGAGCAGCAGCGCGAGGCCCAGGAACTAATCAACGATGAAGCACTAAATGCTGAAGCCGCCAGACGTTATATCAGCAACTCGCTCAGGCGTGAATTTGCCAGCGAGAACGGCACCGAACTCAATGCGCTTCTTCCCAGAATGAGCCCGCTTAATCCGGACTACCTAACAAAAAAGCACAGCGTCTTTCACAAGATCGCCGCATTCGTTGAGAAATTCAAAGGAGTTGGTGGCGAGGTCTGA",
    "translation": "MVEQTKPIVEASNFIVLDRYVKEWTSTESYQTESDLEREFLQDLVDLGYEYLPDLSTPPLLLTNVREQLQALNNVEFLDGEWARFVESWLDRPSDGVVEKTRKIHDDYVHDFVFDDGRIQNIYLLDKKNIARNKVQVIKQFQQTGSHANRYDVTVLVNGLPLVQVELKRRGVAIREAFNQVHRYSKESFNGEQSLFRYLQLFVISNGTDTRYFANTTQRGKNSFDFTMNWAQADNSPIKDLKDFTATFFQKHTLLNVLLSYSVFDVGNTLLVMRPYQIAATERILWKIKSAYQAKHWNSTESGGYIWHTTGSGKTLTSFKAARLATELDFIDKVFFVVDRKDLDYQTMKEYQRFSPDSVNGSDSTAALKRNLDKDDNKIIVTTIQKLNNLMRSESDLPIYGRQVVFIFDECHRSQFGEAQRNLTKRFKKFYQFGFTGTPIFPQNALGADTTASVFGRELHSYVITDAIRDEKVLKFKVDYSDVRPQFKSIESEQDEKKLSAAENREALLHPDRIREITQYILDTFRQKTHRLQAGAKGFNAMFAVSSVDAAKLYYEAFKTLQRSREKPLKVATIFSYAANEEQDAVGEIADEVFEVSALGTSAKEFLNAVVADYNSLFKTSFSVDSKGFQNYYRDLAKRVKDQDVDLLIVVGMFLTGFDAPTLNTLFVDKNLRYHGLVQAYSRTNRIFDSTKTFGNVVTFRDLEDATIDAITLFGDKNTRNVVLEKSYTEYMEGFTDVATGEARRGFVDVVSELEQRFPDPVDIVRESDKKAFAKLFGEYLRVENVLQNYDEFASLKALQSIDTGDPQAVENFKTKHHLSDDDLAVLQKIRVPTERIIQDYRSTYNDIRDWLRREKASEEKARSTIDWDDVVFEVDLLRSQEINLDYILELIFEKNKKTRDKVSLVEEARRMIRASLGNRAKESLVVDFINQTDLDTLADKASVIEAFFSFAQVEQQREAQELINDEALNAEAARRYISNSLRREFASENGTELNALLPRMSPLNPDYLTKKHSVFHKIAAFVEKFKGVGGEV",
    "product": ""
   },
   {
    "start": 59256,
    "end": 59597,
    "strand": -1,
    "locus_tag": "ctg8_52",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 59,256 - 59,597,\n (total: 342 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_52\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCCGCTTGGTAGAAAACCTCAATCTTCTTAGCGAGATCCCCCTGAATCCTACGGCTGTCCGGATCTTAATGCCTCTCATCACCTCTGGCGGAGATTGCGTATACAGCCGAAGAGCTCTCCCCCCGCACACGGCAATGGTCGCGTTGGCCGGAAACTACATCCGGATGCGCACGGGCAAAGTACTCGCGACGACACAGCTGGTGAACATTGTCGAGATGCGTATTTCAACTCAGTCCCTCGATAGGCAGAAGAGCCTCAGCTCAGACCTCGCCACCAACTCCTTTGAATTTCTCAACGAATGCGGCGATCTTGTGAAAGACGCTGTGCTTTTTTGTTAG",
    "translation": "MSRLVENLNLLSEIPLNPTAVRILMPLITSGGDCVYSRRALPPHTAMVALAGNYIRMRTGKVLATTQLVNIVEMRISTQSLDRQKSLSSDLATNSFEFLNECGDLVKDAVLFC",
    "product": ""
   },
   {
    "start": 59563,
    "end": 60693,
    "strand": -1,
    "locus_tag": "ctg8_53",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_53</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_53</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 59,563 - 60,693,\n (total: 1131 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_53\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTTTCAGTCGGGTGCAGTCGCCGTGCGATATCGGCCCACGCGAGTCATGGCTTGATCTGAGAGGCCGCGCCTGGTGTGCTCGCCAATGGCACAGCGATCCGATTCAGCAACGCCCTCATCATCAGTTGCCAAGCTGGTCGCATCTTGCGACTTTGAGCCAGGGTCTCCTCTTCCTCGTTCTCATCGGGCGCCATCGAGGCCAAGGCCCGGAAAGTCGGTACAGTCATGCCATGACGATCGAACACGCGCCAGGACCCGAAATGTCCGTTGTGCTCAAGAACGCGCGAGCCGGCGCACGCGAACGTGGCCTCCCGGTCCTAAACGCCAGCTTCGGTACCGAACCATCCGTTATTTTCGTCAATGCTCAGGTAGGACTCGACGAAGCACTGGATGTCGCGAAAGCGATGAATGCGCCGTTCCTTTCAATCGACGCAACGGAGTTCAGTTTCGAGGACTTCGTCTCCGAGATGAGCGAAGCAAGCGAAACTGCGGCACTTGAGCCCGAGGTCAAGGACTTCAAGAAATATGACGGCGAGCTCGACGGCGTCTACGTTCGTTGGGTCGCTGCCGGCGAAAGCTTCCTTTATATGGCTACTCCAGAGTGGAGCGATCAGATAGGTGAACTGCAGGGCCAGCAAGAGGAACGGGATAGAAAGAATCGATCCAGGGACGTTGCCGCGAGGTGGGCAAGACGGAGGGAACTTGCTGAAGAGATAGAGGCGCTCCCGGCAGTTCGCGGCATAGGCACTCGCGGCCGCAAGGCCCTCGCAACACGTCTCGCCGGCGGACTGCTCAAGGGAGAGGATGACCCCGAGCTCGCGCTGGGCGCGGTTCGCGACGCCGTCGAGTTAGCAAGCGTGAATGCGATCGGTGCGTACGCTGAAATCGAGTCGGATTTACGCGTCGTCGCACGACATCTCATCGAGACAGATGCCTGGCAGAACGCCTGGCGCACCCCAGATCGGATCGCTGCAGCAAAGGCTTTTCTGCTCAGCACCACTAACGGGTACGCCCCAACCGCTGCCCTCTCCGAACAACTCCGCGGAGTGGCCGAAGACGAAGCGCGGCTCAATCTGAAAAGGCCCCAACGGCATGTCCCGCTTGGTAGAAAACCTCAATCTTCTTAG",
    "translation": "MSFSRVQSPCDIGPRESWLDLRGRAWCARQWHSDPIQQRPHHQLPSWSHLATLSQGLLFLVLIGRHRGQGPESRYSHAMTIEHAPGPEMSVVLKNARAGARERGLPVLNASFGTEPSVIFVNAQVGLDEALDVAKAMNAPFLSIDATEFSFEDFVSEMSEASETAALEPEVKDFKKYDGELDGVYVRWVAAGESFLYMATPEWSDQIGELQGQQEERDRKNRSRDVAARWARRRELAEEIEALPAVRGIGTRGRKALATRLAGGLLKGEDDPELALGAVRDAVELASVNAIGAYAEIESDLRVVARHLIETDAWQNAWRTPDRIAAAKAFLLSTTNGYAPTAALSEQLRGVAEDEARLNLKRPQRHVPLGRKPQSS",
    "product": ""
   },
   {
    "start": 60635,
    "end": 61204,
    "strand": -1,
    "locus_tag": "ctg8_54",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_54</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_54</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 60,635 - 61,204,\n (total: 570 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_54 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01872.20 (RibD C-terminal domain): [5:177](score: 48.2, e-value: 1.2e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_54 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01872.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008703' target='_blank'>GO:0008703</a>: 5-amino-6-(5-phosphoribosylamino)uracil reductase activity<br>\n  \n   PF01872.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009231' target='_blank'>GO:0009231</a>: riboflavin biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_54\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_54_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGACCACTCCGATACTCGATCAATGTCACGCTCGACGGCTGCTGCCATCACGAGGCAGGACTCCCCCCGGACGAGGAGTCGATGCACTACTGGACCGCTCAGCTAGAGCGAGCCGATGCCCTACTGTTCGGCCGGGTGACCTACGAGATGATGGAGTCCGCGTGGCGGATGCCGGCCACGGGCAGGTGGCCCGACTGGATGAAGGACTGGCAGAAACCGTTCGCGGAGACCATCGACCGGGCGAAGAAGTACGTCGTGTCGAGCACAATGAGCGGGCTCGATTGGAATGCCGAGCTGGTGCGAGGCGACCTGGGAGCAGCGGTTCAGAGATTCAAGCAGGAGCCAGGCGAGGGTTTGTGGGTGGGTGGCGTGACGCTCCCCCGGGCGTTGGCCGATCTGGGGCTGATCGACGAGTATGAGTTTTTGGTGCAGCCGGTCCTTGCCGGGCACGGGCCGACTTTGCTTGCCGGTCTGCGTGAGCGCATTCAGCTCGAGCTTGTGGACCGCAATGAGTTTCAGTCGGGTGCAGTCGCCGTGCGATATCGGCCCACGCGAGTCATGGCTTGA",
    "translation": "MRPLRYSINVTLDGCCHHEAGLPPDEESMHYWTAQLERADALLFGRVTYEMMESAWRMPATGRWPDWMKDWQKPFAETIDRAKKYVVSSTMSGLDWNAELVRGDLGAAVQRFKQEPGEGLWVGGVTLPRALADLGLIDEYEFLVQPVLAGHGPTLLAGLRERIQLELVDRNEFQSGAVAVRYRPTRVMA",
    "product": ""
   },
   {
    "start": 61677,
    "end": 62663,
    "strand": -1,
    "locus_tag": "ctg8_55",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_55</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_55</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 61,677 - 62,663,\n (total: 987 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1083:oxidoreductase (Score: 101.2; E-value: 1.2e-30)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_55 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00296.23 (Luciferase-like monooxygenase): [30:285](score: 68.7, e-value: 6.1e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_55 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00296.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_55\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_55_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_55\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGGTTAGGCATCGTCTTCCCCGTCCAACCAAACAACACCAATGACATCAAGGCGTTCGGCCGATGGGCGATGGAGCGTCCCGGCACCCGGCTCTGGACTGCACAATCGACCCTCATTGATTCCCACCAGGCGGTAGCCTTCGCTGCCGGCGCTGGGATTCGCTGCCCGATTGGGTTCGGGGTCGCCCTCACTCCGTTGGCACACCCGGTACTAGCTGCCGCTCAAGCCCGTTCGCTAGCCCTCCTGACGGGGCACGATGTCTGGGCAGGTTTCGGCACAGGTGGCCTTCACGTGGAATCTGGGATGCTCGGACAAAAGTACGCGTCGCCGACGAAAGCAGTGCGCGAGTACCTTGAGGTCTGCCGCCTTGCCTTGGACGAGGCGAGCTTCGAGTACAGAGGAGAAGTCTTCAACGTGAGCGGCGGTGCTCCTTCGCTTCACACCAGTGAAGTGAGGGTAGGCGCCGGAGTCCTTCGCCCGCGGATGGCGAGCGTGATTAAGGATGCGGCGGATTTTGTCGTCACATGGCTTTCTCCGCTGCACCATGTTTCCGACACATTAATACCTGCCCTCACCCGGGTGGATCAGACCCGCCCCGCGGTCGTCGCAATGGTGCATTCACGCCTCACATCGTCCGGCCTCGACAAACAAGAACTAATCGAGGACATGACCACCCCCCATCTGGGGGCTGCACATTACCGGGCGATGCTTCGGTCCTCGGGTATAGGTGCCGATTTAGACGACACACCAGCGCAGGTCGCCGAGCAGCTTGTCGATGCGAACGTACTGCTCCACGGCGACGTTGATGACATCGTCGAAGGGCTTTTGGCGTACGAGAGCGCGGGCGTCGAAGAGGTCGCATTGAATATTTCGGGTTCATTCCGACGCTTTGGCGCTCAACGTGCGCTTGCCGAAATGTCCGCTATCCATGCTGCCTATTCTGCGGCGCGGCCGTCGTACCGGACGGAGCCCGCGATGGCGTAA",
    "translation": "MRLGIVFPVQPNNTNDIKAFGRWAMERPGTRLWTAQSTLIDSHQAVAFAAGAGIRCPIGFGVALTPLAHPVLAAAQARSLALLTGHDVWAGFGTGGLHVESGMLGQKYASPTKAVREYLEVCRLALDEASFEYRGEVFNVSGGAPSLHTSEVRVGAGVLRPRMASVIKDAADFVVTWLSPLHHVSDTLIPALTRVDQTRPAVVAMVHSRLTSSGLDKQELIEDMTTPHLGAAHYRAMLRSSGIGADLDDTPAQVAEQLVDANVLLHGDVDDIVEGLLAYESAGVEEVALNISGSFRRFGAQRALAEMSAIHAAYSAARPSYRTEPAMA",
    "product": ""
   },
   {
    "start": 62676,
    "end": 64502,
    "strand": -1,
    "locus_tag": "ctg8_56",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_56</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_56</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 62,676 - 64,502,\n (total: 1827 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 191.6; E-value: 2.8e-58)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_56 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00005.30 (ABC transporter): [376:530](score: 108.1, e-value: 5.2e-31)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_56 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00005.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_56\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_56_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMAGAVKPAGGNAVKTARMPIGLQDIGKVWRLAPGRFSLQAAMAWSVALVPALQVMLTARIVDMASTMVANPTDDWMPLTIAFFQLGLTLVLARAITGLARYLGTSTTLRVNTRLSQDVMKKGIAMPLASYETPEHYNRLQRALAETQSGRALMLVTGVIELVSSLVTVGSVALVLLSWSPLAAVIALIAPIPSALLSAKYGRLRWSIEMDRTENRRKSAYLQWLTTNDHSAKEVSHYQLGPTLMKRYAKFVKHFLTQDLAVNRRSELWVGLVDLLGLALTTSALGIAVVGSVQRGSVGEIAGFIQAMGSLQTATSGFLLGLAALYQNGLWARNLFGYLELPSNSLRATGKCLPFPADASIEFRNVSFTYPSTDRRVLNDLSFTLPAGSRTAIVGPNGAGKSTIVKLLTGLYIPDAGEVLIGGVPVKDLDPDEVRREVGVVFQDFVKYELSAADNIAFGNWPSATEDEVLGAAERAGIWGKLTNLPANIETLLGRRFTGAQQLSLGEWQKMALARAFVSGRTVLIMDEPSASLDPRAEADLVARIADVPKGTTAVVVAHRFATVRALDRIVVLDQGAITEMGNHDELMRLSGTYALMYEAQAAAFSESK\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_56\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGCGGGCGCTGTCAAGCCGGCGGGCGGCAACGCGGTGAAGACAGCAAGAATGCCGATCGGATTGCAGGACATTGGCAAAGTGTGGCGACTCGCGCCCGGGAGGTTTTCTCTTCAAGCAGCCATGGCGTGGTCGGTCGCCCTGGTGCCCGCACTACAGGTGATGCTCACGGCTCGAATTGTTGACATGGCGAGCACCATGGTTGCCAATCCAACGGATGACTGGATGCCGCTAACAATCGCATTCTTTCAGCTGGGGTTGACCCTGGTTCTCGCTCGCGCCATCACCGGTCTGGCCCGGTATCTCGGCACCAGCACCACGCTCCGAGTGAACACTCGTTTGTCGCAGGACGTCATGAAGAAGGGGATTGCGATGCCGCTGGCATCGTACGAAACTCCAGAGCATTACAACCGACTCCAACGCGCATTGGCCGAGACACAGTCGGGGCGTGCTCTGATGCTAGTGACAGGGGTCATCGAGCTGGTCTCGTCGCTCGTCACCGTAGGTTCGGTCGCATTGGTTCTACTGAGTTGGAGCCCTCTAGCCGCTGTAATCGCGCTCATTGCGCCAATTCCGTCAGCCTTGCTCTCCGCCAAATACGGACGTCTTCGGTGGTCGATCGAGATGGACAGAACCGAAAATCGTCGGAAGTCTGCCTATCTGCAGTGGCTCACAACCAACGATCACTCGGCAAAGGAGGTCTCGCATTACCAACTGGGCCCGACTCTTATGAAGCGTTACGCGAAGTTCGTAAAGCACTTCCTTACCCAGGACTTAGCGGTTAATCGCCGGAGCGAACTCTGGGTCGGACTTGTTGACTTGCTTGGCTTGGCCCTCACGACGTCCGCACTGGGAATCGCCGTTGTAGGAAGCGTGCAACGGGGAAGCGTTGGAGAGATCGCAGGGTTCATCCAGGCGATGGGGTCCTTGCAGACTGCTACGAGCGGTTTCTTACTCGGACTTGCCGCTTTGTATCAGAACGGGCTCTGGGCGAGGAATCTTTTCGGCTACCTTGAACTTCCGTCAAACTCCCTTCGGGCAACCGGGAAATGCCTGCCGTTCCCCGCAGATGCCAGCATCGAATTCCGAAACGTTAGTTTCACTTACCCGTCGACGGACCGCCGAGTCCTGAACGACCTCTCGTTCACGCTTCCCGCGGGAAGCCGTACGGCGATAGTTGGTCCCAACGGGGCCGGTAAATCGACGATCGTCAAACTGCTCACAGGATTGTACATTCCTGACGCCGGCGAGGTCCTAATTGGCGGAGTTCCGGTCAAAGATCTGGACCCTGATGAGGTCCGTCGAGAGGTTGGGGTTGTGTTCCAGGATTTTGTGAAATACGAGCTGTCCGCCGCGGACAACATTGCTTTCGGAAACTGGCCCTCGGCCACCGAAGACGAAGTGCTTGGAGCGGCTGAGCGAGCGGGCATCTGGGGAAAGCTCACCAACCTTCCGGCCAATATCGAAACGCTCCTGGGACGAAGATTCACCGGAGCGCAGCAGCTCTCCCTCGGGGAGTGGCAGAAGATGGCCTTGGCGCGTGCGTTCGTCAGCGGTCGAACAGTTCTGATCATGGACGAACCATCCGCGTCGTTGGACCCACGCGCGGAAGCCGATCTCGTCGCGCGGATAGCCGATGTACCCAAGGGCACGACCGCGGTGGTTGTTGCTCACCGTTTTGCTACGGTGCGGGCCCTTGACCGAATAGTCGTGCTCGACCAGGGTGCGATAACTGAGATGGGCAATCACGATGAACTCATGAGACTAAGCGGAACGTACGCGCTGATGTACGAAGCCCAGGCCGCCGCCTTCTCGGAATCGAAATAG",
    "translation": "MAGAVKPAGGNAVKTARMPIGLQDIGKVWRLAPGRFSLQAAMAWSVALVPALQVMLTARIVDMASTMVANPTDDWMPLTIAFFQLGLTLVLARAITGLARYLGTSTTLRVNTRLSQDVMKKGIAMPLASYETPEHYNRLQRALAETQSGRALMLVTGVIELVSSLVTVGSVALVLLSWSPLAAVIALIAPIPSALLSAKYGRLRWSIEMDRTENRRKSAYLQWLTTNDHSAKEVSHYQLGPTLMKRYAKFVKHFLTQDLAVNRRSELWVGLVDLLGLALTTSALGIAVVGSVQRGSVGEIAGFIQAMGSLQTATSGFLLGLAALYQNGLWARNLFGYLELPSNSLRATGKCLPFPADASIEFRNVSFTYPSTDRRVLNDLSFTLPAGSRTAIVGPNGAGKSTIVKLLTGLYIPDAGEVLIGGVPVKDLDPDEVRREVGVVFQDFVKYELSAADNIAFGNWPSATEDEVLGAAERAGIWGKLTNLPANIETLLGRRFTGAQQLSLGEWQKMALARAFVSGRTVLIMDEPSASLDPRAEADLVARIADVPKGTTAVVVAHRFATVRALDRIVVLDQGAITEMGNHDELMRLSGTYALMYEAQAAAFSESK",
    "product": ""
   },
   {
    "start": 64463,
    "end": 66508,
    "strand": -1,
    "locus_tag": "ctg8_57",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_57</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_57</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 64,463 - 66,508,\n (total: 2046 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) lanthipeptide-class-i: Lant_dehydr_C<br>\n \n  biosynthetic (rule-based-clusters) lanthipeptide-class-i: Lant_dehydr_N<br>\n \n  biosynthetic-additional (smcogs) SMCOG1155:Lantibiotic dehydratase domain protein (Score: 419.9; E-value: 3e-127)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_57 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04738.16 (Lantibiotic dehydratase, N terminus): [13:351](score: 213.4, e-value: 4.5e-63)<br>\n \n  PF14028.9 (Lantibiotic biosynthesis dehydratase C-term): [423:664](score: 111.9, e-value: 5e-32)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_57\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_57_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_57\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGTGCCGCGGTGCCGGGGACGCTCTCGAAGAATTCGACCGCTACCTCGACACGTACCGGAATGCGTTCCTGGAACGCTTCGGAGTCGACACCGCTGTGCCGATCGCCAAGGCAGTCGACCCTGTCTTCGGGATCGGTCTACCTGAGCACTTCAATGTCAGGCAGACGCCGCCGCCCACTCGGACCCCTGCTCTCACTCGCTACGAGCGAGTTCTCCTGGACCTTGCAACAGAGACATGGCAAACCGGGTCGAAGCAACTCGTGGTCACACCTGATGTGGAACGAAAACTCAAAGAGGCTGCGCCGGTCTCGTCAAGTCCGCGTCGCCCGCAACCCAGCCTCGACATATTTGCCCAGCTCCTCGCCACACCGAACAGCGAAGGCAGATGGCAAGCGGTGTTGAACTCGGTGCCAGTGGGCCTCGGGGGCGCGTCCTTTGGCCGGTTCATGCACGACATGGACCAGGTAGGGCGAGACAAGACAGCTGCCCTAATCCGACGTCGTGTTCCCAACCCCGAGTCGATCCTCGGCGCCGATCTGGCCTTCGTTCCGGCACAGGCCCGAGTCGCCAACGTCACTGTCCGACCACCAGTTCACGCACATCATGTTGGAATCAACGTTCCGAGCGTTTCCGGCTCAGAAGAGATCGCGCTTCCTGATGTGCACCTCGTTGCCACGTACGAACGGTTGTACCTCTGGTCGGCACGACACCAGCGGGAATTGCACATCTCCGCGCATCATCTGCTGTCGCTTGAAGCCGCGCCACCCGTTGCGCGACTCATAGTCGAGGTCAGCGAGCGACGGTATGCAGCTCCAGGCGGTTTTTCTTGGGGGCCGTTGGAAGGGAGCCTGCGTCTGCCTCGAGTTGTGCGGAAGAACGTTGTCTTGCGGGTCGCGGAATGGACCGTGCCGCGCTCGATGATCGACATCGAGACGGAAGACGTAGCTGAATGGCTCCCGCGCCACCGCGATCGTTGGGATATCCCATCGCAGGTCTACCTCACCAGCCAGGACCAACGACTGCTCATCGATTGCACGTCGGATCGAGGAATGCAGGAGATAAAGGACGCTCTGGCCACATCGGGACAGGTGAGGCTGCAGGAGGTGTACCCACCTCTGGAACCGTCCTGGGTGCACGACGCTCAGGGCTTCGGATACGTCGGCGAAATCGTCGTGCCAGTTGTTGCAAAATATAGAAATCGCCCGACTACCGTCGATCCCAAACCGCTCATTTGCGACCCCCCTGTTGTCGACCACGCCTCAGAGCTGTGGACCTACTGCAAGCTCTACACCGAGCCGCCTCTTCAAGACGAGATTCTTTCCCGGGACCTGCCGCGCCTACTTCAGGCCCACGACCCCGCAGCGTTTGAAAAATGGTTCTTCATCCGCTACTCAGATCCGGCTCACCATCTACGACTTAGATTTCGAAGCGGTTCCGAGGACGACAGGTGGCTCGTCCAACGACACGTCGACCGGTGGGCTACGGAGCTGAAGCGTGCAGGCATGATCAAGGACTTTGCCTTCGCTCAGTACTCACCCGAACTGGCGAGGTACGGCGGGTCGCATTCCATGGGCGTTGTCGAGAAAATATTCGAACTTTCCAGCAAACACGCGGCCGCCATGGCCAGCGCCTCACCCCCTTCTCGACTAATGTCCGCCGTCGCCACCGCAGATAAACTGGCCGCAGCCTGGGGATACTCAGTTTCAGATAGGCGCGGACTGGCTGGCGACTACCCAGCCGAACCCGATGTCACCGACGCCGCACGGGCCTTTGTCCGTTCACATCAACGTGAGCTCTTGGATGCGCTCGACAGCGCCGAAACCGAGCCGGACGAACTAGGCGATCTCATCAGACAGCTTCGCTCGAATGTGGATCGTTCAAGAGAGAACGCTGAGTTCGCCCCAAACAACGAGAGTGTCATCAGGAGCATCATTCACATGAACTTCAACAGGATGCTCAGCACCGATCACACCGAAGCCCTGGCGCACAGAGTGTGGCAGGACGGGTGGCGGGCGCTGTCAAGCCGGCGGGCGGCAACGCGGTGA",
    "translation": "MCRGAGDALEEFDRYLDTYRNAFLERFGVDTAVPIAKAVDPVFGIGLPEHFNVRQTPPPTRTPALTRYERVLLDLATETWQTGSKQLVVTPDVERKLKEAAPVSSSPRRPQPSLDIFAQLLATPNSEGRWQAVLNSVPVGLGGASFGRFMHDMDQVGRDKTAALIRRRVPNPESILGADLAFVPAQARVANVTVRPPVHAHHVGINVPSVSGSEEIALPDVHLVATYERLYLWSARHQRELHISAHHLLSLEAAPPVARLIVEVSERRYAAPGGFSWGPLEGSLRLPRVVRKNVVLRVAEWTVPRSMIDIETEDVAEWLPRHRDRWDIPSQVYLTSQDQRLLIDCTSDRGMQEIKDALATSGQVRLQEVYPPLEPSWVHDAQGFGYVGEIVVPVVAKYRNRPTTVDPKPLICDPPVVDHASELWTYCKLYTEPPLQDEILSRDLPRLLQAHDPAAFEKWFFIRYSDPAHHLRLRFRSGSEDDRWLVQRHVDRWATELKRAGMIKDFAFAQYSPELARYGGSHSMGVVEKIFELSSKHAAAMASASPPSRLMSAVATADKLAAAWGYSVSDRRGLAGDYPAEPDVTDAARAFVRSHQRELLDALDSAETEPDELGDLIRQLRSNVDRSRENAEFAPNNESVIRSIIHMNFNRMLSTDHTEALAHRVWQDGWRALSSRRAATR",
    "product": ""
   },
   {
    "start": 67446,
    "end": 68843,
    "strand": -1,
    "locus_tag": "ctg8_58",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_58</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_58</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 67,446 - 68,843,\n (total: 1398 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) lanthipeptide-class-i: LANC_like<br>\n \n  biosynthetic-additional (smcogs) SMCOG1140:Lanthionine synthetase C family protein (Score: 178.9; E-value: 2.4e-54)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_58 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05147.16 (Lanthionine synthetase C-like protein): [82:452](score: 120.6, e-value: 6e-35)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_58 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05147.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0031179' target='_blank'>GO:0031179</a>: peptide modification<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_58\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_58_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_58\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGACAGTGGTCTCGATCCTCACTACAAACGCGTGCGGATCTACTCAGACGACTGGGCGCTGCTAAGTCGAGTGGTTGTTGCAAGACAAGGGGCCGGCTCGTTGATCTCAACGGGCCGGCTTCGGTCGACCACGAATCATATGCAAATACTCGAGGACATAAGCGCGGGGATTGCCGATCGGCTCGGATCGCCACCAGCAGTGAAGGCTTTGGTTTCGCGTCAACCGAGCGGGATCAATGGGGTTGAGTGGCACGGGCCGTCGCTAGGGAACGGCCATGCGGGAATCTCGCTCTTCCTGCTTGAACGCGCGAAACGAACAGACACGCAGACTGACTACGACGCGGCGTTTGACCACCTGCGTGCAGCAGTCTCAGCTAACAATGAGTCTCCCTCCGGCGCATTGGGGCTGTTCTCAGGTGCTGCGGGCCTCTCTTACGCCATGACTCAATGCGCCAAGCAGGAGCCGCGTTTTGCTCCTAGCGCCGAGCGGTTTCATGAGCGAGTCGCCGATTCCGTGTTGGACGTGAAATGGGACTTCAAGCCACGTCGCGCCATTGACCAAGAATTTGACCTGATTTCAGGCGCATCCGGTGTCTTGCTGTACTTGGTCAGGTCCCCACAGCAATCTCGTACTTCGCGAGTCGCGATTGACCACCTTTCGCATTATCTCGGCTGGCTGCTCACCAGTGCACCACTTGACTTCACCTTCTTCAGAAGCCCCGACGATTACGTGCCAGGCGGCACATTGGCGAGAAAGTACCCACGGGGAGCAATCGATTGCAGTCTCTCGCATGGCATCTCGAGTGTGGCTCTGGCTCTCTCAGCGGTGGAGTTATCGGGTCAGTCCTCGATGGGCCTTCAGGAGCCGTTGCGTCGAGTTCGTGACTGGCTCGCTATAAGCGCCCTTGAAGATGGCGACATTAAGTTCTACCCGTCTGCTTTGGGTGAACCCGCCGGAGCCGTAGCAGGCAACGCTCTCGACTACAGCTGGTGCAGAGGATCCTCCGGAATCGTCGCCGCCCTTTCCGCGGCCAGCGATGCAACTGGAGACTTGGACGGAGCGCGTCATGCCCGGCATAGCGCTCGCGCCGCCTTTGAGAGATACGACCCCGAACGGCGTCCAGCAGGTCCTTCGTATTGTCTATGCCACGGCGCGGCCGGCGTCGCAATCATGGCCCAATCTCTTGGCTTGGACACGGACGCACACGAACGCGAGCTCGGACTAGCTTTCGATGCTGACCTCCCCACCGGATACGCCGAGAAGAATGTTGTAGACGATGACCTGTACGACCCGAGCTTTCTCTCTGGCTCAGCTGGTGTCGGTGCCACTGCCGAGCACCTGCTCAGCAAAACTGCTACTTGGACGAGAGACCTAGGATTCACGCTTGATGAGTGA",
    "translation": "MDSGLDPHYKRVRIYSDDWALLSRVVVARQGAGSLISTGRLRSTTNHMQILEDISAGIADRLGSPPAVKALVSRQPSGINGVEWHGPSLGNGHAGISLFLLERAKRTDTQTDYDAAFDHLRAAVSANNESPSGALGLFSGAAGLSYAMTQCAKQEPRFAPSAERFHERVADSVLDVKWDFKPRRAIDQEFDLISGASGVLLYLVRSPQQSRTSRVAIDHLSHYLGWLLTSAPLDFTFFRSPDDYVPGGTLARKYPRGAIDCSLSHGISSVALALSAVELSGQSSMGLQEPLRRVRDWLAISALEDGDIKFYPSALGEPAGAVAGNALDYSWCRGSSGIVAALSAASDATGDLDGARHARHSARAAFERYDPERRPAGPSYCLCHGAAGVAIMAQSLGLDTDAHERELGLAFDADLPTGYAEKNVVDDDLYDPSFLSGSAGVGATAEHLLSKTATWTRDLGFTLDE",
    "product": ""
   },
   {
    "start": 70012,
    "end": 71001,
    "strand": 1,
    "locus_tag": "ctg8_59",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_59</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_59</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 70,012 - 71,001,\n (total: 990 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_59 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03595.20 (Voltage-dependent anion channel): [15:307](score: 68.7, e-value: 5.7e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_59 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03595.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF03595.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_59\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_59\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACATCCACCCCGCGGCAGACATCCAACGACACCGCCAGGGCCCCGCTCAGCAGTCTCGGCATCCCGTTCGGGCTCTCCGGCCTCGCCGGAACCTGGACCATGGCCGCCGCCACCTCGCTCGCGCCGCAGATCATAGCCGAGGGGCTCTGGACGCTCGCGGCCACGGCCTGGATCGCCGTCGTCGCAAACTACGTCTGGCGATCCCGCAACCGCGGTGGAAGCATCCTTAACGACTTGCGCGACCCTGTGCAGGGGGCGTTCGCGTCGCTCGCCCCGACGTCGGCGATGCTCATCTGCACGCACTACGCGCAGCAGCTCCCGATGGCCGGCCGCATCATCGCGGGCGTGTTCATGGCCATCGGGTTGCTCTTCGGTGCCTGGTTTCTCGCCCAATTGGCGCTGCGCGAGCGAAGCGTCGATGCCATCCATGCCGGGTACCTGCTGCCCACCGTGGCGGCGGCTTTCATCGTCGGGCAGAGTGCAGGCACCTTCGGCTGGACCCTCCTGGGCGAGGGCGCCATCGCGGTGGGCATCCTCTTCTGGCTGATGCTCGGCACGATCATCCTGGCGCGGATGGCGTTCCGCCCGGCTCCGCCCGCCGCGCTCCTGCCGACGTTCGCGATTTTCTCTGCACCGCCGGCCGTCGCCGGCAACGCCTGGTTCGCGGTGAACGGCGGCCGCATCGATCTGGTGGAGACAATGCTGCTGGGAACCTTCGTCGTGCTGATTCTCGTGCAACTTATGATGCTGGGCGCGTACTGGCGGCTGCCGTTCACCCTGGGGTTCTGGGCGTTCACCTTTACCGCGGCATCCAGCGGAACCTACACGGTGCACTGGCTCGCGCTGTGGGGCGGCCCCGGACACGTGGTGTGGGCGTGGCTTGCCATCGGACTTGTCACACTGCTGATCGGGAGCATCGCCGTGCGATCCGCAGCCTTACTCACCGCTCACAGCCGATTCGACGCGCCGTCAGCTCAACTGCTCTGA",
    "translation": "MTSTPRQTSNDTARAPLSSLGIPFGLSGLAGTWTMAAATSLAPQIIAEGLWTLAATAWIAVVANYVWRSRNRGGSILNDLRDPVQGAFASLAPTSAMLICTHYAQQLPMAGRIIAGVFMAIGLLFGAWFLAQLALRERSVDAIHAGYLLPTVAAAFIVGQSAGTFGWTLLGEGAIAVGILFWLMLGTIILARMAFRPAPPAALLPTFAIFSAPPAVAGNAWFAVNGGRIDLVETMLLGTFVVLILVQLMMLGAYWRLPFTLGFWAFTFTAASSGTYTVHWLALWGGPGHVVWAWLAIGLVTLLIGSIAVRSAALLTAHSRFDAPSAQLL",
    "product": ""
   },
   {
    "start": 71024,
    "end": 71581,
    "strand": -1,
    "locus_tag": "ctg8_60",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_60</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_60</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 71,024 - 71,581,\n (total: 558 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1057:TetR family transcriptional regulator (Score: 73.5; E-value: 5.1e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_60 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00440.26 (Bacterial regulatory proteins, tetR family): [11:58](score: 53.4, e-value: 1.8e-14)<br>\n \n  PF17926.4 (Tetracyclin repressor-like, C-terminal domain): [75:173](score: 50.4, e-value: 2.2e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_60 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00440.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_60\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_60_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_60\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCTACGACTCCGCCGCAACACGCACCCGCCTGCTGGATTCTGCTTATGCGGAGTTCGCCGATCGAGGATTCGCCGGTGCGCGAGTGAACCGAATCGCATCAGAGTCAGGTGCGAACAAGCAGGCGATTTATCTCTACTTCGCTTCCAAAGAGGGTTTGTTCGACGCCGTCCTGGAAGACCGTCTGGGCGTGCTGGCCGACCTGGTCCCCTACACCCCGGATGACCTCACGGGATATATCGGCGCCCTCTTTGACCACATGGTTGAGCATCCCGAACTTGTCCGGCTCACGCAGTGGAAACAGCTAGAGCGGCCTGACGCCACAGACCTGGAACTGAACTCTCATGTGTCGAAAGCGGAGGCTCTTGCTCGAGCGATGGGCGTCGACGACACCCGCGGCATGGATGCTCTCATGCTTACTCTTGCCATGGCGCAAGCCTGGAATACAACGAGCACGTCAGTCCGATCCATGAAGGAACCAGCAGAACTGCGTCTTCGGCAACATCGCGCCTCGCTTATTACCGGGGTTGCGTCCGTCGTCAGTGCCCTTCAATAA",
    "translation": "MSYDSAATRTRLLDSAYAEFADRGFAGARVNRIASESGANKQAIYLYFASKEGLFDAVLEDRLGVLADLVPYTPDDLTGYIGALFDHMVEHPELVRLTQWKQLERPDATDLELNSHVSKAEALARAMGVDDTRGMDALMLTLAMAQAWNTTSTSVRSMKEPAELRLRQHRASLITGVASVVSALQ",
    "product": ""
   },
   {
    "start": 71682,
    "end": 72527,
    "strand": 1,
    "locus_tag": "ctg8_61",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_61</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_61</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 71,682 - 72,527,\n (total: 846 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 184.5; E-value: 4e-56)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_61 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00106.28 (short chain dehydrogenase): [3:186](score: 150.9, e-value: 3.1e-44)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_61\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_61_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_61\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGAACGTGGCTCATCACGGGGGCGTCATCCGGAATCGGTCGCTCCGTTACGTCGAGATTGTTGGAGCAGGGGGATCGTGTAGCTGCTTTCGTTCGTCGGCCAGAAGCCCTCAACGAACTGTCCGACACGTACCCCGGGAAGCTGTGGGTGGCGCCGGTCGATGTCACCGACACGCGCGTCCTGCGCGACGCCGTAGTCCGGGCGTTCACTGACCTCGGGAAGATCGATGTTGTCTTCTCGAATGCCGGAGCAGGAGCATTCGGAGCCGCCGAAGAGCTCGACGATAGCGCGATCGAGGAACAGATCGCGCTCAACCTCGTTGCACCGATCCAGCTCATCCGGGCCGTCCTCCCGCACCTCCGCGCCCAAGGTGGGGGTCGGATCATCCAGATGTCCACGATGGGCGGCCAGATCACCAGCACCGGAGGCAGCATGTACCACGCCTCCAAGTGGGGGATCGAGGGGTTCACCGAGTCGGTGATGGGCGAGGTCGCTCCGTTCGGCATCGGCATCACCCTGGTCGAGCCCGGAAATGTGCGCACCGCGTTTGGCGCGGCGCTCACCATCGCCGCGCCCATCGAGGCCTACGCCGACACTCCCGTCGGGCACGTACGGCAGTACATCGAGGCTGCCGGTGGCAACCTCACCGGCGACGCCCTGGGCGACCCGGCCCGCGTCGCCGAAGCGATCATCGCCGTGTCGGTGCAGTCACCCGCCCCTGAGCGCCTGGTCCTGGGAAGCGACGCCTACTCGGCAATCCGCGCCGCACTCACCTCCCGGCTCAGCCAACTCGATGCAGGCAAGGCGGTCTCCGAGAGCACCGACTTCCCCGCCACCACCTGA",
    "translation": "MRTWLITGASSGIGRSVTSRLLEQGDRVAAFVRRPEALNELSDTYPGKLWVAPVDVTDTRVLRDAVVRAFTDLGKIDVVFSNAGAGAFGAAEELDDSAIEEQIALNLVAPIQLIRAVLPHLRAQGGGRIIQMSTMGGQITSTGGSMYHASKWGIEGFTESVMGEVAPFGIGITLVEPGNVRTAFGAALTIAAPIEAYADTPVGHVRQYIEAAGGNLTGDALGDPARVAEAIIAVSVQSPAPERLVLGSDAYSAIRAALTSRLSQLDAGKAVSESTDFPATT",
    "product": ""
   },
   {
    "start": 72621,
    "end": 73025,
    "strand": 1,
    "locus_tag": "ctg8_62",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_62</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_62</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 72,621 - 73,025,\n (total: 405 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF07366<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_62 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07366.15 (SnoaL-like polyketide cyclase): [8:132](score: 90.7, e-value: 6.8e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_62 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF07366.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030638' target='_blank'>GO:0030638</a>: polyketide metabolic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_62\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_62\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_62_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_62\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_62\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACAAGCACGCCTGCTAAGACCATCGCCCGCGAATTCTGGGAGAGCTGGGGGCGCGGCGATCTGGACGCGACCTGGCGCCAGTACGTCGCGGACGACATCGTCATCCACCCGTCGTCGGGATACGAATTCACGCGGCAGAGTTGGCTGGAGGCCGAAAAAGCACTCCATGCCGCGTTCGAGGACATCAAGGTCACCGTCGTCGATCAGATCGAGGACGGCGACATGGTCGCGACCCGATGGGCCGTCACTGCCCGGCAGAGCGGAGAGTTCTTCGGCGTGCCCTCCAGCGGACGGACCGCCACCCTTACTGGAACCACCTTCGACCGCGTTCAGGACGGCAAACTTGCCGAGCACTGGGCCGAAGTGGGCGTTCCGCAGTTCCTCCAGCAGCTCTCCGCCTAA",
    "translation": "MTSTPAKTIAREFWESWGRGDLDATWRQYVADDIVIHPSSGYEFTRQSWLEAEKALHAAFEDIKVTVVDQIEDGDMVATRWAVTARQSGEFFGVPSSGRTATLTGTTFDRVQDGKLAEHWAEVGVPQFLQQLSA",
    "product": ""
   },
   {
    "start": 73056,
    "end": 73493,
    "strand": 1,
    "locus_tag": "ctg8_63",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_63</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_63</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 73,056 - 73,493,\n (total: 438 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_63 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13577.9 (SnoaL-like domain): [13:136](score: 50.2, e-value: 2.6e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_63\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_63\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_63\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_63\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCTCTAGAACAGATCGGCATCCTCGTCACTGATTCCGACCACGTCCAACTCACGCGCCTCGCCCTCGAGGTCGCCTGGCGCGTCGACATCGGCCAAGCCGAGACGCTCCCGGAGCTCTTCACCGAAGACGGCTGGATCGCGACCCTGGGCGAACCCAACGTCGGACACGCCGCCATCCGCAGCTGGGGGCAGATGATGGACACGGATAGCCCCATACCCGGGGTACGCCACGTTCTGACGAACTTCAGGTTCACAACTGAGGCACCTGACCAAGCCGTCGGCACGATGTACATCACCGCCTACTTGGCCGGGGCCCCGGAGGGACAGGCCACTGTCCCCTTCGCGATGGGCACTGGCACCGACCACTACCGCCGTACCGCCGACGGCTGGAAGGTCACCTCCCGAGCCTTCACACCACATTTTCTCCGGGAATAG",
    "translation": "MPLEQIGILVTDSDHVQLTRLALEVAWRVDIGQAETLPELFTEDGWIATLGEPNVGHAAIRSWGQMMDTDSPIPGVRHVLTNFRFTTEAPDQAVGTMYITAYLAGAPEGQATVPFAMGTGTDHYRRTADGWKVTSRAFTPHFLRE",
    "product": ""
   },
   {
    "start": 73603,
    "end": 74241,
    "strand": -1,
    "locus_tag": "ctg8_64",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_64</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_64</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 73,603 - 74,241,\n (total: 639 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_64 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01966.25 (HD domain): [31:118](score: 35.8, e-value: 8.7e-09)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_64\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_64\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_64_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_64\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_64\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACACAGACCATCGCCGGCATCGCCATTCCCGACAGTTCACTTGCTGTCGAAGCCACCGAATTGGTGCGCGATACGACCAACGAACTCATCTTCAACCACTCCCGCCGGGTGTTCCTGTTCGGCAGCCTGCGGGCGCAGGCGCTGAATATCACGCCGGAACCCGAGCTGTTATATGTCGCTGCGCTGTTCCACGATCTCGGACTCGTCGCCCCGTACAAGAACGTCGCCCAGCGCTTTGAATTGGATGGTGCCGGGCACGCTCGCGAGTTCCTGACCTCGCACGGTATCTCCGGTGCCGACGCGGAGGAGGTATGGACCGCGATTGCCCTGCACACCACGCCTGAAGTTCCCTACCGGATGAGCCCGGTGATCGCGGCGACAACGGCCGGGGTGGAGGCCGATGTGCTCGGGATCAACCTCGGCTCGCTGTCAGAGAGCCAGATCGGCGCCATCACGGCGGCGCATCCGCGTCCGGACTTCAAAAAGCGCATTCTGCAGGCGTTCTTCGACGGCTTCTCCGACCGCCCGGACACAACTTTCGGCACCGTCAACGCCGACGTTCTGGAGCATTTCCAAGCCGACTTCCGGCACATCGACTTCGTCGACGTGATCCGGAACTCCGCCTGGAGCGAATAG",
    "translation": "MTQTIAGIAIPDSSLAVEATELVRDTTNELIFNHSRRVFLFGSLRAQALNITPEPELLYVAALFHDLGLVAPYKNVAQRFELDGAGHAREFLTSHGISGADAEEVWTAIALHTTPEVPYRMSPVIAATTAGVEADVLGINLGSLSESQIGAITAAHPRPDFKKRILQAFFDGFSDRPDTTFGTVNADVLEHFQADFRHIDFVDVIRNSAWSE",
    "product": ""
   },
   {
    "start": 74436,
    "end": 75371,
    "strand": 1,
    "locus_tag": "ctg8_65",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_65</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_65</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 74,436 - 75,371,\n (total: 936 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1260:AraC family transcriptional regulator (Score: 72.3; E-value: 8e-22)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_65 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01965.27 (DJ-1/PfpI family): [1:160](score: 93.0, e-value: 1.9e-26)<br>\n \n  PF12833.10 (Helix-turn-helix domain): [220:299](score: 78.1, e-value: 5e-22)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_65 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF12833.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity<br>\n  \n   PF12833.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043565' target='_blank'>GO:0043565</a>: sequence-specific DNA binding<br>\n  \n   PF12833.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_65\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_65\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_65_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_65\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_65\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACTTCTCGACATGGCTGGGCCCGCCGAAGTGTTCACCGAGGCGAACCTTTCCGGGGCGAATTACCGCATCAGCATGGTGTCCACCGGCGGCCACGACGTCCGATCCTCCATCGGCATGCGTGTGCCAGTCGATGTCTCCGCGGCCGACGCCGGACGCTTCGATACCGTCCTGGTCGCGGGCGGCGAGGTGTTCCCGGCTCACCCCGTCCCAGAGCCCCTCGCCGGCGCGGCGCTCCACCTTGCCGACCGGGCGTCCCGCACCGCATCAATCTGCACCGGTGCTTTCGTGTTGGCGGCGGCAGGACTGCTAGACGGCAAGCGGGCGACCACGCACTGGAAGCACACTCGAGAACTCGCCCTGCGGTATCCCGCAACACAGGTAGAACCCGATGCCATCTTCGTCCGGGATCAGAGCACGTATTCGTCCGCCGGAGTCACCGCCGGGATCGATCTCGCCCTCGCGCTGCTGGAGGAAGACGAAGGCGACGGACTCACCCGCACCGTCGCTCGCTCGTTGGTCGTCTACATGCAGCGCGCCGGAGGACAATCCCAGTTTTCCGCGACCCTGCAGGGCCCCGCACCCCGCACGGCCTTGCTGCGCGGCGTCGTCGACATTGTGAACGCCGACCCGGCGGCCGAGTACACCGTGACCCGGCTCGCGGCGATCGCCCAAGTGAGCCCACGCCACCTCACCCGCCTCTTCCACGACGAACTCGGGACCACTCCGGGCAGGTACGTCGAGCTGATCCGCTTCGACAAGGCCAAGGCGTTGCTGGATACCGGAATGAGCGTCACGGATGTGGCCCAGTACTCGGGCTTCGGCACATCCGAGTCGCTCCGGCGTGCCTTCATCGCTCACCTGGCGATCCCACCGTCCAAGTATCGAGGCCGGTTCTCCCCGATGTCGGGAACGAGAAATACTGCCGCCTGA",
    "translation": "MKLLDMAGPAEVFTEANLSGANYRISMVSTGGHDVRSSIGMRVPVDVSAADAGRFDTVLVAGGEVFPAHPVPEPLAGAALHLADRASRTASICTGAFVLAAAGLLDGKRATTHWKHTRELALRYPATQVEPDAIFVRDQSTYSSAGVTAGIDLALALLEEDEGDGLTRTVARSLVVYMQRAGGQSQFSATLQGPAPRTALLRGVVDIVNADPAAEYTVTRLAAIAQVSPRHLTRLFHDELGTTPGRYVELIRFDKAKALLDTGMSVTDVAQYSGFGTSESLRRAFIAHLAIPPSKYRGRFSPMSGTRNTAA",
    "product": ""
   },
   {
    "start": 75481,
    "end": 75993,
    "strand": 1,
    "locus_tag": "ctg8_66",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_66</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_66</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 75,481 - 75,993,\n (total: 513 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_66 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00210.27 (Ferritin-like domain): [28:163](score: 68.6, e-value: 5.8e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_66 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00210.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008199' target='_blank'>GO:0008199</a>: ferric iron binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_66\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_66\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_66\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_66\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCCCACGCCCAGAACCAGCACATCGTCGACATCCCCGTGTCGAGCACCCCACGATTCATCGCCAGCGACACGCTCCTGAGTAGCCTGCAGTCCGTGCTCGTGGATCTAATCGAACTGAACCTCCAGGGTAAGCAAGCACATTGGAACGTCGTCGGGCCGAACTTCCCCGACGTGCACCGGCAACTCGACCTGATTGTGTCGACGGCCCAGGATGCCGCGGACGGCGTAGCCGAGCGCATGCGCGCGGTTGGCGGAATTCCCGACGGGCTGAGCTCCACGGTGGCCGAGACCACCGGACTTCTGGCCTATCCCCGGGGCGAAGTGACCACTCGGCAGACGATCGACCTCATCTCGGAACGCATCTACACCACCGTGGCAAATGCCCGCGCCGTGCATTCAGCCGTCGACGACGAGGATCCGGTGTCCGCGGACCTGCTCAACGGCACGATCGCCCAGCTCGAGCAGCACGCCTGGTTGCTGTCGTCCGAGAACCGTACGCCGAGCTTGTGA",
    "translation": "MPHAQNQHIVDIPVSSTPRFIASDTLLSSLQSVLVDLIELNLQGKQAHWNVVGPNFPDVHRQLDLIVSTAQDAADGVAERMRAVGGIPDGLSSTVAETTGLLAYPRGEVTTRQTIDLISERIYTTVANARAVHSAVDDEDPVSADLLNGTIAQLEQHAWLLSSENRTPSL",
    "product": ""
   },
   {
    "start": 76111,
    "end": 76659,
    "strand": 1,
    "locus_tag": "ctg8_67",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_67</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_67</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 76,111 - 76,659,\n (total: 549 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_67 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02627.23 (Carboxymuconolactone decarboxylase family): [55:110](score: 36.5, e-value: 4.3e-09)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg8_67 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02627.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051920' target='_blank'>GO:0051920</a>: peroxiredoxin activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_67\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_67\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_67\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_67\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGGTCACCACCGCCACGCTCGCCCCCATCCAGCCCGAGGACGCCACGGGCGTCGCCAAAGACCTGCTCGCGCAGGTGCAGAAGGGCCTCGGCCGCGTGCCGAACATGACCAAGGTCATGGCGAACAGCCCGGCACTTCTCAAGAGCTACCTCGTTTTGTCTGCCGCCGTGGGCTCCGGCACCCTTCCGGCCGCCGTTCGTGACCGCCTCGCGATCGCGACCGCCCAGCTGAATGGATGCGAATACTGCCTCTCCGCACATACCTACATCGGCAGCAACGTGTCGAAGGTGACCGCCGACGAACTCGATTCCGCACGACGCAGCGACTCGACCAACCCCCACGTTGCCGCGCTGCTGACGCTTTCCAGCGCGATCGCGGAGAATGCCGGGGATGTGGCTGAGGACACGATCGCGAAGGCCCGCGAAGCCGGGGTGACGGACCAGGAGATCGGGGAACTGGTGGCTAATCTGGCGTTGAATGTGCTGACGAACTACTTCAACGTTCTCGCCCGGGTCGAAAACGACTGGCCTGTTGTGGCGTTGTAG",
    "translation": "MTVTTATLAPIQPEDATGVAKDLLAQVQKGLGRVPNMTKVMANSPALLKSYLVLSAAVGSGTLPAAVRDRLAIATAQLNGCEYCLSAHTYIGSNVSKVTADELDSARRSDSTNPHVAALLTLSSAIAENAGDVAEDTIAKAREAGVTDQEIGELVANLALNVLTNYFNVLARVENDWPVVAL",
    "product": ""
   },
   {
    "start": 76742,
    "end": 77713,
    "strand": 1,
    "locus_tag": "ctg8_68",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_68</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_68</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 76,742 - 77,713,\n (total: 972 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF00561<br>\n \n  biosynthetic-additional (rule-based-clusters) Abhydrolase_6<br>\n \n  biosynthetic-additional (smcogs) SMCOG1036:alpha/beta hydrolase fold protein (Score: 118.3; E-value: 8.1e-36)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_68 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00561.23 (alpha/beta hydrolase fold): [68:304](score: 95.8, e-value: 3.5e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_68\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_68\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg8_68_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_68\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_68\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCGTATTCGAGGGCAGTCTGGCCGGAGACGCGGGGCGGCTGAGGCCGGGCATCTTCAGACTGAATATACGGCCCGACCCAGAGCGGGCCACAGCGAGAACCTCTCTTCTAGCGGATAGGAACACCATGTCAGTCATCACCGTCGGCACCGAGAACAGCACGTCGATCGACCTGTACTACGAAGACCACGGCAGCGGCCAGCCTGTCGTCCTCATCCACGGCTACCCTCTCAACGGGGCCTCCTGGGCACCGCAAACCCGGGCGCTCCTCGCGGCCGGCTACCGAGTCATCACCTACGACCGCCGCGGTTTCGGCAAGTCCAGCCAGCCGAGCGAAGGCTACAACTACGACACCTTCGCCGCCGACCTCGACGTCGTCCTCACGACACTCGACCTCCAGAACGTGCTGCTCGTCGGCTTCTCCATGGGCACCGGCGAGGTCGGCCGGTACACGGCGACCTACGGTACCGACCGCCTCGCGAAGATCGCGTTCCTGGCGCCGATCGAGCCGTTCCTGCTCAAGACCGACGACAACCCCACCGGGCTCCCGCAGGAGGTTTTCGACGGCATCGCTGCGGGCGCGCAAGCCGACCCGTACGCGTTTTACACGTCATTCTATGAGAACTTCTACAACCTCGATGAGAACCTCGGCACCCGCGTGAGCCCCGAGGTCGTTCAGGGGAGCTGGAACGTCGCAACGGGCGGTTCGCTGATCGCGGCCTACGCTGTCGTGCCGTCCTGGCACGAAGACTTCCGCGGCGATATCGAGAAGATCCGCGCGACCGGGATTCGCAGCCTGATCATGCAGGGTGTGCTCGACCGCATCCTCCCGATCGACGCGACCGGGCGCGCCTTCCACAAGGCGTTCCCCGAGAGCGACTACGTGGAGATCGAGGGCGGGCCGCACGGCTTCGGCTGGAGCCACGCCGCCGAGGTCAACGAAAACCTGCTGCGCTTCCTCGCGAGCTAG",
    "translation": "MSVFEGSLAGDAGRLRPGIFRLNIRPDPERATARTSLLADRNTMSVITVGTENSTSIDLYYEDHGSGQPVVLIHGYPLNGASWAPQTRALLAAGYRVITYDRRGFGKSSQPSEGYNYDTFAADLDVVLTTLDLQNVLLVGFSMGTGEVGRYTATYGTDRLAKIAFLAPIEPFLLKTDDNPTGLPQEVFDGIAAGAQADPYAFYTSFYENFYNLDENLGTRVSPEVVQGSWNVATGGSLIAAYAVVPSWHEDFRGDIEKIRATGIRSLIMQGVLDRILPIDATGRAFHKAFPESDYVEIEGGPHGFGWSHAAEVNENLLRFLAS",
    "product": ""
   },
   {
    "start": 77789,
    "end": 78184,
    "strand": 1,
    "locus_tag": "ctg8_69",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg8_69</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg8_69</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 77,789 - 78,184,\n (total: 396 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg8_69 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03625.17 (Domain of unknown function DUF302): [35:97](score: 58.2, e-value: 6e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg8_69\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg8_69\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_69\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg8_69\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCGAGGAACTGAAAACACTACGGGTGCAGGGCAGCGTCGCTGAGGCGACCGCTCGACTCCGCGAGCTGTTGGAGCGACGAGGCGTTGCAGTGATCGCGAGCATCGATCACGCCGCAGGAGCGCGGGCGGCGGGCCTGGAGCTAGCCGATGAAGTCGTCGTGTTCTTCGGAGACCCGGCCGTGGGTACGGGGGTGATGCAGGACGATCCGAGAGCCGGAATCGATCTCCCGCTTCGGATGCTGGTCTGGGACGACAACGGTTCCACGTACATCGGCTACCGTGACCCGCACGTGCTCTCCGACCTGTTTGAGCTCGACATCCATCGCGACGTGCCGGCGAAGCTGAGCGGATTCATGGAACGACTTGCACACGATCTATCGGCCGAGCAGTGA",
    "translation": "MGEELKTLRVQGSVAEATARLRELLERRGVAVIASIDHAAGARAAGLELADEVVVFFGDPAVGTGVMQDDPRAGIDLPLRMLVWDDNGSTYIGYRDPHVLSDLFELDIHRDVPAKLSGFMERLAHDLSAEQ",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 64462,
    "end": 68843,
    "tool": "rule-based-clusters",
    "neighbouring_start": 54462,
    "neighbouring_end": 78843,
    "product": "lanthipeptide-class-i",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "lanthipeptide-class-i",
  "products": [
   "lanthipeptide-class-i"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP lanthipeptide-class-i",
  "anchor": "r8c1"
 },
 "r14c1": {
  "start": 14041,
  "end": 54779,
  "idx": 1,
  "orfs": [
   {
    "start": 14438,
    "end": 15334,
    "strand": -1,
    "locus_tag": "ctg14_17",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,438 - 15,334,\n (total: 897 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1069:putative ABC transporter permease protein (Score: 245; E-value: 1.5e-74)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_17 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00528.25 (Binding-protein-dependent transport system inner membrane component): [106:287](score: 65.2, e-value: 6.6e-18)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_17 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_17_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSRTQTEKIADAPDRTHRADGMSRGQNILRGVVLLVGALVFLFPFYYMVIGSLQAKPDPTIAGAFPNPANLTLDNYADINGRINLLQGLLNSGIFTGGVILCTVVFGVLVGYALAQLQWRGRGVTFALALLVQVVPFQLLMIPLYVMIARDYGLADNYLGMILPFAINSTAVIIFRQYFLQIPKELFDAARIDGAGELRILRRIALPLVRPALLTVVLLTFIGPWNEFLWPFLITKEASLQPLAVSLANYLSNVAATAANPFGAILAGACVLAGPAVLLFILFQRHFVSSNIGSGVKG\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCCGCACCCAGACCGAGAAGATCGCGGACGCCCCCGACCGCACCCACCGGGCGGACGGCATGAGCCGTGGCCAGAACATCCTCCGCGGCGTCGTGCTGCTGGTCGGCGCGCTGGTGTTCCTGTTCCCGTTCTACTACATGGTCATCGGATCGCTCCAGGCCAAACCGGACCCGACGATCGCCGGCGCGTTCCCCAACCCGGCGAACCTGACGCTGGACAACTACGCCGACATCAACGGCCGGATCAACCTGCTGCAGGGGCTGCTCAACTCGGGCATCTTCACCGGCGGCGTGATCCTGTGCACGGTCGTGTTCGGGGTTCTGGTCGGCTACGCCCTGGCGCAGCTGCAGTGGCGCGGCCGCGGCGTCACGTTCGCGCTGGCCCTGCTGGTGCAGGTGGTGCCGTTCCAGCTCCTGATGATCCCGCTCTACGTGATGATCGCCAGGGACTACGGCCTGGCCGACAACTACCTGGGCATGATCCTGCCGTTCGCCATCAACTCGACGGCGGTCATCATCTTCCGGCAGTACTTCCTGCAGATCCCCAAGGAGCTCTTCGATGCCGCCCGCATCGACGGCGCCGGAGAACTGCGGATCCTGCGCCGGATCGCGCTGCCGCTCGTGCGGCCGGCGCTGCTCACGGTGGTGCTGTTGACGTTCATCGGCCCGTGGAACGAGTTCCTCTGGCCGTTCCTGATCACCAAGGAGGCCTCGCTGCAACCGCTCGCGGTCTCCCTGGCGAACTACCTCAGCAACGTCGCGGCCACCGCGGCCAACCCCTTCGGAGCCATCCTGGCCGGCGCCTGCGTTCTGGCCGGCCCCGCTGTGCTCCTGTTCATCCTGTTCCAGCGTCACTTCGTCTCGAGCAATATCGGCTCGGGCGTGAAAGGTTAG",
    "translation": "MSRTQTEKIADAPDRTHRADGMSRGQNILRGVVLLVGALVFLFPFYYMVIGSLQAKPDPTIAGAFPNPANLTLDNYADINGRINLLQGLLNSGIFTGGVILCTVVFGVLVGYALAQLQWRGRGVTFALALLVQVVPFQLLMIPLYVMIARDYGLADNYLGMILPFAINSTAVIIFRQYFLQIPKELFDAARIDGAGELRILRRIALPLVRPALLTVVLLTFIGPWNEFLWPFLITKEASLQPLAVSLANYLSNVAATAANPFGAILAGACVLAGPAVLLFILFQRHFVSSNIGSGVKG",
    "product": ""
   },
   {
    "start": 15331,
    "end": 16290,
    "strand": -1,
    "locus_tag": "ctg14_18",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,331 - 16,290,\n (total: 960 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1067:putative ABC transporter permease protein (Score: 248.3; E-value: 1.6e-75)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_18 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00528.25 (Binding-protein-dependent transport system inner membrane component): [113:311](score: 58.1, e-value: 1e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_18 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00528.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_18_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSTLTPKRPLAGRPATPPGGGARPRRKRQWLGKNPFGLLLSAPYLIFVLAVFAYPLVFAFWMSFHDYFFAAPGAQVDRPFVGLANFQEVLGDPAVIRSFGNVGIFLLINVPLTVVLSLVLASALNKAVRFRTFLRVSYYVPYVTASVAVVGVWIFLFSGNGLVNQILGPLAPDPAWLINEQWAMPTIAIFVTWKGLGFFILLYLAALQNVSEELYEAAATDGAGKIRSFFSVTVPGVRPATVLVLLLSTVTGANLFTEPYLLTGGGGPNGASTSPVLIMYQRGIEQGSPDTAAAIGVILVIGVLILAFIQRKLAGGDES\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCACCCTCACCCCGAAACGACCCCTCGCCGGGAGGCCCGCAACGCCTCCCGGCGGGGGCGCCCGCCCGCGCCGCAAGCGCCAGTGGCTGGGCAAGAACCCGTTCGGGCTCCTGCTCAGCGCACCGTACCTGATCTTCGTCCTCGCGGTCTTCGCCTACCCCCTGGTGTTCGCGTTCTGGATGTCGTTCCACGACTACTTCTTCGCCGCCCCCGGCGCGCAGGTGGACCGGCCCTTCGTGGGGTTGGCCAACTTCCAGGAGGTGCTCGGCGATCCCGCCGTCATCCGGTCGTTCGGCAACGTGGGAATCTTCCTGCTGATCAATGTGCCGCTCACCGTGGTGCTCTCCCTGGTCCTGGCCAGCGCCCTGAACAAGGCGGTCAGGTTCCGCACCTTCCTGCGGGTGTCGTACTACGTGCCGTACGTCACCGCATCCGTCGCGGTCGTCGGCGTGTGGATCTTCCTGTTCAGCGGCAACGGACTGGTCAACCAGATCCTGGGCCCGCTGGCGCCCGACCCGGCCTGGCTGATCAACGAGCAGTGGGCAATGCCCACCATCGCCATCTTCGTCACCTGGAAGGGCCTGGGGTTCTTCATCCTGCTCTACCTCGCCGCGCTGCAGAACGTGTCGGAGGAACTGTACGAGGCCGCCGCGACGGATGGTGCGGGCAAGATCCGCAGCTTCTTCTCGGTGACGGTGCCCGGCGTGCGCCCCGCCACGGTGCTCGTGCTGCTGCTGTCCACCGTCACCGGCGCGAACCTCTTCACCGAGCCGTACCTGCTCACCGGCGGCGGCGGCCCGAACGGCGCCTCCACCTCTCCCGTGCTGATCATGTACCAGCGCGGCATCGAACAGGGCTCGCCGGACACGGCGGCCGCGATCGGAGTGATCCTCGTGATCGGTGTCCTCATCCTCGCGTTCATCCAGCGGAAGCTGGCCGGGGGTGACGAATCATGA",
    "translation": "MSTLTPKRPLAGRPATPPGGGARPRRKRQWLGKNPFGLLLSAPYLIFVLAVFAYPLVFAFWMSFHDYFFAAPGAQVDRPFVGLANFQEVLGDPAVIRSFGNVGIFLLINVPLTVVLSLVLASALNKAVRFRTFLRVSYYVPYVTASVAVVGVWIFLFSGNGLVNQILGPLAPDPAWLINEQWAMPTIAIFVTWKGLGFFILLYLAALQNVSEELYEAAATDGAGKIRSFFSVTVPGVRPATVLVLLLSTVTGANLFTEPYLLTGGGGPNGASTSPVLIMYQRGIEQGSPDTAAAIGVILVIGVLILAFIQRKLAGGDES",
    "product": ""
   },
   {
    "start": 16296,
    "end": 17630,
    "strand": -1,
    "locus_tag": "ctg14_19",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,296 - 17,630,\n (total: 1335 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1143:sugar-binding lipoprotein (Score: 235.6; E-value: 2.1e-71)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_19 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13416.9 (Bacterial extracellular solute-binding protein): [69:385](score: 121.3, e-value: 7.1e-35)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCACACCCGCACCACACCCACCGGCACCACCCGTCAGACCAGGCGCCGAAACGCGAGATTCCTCGCGGCCGCCGCCACCTCCGCCGCCATGATCGCCGCGCTGGGCGCCTGCTCCAGCGGAGGCGCCGCCTCCGGCGGCTCAGACTCCCGCGGTGACATCACCATCTGGTATTCCAACAACGAGACCGAGATCGCCTGGGGCAAGCAGATGGTCGAGGCCTGGAACGCCGATCACCCGGACGAGCAGGTCAAGGCCCAGGAGATCCCCGCCGGCAAGAGCAGCGAAGAGGTCATCGGCGCCGCCATCACGGCCGGCAACGCGCCCTGCCTGGTCTTCAACACCGCCCCCGTCGCGGTCCCGCAGTTCCAGAAGCAGGGCGGCCTGGTCGACCTCAGCAGCTTCGAGGACGGCGCGGCCTACATCGAGGAGCGCACCGGCGAGGCGTCCTCGCAGTACCAGGACGCCGACGGGAAGTACTACCAGATGCCCTGGAAGTCCAACCCCGTCATGATCTTCTACAACAAGGACATGTTCGCCGCGGCCGGGCTCGACCCGGAGAACCCGCAGCTGTCCACCTACGACGACTTCCTCGCCACCTCGCGTGCCCTCGTGGCCAGCGGTGCCGCCCCAAACGCCATCTACCCGGCCCCGACCAGCCAGTTCTTCCAGAGCTGGTTCGACTTCTACCCGCTGTACGCGGCCGAGACCGGCGGCACCCAGCTCGTCGCCGACGGCGAGGCCACGTTCAACGACGCCGACGGCGCCGCCGTGGCCGAGTTCTGGAAGACCCTCTACTCGGAGGGTCTGGCCGGCAAGGAGCAGTACCAGGGTGACTCGTTCGCCGACGGCCAGGCCGCCATGTCGATCGTGGGCCCGTGGGCGGTGTCCGTCTATAAGGACGCCGTGAACTGGGGCGCCGTCCCGGTTCCCACCAGTGCCGGCACCCCCGCCGACCAGACCTACACCTTCAGCGACGCCAAGAATGTGGGCATGTTCACGGCCTGCAAGAACCAGGCCACGGCCTGGGATGTGCTCAAGTTCGCCACCAGCGAGGAACAGGACGGCCAACTGCTCGAGCTGACCGGCCAGATGCCGCTGCGGGCCGACCTCACCACCGTGTACCCGGACTACTTCGCGGCCAACCCCGCCTACCAGCAGTTCGGTGACCAGGCGTCCCGCACGGTCGAGGTGCCCAGTGTGGCCAACTCGGTTGCCGTCTGGCAGGCCTTCCGTGACGCGTACACGAAGTCGGTGATCACCGGGGACGGCGACGTGGCCGGAGCCCTGGACGACGCCGCCACGAAGATCAACGACCTGATCACGCAGCCGTAG",
    "translation": "MHTRTTPTGTTRQTRRRNARFLAAAATSAAMIAALGACSSGGAASGGSDSRGDITIWYSNNETEIAWGKQMVEAWNADHPDEQVKAQEIPAGKSSEEVIGAAITAGNAPCLVFNTAPVAVPQFQKQGGLVDLSSFEDGAAYIEERTGEASSQYQDADGKYYQMPWKSNPVMIFYNKDMFAAAGLDPENPQLSTYDDFLATSRALVASGAAPNAIYPAPTSQFFQSWFDFYPLYAAETGGTQLVADGEATFNDADGAAVAEFWKTLYSEGLAGKEQYQGDSFADGQAAMSIVGPWAVSVYKDAVNWGAVPVPTSAGTPADQTYTFSDAKNVGMFTACKNQATAWDVLKFATSEEQDGQLLELTGQMPLRADLTTVYPDYFAANPAYQQFGDQASRTVEVPSVANSVAVWQAFRDAYTKSVITGDGDVAGALDDAATKINDLITQP",
    "product": ""
   },
   {
    "start": 17706,
    "end": 18776,
    "strand": -1,
    "locus_tag": "ctg14_20",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,706 - 18,776,\n (total: 1071 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1078:LacI family transcription regulator (Score: 304; E-value: 2.2e-92)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_20 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00356.24 (Bacterial regulatory proteins, lacI family): [21:67](score: 42.7, e-value: 3.8e-11)<br>\n \n  PF13377.9 (Periplasmic binding protein-like domain): [191:349](score: 117.2, e-value: 9.3e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_20 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00356.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF00356.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_20_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATTCCCACCCGGATTCCGGCACGAACGACGAGTCCGCGTCGAAGGATACGGGCAAGGTCACGATCGCCGACGTCGCCCGTCAGGCCGGGGTCAGCAAGGGCCTCGTGTCGTTCGCCCTCAATGACCGTCCTGGGGTGTCCGCCGAGACGCGCGCGCGCATCCTCTCGGTCGCCGGCCTGCTCGGCTGGACGCCGTCGCTCCGGGCCCGGTCGCTGTCCTCGCAGCGTTCCTTCGCCCTCGGCCTGGTCATCGCCAGGGACCCCGAGGTCCTCGGATCCGACCCCTTCTTCACGTCGTTCATCGCCGGGGTCGAGACCATCCTGGCGCCGGAGGGCCTGGCCCTGGTGCTCAGCGTCGTTCCCGACGAGAAGACCGAGCTGGCGACCTACCGCACCCTCGTGGCCGACGGCCGGGTCGACGGCGTCTTCCTCAGCGATCTCCGCCGCGACGACGCCCGCATCCCCTGCCTGACCGAACTCGCGCTGCCGACCGTGACCCTGGGCCGGCCGGACCAGCCGAGCCCGTTCCCCGCGGTGTCCATCGACGACACCCAGGGGGTCGCCGAGTCGGTGCGGCACCTGAGCACCCTCGGCCACCGACGCATCGCGCACGTCGCCGGCAGCCCCGCCATGCTGCACGGTCGTCGGCGACGGGATGCGTTCACCCGGGCCATGCAGGCCGCCGGACTCGGCCAGGGCCAGGTCGTCGAAACCGACTTCTCGATCGCGGCCGGCGCCGACGCCACCCGGCGTCTGCTGAGCCAGCCCGAACCCCCCACCGCCATCGTGTTCGCCAACGACCCGATGGCCATCGCCGGCATCGGCGTGGCCCAGGAACTGGGCGTGCGGGTTCCGGACGACCTGTCGATCACCGGCTTCGACGATATCGAGTTCGCCCGGTACGTCTACCCGGCGCTGACCACCGTCGGCGCCACCCCCATGGTCTGGGGCCGCGCCGCGGCGAGCACGCTGCTCGGCCTCATCCGGACCGGCAGCGCCGACGATGTCGAGCTTCCCGCCGCCCGCCTGATCGTGCGCGGCTCGGCATCCGCACCGCCGCCGTACTAG",
    "translation": "MDSHPDSGTNDESASKDTGKVTIADVARQAGVSKGLVSFALNDRPGVSAETRARILSVAGLLGWTPSLRARSLSSQRSFALGLVIARDPEVLGSDPFFTSFIAGVETILAPEGLALVLSVVPDEKTELATYRTLVADGRVDGVFLSDLRRDDARIPCLTELALPTVTLGRPDQPSPFPAVSIDDTQGVAESVRHLSTLGHRRIAHVAGSPAMLHGRRRRDAFTRAMQAAGLGQGQVVETDFSIAAGADATRRLLSQPEPPTAIVFANDPMAIAGIGVAQELGVRVPDDLSITGFDDIEFARYVYPALTTVGATPMVWGRAAASTLLGLIRTGSADDVELPAARLIVRGSASAPPPY",
    "product": ""
   },
   {
    "start": 18934,
    "end": 20400,
    "strand": 1,
    "locus_tag": "ctg14_21",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,934 - 20,400,\n (total: 1467 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_21 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06762.17 (Lipase maturation factor): [120:274](score: 195.0, e-value: 2.6e-57)<br>\n \n  PF06762.17 (Lipase maturation factor): [300:476](score: 200.8, e-value: 4.7e-59)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_21 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF06762.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051604' target='_blank'>GO:0051604</a>: protein maturation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_21_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACTGGTTCGGGACCGGCGACTATGGGATCGCCCGCGAGGTGCTGCAGCGCGGGATCGCCGCGATCTTCCTGATCGCGTTCGCCTCGGCGCTGGCCCAGTTCCCGGCGCTGCTGGGCGAGAACGGGCTGCTGCCGGTGCGCCGGTTCACCCAGGTGGTGAGCATGCGCCGGGCGCCCAGCCTGTTCCAGTGGCGGTACTCGGACCGATTGTTGCGCCTGGTGGCGTGGGGATGCATCGTCGTGGCCGCATCGGTACTCCTCGGCCTGCCCCAGGCCGGCCCGGCCTGGCTGCCGATGCTCGTGTTCCTGGTCCTGTTCGCGGCCTACCTGTCGGTCGTCAACGTCGGGCAGACCTTCTACGCCTTCGGCTGGGAGAGCCTGCTGGTCGAGGCCGGCTTCATCGTCGCGTTCCTCGGCTCGGACGCCGTGGCCACCCCGGTGCCGATCCTGCTGTTCCTGCGTTGGCTGGTGTTCCGGCTCGAGTTCGGCGCCGGCCTGATCAAGATCCGGGGCGGCCGCGAGTGGCGCGACCTCACCGCGCTGTATTACCACCACGAGACCCAGCCCATGCCCAACCCGGTGAGCTGGTTCGTGCACCACCTGCCGCGGTGGTTCCACCGCGGCGAGGTGCTGGGCAACCATGCCGTGCAGCTGGGGCTGCCGTTCCTGCTCTTCGCACCGCAGCCCGTGGCGTCGATCGCCGCCGGAATCATCGTGCTCAGCCAGCTCTGGCTGGTCCTCACGGGCAACTTCGCCTGGCTGAACTGGATCACCATCGTGCTGGCCGTCTCCGCCATCGACGATGCGTCTTTCCGCTGGCTGGGCGGATGGGTCGTGCCGGCCCTCCGCGAACCCGCACCGCCGGCCGCAGCGGGGGAGCAGCCGCCGTGGTTCGTCGTGGTGGTGCTGGCGGTGACCGCCCTGCTGGTCGCGCTGAGTTATTGGCCGGCCCGCAACCTGCTCCGCCGCCGGCAACTCATGAACGCGAGCTTCAACCCGTTCCACCTGGTGAACGCCTATGGGGCCTTCGGCACGGTCACCAAGGAACGCTTCGAGGTGGTGGTCGAGGGCAGCGTCGCGGAGGATCCGCGCTCCGAGGAGGGCTGGCTGGCCTACGAGTTCCGCGGCAAGCCGGGGAACGTCAGGCGTCTCCCCGGCCAGTTCGCCCCGTACCACCTGCGGCTGGACTGGCTGATGTGGTTCCTGGCCCTGGGTGCCCGCGACACCCGCTGGTTCGAGGTCTTCCTGGCCCGGCTGCTACAGGGCGACCGGGCCACCCTGCGCCTGCTGGCCCGCAATCCGTTCCCGGATGGGCCGCCGCGCTTCGTGCGGGCGCGGGTGTTCCGCTACCGGTTCAGCACCCCGGCCGAACGCCGTGCCGAGCAGGTCTGGTGGGTGCGCACGGAGGCCGGCGTGCTGGTACCGCCGGTGACCCTGCCGCCGGTCCCACCCCCGGAGCCGTAG",
    "translation": "MDWFGTGDYGIAREVLQRGIAAIFLIAFASALAQFPALLGENGLLPVRRFTQVVSMRRAPSLFQWRYSDRLLRLVAWGCIVVAASVLLGLPQAGPAWLPMLVFLVLFAAYLSVVNVGQTFYAFGWESLLVEAGFIVAFLGSDAVATPVPILLFLRWLVFRLEFGAGLIKIRGGREWRDLTALYYHHETQPMPNPVSWFVHHLPRWFHRGEVLGNHAVQLGLPFLLFAPQPVASIAAGIIVLSQLWLVLTGNFAWLNWITIVLAVSAIDDASFRWLGGWVVPALREPAPPAAAGEQPPWFVVVVLAVTALLVALSYWPARNLLRRRQLMNASFNPFHLVNAYGAFGTVTKERFEVVVEGSVAEDPRSEEGWLAYEFRGKPGNVRRLPGQFAPYHLRLDWLMWFLALGARDTRWFEVFLARLLQGDRATLRLLARNPFPDGPPRFVRARVFRYRFSTPAERRAEQVWWVRTEAGVLVPPVTLPPVPPPEP",
    "product": ""
   },
   {
    "start": 20425,
    "end": 20793,
    "strand": -1,
    "locus_tag": "ctg14_22",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,425 - 20,793,\n (total: 369 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_22 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01479.28 (S4 domain): [6:52](score: 45.6, e-value: 4.6e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_22 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01479.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_22\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAACTGCAGAGCGCTCGCGTCGACAGCTGGGCCTGGGCGGTGCGGATGTACAAGACCCGCTCCCAGGCGACGGCGGCCTGCCGCGCCGGTCATGTGCGGGTCAACGGCGAGCGGGCCAAGTCGGCCCAGTCGGTGAAACCGGGCGACGAGGTGCGCATCCGCTCCAACGGATTCGACCGGGTGCTCGTGGTGTCCCGGATCATCGTCAAGCGCGTGGGGCCGAGCGTGGCCGCGGAGTGCTTCGTGGACAACACCCCACCACCGCCGCCCCGCGAGGAGGTGGCCCTGGTGCCGATGCGCGACCGCGGCGCCGGCCGGCCCACCAAGCGCGAGCGGCGGGACATCGAGGAACTGCGCGGGTACTAA",
    "translation": "MELQSARVDSWAWAVRMYKTRSQATAACRAGHVRVNGERAKSAQSVKPGDEVRIRSNGFDRVLVVSRIIVKRVGPSVAAECFVDNTPPPPPREEVALVPMRDRGAGRPTKRERRDIEELRGY",
    "product": ""
   },
   {
    "start": 20838,
    "end": 21743,
    "strand": -1,
    "locus_tag": "ctg14_23",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,838 - 21,743,\n (total: 906 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) ubiA<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_23 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01040.21 (UbiA prenyltransferase family): [32:283](score: 119.1, e-value: 2.1e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_23 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01040.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016765' target='_blank'>GO:0016765</a>: transferase activity, transferring alkyl or aryl (other than methyl) groups<br>\n  \n   PF01040.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_23\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_23_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGAATCGGCACACCGGCCGGCCACCGGCCTCGGGCACACCGTGCGTCAGGTCGTGCTGTCGTCGCGCCCGCTCAGCTGGATCAACACGGCGTTCCCCTTCGCGGCCGCGTACATCGTCAGCACCGGTCGCGTCGACCTGCTGCTCGTGGTGGGCACCCTGTTCTTCCTCATTCCGTACAACCTGCTGATGTACGGCATCAACGACGTCTTCGACTACGAGTCCGACCTGCGCAACCCCCGGAAGGGCGGTGTCGAGGGCGCCATGCTCGACCGGAGCCTGCACCGCACGGTGCTGGTGTCCGGCGTGGCGACGGCGCTGCCGGTGCTGCTCGCGATGCTCCTGCTCGCCGGCGCGAACCCGTGGTCGTGGGTGGTGCTCGCGCTCAGCCTGTTCGCGGTGGTGGCCTACTCCGCCCCTGGCCTCCGCTTCAAGGAACGCCCGGTGCTGGACTCGGTGACCTCCAGCATCCACTTCGTCAGCCCGGCCGTGTACGGGCTGGCCGTGGCCGGCGCCCTGATCACGCCCGACCTCGTGGCCCTGCTCACGGCGTTCTTCTTCTGGGGCATCGCCAGCCACGCGTTCGGCGCCGTGCAGGATGTCGAACCCGACCGTCAGGGCGGCATCAGTTCCATCGCCACGGCGTTCGGCGCCGCCCAGACGGTGCGCCTGGCGATCGTGTTCTGGGTGCTGGCGGGCCTGTTGATGCTCGTGACGGACTGGCCCGGACCGCTCGCGGCGGTGCTCGTGATCCCCTATGTGCTCGCCGCGTGGCCGTACCGGTCGATCAGCGACGCCGATTCCGAGCTCGCCAACAACGGCTGGAAGCGGTTCCTCAGGCTGAACTTCTTCACCGGCTTCCTGGTGACCATGCTGCTGATCGTCTGGGTCGTGGTGCGTTGA",
    "translation": "MTESAHRPATGLGHTVRQVVLSSRPLSWINTAFPFAAAYIVSTGRVDLLLVVGTLFFLIPYNLLMYGINDVFDYESDLRNPRKGGVEGAMLDRSLHRTVLVSGVATALPVLLAMLLLAGANPWSWVVLALSLFAVVAYSAPGLRFKERPVLDSVTSSIHFVSPAVYGLAVAGALITPDLVALLTAFFFWGIASHAFGAVQDVEPDRQGGISSIATAFGAAQTVRLAIVFWVLAGLLMLVTDWPGPLAAVLVIPYVLAAWPYRSISDADSELANNGWKRFLRLNFFTGFLVTMLLIVWVVVR",
    "product": ""
   },
   {
    "start": 21740,
    "end": 22093,
    "strand": -1,
    "locus_tag": "ctg14_24",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,740 - 22,093,\n (total: 354 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_24 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF18916.3 (Lycopene cyclase): [1:89](score: 31.7, e-value: 1.8e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_24 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF18916.3: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016872' target='_blank'>GO:0016872</a>: intramolecular lyase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_24\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_24_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACCTACACCCTGCTCAACGTCGTGTTCCTCGGCCTCGCCGTGGTCGTGGCCGTCGTGGCGTACCTCCGCCGGCCGGGATACCGCCGGATGCTGCCGGCGGCGGGACTCGCCCTGGTGGCCGTCCTGCTGCTGACCGCGGTGTTCGATAACATCATGATCGGAGTGGGACTGGTCGACTACGACCCGGCCCTGATCTCCGGGTTCTTCGTGGGGATCGCTCCCGTGGAGGACTTCGCCTACCCCGTGGCGGCGGCACTCCTGCTGCCCGCGGTGTGGACGCTGCTCGGCGGTGACGCCGGGCGGGGCCCGCTGGGCCGGAGTTCGTCACGATCGGAAGGGCACCAGCAATGA",
    "translation": "MTYTLLNVVFLGLAVVVAVVAYLRRPGYRRMLPAAGLALVAVLLLTAVFDNIMIGVGLVDYDPALISGFFVGIAPVEDFAYPVAAALLLPAVWTLLGGDAGRGPLGRSSSRSEGHQQ",
    "product": ""
   },
   {
    "start": 22090,
    "end": 22428,
    "strand": -1,
    "locus_tag": "ctg14_25",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,090 - 22,428,\n (total: 339 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_25\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_25_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACCGGCCCGATGCCGGGTGTGCTGTACCTGCTGGCCCTGCTCGTCTCCCTGACCGGCATGGTCGTGCTCGACCGACGTTTCGGCCTGTTCTTCTGGCGTGCGCCCGTCGTGGCGGCGGCGGTACTGGCGATCGGGGTGGCCTTCTTCCTCGCCTGGGACCTGGTGGGGATCGGCGCCGGTATCTTCTACCGGGGCGAGACCGACTTCATGACCGGCGTGCAGCTGGCCCCCGAGCTGCCCGTCGAGGAGTTCTTCTTCCTCACCTTCCTCTGCTACCTGTTCATGAACGCCCTGCAGGGCGTGCGGATGCTGCTGGCTGCGAGGCGCGCCTCGTGA",
    "translation": "MTGPMPGVLYLLALLVSLTGMVVLDRRFGLFFWRAPVVAAAVLAIGVAFFLAWDLVGIGAGIFYRGETDFMTGVQLAPELPVEEFFFLTFLCYLFMNALQGVRMLLAARRAS",
    "product": ""
   },
   {
    "start": 22425,
    "end": 24044,
    "strand": -1,
    "locus_tag": "ctg14_26",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_26</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_26</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,425 - 24,044,\n (total: 1620 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) DAO<br>\n \n  biosynthetic-additional (smcogs) SMCOG1222:dehydrogenase (Score: 462.3; E-value: 3.9e-140)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_26 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01593.27 (Flavin containing amine oxidoreductase): [16:509](score: 91.9, e-value: 5.9e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_26 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01593.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_26\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_26_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCCGCCCGACCGCACGCCTCCGCACCGTCGTGATCGGCGGCGGGATCGCCGGGCTGGCCAGCGCGGCCCTGCTCGCCAAGGAGGGCCACGAGGTCACGCTGCTCGAGGCTCACGACACCCTCGGCGGCCGGGCCGGCTTCTGGGAGGCCGACGGCTTCAGGTTCGAAACCGGGCCGTCCTGGTACCTGATGCCCGAGGTGTTCGAGCACTTCTACCGGCTCATGGGCACGAGCGCGGCCGAACAGCTCGAGCTCACCCGGCTCGACCCGGGCTACCGGGTCTACTTCGAAGCCGACCTCGAGCCCGTGGATGTGCGCGCAGACCGCGCCGACAACATCCGCCTGTTCGAGAGCCTGGAGCCCGGTGCCGGCGCCCGGCTCGAGGACTACCTCGCCTCGGCGCGGGAGACCTACGACATGGCCGTGGACAGGTTCCTGTACACCAGCTTCGCCTCGTTCAAGCCCTTGCTGGTGCGCGACGTGCTGAGCCGGATGGGCCGGCTCGGCCGCCTGCTGCTCCAGCCGCTGGACCGGTTCGTCGCCGGCTACTTCCGCGACCCCCGGATCCGGCAGATCCTGGGCTACCCCGCCGTCTTCCTCGGTTCCTCCCCCGACCGCACCCCGTCGATGTACCACCTGATGAGCCACCTCGACCTGGCGGACGGCGTGCTCTACCCGCAGGGCGGCTTCACCCGGCTGATCGACAGCATCGCCGACCTCGCCCGCGCCGAGGGCGTCACCGTCGAGACCGGCGCCCGGGTGCAGGCGATCCGCTCCGGCGCAGCGCCGACCGGACGGGGCGCCAAGGCCGCCGTCGAGGGCGTGACGTACACGAACGCGTCCGGCGTGACGGTGTCCCTGGACGCCGACATCGTCGTCTCGGCGGCCGACCTGCACCACACCGAGACCGAGCTCGTGGAGCCCGCCAAGCAGACCTACCCCGAGCGCTGGTGGCAGAAGCGCACCTCGGGCCCCGGCGCCGTGCTGGTTCTGCTGGGGGTGACGGGCGAGCTGCCCGCGCTGACCCACCACACCCTGTTCTTCACGCAGGACTGGGCCGACAACTTCGACCGGATCTTCGGCGCCGAGACCTCGGTGCCCAACCCGGCGTCGTTCTATGCCTGCATGCCCAGCGCCACCGACCCCGGCGTCGCCCCGGACGGATCGAGCAACCTGTTCCTGCTCATCCCCGTGCCCGCCGACACCGGCCTCGGTCACGGCGGGGTGAACGGAGCCGGCTCGGCCACCGTCGAGGGCATCGCCGACGCCGCGATCGGCCAACTCGCCGAGTGGGCCGGCATCCCCGACCTGGCCGAGCGCATCGTGGTGCGCCGCACGATCGGCCCGGCCGACTTCGCCGACGACCTCAACTCCTGGAAGGGCGGGGCGTTGGGCCCGGCGCACACGCTCAAGCAGAGCGCCTTCTTCCGTGGCACCAATGTCTCCAAGCACATCGAGGGTCTCTACTACGCCGGCGGCAGCACCATTCCGGGTATCGGCCTGCCGATGTGCCTGATCAGCGCCGAGATCCTGCTCAAGCGCCTGCGCGGCGACGTGAGCACCGGGCCCCTGCCGGAGCCGTTGCCGAGCGGGCCGGCCGGCGCCAGGCTGCGGTGA",
    "translation": "MSRPTARLRTVVIGGGIAGLASAALLAKEGHEVTLLEAHDTLGGRAGFWEADGFRFETGPSWYLMPEVFEHFYRLMGTSAAEQLELTRLDPGYRVYFEADLEPVDVRADRADNIRLFESLEPGAGARLEDYLASARETYDMAVDRFLYTSFASFKPLLVRDVLSRMGRLGRLLLQPLDRFVAGYFRDPRIRQILGYPAVFLGSSPDRTPSMYHLMSHLDLADGVLYPQGGFTRLIDSIADLARAEGVTVETGARVQAIRSGAAPTGRGAKAAVEGVTYTNASGVTVSLDADIVVSAADLHHTETELVEPAKQTYPERWWQKRTSGPGAVLVLLGVTGELPALTHHTLFFTQDWADNFDRIFGAETSVPNPASFYACMPSATDPGVAPDGSSNLFLLIPVPADTGLGHGGVNGAGSATVEGIADAAIGQLAEWAGIPDLAERIVVRRTIGPADFADDLNSWKGGALGPAHTLKQSAFFRGTNVSKHIEGLYYAGGSTIPGIGLPMCLISAEILLKRLRGDVSTGPLPEPLPSGPAGARLR",
    "product": ""
   },
   {
    "start": 24041,
    "end": 24949,
    "strand": -1,
    "locus_tag": "ctg14_27",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_27</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_27</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,041 - 24,949,\n (total: 909 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_27 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [33:281](score: 113.5, e-value: 1.3e-32)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_27 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_27\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_27_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCCGCGACACCACGGGGCCGCGCACCAACGCCCTGCCCACCACTCTGGGCACCTACAACGCCGCCGCCCTGGCCAGTTCCGCCACGGTGATCGGACACTACTCGACGTCGTTCGGGCTCGCCGCCCGCCTCCTCGCGCCCGGCGTGCGGGAGGACGTGCGCACCATCTACGCTCTCGTGCGGATCGCCGACGAGATCGTCGACGGCGCCGCCGCCGAGGCCGGCATCGACCTGGCCGGCCAGCGCGAACTGCTCGACGACCTCGAGCAGGAGACCGAGCGCGCCCTGGCCCGGGGCTTCAGCACCAACCTGGTGGTGCACGCCTTCGCCCTCACCGCCCGCCGGGTGGGGATCGAGCCGGCCCTCACGCGCCCGTTCTTCGCATCGATGCGCCGCGACCTCGACCCGGCACCGTTCACGGCCGCGAGCGTCGCCGAGTACATCTACGGCTCGGCGGAGGTCGTCGGGCTGATGTGCCTGCAGAGCTTCCTGCAGGACTTCCCGCGCAGCCCCGCTGAGCGGGCCGAGCTGGTCCACGGCGCCCGCAGCCTCGGCGCGGCGTTCCAGAAGGTCAACTTCCTCCGCGACCTGGCCGCCGACCGCGACGCGCTCGGCCGCAACTACTTCCCCGGGATCGACCTGGCCCGGCTCACCGACCCGCAGAAGGACCTCCTGCTCGACGACATGGACGCCGATCTCGAGGCCGCCGAGCGGGTCCTGCCGCTGCTGCCGACGGGGAGCCGGCGCGCCGTCACGGCCGCCCACCACCTGTTCGCCCGGCTGTCTGCGAGACTGCGGGAGACCCCCGCGCACGAATTGATGAGCACCCGCGTGCGGGTGCCGGATCCGGAGAAACTGATGATCGCCCTGTCGTCCTCGCTCGGCCCGCAGGCATGGCGCCGATGA",
    "translation": "MSRDTTGPRTNALPTTLGTYNAAALASSATVIGHYSTSFGLAARLLAPGVREDVRTIYALVRIADEIVDGAAAEAGIDLAGQRELLDDLEQETERALARGFSTNLVVHAFALTARRVGIEPALTRPFFASMRRDLDPAPFTAASVAEYIYGSAEVVGLMCLQSFLQDFPRSPAERAELVHGARSLGAAFQKVNFLRDLAADRDALGRNYFPGIDLARLTDPQKDLLLDDMDADLEAAERVLPLLPTGSRRAVTAAHHLFARLSARLRETPAHELMSTRVRVPDPEKLMIALSSSLGPQAWRR",
    "product": ""
   },
   {
    "start": 24946,
    "end": 25992,
    "strand": -1,
    "locus_tag": "ctg14_28",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_28</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_28</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,946 - 25,992,\n (total: 1047 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1182:Polyprenyl synthetase (Score: 224.9; E-value: 2e-68)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_28 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00348.20 (Polyprenyl synthetase): [39:271](score: 165.8, e-value: 1.1e-48)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_28 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00348.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_28\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_28_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCATGAGATCGCGACGCTGGGCGTCGAGACCGAACTGCACCGCTTCTTCGCCGCCGCGAGGCTGCGTGCCAGCGACTACGGCGAGCACTACGTCGCGCTCTGGGACTCCCTCGACCAGGCCAGCCGCGGCGGCAAACGCGTGCGCCCGGCGCTGGTGCTGGCCGCCTACGACGGCTTCGGCGGCACCGACCACACCCTGTCCACGCCGGTCGCGGTGAGCTTCGAGCTGCTGCACACGGCGTTCCTCATCCACGACGACGTCATCGACCGCGACCTCTCCCGCCGGGGAATGGCCAACATCGCCGGCCGGTTCACCGAACGCGCCATCGCGCACGGAGCGGGCACCGGCCAGGCGGAAGCCTGGGCCGCGACCGCCGCCATCCTGGCCGGCGACCTGGCCCTGAGCGAGGCCCACCGCGCCCTGGCCCTGCTGCCCGTGGAGACCACCATGCGGGCGCGCCTGCTCGACCTGCTCGACCGCGCGGTGTTCGTGTCGGCTGCGGGCGAGCTGGCGGATGTGACCAACACGGTCAGCCGGGTGCCGCTCACGATCGAGCAGGTCATCGCGACCCTCGAGCACAAGACGGCCATCTACTCGTTCGAGGCCCCCCTGCAGGCCGGCGCCGTCCTGGCCGGGGCGCCGGAGGAGGCCATCGACGCCCTGGGCCGGTTCGGCCGCCTCATCGGCGTGGCCTTCCAACTCACCGACGACCTGCTCGGCGTGTTCGGCGACCCGGCCACCACGGGCAAGAGCACGCTCGCCGACCTGCGCGAGGGCAAGCAGACCGCCCTCATCGCGCACGCCGGCGCCACCGACCGGTGGCCGATGATCGCGCCGTTCCTGGGCAAGGACGATCTGACCGAACCGGAGGCCGAGTCCGTGCGCACGCACCTGCGCGAGTGCGGAGCCCTTGACACCGCGGATGCGCTCGCCCGCGAATACGCCGGCCGCGCCGTCGAGGCCCTCGCCGTGCCGCTCATGCCCGAGGACCTGCGCACCACCCTGACCCAGCTGGCGCGCAGCGCCGTGACCCGCCGCAAATGA",
    "translation": "MHEIATLGVETELHRFFAAARLRASDYGEHYVALWDSLDQASRGGKRVRPALVLAAYDGFGGTDHTLSTPVAVSFELLHTAFLIHDDVIDRDLSRRGMANIAGRFTERAIAHGAGTGQAEAWAATAAILAGDLALSEAHRALALLPVETTMRARLLDLLDRAVFVSAAGELADVTNTVSRVPLTIEQVIATLEHKTAIYSFEAPLQAGAVLAGAPEEAIDALGRFGRLIGVAFQLTDDLLGVFGDPATTGKSTLADLREGKQTALIAHAGATDRWPMIAPFLGKDDLTEPEAESVRTHLRECGALDTADALAREYAGRAVEALAVPLMPEDLRTTLTQLARSAVTRRK",
    "product": ""
   },
   {
    "start": 25985,
    "end": 26515,
    "strand": -1,
    "locus_tag": "ctg14_29",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_29</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_29</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,985 - 26,515,\n (total: 531 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_29 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00293.31 (NUDIX domain): [32:149](score: 65.8, e-value: 4.2e-18)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_29\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_29_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACCGGGTGGAAGATTGGGTCGTGCTGCTCGATGAGGACGGACTCGAGATCGGCACCGCCCCCAAGAGCAGCGTGCACGGAGCCGACACCTCGCTGCACCTGGCCTTCTCCTGCTACGTCTTCAACGATCGCGGCGAGGTCCTGCTGACCCGCAGGGCCCTGGGGAAGAAGACCTGGCCCGGCGTCTGGACGAACTCGTTCTGCGGCCACCCTGCCCCCGCCGAGCCCCTCCTGGATGCCGTGCACCGCCGCGCCGAGTTCGAGCTGGGCCTCCGCATCGACGACATCGAGCTTGCCCTCCCCCTGTTCCGGTACCGCGCCACCGACAGCAGCGGCATCGTCGAGAACGAGGTCTGCCCGGTCTACCTGGCCCGCGCAGTGGGCGACCCTGAAGCCAATCCCGACGAGGTGATGGAGTACACCTGGACCGACCCTGAGGTGATGCGGCGTTCCGTCCTGGCCAGCCCCTTTGCCTTCAGCCCGTGGATGGTCCTGCAGATGCGCGAACTGGAGACCTTCGGTGCATGA",
    "translation": "MDRVEDWVVLLDEDGLEIGTAPKSSVHGADTSLHLAFSCYVFNDRGEVLLTRRALGKKTWPGVWTNSFCGHPAPAEPLLDAVHRRAEFELGLRIDDIELALPLFRYRATDSSGIVENEVCPVYLARAVGDPEANPDEVMEYTWTDPEVMRRSVLASPFAFSPWMVLQMRELETFGA",
    "product": ""
   },
   {
    "start": 26529,
    "end": 27269,
    "strand": 1,
    "locus_tag": "ctg14_30",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_30</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_30</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,529 - 27,269,\n (total: 741 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_30 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01047.25 (MarR family): [108:149](score: 32.4, e-value: 6.9e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_30 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01047.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity<br>\n  \n   PF01047.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_30\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGTGCATCACTGGGCTCCCTCTCGTGCAGCCAAGATACCTGAAAAAGTACCTAACCGAGTTAGCGATATTCGAGGCTAGCATGGTGGCTATGCCCGCAGACGCCCAACCTGCCGGGGACGTGGAGGCCGGCCGCTCAGGCGGCTTCTGGTACCCGGTTTCCGGCGGTGCTCCTTTGAGCGCCGTTGACGTCCTGCGCGCCGTGCGCCGCTTCCGTGCTGCCGATCTGGCCATGCGCAATCGGGTCCGCTCGGGCATGGACATGCACCACACCGACCTCGTCGCGGTCCGGCACCTGATCGCGGCGGAGGAGCGGGGCGAGTCGGTCGGGCCCACCGACCTGAGCAGGTACCTCGGCATCTCCTCCGCTGCGACGGCCAAACTGCTCACCCGGTTGGAGTCGGCCGGCCGGCTCCGCCGCGAACCGCATCCGAGTGACCGGCGGGCGCAGGTGCTGCACGCCACCGGCGCCGCCCACGACGAGGTGCGCCTGGCCCTCGGGGCGGCGCACCAGCGGATGCTCGCCGCCGCCGAGAAGCTGAGCGCGTCGGAGCAGCTCGCGGTGGTGAGGTTCCTCGACGAGCTCAGCGGAGCCATGGACGAACCGGTCGAGCCGGCCGAGCCGACCGAGCAGCCCGGGTCGCGCGAGCCGACGGCCGACGGCGGGTCGGGTGGGCAGGCACAGCCCGGCCCCGTCGCACCCGGGACCTCCGGCCCGGCCGCGCAGCAGGGGCGACCCTGA",
    "translation": "MCITGLPLVQPRYLKKYLTELAIFEASMVAMPADAQPAGDVEAGRSGGFWYPVSGGAPLSAVDVLRAVRRFRAADLAMRNRVRSGMDMHHTDLVAVRHLIAAEERGESVGPTDLSRYLGISSAATAKLLTRLESAGRLRREPHPSDRRAQVLHATGAAHDEVRLALGAAHQRMLAAAEKLSASEQLAVVRFLDELSGAMDEPVEPAEPTEQPGSREPTADGGSGGQAQPGPVAPGTSGPAAQQGRP",
    "product": ""
   },
   {
    "start": 27292,
    "end": 27819,
    "strand": 1,
    "locus_tag": "ctg14_31",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_31</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_31</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 27,292 - 27,819,\n (total: 528 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_31 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00156.30 (Phosphoribosyl transferase domain): [39:153](score: 54.0, e-value: 1.3e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_31\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_31_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGATCGTTCCCGCAGCCCAGCACGTGCACACCCTTCTCGCCTCCTACCCCGACTTCCCGCTTCCCGGCATCCTGTTCCGAGACCTCAATCCGGTCTTCGCGGATGCGGTGGCGTTCCGGTCTATCATCGACGAACTGGCCGAGCGCTACCGGGGCTCCTTCGACGCCGTGGCCGGCATCGAAGCGCGCGGCTTCCTGCTCGCGGCCGGCATCGGGTATGCCGCCCAGTGCGCCGTGCTGGCGGTGCGGAAGGGCGGCAAGCTGCCGGGTACCGTGCTGACCGAGGAATACGACCTCGAGTACGGCTCGGCCCGGCTCGAGCTGGAGGTCGGGCAGTTGCCGGCCGGCTCCCGTGTGCTGATCGTGGACGACGTGCTCGCCACCGGCGGTACCGTCGCCGCCACCGCACGCCTGATCGAGCGGGCCGGGTACCTCACGGTCGGGGTGGGCGTGGTGCTCGAGCTGGCCGAACTCGACGGCCGCGGCCGCATCGGCAACGTGCCGGTGCACACCATCGTGTCGGTCTAG",
    "translation": "MIVPAAQHVHTLLASYPDFPLPGILFRDLNPVFADAVAFRSIIDELAERYRGSFDAVAGIEARGFLLAAGIGYAAQCAVLAVRKGGKLPGTVLTEEYDLEYGSARLELEVGQLPAGSRVLIVDDVLATGGTVAATARLIERAGYLTVGVGVVLELAELDGRGRIGNVPVHTIVSV",
    "product": ""
   },
   {
    "start": 27949,
    "end": 28662,
    "strand": -1,
    "locus_tag": "ctg14_32",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_32</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_32</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 27,949 - 28,662,\n (total: 714 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_32 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01791.12 (DeoC/LacD family aldolase): [17:216](score: 65.0, e-value: 8.3e-18)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_32 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01791.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016829' target='_blank'>GO:0016829</a>: lyase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_32\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_32_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCTCTTCCTCCTCCGCCAGCACCCTCGACGCGGCTGGTCTGGCCCGGTACATCGACCACACCCTGCTCAAGCCCGAAGCCACCCAGGCCGACGTCGCCGCCCTCATCGCCGAGGCCGTCGAGCTGGGCGTCTACTCGGTGTGCGTGTCACCGTCGATGCTGCCCCTGACCCTGCCCGCGGATGCCGACCTCAAGGTTGCCGTGGTCTGCGGGTTCCCGAGCGGGAAGCACGCGTCGGCGATCAAGGCCGCCGAGGCCGCACTGGCCGTGGCCCAGGGCACCGACGAGGTGGACATGGTGATCGACATCGGTGCCGCCAAGGCCGGCCGGTTCGACCTGGTCGAGGCCGACATCAGCGCCGTGCGCGCCGAGATCCCGGCCCCCCTGGTGCTCAAGGTCATCATCGAGTCGGCCGCCCTCACCGACGACGAGATCGTCGGCGCCTGCCGTGCGGCCGTTGCCGCCGGTGCCGACTTCGTCAAGACCTCCACCGGTTTCCACCCCACCGGCGGCGCCACCGTGCACGCCGTGCGCCTGATGCGCCAGACCGTGGGCGACGCTGTCGGCGTCAAGGCCTCCGGCGGGGTGCGCAGCCACGCGGACGCGCTGGCCATGATCGAGGCCGGCGCCACCCGCCTCGGCGTCTCCGGCAGCACGGCCGTGCTCTCCGGCGCCGTGGTCGAAGCCCCGGCCAACCCCGCCGCGTACTGA",
    "translation": "MTSSSSASTLDAAGLARYIDHTLLKPEATQADVAALIAEAVELGVYSVCVSPSMLPLTLPADADLKVAVVCGFPSGKHASAIKAAEAALAVAQGTDEVDMVIDIGAAKAGRFDLVEADISAVRAEIPAPLVLKVIIESAALTDDEIVGACRAAVAAGADFVKTSTGFHPTGGATVHAVRLMRQTVGDAVGVKASGGVRSHADALAMIEAGATRLGVSGSTAVLSGAVVEAPANPAAY",
    "product": ""
   },
   {
    "start": 28762,
    "end": 29226,
    "strand": 1,
    "locus_tag": "ctg14_33",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_33</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_33</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,762 - 29,226,\n (total: 465 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_33 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00293.31 (NUDIX domain): [27:138](score: 53.5, e-value: 2.5e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_33\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGGCAGCGTGAGTGTGAACAGCGGGGACGCCTGGGTGTACGGCCCGGACGGTTCCCGGTTCTGGGGACGCTACGGTGCGGCCGGCTTGCTCGTGCACCACGCAGAGCGCGGGGTGCTGCTCCAGCACCGGGCCGCCTGGAGCCACCACGGTGACACCTGGGGCGTGCCGGGCGGTGCGAGGCACGAGAACGAGAGCGCGCTGGATGCCGCGATCCGCGAGGCCGGCGAAGAGGCCGGGGTGCCCGCACGGCTGCTCCGGTTCAGCTTCAGCTCGGTGGTCGACCTGGGGTTCTGGTCGTACACGACCGTCGTGGTGGAGGCCGTGGAGGCCTTCGAGGCGGTGATCAGCGACTCCGAGAGCATTGCGTTGCGCTGGGTGGCGCCGGCCGAGGTCGACCTGTTGCCGCTCCATCCGGGCTTCGCCGCCAGCTGGCCCGCGCTCAGGGCCCGTCTGCCCTGA",
    "translation": "MSGSVSVNSGDAWVYGPDGSRFWGRYGAAGLLVHHAERGVLLQHRAAWSHHGDTWGVPGGARHENESALDAAIREAGEEAGVPARLLRFSFSSVVDLGFWSYTTVVVEAVEAFEAVISDSESIALRWVAPAEVDLLPLHPGFAASWPALRARLP",
    "product": ""
   },
   {
    "start": 29207,
    "end": 30073,
    "strand": -1,
    "locus_tag": "ctg14_34",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_34</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_34</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,207 - 30,073,\n (total: 867 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_34 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06966.15 (Protein of unknown function (DUF1295)): [23:259](score: 160.3, e-value: 5.8e-47)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_34\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_34_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGGGCCCGCCGCATCCGCCCTGCTGATCTGCCTGGTGATCGTGGGCCTCGCCTCGGCCACCTCGTGGCTGCTCTCGCTGGCGACCAGGGACTACTCCTGGGTGGACCGGGCCTGGTCGATCCTGCCGGCCGTCTACCTCTGGGTCTTCGCCGTCGCGGCGGACCCGCCGGATGCGCGCCTGCTCGTGCTGGCGGTGCTGGGCACCCTGTGGGGCATCCGGTTGACGCTGAACTTCGCGCGCAAGGGCGGCTACCGGCCCGGCGGCGAGGACTACCGCTGGGCCGAACTGCGCCGGCGGATGTCGCCGGGGCGCTTCGCCGTGGTCAACCTGGTGTTCATCTCGGTCGCCCAGAACGTGCTCCTGCTGCTGCTCGCCCTGCCGGCCTGGATCGTGCTGCAGCACCCCGGCCGGTTCGGGCTGCCCGAACTGGCTTTAACGGCACTGTTCCTGGCCCTGCTGGCAGGCGAGGGCATCGCGGACCAGCAACAGTGGCGGTTCCAGCAGGAGCGGCGCACGATCCGCGCCCGGGCAGGGGCGGATCCGGGCTTCCTCAGGAGCGGGCTGTTCCGCTTCTCCCGGCACCCGAACTACTTCTTCGAGATCGCCCAGTGGTGGACCGTCGCGCTGGTCGGCGCCGTCGCGGCCGGCACCCCCTGGCAGTCGGGGTCGCTCGGCGCCGTGCTGCTCACCCTGCTCTTCGTCGGCTCGATCGCCCTCACCGAGAGCATCTCGATGGGGCGGCATCCCGGCTATGCCGCGTACCGGCGCGAGGTATGGCCGCTGGTGCCGTGGTTCCCCAAACGATCGCCGGGCCTGGCGGCCCGGGGCGCCGAGGACCCGTTCAGGGCAGACGGGCCCTGA",
    "translation": "MSGPAASALLICLVIVGLASATSWLLSLATRDYSWVDRAWSILPAVYLWVFAVAADPPDARLLVLAVLGTLWGIRLTLNFARKGGYRPGGEDYRWAELRRRMSPGRFAVVNLVFISVAQNVLLLLLALPAWIVLQHPGRFGLPELALTALFLALLAGEGIADQQQWRFQQERRTIRARAGADPGFLRSGLFRFSRHPNYFFEIAQWWTVALVGAVAAGTPWQSGSLGAVLLTLLFVGSIALTESISMGRHPGYAAYRREVWPLVPWFPKRSPGLAARGAEDPFRADGP",
    "product": ""
   },
   {
    "start": 30070,
    "end": 32661,
    "strand": -1,
    "locus_tag": "ctg14_35",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_35</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_35</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,070 - 32,661,\n (total: 2592 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_35 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13298.9 (DNA polymerase Ligase (LigD)): [347:438](score: 113.4, e-value: 5.9e-33)<br>\n \n  PF01068.24 (ATP dependent DNA ligase domain): [503:700](score: 123.1, e-value: 1.2e-35)<br>\n \n  PF04679.18 (ATP dependent DNA ligase C terminal region): [719:825](score: 75.0, e-value: 6e-21)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_35 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01068.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003910' target='_blank'>GO:0003910</a>: DNA ligase (ATP) activity<br>\n  \n   PF01068.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF01068.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006281' target='_blank'>GO:0006281</a>: DNA repair<br>\n  \n   PF01068.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006310' target='_blank'>GO:0006310</a>: DNA recombination<br>\n  \n   PF04679.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003910' target='_blank'>GO:0003910</a>: DNA ligase (ATP) activity<br>\n  \n   PF04679.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006281' target='_blank'>GO:0006281</a>: DNA repair<br>\n  \n   PF04679.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006310' target='_blank'>GO:0006310</a>: DNA recombination<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_35\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_35_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGACGGTCGCCGAGTCACCCTGACCAATCTGGAGAAGGTGATGTACCCGGCCACCGGCACCACCAAGGCCGACGTCCTCAGCTACTACGCGGCAGTGGCGGATGCCCTCATCCGGCACGCCAGGGACCGCCCGGCCACCCGCAAGCGCTGGGTGCACGGAGTGGGTACCGCCGCCGAGCCCGGCCAGGTGTTCTTCCAGAAGAACCTGGGCGACGGCACTCCGGAATGGGTGGAACGCCGGGAACTGGAGCACAAGGAGCGTCGCACCGTGTATCCGCTCGTCAACGACCTGGCCACGCTCACCTGGCTCGCCCAGATCGGCACCCTCGAGATCCACGTTCCGCAGTGGCGATTCGACTCCGGCGGCGCGCCGAGCACTCCCGACCGGCTGGTGCTCGACCTGGACCCCGGCGAGGGGGTGGGCCTGGCCGAGTGCGCCGAGGTGGCGCGCTGGGCCCGGGCGCTGCTTCTCGACATGGGCCTGGACGCCCGGCCGGTGACGAGCGGCAGCAAGGGCATCCACCTGTACACGGCGCTGGACGGCAGCCACAGCTCCGAGCAGGTGAGCCAGGTGGCCCGGGAGCTGGCCCGGGCGCTCGAGGCCGACCACCCCGGCGAGGTGCTCAGCGCCATGACCCGGTCGCTGCGGCCGGGGAAGGTCTTCGTGGACTGGAGCCAGAACAGCGCCGCGAAGACCACGATCGCGCCGTACAGTCTGCGCGGACTGCTACGGCCGTTCGTGGCGGCCCCGCGCACGTGGCGCGAACTGGAGGCGCCCGGCCTGGAGCAGCTGGACTACCGCCAGGTGCTCAAACGGCTCTCCCGGGGGCCCGACCCTCTGGCGGCCGTGGCCGACGCCGCCGAGGCACACGCCGGCGGCCCGGCCGTGAACGCGGCCGTGAGCGCGGCCGGCGGGGCACCGGATGCGGCCCAGTCTGACCGTCTGCACACCTACCGGAGCAAGCGGGACGCCAAGCGCACGCCCGAGCCCATGCCGGAGCGCACCCCGGCCGGCACCGGCGGGGCCGCGTTCGTGATCCAGGAACACCACGCCAGGGCCCTGCACTTCGACCTGCGCCTCGAGCACGACGGTGTCCTGGCCTCCTGGGCGCTGCCGAAGGGCGTGCCCACCGACCCCACCCACAACCACCTGGCCGTGCAGACCGAGGACCACCCGTTGGAGTACCTCGAGTTCGAGGGAGACATCCCGGCCGGGGAATACGGCGCCGGTTCGATGTCGATCTGGGACCGTGGCGACTACAGCGTGGAGAAGTGGCGGGACGACGAGATCATCGTGGCCCTGCACGGCCGGGCGGGCGGCCCGCTCCAGACGGGTCCGGGCGAGCCGCGGCGCACCTTCGCCCTCATCCGCACCGGGGGCGCCGGCTCCCGCAACTGGCTGATCCATCTCATGAAGCCCAAGCCGGCCCCGGCCGGCCAGACCAGCGCCCGGGCCCAGGACGCCCCGGTCACCAGCGCACCGCTGCGGCCCGCACCCGGCTACTCCCCCATGCTCGCCCGGCCCGGCTCCCTCCTGAGCCTGTCCGCGGAGACGGAGTGGGCCTACGAGATGAAATGGGACGGCATCCGCATGATCGCCACCGTGGACGGCGGCCCGGGCGGAGCCGTGCGCTTTCTCACCCGCAACGGCAACGACGTCACGGCCGCGTTCCCCGAACTCGTCGACGACCTGCGCGCGGCCCTGGCCGGCCGCTCCGCGGTGCTGGACGGCGAGGTCGTCGCGCTGGACCGGCGCAACCGGCCGGACTTCTCCCTGCTGCAGACCCGGCTCGGACTCACCGGGGAGACCGAGGTGCGCCGGGCGCGACAGGGGGCGCCCGTGCACTATTTCGCCTTCGACCTCCTCGAACACGACGGTGTGCCCCTGGTCGAACTCCCGTACGCCGAGCGCCGGCAGGTGCTGGAGGAGGTGGTGCGCGGCACCGGCACCGTGCAGGTTCCGCCGGCCTTCGACGACCAGGATGCGGCGACCGTGCTGGCCACCAGCGCCCGGTTGGGCCTGGAGGGGATCATCGCCAAGGACACCCGCAGCGGCTATCTCACCGGCCGGCGCGCCGACCGCTGGGTGAAGATCAAGCATGTGACGAGCCAGGAGGTCGTCATCGGCGGCTGGCGGCCGGGCGCCGGGCATCGCTCCGCGACCCTCGGGTCGCTCCTGGTCGGGATCCCCGCGCCCGCCGACCCCGACGGCGGGGAGGCGACCGGCACGCCGCGCCCGCTGCTCTACGCGGGCCGGGTCGGTACGGGCTTCCGCGACCGGGACCTCACCGCGCTCCGGCGCCGCCTCGACGCACTGCCGGCCGCCGAGACCCCGTTCCAGGATGTGCCGCCGGCCGATGCGGCCGACGCCGTGTGGGTGCAGCCGGTCCTGGTGGGCGAGGTGGACTTCTCCGCCTGGACCCCGGCCGGCCGGCTGCGTCACCCCAGCTGGCGGGGACTGCGCGCCGACAAGGACCCCGCCGACGTCGTCCGGGAGGACGTGGTGCAGGAGGACGTCGTGCAGGAGGACATCGTGCGGGAGGACGGATCACCGGACGACCGATCACGAGGGGATGGTGGTCCCCGATGA",
    "translation": "MDGRRVTLTNLEKVMYPATGTTKADVLSYYAAVADALIRHARDRPATRKRWVHGVGTAAEPGQVFFQKNLGDGTPEWVERRELEHKERRTVYPLVNDLATLTWLAQIGTLEIHVPQWRFDSGGAPSTPDRLVLDLDPGEGVGLAECAEVARWARALLLDMGLDARPVTSGSKGIHLYTALDGSHSSEQVSQVARELARALEADHPGEVLSAMTRSLRPGKVFVDWSQNSAAKTTIAPYSLRGLLRPFVAAPRTWRELEAPGLEQLDYRQVLKRLSRGPDPLAAVADAAEAHAGGPAVNAAVSAAGGAPDAAQSDRLHTYRSKRDAKRTPEPMPERTPAGTGGAAFVIQEHHARALHFDLRLEHDGVLASWALPKGVPTDPTHNHLAVQTEDHPLEYLEFEGDIPAGEYGAGSMSIWDRGDYSVEKWRDDEIIVALHGRAGGPLQTGPGEPRRTFALIRTGGAGSRNWLIHLMKPKPAPAGQTSARAQDAPVTSAPLRPAPGYSPMLARPGSLLSLSAETEWAYEMKWDGIRMIATVDGGPGGAVRFLTRNGNDVTAAFPELVDDLRAALAGRSAVLDGEVVALDRRNRPDFSLLQTRLGLTGETEVRRARQGAPVHYFAFDLLEHDGVPLVELPYAERRQVLEEVVRGTGTVQVPPAFDDQDAATVLATSARLGLEGIIAKDTRSGYLTGRRADRWVKIKHVTSQEVVIGGWRPGAGHRSATLGSLLVGIPAPADPDGGEATGTPRPLLYAGRVGTGFRDRDLTALRRRLDALPAAETPFQDVPPADAADAVWVQPVLVGEVDFSAWTPAGRLRHPSWRGLRADKDPADVVREDVVQEDVVQEDIVREDGSPDDRSRGDGGPR",
    "product": ""
   },
   {
    "start": 32835,
    "end": 33824,
    "strand": 1,
    "locus_tag": "ctg14_36",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_36</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_36</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,835 - 33,824,\n (total: 990 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_36 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02735.19 (Ku70/Ku80 beta-barrel domain): [10:188](score: 119.0, e-value: 2.3e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_36 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02735.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF02735.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006303' target='_blank'>GO:0006303</a>: double-strand break repair via nonhomologous end joining<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_36\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_36_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGATCGATCTGGAAGGGTGCCATCACCTTCGGCCTGGTCAACGTGCCGGTCAAGGTGTACAGCGCCACCGAGGACCACGACGTCGAGCTGCACCAGGTGCACGACGCGGATGGCGGCCGCATCCGCTATCAGCGCCGCTGTGAGGTGTGCGGCAACATCGTGGACTACGCGCACATCGACAAGGCCTTCACCGACGCGGACAAGACCGTCATCATCACGGATGCCGACCTCAAGGCGCTGCCGGAGGAACGCAGCCGGGAGATCGACGTGCTCGAATTCGTGCCGAACGACCAGCTCAATCCGATCATGTTCGACAAGAGCTATTTCCTCGAACCCGACGGGAGCTCGCCCAAGGCCTACGTGCTCTTGCGCCGCACACTGGAGCAGTCCGATCGCACCGCCATCGTGCACTTCTCCCTCCGGCAGAAGACCCGCCTGGCCGCGTTGCGGGTGCAGGGGGACGTCCTGATGCTGCAGACCCTGCTCTGGAACGACGAGGTGCGCACGGCCGACTTCCCGGCGCTGGAGCAGACGGTGACGATCTCCGACCGGGAGCTGGACCTGTCGGCGGCGCTGGTCGAGTCGTTCGCGGCCGACTTCAGCCCGGGTGACTACACCGACGAGTACCAGGTCCAGCTGCGCCGGCTCATCGAGGAGAAGCTCGAGAAGGGCGACGCCATCGACACCGAGGCCACCTTCGGCGCCGCCGAGGAGGAGGGCGGCGGGGGAGAGGTGCTCGACCTGATGGAGGCGCTGCGTCGGAGTGTCGACCGCAGCCGCAAGGGACCCGCCGCGGCGGACGCGGCCTCGACGTCGTCCGGGGCGGAGCCCGCGGCCACGAAGGCCACGAAGCCGGCGGCCCGGAAGGCGGCGGCCAAGAAGCCCGCGGCCCGGAAGTCGGCCGAGAAGCCGGCCGAGAAGAAGACCGCCGCGACGGCGAAGAAGAAGAGCACGACCACGAGCGCCGCACAGCGGCACACGGCCTGA",
    "translation": "MRSIWKGAITFGLVNVPVKVYSATEDHDVELHQVHDADGGRIRYQRRCEVCGNIVDYAHIDKAFTDADKTVIITDADLKALPEERSREIDVLEFVPNDQLNPIMFDKSYFLEPDGSSPKAYVLLRRTLEQSDRTAIVHFSLRQKTRLAALRVQGDVLMLQTLLWNDEVRTADFPALEQTVTISDRELDLSAALVESFAADFSPGDYTDEYQVQLRRLIEEKLEKGDAIDTEATFGAAEEEGGGGEVLDLMEALRRSVDRSRKGPAAADAASTSSGAEPAATKATKPAARKAAAKKPAARKSAEKPAEKKTAATAKKKSTTTSAAQRHTA",
    "product": ""
   },
   {
    "start": 33878,
    "end": 34435,
    "strand": 1,
    "locus_tag": "ctg14_37",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_37</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_37</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,878 - 34,435,\n (total: 558 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_37 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01066.24 (CDP-alcohol phosphatidyltransferase): [7:162](score: 121.9, e-value: 3.5e-35)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_37 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01066.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016780' target='_blank'>GO:0016780</a>: phosphotransferase activity, for other substituted phosphate groups<br>\n  \n   PF01066.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008654' target='_blank'>GO:0008654</a>: phospholipid biosynthetic process<br>\n  \n   PF01066.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_37\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGTGAGCTCCCGGGTGATCACCGTGCCCAATCTGCTCAGTTTCCTGCGCCTGGGGCTCGTTCCGGTCTTCCTCGGCCTCATCGTCAGCGGCGCGGACGCCTGGGCACTGCTGGTGCTGGCGGTGTCCAGCCTCACCGACTTCCTCGACGGCTGGATCGCCCGCCGGTTCAACCAGGTCACCCGGCTGGGCCAGCTTCTGGACCCCGCCGCCGACAGGCTCTACATCTTCGCGGCGCTGATCGGCCTGGCCTGGCGTGACCTCGTGCCCTGGTGGATCGTGGTTGTCGTTGTGGGCCGGGACGTCTTCCTGCTGGGCCTGGGTGTGGTGCTGGCCAACCACGGTTTCGGCCCGCTGCCGGTGCACCAGCTGGGCAAGATCGCCACCTTCTGCCTGTTCTACGCCCTGCCGATGATCATGCTCGGGCAGGCGTTCCCCGAGCTGGCCTGGTGGTCGCAGCCCGTCGGCTGGGCCTTCGGGCTCTGGGGTGCGTACCTGTACTGGTGGGCCGGAGTCATCTACGCGATTGAAACGGTTCGGGTGATTCGGCTGCCATAG",
    "translation": "MVSSRVITVPNLLSFLRLGLVPVFLGLIVSGADAWALLVLAVSSLTDFLDGWIARRFNQVTRLGQLLDPAADRLYIFAALIGLAWRDLVPWWIVVVVVGRDVFLLGLGVVLANHGFGPLPVHQLGKIATFCLFYALPMIMLGQAFPELAWWSQPVGWAFGLWGAYLYWWAGVIYAIETVRVIRLP",
    "product": ""
   },
   {
    "start": 34486,
    "end": 34995,
    "strand": 1,
    "locus_tag": "ctg14_38",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_38</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_38</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,486 - 34,995,\n (total: 510 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_38 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00498.29 (FHA domain): [86:150](score: 61.4, e-value: 8.7e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_38 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00498.29: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_38\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGTCGATTCCGACGATAAGAAAGAACCCGAGCAGACGGTGGCGCCGGGGAAGACGGTCGCGCCAGAGAACGCCAGGGGGAACGTCGACACGACGATGACGTTCAGCCAGGAGTTCGCGGCGTCGTTGGCCGCCCTCGACTCGAACGTCACGGTCGAGGAGCAGGAAGCCATCGCCGCCCTGCCCTCAGGCTCGGCTCTGCTCGTGGTGCGCCGCGGCCCCAATTCGGGCGCACGCTTCCTCCTCGACGCCGACGTCACCACGGTCGGCCGTCACCCCAACGCCGACATCTTCCTCGATGACGTCACGGTCTCGCGTCGCCACGCCGAGTTCCTGCGCTCCGGTCGCACCTTCCAGGTGAAAGACCTGGGCTCGCTCAACGGAACCTATTTCGATGGCGAACGTATCGACCTGGCCGTCCTCACCGACGGGTCCGAAGTGCAGGTCGGAAAATTCCGCCTGACGTTCTACGCCTCGCGGCTCGACCTCGTACACCTGGCGAGCGACTAG",
    "translation": "MVDSDDKKEPEQTVAPGKTVAPENARGNVDTTMTFSQEFAASLAALDSNVTVEEQEAIAALPSGSALLVVRRGPNSGARFLLDADVTTVGRHPNADIFLDDVTVSRRHAEFLRSGRTFQVKDLGSLNGTYFDGERIDLAVLTDGSEVQVGKFRLTFYASRLDLVHLASD",
    "product": ""
   },
   {
    "start": 34995,
    "end": 35693,
    "strand": 1,
    "locus_tag": "ctg14_39",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_39</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_39</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,995 - 35,693,\n (total: 699 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_39 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13411.9 (MerR HTH family regulatory protein): [32:89](score: 38.2, e-value: 1.2e-09)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_39 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF13411.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF13411.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_39\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCCGGCGTCCTCCGCCCAGGCCAGGCTGCCGGGCGCGACGTCACTTCTGAGTATCGGCCAGGTCCTGGCCAGGCTCACGCCTGAGTTCCCGGACCTCACCCCGTCCAAGCTGCGCTTCCTCGAGGAGCAGGGCCTGGTCTCTCCGGCCCGCACCGAGTCCGGCTACCGCAAGTTCAACGGCGGCGACCTGGACCGGCTGCGACTGATCCTGTCGATGCAGCGCGACCATTACCTGCCGCTCAAGGTCATCCGCTCCTACCTCGACGACCTCGACTCCGGTCTGTCGCCGTCCCTGCCCGGCGGCGGGGCCCCCGGGCCGAGCATGCTCGTCGTGGCCCGCCGCTTCAGCCGGGACGAACTGCTGCGTGAGTCCGGCGCGACCGCCGCCCTGCTGCACGACGCCGTCTCGTCGTCGATCATCCTGCCGGCCGAGCACTACGGCGACGACGCCCTGCAGGTGCTCCGTGCCCTCGTCGACCTGCAGAAGAGCGGCATCGAACCGAGGCACCTGCGCGGGTTCCGCGGTGCCGCCGAACGCGAGCTCGGCCTGATCGAGAGCGCCCTCGTGCCGCTCGCCCGCCGCAAGGACGCCTCCAGCCGGGCCAAGGCCGCCGAGATGGCCGTGGAGATCGCCGGCCAGCTCGAAGTCATCCGCGGCAGCCTCATCCGCTCCGCCCTGGGTCGCCTGACCAAATAG",
    "translation": "MPASSAQARLPGATSLLSIGQVLARLTPEFPDLTPSKLRFLEEQGLVSPARTESGYRKFNGGDLDRLRLILSMQRDHYLPLKVIRSYLDDLDSGLSPSLPGGGAPGPSMLVVARRFSRDELLRESGATAALLHDAVSSSIILPAEHYGDDALQVLRALVDLQKSGIEPRHLRGFRGAAERELGLIESALVPLARRKDASSRAKAAEMAVEIAGQLEVIRGSLIRSALGRLTK",
    "product": ""
   },
   {
    "start": 35897,
    "end": 36448,
    "strand": 1,
    "locus_tag": "ctg14_40",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_40</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_40</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,897 - 36,448,\n (total: 552 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_40 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13411.9 (MerR HTH family regulatory protein): [34:103](score: 54.2, e-value: 1.2e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_40 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF13411.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF13411.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_40\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTGAGCTCAATCCCCGAGACGATTCGTCTCGCTACGGTCAGGGACTGCTCTTCACCGACGGTATGCCCGAGCTGGACGAGAACTCCGGGTACCGCGGCGCCGTCGCCGCCCGTGCCGCCGGCATCAGCTACCGCCAGCTCGACTACTGGGCCCGCACCGAACTCGTCGAACCCACCGTGCGCGGCGCGGCCGGATCCGGCTCCCAGCGCCTCTACGGCTTCCGCGACATTCTCGTGCTCAAGCTCGTCAAGCGCCTGCTCGACACCGGTATCTCCCTGCAGCAGATCCGCACCGCGGTCAACCAGTTGCGTGAGTCCGGCGTCAACGACCTGGCCCAGACCACCCTCATGAGCGACGGCGCCAGCGTCTACCTCTGCACCTCCAACGACGAGGTCATCGACCTGGTCAGCCGCGGCCAGGGCGTCTTCGGCATCGCCGTGGGCAAGGTCCTCCGCGAGGTCGAGACCACGCTGGTGGAACTCGACACCCAGGCCAACGACCCCTCCGACGAGCTCGCCGCCCGTCGCGTCTCCCGCAAGGTCTCCTAG",
    "translation": "MSELNPRDDSSRYGQGLLFTDGMPELDENSGYRGAVAARAAGISYRQLDYWARTELVEPTVRGAAGSGSQRLYGFRDILVLKLVKRLLDTGISLQQIRTAVNQLRESGVNDLAQTTLMSDGASVYLCTSNDEVIDLVSRGQGVFGIAVGKVLREVETTLVELDTQANDPSDELAARRVSRKVS",
    "product": ""
   },
   {
    "start": 36554,
    "end": 37264,
    "strand": -1,
    "locus_tag": "ctg14_41",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_41</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_41</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,554 - 37,264,\n (total: 711 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1157:hypothetical protein (Score: 119.4; E-value: 3.3e-36)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_41 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13614.9 (AAA domain): [0:146](score: 62.6, e-value: 4.6e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_41\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGTCGACCTCGATCCGCAATCGGATGTCTCAACCGGGCTCGACATCCAACTCGCCGGCCACCTCAATGTGGCCGATGTGCTGGCCTCGCCGAAGGAGAAAATCGTCCGGGCCGCCATCGCGCCCAGCGGCTGGACCCGCGGTCGCCCCGGCACCATCGACGTCATGATCGGCAGCCCCTCCGCCATCAATTTCGACGGCCCGCACCCCAGCATCCGCGACATCTGGAAGCTCGAGGAGGCCCTCTCCACAGTGGAGAAGGACTATGACCTGGTGCTCATCGACTGCGCGCCCTCGCTCAACGCCCTGACCCGCACCGCGTGGGCCGCGAGCGACCGTGTCGCCGTGGTCACCGAACCCGGCCTCTTCTCGGTGGCCGCCGCCGACCGCGCCCTCCGCGCGATCGAGGAGATCCGTCGTGGGCTCAGCCCGCGCCTGCAGCCGCTGGGCATCATCGTGAACCGGGCCCGCACGGCCTCGCTCGAGCACCAGTTCCGCATCAAGGAGCTCCGAGACATGTTCGGTCCCCTCGTGCTCACCCCGCAGCTTCCGGAGCGCACCAGCCTGCAGCAGGCGCAGGGCGCGGCGAAGCCCCTGCACACCTGGCCGGGTGACAGTGCCCAGGAGATGGCGCACTACTTCGACCAGCTGCTCGACCGGGTCCTGCGCACGGCACGCATCGGCGAATACGCGGAGGCGACCGCCCGCTAA",
    "translation": "MVDLDPQSDVSTGLDIQLAGHLNVADVLASPKEKIVRAAIAPSGWTRGRPGTIDVMIGSPSAINFDGPHPSIRDIWKLEEALSTVEKDYDLVLIDCAPSLNALTRTAWAASDRVAVVTEPGLFSVAAADRALRAIEEIRRGLSPRLQPLGIIVNRARTASLEHQFRIKELRDMFGPLVLTPQLPERTSLQQAQGAAKPLHTWPGDSAQEMAHYFDQLLDRVLRTARIGEYAEATAR",
    "product": ""
   },
   {
    "start": 37444,
    "end": 40848,
    "strand": 1,
    "locus_tag": "ctg14_42",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_42</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_42</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 37,444 - 40,848,\n (total: 3405 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: HMGL-like<br>\n \n  biosynthetic-additional (rule-based-clusters) Dala_Dala_lig_C<br>\n \n  biosynthetic-additional (rule-based-clusters) ATP-grasp<br>\n \n  biosynthetic-additional (smcogs) SMCOG1090:acetyl-CoA carboxylase biotin carboxylase (Score: 134.2; E-value: 9.6e-41)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_42 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00289.25 (Biotin carboxylase, N-terminal domain): [0:111](score: 131.5, e-value: 2e-38)<br>\n \n  PF02786.20 (Carbamoyl-phosphate synthase L chain, ATP binding domain): [116:326](score: 228.4, e-value: 7e-68)<br>\n \n  PF02785.22 (Biotin carboxylase C-terminal domain): [342:451](score: 122.3, e-value: 9.3e-36)<br>\n \n  PF00682.22 (HMGL-like): [528:801](score: 101.5, e-value: 6.1e-29)<br>\n \n  PF02436.21 (Conserved carboxylase domain): [824:1013](score: 167.3, e-value: 3.8e-49)<br>\n \n  PF00364.25 (Biotin-requiring enzyme): [1072:1130](score: 53.6, e-value: 1.6e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_42 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00682.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF02786.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_42\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_42_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTCACCAAAATCCTCGTCGCAAACCGTGGAGAGATAGCAATCCGCGCGTTCCGCGCCGCCTATGAATTGGGAGCAAAGACCGTCGCGGTCTTCCCGTTCGAAGACCGTAATTCACTGCACCGGCTCAAGGCCGACGAGGCGTACGAGATCGGCGAACCGGGTCACCCGGTGCGCGCGTACCTCGACGTGGCGGAGATCATCCGGGTGGCCAAGGAGAGTGGCGCAGATGCCATCTACCCCGGCTACGGATTCCTCTCCGAGAACCCCGACCTGGCGGAGGCGGCCACGGCGGCCGGCATCACCTTCATCGGCCCGGGTTCACACGTACTCGAAATGGCCGGTAACAAGGTCACCGCGAAGGAACACGCCATCGCGGCCGGCGTTCCCGTCCTCAAGTCCAGCGCACCGTCGCGCGACGTCGAGGAACTCATCGCCGCGGCCGAGGAGATCGGCTTCCCCATCTTCGCCAAGGCCGTCGCCGGCGGCGGCGGACGCGGCATGCGCCGCGTGGCCACCATGGCCGACCTGCGCGGCTCGCTCGAAGAAGCCATGCGCGAGGCCAACAGCGCCTTCGGCGATCCCACCATGTTCCTCGAGCAGGCGGTGCTCCGCCCGCGCCACATCGAGGTGCAGATCCTCGCGGATGCCACGGGCGAGACCGTGCACCTGTTCGAGCGGGACTGCTCCGTGCAGCGCCGCCACCAGAAGGTCATCGAGATCGCCCCGGCCCCCAACCTCCCCGAGGAGATCCGCCAGCGCCTGCACAAGGACGCCGTCGCCTTCGCCCGGTCGATCGGCTACGTCAACGCCGGCACGGTCGAGTTCCTGCTCGACACCGTGGGCGAGCGCGCCGGCCAGCACGTGTTCATCGAGATGAACCCGCGCATCCAGGTGGAGCACACCGTCACGGAAGAGGTCACCGACGTCGACCTCGTGCAGTCGCAGATCCGCATCGCCGCGGGGGAGACCCTCGCCGACCTGGGGCTCAGCCAGGACTCCATCAAACTGCGCGGCTTCGCCCTGCAGTGCCGCATCACCACGGAGGACCCCACGGCCGGGTTCCGCCCCGACACCGGCAAGATCACCACGTACCGCTCACCGGGCGGCGCCGGCATCCGCCTGGACGGCGGCACGATCAACCCGGGCGCGCAGATCAGCCCGCACTTCGACTCGATGCTGGCCAAGCTCACCTGCCGTGGCCGCGACTACGCCTCGGCCGTCACCCGGTCCAAGCGCGCGCTGGCGGAGTTCCGCATCCGCGGCGTCTCCACCAACATCGCCTTCCTGCAGGCCGTGCTCGAGGACCCCGACTTCGCCGCCGGCGACCTGAGCACCTCCTTCATCGACGAGCGTCCGCAGCTGCTGCGCGGCCGCGCGTCCAAGGACCGCGGCACGAAGATCCTCAACTGGCTGGCCGACGTCACCGTCAACCAGCCCAACGGTGTGCCGATCACGCTGATGAACCCGGCCGAGAAGCTCCCGAAGATCGACCTGTCGGTGCCGGCCCCGGAGGGCTCCCGGCAGAAGTTGCAACTGCTCGGCCCGGTCGGTTTCGCCAGTGCCCTGCGCAAGCAGACCGCACTGGCCGTCACGGACACCACCTTCCGCGACGCCCACCAGTCCCTGCTGGCGACCCGGGTGCGCACCAAGGACCTCGTGGCCGTGGCCCCGCACGTGGCCCGACTCACTCCCGAGCTGCTCTCGGTCGAGGCCTGGGGCGGCGCGACCTACGACGTCGCGCTACGCTTCCTCGGCGAGGACCCGTGGGAGCGACTCAGCGCCCTGCGGGAGGCGCTGCCCAACATCAACATCCAGATGCTGCTGCGCGGCCGCAACACCGTCGGCTACACGCCGTACCCCACCGAGGTGACGGATGCGTTCGTGCGCGAGGCCAGCGACACCGGCGTCGACATCTTCCGCATCTTCGACGCCCTCAACGACGTCAACCAGATGCGCCCGGCCATCGACGCGGTGCTGAACACCGGCACGAGCGTCGCCGAGGTCGCGGTCTGCTACACCGGCGACCTGCTGGACCCGGCCGAGGACCTCTACACGCTGGACTACTACCTACGCCTGGCCGACCAGATCGTCGCCTCCGGCGCGCACATCCTGGCGATCAAGGACATGGCCGGTCTGCTGCGCCCGGCCGCGGCGGAGAAGCTCGTCGCCGCGTTCCGCGAACGGTTCGACCTGCCGGTGCACGTGCACACGCACGACACCCCCGGTGGCCAGCTCGCCACGCTGCTCGCGGCCTCCCGCGCCGGGGCCGACGCCGTCGACGTCGCCAGCGCCCCGATGGGCGGCACCACCAGCCAGCCGTCGGCCTCCTCGCTCGTCGCCGCGCTCGCGCACACCGAACGCGACACGGGCATCTCGCTGCAGAACGTCTGCGACCTCGAGCCCTACTGGGAGGACGTGCGCCGGGTCTACCACCCCTTCGAATCCGGCCTCCGCGCCCCCACCGGCCGGGTGTACAAGCACGAGATCCCGGGCGGCCAGCTCTCCAACCTGCGCACGCAGGCCGTGGCGCTGGGACTCGCCGACGACTTCGAGCTCATCGAGGACATGTACGCGGCGGCCAACACCATCCTGGGCCGCGTGCCCAAGGTGACCCCGTCCTCCAAGGTGGTCGGCGACCTCGCCCTCTACCTCGCCGCGGTGAACGCCGACCCGGCCGACTTCGAGGCGAACCCGGCGAAGTACGACGTGCCCGACTCCGTGGTCGGCTTCATGGCCGGCGAACTGGGCGACCTGCCCGGCGGCTGGCCCGAGCCCTTCCGCAGCAAGGTCCTCGAGGGCCGGAACGTCCGGGTCAGCACCACCGAGCTGACCGACGAGGAGCGTGTCGCCCTGGCCGGCGACAGCGCCACCCGCCGCGGCATGCTCAACCAGCTACTCTTCCCGGCTCCCACCCGGCACTTCCAGCAGATCCGGGAGCTGTTCGGTGACCTGTCCGTGGTCGACACGGTCGACTACCTCTACGGCCTGCGCCAGGGCACCGAGCACTCGGTCGAGATCGACAAGGGCGTGCGGCTCTACGTGGGCCTCGAGGCGATCGGCGAGGCCGACGACAAGGGCATGCGCACCGTCATGACCATCCTCAACGGCCAGTTGCGGCCCGTGTTCGTGCGCGACCGCAGCATCGCCGTCGTCACCAAGGCGGCCGAGAAGGCGGATGCCAACCAGCCCGGCCAGATCGCCGCCCCGTTCTCCGGAGTGGTCACCCTGCAGGTCGCCGACGGCGACCACGTCGTGGCCGGCCAGAGCGTGGCCTCCATCGAAGCCATGAAGATGGAAGCGGCCATCACCTCGCCCATCGCGGGCGTCGTGGAGCGGGTGGCGATTCCCACCACCCAGCAGGTCGACGCCGGGGACCTGCTTGTGGTGGTGCGACCACGCTAG",
    "translation": "MFTKILVANRGEIAIRAFRAAYELGAKTVAVFPFEDRNSLHRLKADEAYEIGEPGHPVRAYLDVAEIIRVAKESGADAIYPGYGFLSENPDLAEAATAAGITFIGPGSHVLEMAGNKVTAKEHAIAAGVPVLKSSAPSRDVEELIAAAEEIGFPIFAKAVAGGGGRGMRRVATMADLRGSLEEAMREANSAFGDPTMFLEQAVLRPRHIEVQILADATGETVHLFERDCSVQRRHQKVIEIAPAPNLPEEIRQRLHKDAVAFARSIGYVNAGTVEFLLDTVGERAGQHVFIEMNPRIQVEHTVTEEVTDVDLVQSQIRIAAGETLADLGLSQDSIKLRGFALQCRITTEDPTAGFRPDTGKITTYRSPGGAGIRLDGGTINPGAQISPHFDSMLAKLTCRGRDYASAVTRSKRALAEFRIRGVSTNIAFLQAVLEDPDFAAGDLSTSFIDERPQLLRGRASKDRGTKILNWLADVTVNQPNGVPITLMNPAEKLPKIDLSVPAPEGSRQKLQLLGPVGFASALRKQTALAVTDTTFRDAHQSLLATRVRTKDLVAVAPHVARLTPELLSVEAWGGATYDVALRFLGEDPWERLSALREALPNINIQMLLRGRNTVGYTPYPTEVTDAFVREASDTGVDIFRIFDALNDVNQMRPAIDAVLNTGTSVAEVAVCYTGDLLDPAEDLYTLDYYLRLADQIVASGAHILAIKDMAGLLRPAAAEKLVAAFRERFDLPVHVHTHDTPGGQLATLLAASRAGADAVDVASAPMGGTTSQPSASSLVAALAHTERDTGISLQNVCDLEPYWEDVRRVYHPFESGLRAPTGRVYKHEIPGGQLSNLRTQAVALGLADDFELIEDMYAAANTILGRVPKVTPSSKVVGDLALYLAAVNADPADFEANPAKYDVPDSVVGFMAGELGDLPGGWPEPFRSKVLEGRNVRVSTTELTDEERVALAGDSATRRGMLNQLLFPAPTRHFQQIRELFGDLSVVDTVDYLYGLRQGTEHSVEIDKGVRLYVGLEAIGEADDKGMRTVMTILNGQLRPVFVRDRSIAVVTKAAEKADANQPGQIAAPFSGVVTLQVADGDHVVAGQSVASIEAMKMEAAITSPIAGVVERVAIPTTQQVDAGDLLVVVRPR",
    "product": ""
   },
   {
    "start": 41001,
    "end": 42308,
    "strand": 1,
    "locus_tag": "ctg14_43",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 41,001 - 42,308,\n (total: 1308 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1157:hypothetical protein (Score: 61.8; E-value: 1.3e-18)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_43 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01656.26 (CobQ/CobB/MinD/ParA nucleotide binding domain): [191:349](score: 32.9, e-value: 6e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_43\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCGGGCCGGTGACGAGTACCACAGCGAGCTCCCGCCGCACACCTTCGACAACCTCGCGGCCGCGCTGCCCGAGAGCCTCGGGGTGTCCCTGGGCGACGGGACGCGCCCCGTGTCGGCCGCGCCGGCATCCGCACTGACCCGCGGCTCCGCCCGCCCACCGGCCCGTCCCACCGGTGACGCCTCGGCGCACGCCCACCCCGGCACACACACCATCGAGATCGTCACGCCGCAGCCGGCCCGCGAGCTGGCCGTTCCCGTCGGGGCGAGCGGGATGGCCGCCGCCGCGCTCTCGCTCGGCACCGGCCCCACCGGCGCTCCCACCGCCAGCCGGCGGGAGCGCACCCGCACGGACACCGTGGCACCGGAATCCGCCTCGATGCTCACCTCCGACCGGCTGCTCGAGGTCAACCGGCGCACCCGGCGGCCCCCCAACGGCGCCTGGAACCGTTTCGTCTACAACGTCTCCCTGCACCTGATCAACCTCGGCGACTCCGCCGCGGTGCGTGCCCATCAGGCCATGGACGAACGCATCCGCAAGCAGTTCGAGGGCGGCGCCCGCTTCGTACCGGTGCTCACCCGTAAGGGCGGCGTGGGCAAGACCACGGTCACCGCGCTCATGGGTATGGCCCTGGCCGACGCCCGCGAGGACCGCATCATCGCCGTGGACGCCAACCCCGACCGCGGAACCCTGTCCGAACGCGTCACCAAGCAGACCAGGTCGACGGTGCGCGACGTCGTCACGAAGGCGGCCTCCATCGGCGGCTTCACCGACTTCTCCGCGCTGGTCTCCCGGGACGAGACCCGCCTCGACATCCTGGCCAGCGACACCGACCCGCTGCTCTCGGAGGCGTTCGACGAGAACGACTACAACGTCGTCGCCGATCTCGCGGCCCGGTTCTACTCCATCGTGCTCACCGACTGCGGCACCGGCATCGTGCACTCGGTCATGCGGGCGACCCTGCAGCGGGCCGACTCCATCGTGATCGTCTCCGGCGGCAGCGTCGACGAGGCCCGGCTGGCCTCCGAGACCCTCACCTGGCTCGAGGCCAACGGATACGGCGAGCTGGTCCGCAACGCCGTCGTCGCGTTGAACACGGCCACCCAGGGCACCAACCTCGTCAAGCTCGAGGAGATCGAGTCGCACTTCAGGTCCCGCGTGCGGGAGATCGTGCGGATCCCGTACGACCCGCAGCTGGCCGCCGGCAGTGTGGTCTCCTACAAGGACCTCAAGCCGATCACGCGCCTCGCCGCGCGCACCCTGGCAGCCCTCGTCGTGGAAGGGCTGCCTGCCGAGCGACGCGTCTGA",
    "translation": "MRAGDEYHSELPPHTFDNLAAALPESLGVSLGDGTRPVSAAPASALTRGSARPPARPTGDASAHAHPGTHTIEIVTPQPARELAVPVGASGMAAAALSLGTGPTGAPTASRRERTRTDTVAPESASMLTSDRLLEVNRRTRRPPNGAWNRFVYNVSLHLINLGDSAAVRAHQAMDERIRKQFEGGARFVPVLTRKGGVGKTTVTALMGMALADAREDRIIAVDANPDRGTLSERVTKQTRSTVRDVVTKAASIGGFTDFSALVSRDETRLDILASDTDPLLSEAFDENDYNVVADLAARFYSIVLTDCGTGIVHSVMRATLQRADSIVIVSGGSVDEARLASETLTWLEANGYGELVRNAVVALNTATQGTNLVKLEEIESHFRSRVREIVRIPYDPQLAAGSVVSYKDLKPITRLAARTLAALVVEGLPAERRV",
    "product": ""
   },
   {
    "start": 42401,
    "end": 42892,
    "strand": 1,
    "locus_tag": "ctg14_44",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 42,401 - 42,892,\n (total: 492 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1275:peptide deformylase (Score: 148; E-value: 2.8e-45)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_44 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01327.24 (Polypeptide deformylase): [3:150](score: 115.1, e-value: 2.5e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_44 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01327.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0042586' target='_blank'>GO:0042586</a>: peptide deformylase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_44\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_44_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCCCGAACGCCAGATCCGCCTGTTGGGCGACCCCGTCCTCAAGACCCGCTCCGAACCGATCGGTACGATCGACGCCCGCGTGCGGAGCCTGGTGGAGGACCTCGTCGACAGCGTGACGCTGCCGGGCCGTGCCGGTGTGGCGGCGTCCCAGATCGGCGTCAACCTGCGGGCGTTCAGCTACAACATCGACGGCGACATCGGCTACATCCTCAACCCCGTCATCGTGGAGCTCTCGGGCGAACCCGAGCTCGTCGACGAGGGCTGCCTGTCGGTGCCTGGCCTGTGGTACCCCACCCGGCGGTACCCGTTCGCGCGCGTCACGGGCATCGACCTCGACGGCAACACCGTCGAGCTGGCCGGGGAGGGCCTGCTGGCCCAGGCCCTGCAGCACGAGACCGACCACCTGGACGGCCTGCTCTACCTGGACAGGCTCGACAAGGAGAGCCGCCGGGCTGCCATGAAGGAAGTCCGCGAGTCGGACTGGTTCTGA",
    "translation": "MPERQIRLLGDPVLKTRSEPIGTIDARVRSLVEDLVDSVTLPGRAGVAASQIGVNLRAFSYNIDGDIGYILNPVIVELSGEPELVDEGCLSVPGLWYPTRRYPFARVTGIDLDGNTVELAGEGLLAQALQHETDHLDGLLYLDRLDKESRRAAMKEVRESDWF",
    "product": ""
   },
   {
    "start": 42935,
    "end": 44779,
    "strand": -1,
    "locus_tag": "ctg14_45",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 42,935 - 44,779,\n (total: 1845 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 250.6; E-value: 4.2e-76)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_45 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [36:467](score: 303.1, e-value: 2.8e-90)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_45\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_45_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAAACAGTTCGATGAGCCCGCCGTCGTCCCTGCAGACCCGAACGCGAACGTCACCGACCTGCTGGTCGACCGCCTCGCCCTGACCCCGCAGTCCGTGCTGTTCTCCCGCCCGGACCGGGGCGGCTGGCTGCCGGTCACCACCGCCGAGTTCCACGCCGAGGTCGTGGCCCTGGCCAAGGGGCTGGTCGCCTCAGGCGTGCAGCCGGGCGACAAGATCGGGCTGACCTGCAAGACCCGCTACGAGTGGACGCTGATCGACTTCGCCGTCTGGTTCGCAGGCGCGATCCTGGTCCCGGTCTACGAGACCAGCTCACCCAGCCAGATCCAGTGGATCCTCAGCGACTCGGGGGCAACGGCGCTCATCGTGGAGACTGCGGACCACTTCGCCCGGTTCGACGAGGTGCACCCCGACCTGCCCGGCGTCGAGACGGTGTGGCAGATCGATCTCGGTGACCTCGACAAGCTCGCCGCGCGCGGCGTCGACGTTCCGGATGCCGAGATCGAGCGACGTCGCCGCCTCGCGGTCGGCTCGGACATGGCCACCCTCATCTACACCTCGGGCTCCACCGGGCGCCCCAAGGGTTGCGTGCTCAGCCACAGCAACTTCGTGGAGACCAGCCGCAACGCCGGGATCGCCCTCAAGCCGGTGCTCACCGACCCGGAGGGCGCATCCACCCTGCTGTTCATCACGACGGCCCACGTGTTCGCCCGGTTCATCTCGGTGCTGTGCGTGCACGGCGGCGTGCGGGTCGGCCACCAGCCGGACACCCGGCAGCTGCTGCCGTCGCTGGGCAGCTTCAAGCCCACCTTCCTGCTGGCCGTCCCCCGGGTGTTCGAGAAGGTCTACAACTCGGCCGAGCAGAAGGCGGAGGCCGGCGGCAAGGGCAAGATCTTCGAGGCCGCGTCCGACGTCGCCGTTGCGCACTCCAAGCTCATCGAGGCCGGCGAGCGGATCCCGCTGGGCATGAAGATCAAGTTCGCCCTCTTCGACCGGCTGGTCTACAGCAAGCTGCGGGCCGCGATGGGTGGCAAGGTCAAGTACGCCGTGTCGGGCTCCGCCCCGCTCGGCGCCCACCTGGGCCACTTCTTCCACAGCCTCGGCATCGTCATCCTGGAGGGCTACGGCCTCACCGAGACCACGGCTCCCGCGACCGTCAACCTGGCCACCAAGTCCAAGATCGGCACTGTCGGGCCGGCGCTGCCCGGCGTGTCCGTCCGGGTCATGGACGACGGCGAGATCGAGGTGAAGGGCGTCAACGTCTTCACCGAGTACTGGCACAACCCGGAGGCCACGGCCGCCGCGTTCGACGACGGCTGGCTGAAGACCGGTGACATCGGCGCCCTGGACGCCGAGGGTTTCCTGTCCATCACCGGGCGCAAGAAGGAGATCATCGTGACCGCCGGCGGCAAGAACGTGGCCCCGGCCGCGCTCGAGGACCCCATCCGGTCGAACCCGTTGGTCGGCCAGGTCGTCGTGGTCGGCGACCAGAAACCGTTCATCGCCGCCCTCGTCACCCTCGACCCCGAGATGCTGCCGGTCTGGCTGAACAACAATCACGAAGACGCTGGTCTGTCGCTCATGGACGCGTCGGTGCACCCCAAGGTGCTCGCCGAGGTGCAACGCGCCATCGACCACGCCAACGAGACCGTGTCGCGCGCCGAGTCGATCCGCAAGTTCGTGGTGCTGCCCATCGAACTCACCGAGGCTGCCGGCTACCTCACCCCCAAGATGAGCATCAAACGCGATGTGATCCTGCGTGACTTCGCCGCCGAGATCCAGAACCTCTACGGGGCCAACCCGGTCACCGCGGCCGTGCCGGTGCGCTCGAGCGCACAGGACTGA",
    "translation": "MKQFDEPAVVPADPNANVTDLLVDRLALTPQSVLFSRPDRGGWLPVTTAEFHAEVVALAKGLVASGVQPGDKIGLTCKTRYEWTLIDFAVWFAGAILVPVYETSSPSQIQWILSDSGATALIVETADHFARFDEVHPDLPGVETVWQIDLGDLDKLAARGVDVPDAEIERRRRLAVGSDMATLIYTSGSTGRPKGCVLSHSNFVETSRNAGIALKPVLTDPEGASTLLFITTAHVFARFISVLCVHGGVRVGHQPDTRQLLPSLGSFKPTFLLAVPRVFEKVYNSAEQKAEAGGKGKIFEAASDVAVAHSKLIEAGERIPLGMKIKFALFDRLVYSKLRAAMGGKVKYAVSGSAPLGAHLGHFFHSLGIVILEGYGLTETTAPATVNLATKSKIGTVGPALPGVSVRVMDDGEIEVKGVNVFTEYWHNPEATAAAFDDGWLKTGDIGALDAEGFLSITGRKKEIIVTAGGKNVAPAALEDPIRSNPLVGQVVVVGDQKPFIAALVTLDPEMLPVWLNNNHEDAGLSLMDASVHPKVLAEVQRAIDHANETVSRAESIRKFVVLPIELTEAAGYLTPKMSIKRDVILRDFAAEIQNLYGANPVTAAVPVRSSAQD",
    "product": ""
   },
   {
    "start": 44981,
    "end": 45928,
    "strand": 1,
    "locus_tag": "ctg14_46",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_46</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_46</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 44,981 - 45,928,\n (total: 948 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1108:ROK family protein (Score: 268.8; E-value: 1.3e-81)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_46 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00480.23 (ROK family): [3:310](score: 264.9, e-value: 1e-78)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_46\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_46_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_46\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCACGCCATTGGGATTGACATCGGCGGGACCAAGATCGCCGGTGCCCTCGTCGACGAATTCGGAACCATCATCAAGTCGGACCGCCGGCCCACCGAGGCGGCCGATCCGCGCGAGATCGAGGACGCCGTCGTCGAGATGATCGAGGGGCTCTCCGCCGGCGAGGACGTCGTGGCCGCCGGCGTGGCCGCCGCCGGCTTCATCGACGCCGCCCAGTCGACCGTCTACTACGCTCCCAACATCAACTGGCGCAACGAGCCGCTGCGCGAGAAGCTCGAGTCCCGCCTGTCGGTGCCCATCATCATCGAGAACGACGCCAACGCCGCCGGCTGGGCCGAGTTCTGCTTCGGCGCCGGGCGGCTCTACAGCGACATGGTGACCCTCACCATCGGCACCGGGGTGGGCGGGGCCATCGTCTCCCGCGACCGGTTGTTCCGCGGCGGCTTCGGCGTGGGCGCCGAGCTCGGCCACATGCGCGTCGTGCCGGACGGCCTGCCCTGCGGCTGCGGTGCGCACGGCTGCATCGAACAGTACGGCTCGGGCCGCGCGTTGTTGCGCATCGCCAACGAGTTCGCGGATGCCGGCGGCATCGGGCTGGGCCTGGCCGCGTCGCGCGCCAAGCGCGGCAAGCTCACCGGCAAGGATGTCGGCCGGTTCATCCAGGAGGGTGACCCCGGCGCCCTGGCGGCGCTCCGCCAGCTCGGCGCCTCCCTCGGCCAGGCCTGCGCCAGCCTGGCCGCGGTCCTCGACCCGCAGGTCTTCGTCTTCGGCGGCGGCGTGGCCGCAGCGGGCGAACTGCTGCTCGAACCCATCCGCAGCGCCTACCTGGACAACCTGCCGGCGCGGGGCTACCACCCCGAGGCCGAGTTCGCGATCGCAGAACTGGTCAACGATGCCGGAGTGGTCGGCGCCGCCGATCTCGCCCGCCGGCACGTGACCGGTGAGTAG",
    "translation": "MHAIGIDIGGTKIAGALVDEFGTIIKSDRRPTEAADPREIEDAVVEMIEGLSAGEDVVAAGVAAAGFIDAAQSTVYYAPNINWRNEPLREKLESRLSVPIIIENDANAAGWAEFCFGAGRLYSDMVTLTIGTGVGGAIVSRDRLFRGGFGVGAELGHMRVVPDGLPCGCGAHGCIEQYGSGRALLRIANEFADAGGIGLGLAASRAKRGKLTGKDVGRFIQEGDPGALAALRQLGASLGQACASLAAVLDPQVFVFGGGVAAAGELLLEPIRSAYLDNLPARGYHPEAEFAIAELVNDAGVVGAADLARRHVTGE",
    "product": ""
   },
   {
    "start": 45983,
    "end": 46672,
    "strand": 1,
    "locus_tag": "ctg14_47",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_47</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_47</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,983 - 46,672,\n (total: 690 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1141:acyltransferase (Score: 197.6; E-value: 2.9e-60)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_47 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01553.24 (Acyltransferase): [22:151](score: 87.3, e-value: 7.3e-25)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_47 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01553.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016746' target='_blank'>GO:0016746</a>: acyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_47\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_47_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_47\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTCTACTGGTTCATGAAGAATATTGTCGCCGGGCCGCTCCTGCTCGGCCTGTTCCGGCCGTGGGTGATCGGGCTCGAGAACATCCCCAAAGAGGGCGGCGTGGTGCTCGCGAGCAACCACCTCTCGTTCATCGACTCGGTCTTCCTGCCGCTCGTGGTGCCGCGCCGGGTCGTCTTCCTGGCCAAGAGCGAGTACTTCACCGGCACGGGCCTCAAGGGCTGGGCCACCCGTCAGTTCTTCAAGGCCACCGGCCAGCTGCCGATCGACCGGTCCGGCGGCAAGGCCTCAGAAGACTCCCTGAACACCGGGCTCGCGGTGCTGAATGCCGGGGGAGCGCTCGGCATCTATCCGGAGGGCACCCGCAGTCCGGACGCGCGCATGTACCGCGGTCGCACCGGCGTGGCGCGGATGGTGCTCGAGGCCGGTGTCCCCGTCGTCCCGGTGGCCATGATCGACACCGAGAAGGCCATGCCCACCGGAACCCGCATCCCGAAGGTGCGCCGGATCGGCATCGTGATCGGGAAGCCGTTGGACTTCAGCAGGTTCGAGGGAATGGAGGGCGACAGGTTCGTGTTGCGCTCCGTGACGGACGAGCTGATGTACGAACTGCGCCGCCTCAGCACGCAGGAGTACGTCGACGTCTATGCCACCAGCGTCAAGGAGAAGCGCGCCAGCCTTTCACGCTAG",
    "translation": "MFYWFMKNIVAGPLLLGLFRPWVIGLENIPKEGGVVLASNHLSFIDSVFLPLVVPRRVVFLAKSEYFTGTGLKGWATRQFFKATGQLPIDRSGGKASEDSLNTGLAVLNAGGALGIYPEGTRSPDARMYRGRTGVARMVLEAGVPVVPVAMIDTEKAMPTGTRIPKVRRIGIVIGKPLDFSRFEGMEGDRFVLRSVTDELMYELRRLSTQEYVDVYATSVKEKRASLSR",
    "product": ""
   },
   {
    "start": 46802,
    "end": 48145,
    "strand": 1,
    "locus_tag": "ctg14_48",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_48</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_48</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 46,802 - 48,145,\n (total: 1344 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_48 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01474.19 (Class-II DAHP synthetase family): [10:441](score: 648.7, e-value: 3.7e-195)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_48 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01474.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003849' target='_blank'>GO:0003849</a>: 3-deoxy-7-phosphoheptulonate synthase activity<br>\n  \n   PF01474.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009073' target='_blank'>GO:0009073</a>: aromatic amino acid family biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_48\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_48_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_48\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAGACACATCTGTAATCAACGGGCTGGACTATTGGCGCACCCTCCCCATCAAGCAGCAGCCGGCCTGGCCGGATGCCGACGCCGTCGCCGCGGCGTCCGCGGAGCTGGCCACCCAGCCGCCGCTGGTCTTCGCCGGCGAGGTCGACATCCTGCGCGACCGCCTGGCCCAGGCCGCCCGCGGCGAGGCCTTCCTGCTCCAGGGCGGTGACTGCGCCGAGACGTTCAGCGGCGCCACCGCCGAGCAGATCCGCAACCGGGTCAAGACGGTGCTGCAGATGGCCGTCGTCCTCACCTACGGCGCCTCCATGCCCGTCGTGAAGATGGGCCGCATGGCCGGACAGTTCGCCAAGCCCCGCTCCAGCGACTTCGAGACCCGCGGCGACGTCACCCTGCCCGCCTACCGCGGCGACATCGTGAACGGCTACGACTTCACCCCGGAGTCCCGCGAAGCGGACCCCGACCGGCTGGTCAAGGCGTACCACACGAGCGCCTCCACCCTCAATCTGATCCGCGCGTTCACGCAGGGCGGCTTCGCCGACCTCCGTCAGGTGCACAGCTGGAACCAGGGCTTCGCGAAGAACCCGGCCAACCAGCGCTACGAGGGCCTGGCCAAGGACATCGACCGCGCCATCAAGTTCATGATCGCCTGCGGCGCCGACTTCGAGGCCATGCGCCGCACGGAGTTCTACACCAGCCACGAGGGTCTGCTGATGGACTACGAGCGCCCCATGACGCGCATCGACTCCCGTACCGGCACGCCGTACAACACCTCGGCGCACTTCGTCTGGATCGGCGAACGCACCCGGGAGATCGACGGCGCCCACGTGGACTTCCTGTCCCGCGTGCGCAACCCCATCGGCGTCAAGCTCGGCCCGAGCACCTCGATCGACGACATGCTGCGCCTGATCGACAAGCTGGACCCGAACCGCGAACCCGGCCGGCTCACCTTCATCACCCGGATGGGCGCCGGCAAGATCCGCGACGCCCTTCCGCCCCTGCTCGAGGCGATCAAGGCCAGCGACGCGACACCGCTCTGGGTCACCGACCCGATGCACGGCAACGGCGTCACCACCCCCACCGGGTACAAGACCCGTCGCTTCGACGACGTCGTCGACGAGGTCAAGGGCTTCTTCGAGGCGCACCGCGCCGTCGGCACGCACCCGGGCGGCATCCACGTCGAGCTCACCGGAGACGATGTCACCGAGTGCCTCGGCGGATCGGAGCACATCGACGAGGCCGCCCTGGCGACCCGCTACGAGTCGCTCTGCGACCCGCGCCTGAACCACATGCAGTCGCTGGAGCTGGCGTTCCTGGTGGCCGAGGAACTGGCCGCCCGCTAA",
    "translation": "MADTSVINGLDYWRTLPIKQQPAWPDADAVAAASAELATQPPLVFAGEVDILRDRLAQAARGEAFLLQGGDCAETFSGATAEQIRNRVKTVLQMAVVLTYGASMPVVKMGRMAGQFAKPRSSDFETRGDVTLPAYRGDIVNGYDFTPESREADPDRLVKAYHTSASTLNLIRAFTQGGFADLRQVHSWNQGFAKNPANQRYEGLAKDIDRAIKFMIACGADFEAMRRTEFYTSHEGLLMDYERPMTRIDSRTGTPYNTSAHFVWIGERTREIDGAHVDFLSRVRNPIGVKLGPSTSIDDMLRLIDKLDPNREPGRLTFITRMGAGKIRDALPPLLEAIKASDATPLWVTDPMHGNGVTTPTGYKTRRFDDVVDEVKGFFEAHRAVGTHPGGIHVELTGDDVTECLGGSEHIDEAALATRYESLCDPRLNHMQSLELAFLVAEELAAR",
    "product": ""
   },
   {
    "start": 48225,
    "end": 50147,
    "strand": -1,
    "locus_tag": "ctg14_49",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_49</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_49</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 48,225 - 50,147,\n (total: 1923 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Pkinase<br>\n \n  regulatory (smcogs) SMCOG1030:serine/threonine protein kinase (Score: 260.6; E-value: 2.7e-79)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_49 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00069.28 (Protein kinase domain): [9:281](score: 174.0, e-value: 4.1e-51)<br>\n \n  PF03793.22 (PASTA domain): [369:430](score: 48.9, e-value: 4.6e-13)<br>\n \n  PF03793.22 (PASTA domain): [508:569](score: 46.5, e-value: 2.6e-12)<br>\n \n  PF03793.22 (PASTA domain): [574:633](score: 39.5, e-value: 4.1e-10)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_49 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00069.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004672' target='_blank'>GO:0004672</a>: protein kinase activity<br>\n  \n   PF00069.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00069.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006468' target='_blank'>GO:0006468</a>: protein phosphorylation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_49\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_49_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_49\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCGGCCGTCTCATCGACGGCCGCTATCAGGTGCGCTCCCGGATCGCCCGCGGCGGTATGGCCACCGTGTACCTCGCCACCGACCTGCGCCTGGAGCGTCGGGTGGCGATCAAGATCATGCACGGCCACCTGGCCGACGACAACGCGTTCCGCAGCCGCTTCATCCAGGAGGCCCGTTCGGCGGCCCGCCTGGCGCACCCGAACGTGGTGAACGTCTTCGACCAGGGCCAGGATGCCGACATCGCCTACCTAGTGATGGAACACCTGCCCGGCATCACGCTGCGCGACCTTCTCAAGGACTACGGCCGGCTCACGCCGGAGCAGACCATGGACATCCTCGAGGCCGTGCTGTCCGGTCTCGCCGCCGCCCACAAGGCCGGCATCGTGCACCGCGATGTGAAGCCCGAGAACGTGTTGCTGGCCGATGACGGCCGCATCAAGATCGGCGACTTCGGGCTGGCCCGGGCCGTGAACAACAACACCGCCACCGGCCAGGCGCTGCTGGGCACTGTCGCGTACCTCTCCCCCGAACTCGTCACCCGCGGCATCGCGGATGCCCGCAGCGACATCTACGCCCTCGGCATCATGACCTACGAGATGCTCACGGGCGAGCAGCCCTACGTGGGCGAGGCACCCATGCAGGTGGCCTACCAGCACGCCAATGACACCGTTCCGATGCCCAGCCTCGTCGCCCCCGGCGTGCCGCAGGAGCTGGACGAGCTGGTGCTCTGGGCCACGGCCCGCGACCCCGAAGAGCGTCCGCGCGACGCCCGGGTGATGCTGGACCAGCTCCTGGACGTGGAGAAAATGGTGCGGCCGCACGACCAGAGCGCCCTGCAGGCCACCATGGTGCTTCCGCGCGACACGGTCGCCGCATCGGCCGACGCCGAGACGCAGATCCTCGGGCGCGCCCCGCTGGCGCCCGCGGCCACCCTGGCCGCTCCGGCGCCGGAGGCCGACGAACCGGACAGCACCGACCAACTCGCCGGAACGGCACGGAAGCGCCGCCGCCGCGGCTACGGGCTGTTCGCGCTGATCGTGCTCCTGGCCGCCCTCGCGGGCGGTGCCGGCTGGTACTTCGGCGTCGGCCCCGGTTCGGAGATCGCCGTGCCCAGCCTGACCTCGGCCTCCCCCGAGGATGCGGCCGCGCAGTTGGAGGCTCTCGGACTCGTCGCGGCCACCGGCACGGCCTACAGCACCGAGATCCCCTCGGGGCTCGTGGTCGACACCGACCCGGGAGACGGGGCCCGGGTGGCCAAGGGCAGCACGGTGACCGTCAACGTGTCGCAGGGGCCCGCACCGATCGTGCTGCCGGTCCTGGCCGGCCTCACCCCGGATGCCGCCGCCACAGCCATCACCGATGCCCTGGCCGTTCCGGGCACGGCGGACGAGATCTTCTCGAACACGGTCAAGAAGGGTCTGGTCATCTCCGCCACCCGGGACAGCGACGGCGGCGACGTCTCGCAGGGCGGGGACTCCTTCGAGGGGGCGACCATCAACTACACGGTCTCCCTCGGCGACGTGACCGACGTCACCGGCGAGAGCCTCGACGATGCCATCGACACCCTCGCCGAGCAGGGCCTCGAGGGCCGCTCAGGGCCGGAGACCTACAGCGAGACCGTGGCCAAGGGCAAGGTCATCTCGGCCGCGCCGGCCAGCGGCGGGCCGCTCCGGCAGGGCTCCGTCATCACGCTCACGGTCTCCCGCGGACCCGAACCCGTCGAGGTGCCCGATGTGGTCGGCAAGGGCTGGTCGGACGCCAAGGCGATCCTGACCGACCTCGGTTTCAAGCTGAGCTACAACCCCGGCGCCGACGCCATCGCAGCCCTGCTGAGCGTGGACTCGACCGACCCCGTCGCCGGCACCTCGCTGCCCAAGGGCAGCACCATCACCCTGAAGCCGACGAACCCGTTCGGCTGA",
    "translation": "MIGRLIDGRYQVRSRIARGGMATVYLATDLRLERRVAIKIMHGHLADDNAFRSRFIQEARSAARLAHPNVVNVFDQGQDADIAYLVMEHLPGITLRDLLKDYGRLTPEQTMDILEAVLSGLAAAHKAGIVHRDVKPENVLLADDGRIKIGDFGLARAVNNNTATGQALLGTVAYLSPELVTRGIADARSDIYALGIMTYEMLTGEQPYVGEAPMQVAYQHANDTVPMPSLVAPGVPQELDELVLWATARDPEERPRDARVMLDQLLDVEKMVRPHDQSALQATMVLPRDTVAASADAETQILGRAPLAPAATLAAPAPEADEPDSTDQLAGTARKRRRRGYGLFALIVLLAALAGGAGWYFGVGPGSEIAVPSLTSASPEDAAAQLEALGLVAATGTAYSTEIPSGLVVDTDPGDGARVAKGSTVTVNVSQGPAPIVLPVLAGLTPDAAATAITDALAVPGTADEIFSNTVKKGLVISATRDSDGGDVSQGGDSFEGATINYTVSLGDVTDVTGESLDDAIDTLAEQGLEGRSGPETYSETVAKGKVISAAPASGGPLRQGSVITLTVSRGPEPVEVPDVVGKGWSDAKAILTDLGFKLSYNPGADAIAALLSVDSTDPVAGTSLPKGSTITLKPTNPFG",
    "product": ""
   },
   {
    "start": 50265,
    "end": 51623,
    "strand": -1,
    "locus_tag": "ctg14_50",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 50,265 - 51,623,\n (total: 1359 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_50 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01476.23 (LysM domain): [108:151](score: 37.0, e-value: 2.7e-09)<br>\n \n  PF01476.23 (LysM domain): [171:215](score: 42.4, e-value: 6e-11)<br>\n \n  PF01476.23 (LysM domain): [241:285](score: 37.4, e-value: 2.2e-09)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_50\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_50\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCGGTCAGAGCCAGCAAAATCGAATCGGGGACGGTCGCCGCCGACTCCCCCGGTGCTGACTCCCCCGTCGAGTCGGCGGTCGGCCGCCCGGCGGCCCGGCGCCGCCCGGCGAAGACCGGTGTGCGCCGATCCTGGGGCGCGGTGGCGAGCCTTCCCCTTGTCGTGGTGAGCACCATGGCCATCGTGTTCAACCTGGCCTCTCCCGCCCAGGCAGCGACGGCCCTGAAGAAGCCGTTGAAGAGCCGCACGACACTGCCGCAGTCGGCCGTCAAGCCGGTGCAGACCGTTCGGCCGGCCACGGCGACCCCCGCGCCGAACCAGTACACCGTCGTCGACGGGGACACCATCAGCGCCATCGCCGGCAAGTTCGGCCTCTCCACCGCCTCGGTCCTCGCCCTCAACGGCCTGGGCTGGACCGCCGTGATCTTTCCCGGCCAGGTCCTCACCCTCTCGACCTCCCCGGTCACGGCGGCCGCCGCGCCGGCAGCCGTCGCCAGCGAACTCACCCGGTACACCATCCGCTCCGGCGACACCCTGAGCGGGATCGCGGCCGCGAACGGCGTGAGCTCCGATGCCGTCTTCCGCGCCAACGGCCTCGGCCGGGACAGCATCATCTTCCCCGGCCAGACCATCGTGCTGCCCGCCGCCGGGTCCTCGGCCGCCGTGGCCGGTGGGGCGCAGATCTCCCTCGCCTCGGCCTCGTCGGCCACGCCGGGCAGCCACACCGTGGTCGCCGGCGACACCGTCGACAAGGTCGCCGGTGCTGCCGGCGTCTCGGTGCAGTCGGTTCTGGAGGCGAACGGCCTGGGCTGGTCGAGCGTCATCCACCCCGGCCAGGTCCTGAAGATCCCCGGCGCCGCGACTGTTCTCGACGCTGCCCCTGCCGTCGTCGTGACCCCGAACACGCCCGCGACGCCCGCACCGACGGCCGTGCGCGACACCGTGACACCCCTCACCTCGGAGATGGCCGCGAACGCCCGGCTCATCATCGCCGTCGGTCGGCAGGCCGGGGCGAACGATGCCGCCCTCGTCATCGCCCTCGCCGCCGCCGCCCAGGAATCGGGCCTGCGCAACATCGATTACGGCGACCGGGATTCGCTCGGGCTCTTCCAGCAGCGCCCGAGTTCCGGCTGGGGAACCGCCGAGCAGGTCATGGACGCCGAGCGTGCCAGCCGCGCCTTCTTCGGCGGCCCGGTCAACCCCAACCCGGGCGTCACCCGCGGGCTGCTGGACATCCCGGGCTGGGAGAGCATGACGGTCACGCAGGCCGCCCAGGCCGTGCAGATCTCCGCCTACCCCGACTACTACGCCAAGTGGGAGACCTCCGCGCGGAGCTGGCTCGCCGAACTCGGCTGA",
    "translation": "MPVRASKIESGTVAADSPGADSPVESAVGRPAARRRPAKTGVRRSWGAVASLPLVVVSTMAIVFNLASPAQAATALKKPLKSRTTLPQSAVKPVQTVRPATATPAPNQYTVVDGDTISAIAGKFGLSTASVLALNGLGWTAVIFPGQVLTLSTSPVTAAAAPAAVASELTRYTIRSGDTLSGIAAANGVSSDAVFRANGLGRDSIIFPGQTIVLPAAGSSAAVAGGAQISLASASSATPGSHTVVAGDTVDKVAGAAGVSVQSVLEANGLGWSSVIHPGQVLKIPGAATVLDAAPAVVVTPNTPATPAPTAVRDTVTPLTSEMAANARLIIAVGRQAGANDAALVIALAAAAQESGLRNIDYGDRDSLGLFQQRPSSGWGTAEQVMDAERASRAFFGGPVNPNPGVTRGLLDIPGWESMTVTQAAQAVQISAYPDYYAKWETSARSWLAELG",
    "product": ""
   },
   {
    "start": 51796,
    "end": 52164,
    "strand": 1,
    "locus_tag": "ctg14_51",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 51,796 - 52,164,\n (total: 369 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_51 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF18367.4 (Rv2175c C-terminal domain of unknown function): [68:122](score: 74.9, e-value: 4.4e-21)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_51\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_51\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACCGATTCGTCTTCCGCACCGCAGCAGTCCGTTCCTTCCTCCACCCCCGAGTGGTACTCCATCCCCGACCTCGTCGAGGTCCTCGGGATCAGCCACAGCCGGGTGCGCCAGCTCATCGAAGACAAGCACCTGCTCGCCGTCCGGCGCGACGGCCGGGTCAGTGTTCCCGCGTCCTTCATCCGCGACGGGGCGCCGCTGGGCGAGCTCCGCGGCACTCTCATCGTGCTCTCCGATGACGGGTTCACCGACGAGCAGGCCATGGAGTGGCTGCTCGAGGTGGACGACAGCCTCGGCGTTCCCCCCATCGACGCGCTGCTGGCCGGACGCAAGGCCGAGGTTCGGCGCGTGGCCCAGGCCCTGGCCTGA",
    "translation": "MTDSSSAPQQSVPSSTPEWYSIPDLVEVLGISHSRVRQLIEDKHLLAVRRDGRVSVPASFIRDGAPLGELRGTLIVLSDDGFTDEQAMEWLLEVDDSLGVPPIDALLAGRKAEVRRVAQALA",
    "product": ""
   },
   {
    "start": 52246,
    "end": 53253,
    "strand": -1,
    "locus_tag": "ctg14_52",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 52,246 - 53,253,\n (total: 1008 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1182:Polyprenyl synthetase (Score: 227.8; E-value: 2.6e-69)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_52 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00348.20 (Polyprenyl synthetase): [5:283](score: 158.3, e-value: 2e-46)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg14_52 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00348.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_52\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg14_52_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_52\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCTGGTGGACTTCTCACGGCAGTTTCTCAGCGGCGGGAAGCGCTTCCGGGCCCAGTTCGCACACCTCGGTTGGCAGAGCGTCCCGGCCCCCATTGCGGCCGAGCCGGACGGGGTCTCCGCCGGTCTGGCCGGACTGGTCTCCGCGGCCTCCGCCCTGGAGGTTTTCCACGCGGCCGCCCTCGTCCACGACGACATCATCGACAATTCGGACACCCGCAGAGGCGCTCCGTCCGCGCACCGCCGCTTCGAAAGTCTGCACGGCGCCAACGGGTGGGCGGGCAGCCCAGCCGACTTCGGCCGGGCCTCGGCGATCCTGCTCGGCGACCTCCTGCTCGGCTGGAGCGACGAGCTGCTCGACGACGGCCTCGACGGCGCGGCCGACCGGGTGAGCGCCCGGCGTGCGCGCGCCGAATTCAACCGCATGCGCACCGAGGTCACGGCGGGCCAGTATCTGGACATCCTCGAGGAGCGGGCCTGGCTCACCCAGCCGGAGTCCGAGCTCCTCGACCGCGCGGTGCGGGTCATCGTCTTCAAGTCCGCCAAGTACAGCGTGCAGGCCCCGCTGGTGATCGGCGCAGCCCTGGCCGGCGCGGACGACGCCCAGCTCGACGTCCTGCGGGCGTTCGGCCTGCCGCTCGGCATCGCCTACCAGCTTCGTGACGATCTGCTCGGGGTCTTCGGCGATGCCGCCGTCACGGGCAAGCCCAGCGGAGACGACCTGCGGGAGGGCAAGCGCACCGTGCTGATCGCGCTGGCGCGGGAGAACCTGGACGCTGTGGCCCTGGGCACCGTCGACCGTCTGCTCGGGCGCCCCGACCTCACGCCGGAGCAGATCTCGTCACTGCAGCAGATCATCGTCGACAGCGGCGCCGTCGACAGGGTCGAGACCCTGATCCAGCAGAACGTGGCCCAGGCTCTCGCCGCGCTGGACGGTTCCCGCGTCGAACAGGGCGTTCTGAACGCCCTGACCGACTTCGCCGGCACGGTCACCCGCCGGGTCTTCTAA",
    "translation": "MLVDFSRQFLSGGKRFRAQFAHLGWQSVPAPIAAEPDGVSAGLAGLVSAASALEVFHAAALVHDDIIDNSDTRRGAPSAHRRFESLHGANGWAGSPADFGRASAILLGDLLLGWSDELLDDGLDGAADRVSARRARAEFNRMRTEVTAGQYLDILEERAWLTQPESELLDRAVRVIVFKSAKYSVQAPLVIGAALAGADDAQLDVLRAFGLPLGIAYQLRDDLLGVFGDAAVTGKPSGDDLREGKRTVLIALARENLDAVALGTVDRLLGRPDLTPEQISSLQQIIVDSGAVDRVETLIQQNVAQALAALDGSRVEQGVLNALTDFAGTVTRRVF",
    "product": ""
   },
   {
    "start": 53429,
    "end": 53809,
    "strand": 1,
    "locus_tag": "ctg14_53",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_53</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_53</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 53,429 - 53,809,\n (total: 381 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_53 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF11239.11 (Protein of unknown function (DUF3040)): [0:79](score: 88.1, e-value: 3.7e-25)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_53\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_53\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCGCTTTCAGAACAAGAGCAGCGACTCCTCGAAGAGATGGAGCGCAGTCTCTATCACAACGATGCCGAATTCGTGGCGAGCGTCGGGGGCACGCGTCTCCGCCCCAATTACCGATCGATAGTCCTCGGGGTGCTCGCGGGCGTCGTGGGGATCGCGACTCTTGTGGCCGGTGTTGCGGTGCAGCAGCTCTGGTTGGGCATCATCGGATTCATCATCATGTTCGGCGGCGTGCTCCTGGCCATCACGCCGGGTCGCACCGCCCGGGCGACGCGGCCGTCGTCCTCCCAGGCCCGCCGCCCCGCGCAGGCACGCAGTCAGCAGGGCTTCATGGACAAGTTGAACGACCGCTGGGACCGTCGCCAGGACGGCCAGCAGTAA",
    "translation": "MPLSEQEQRLLEEMERSLYHNDAEFVASVGGTRLRPNYRSIVLGVLAGVVGIATLVAGVAVQQLWLGIIGFIIMFGGVLLAITPGRTARATRPSSSQARRPAQARSQQGFMDKLNDRWDRRQDGQQ",
    "product": ""
   },
   {
    "start": 54179,
    "end": 54610,
    "strand": 1,
    "locus_tag": "ctg14_54",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg14_54</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg14_54</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 54,179 - 54,610,\n (total: 432 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg14_54 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02381.21 (MraZ protein, putative antitoxin-like): [0:69](score: 60.4, e-value: 1.4e-16)<br>\n \n  PF02381.21 (MraZ protein, putative antitoxin-like): [71:137](score: 65.7, e-value: 2.9e-18)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg14_54\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg14_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg14_54\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTCCTCGGGACCTATGCCCCCAAGCTCGACGAAAAAGGACGCGTCATCCTGCCGGCCAAATTCCGCGACGAACTCTCGACCGGCATCGTGATGACCCGCGGCCAGGAACGGTGCCTCTACGTCTTCACCACGCGTGACTTCGACGAGGTGAACGAGAAGATCCGCCAGGCGCCCATCACCAGCAAGGAGGGGCGCGACTTCTTCCGCGTCTTCCTGTCGGGAGCCAGCGCCGAAACACCCGACAAGCAGAACCGCGTCAGCATCCCGGCCAACCTCAGGGCCTACGCCGGACTCGACCGTGACCTGACGGTCATCGGCGTGGGCAACCGCGTGGAGATCTGGGACACCGAGGTCTGGGACGCGTACCTCACCGAGCAGGAAACCTCGTTCGCCAACATCACGGAGGAGGTGATTCCGGGACTCTTCTAG",
    "translation": "MFLGTYAPKLDEKGRVILPAKFRDELSTGIVMTRGQERCLYVFTTRDFDEVNEKIRQAPITSKEGRDFFRVFLSGASAETPDKQNRVSIPANLRAYAGLDRDLTVIGVGNRVEIWDTEVWDAYLTEQETSFANITEEVIPGLF",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 14041,
    "end": 54778,
    "tool": "",
    "neighbouring_start": 14040,
    "neighbouring_end": 54779,
    "product": "CC 1: neighbouring",
    "kind": "candidatecluster",
    "prefix": "",
    "height": 0
   },
   {
    "start": 14041,
    "end": 34948,
    "tool": "",
    "neighbouring_start": 14040,
    "neighbouring_end": 34949,
    "product": "CC 2: single",
    "kind": "candidatecluster",
    "prefix": "",
    "height": 1
   },
   {
    "start": 27444,
    "end": 54778,
    "tool": "",
    "neighbouring_start": 27443,
    "neighbouring_end": 54779,
    "product": "CC 3: single",
    "kind": "candidatecluster",
    "prefix": "",
    "height": 2
   },
   {
    "start": 24040,
    "end": 24949,
    "tool": "rule-based-clusters",
    "neighbouring_start": 14040,
    "neighbouring_end": 34949,
    "product": "terpene",
    "category": "terpene",
    "height": 4,
    "kind": "protocluster",
    "prefix": ""
   },
   {
    "start": 37443,
    "end": 44779,
    "tool": "rule-based-clusters",
    "neighbouring_start": 27443,
    "neighbouring_end": 54779,
    "product": "betalactone",
    "category": "other",
    "height": 6,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [
    {
     "start": 26589,
     "end": 26591,
     "strand": 1,
     "containedBy": [
      "ctg14_30"
     ]
    },
    {
     "start": 29633,
     "end": 29635,
     "strand": -1,
     "containedBy": [
      "ctg14_34"
     ]
    }
   ],
   "bindingSites": []
  },
  "type": "betalactone,terpene",
  "products": [
   "terpene",
   "betalactone"
  ],
  "product_categories": [
   "terpene",
   "other"
  ],
  "cssClass": "hybrid",
  "anchor": "r14c1"
 },
 "r36c1": {
  "start": 17644,
  "end": 46916,
  "idx": 1,
  "orfs": [
   {
    "start": 17673,
    "end": 18467,
    "strand": 1,
    "locus_tag": "ctg36_19",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,673 - 18,467,\n (total: 795 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 233.3; E-value: 5e-71)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_19 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00005.30 (ABC transporter): [30:189](score: 114.2, e-value: 6.7e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_19 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00005.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_19_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSDTTVGGVAFDVPMVLAEQVTKSFGSHEVLKGITLEVKRGEVMCLVGPSGSGKSTFLRCINHLEVLSAGRLSVDGELIGYREANGKLYEMAPKEAAKQRRDIGMVFQRFNLFPHMTALQNVMEAPLRVKGLPKAQVERTARDLLARVGLADRADYYPAHLSGGQQQRVAIARALAMEPKLMLFDEPTSALDPELVGEVLDVMKALAKEGMTMIVVTHEMGFAREVADSLVFMDAGVVVESGLPSEVLANPRHARTQAFLSKVL\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGACACGACAGTGGGGGGCGTCGCATTCGACGTGCCGATGGTGTTGGCCGAGCAGGTGACCAAGAGCTTCGGCTCGCACGAGGTGCTCAAGGGCATCACCCTCGAGGTCAAGCGCGGTGAGGTGATGTGCCTGGTCGGGCCCTCGGGCTCCGGCAAGTCCACGTTCCTGCGCTGCATCAACCACCTCGAGGTGCTCTCGGCCGGCCGGCTCAGCGTGGACGGCGAACTGATCGGCTACCGCGAGGCGAACGGCAAGCTCTACGAGATGGCGCCGAAGGAAGCGGCCAAGCAGCGCCGCGACATCGGCATGGTCTTCCAGCGCTTCAACCTGTTCCCGCACATGACCGCGCTGCAGAACGTGATGGAGGCGCCGCTGCGCGTCAAGGGCCTGCCCAAGGCGCAGGTCGAACGCACCGCGCGCGACCTGCTCGCCCGGGTGGGGCTGGCCGACCGGGCCGACTACTACCCGGCGCACCTCTCCGGCGGTCAGCAGCAGCGGGTGGCCATCGCCCGGGCGCTGGCCATGGAGCCCAAGCTGATGCTCTTCGACGAGCCCACCAGCGCGCTCGACCCCGAGCTCGTCGGCGAGGTGCTCGACGTGATGAAGGCCCTGGCCAAGGAGGGCATGACCATGATCGTGGTCACCCACGAGATGGGCTTCGCCCGTGAGGTCGCCGACTCCCTGGTCTTCATGGACGCCGGCGTCGTCGTCGAATCCGGCCTCCCCTCGGAGGTCCTGGCGAACCCGCGGCACGCCCGCACCCAGGCGTTCCTCTCCAAGGTGCTTTAA",
    "translation": "MSDTTVGGVAFDVPMVLAEQVTKSFGSHEVLKGITLEVKRGEVMCLVGPSGSGKSTFLRCINHLEVLSAGRLSVDGELIGYREANGKLYEMAPKEAAKQRRDIGMVFQRFNLFPHMTALQNVMEAPLRVKGLPKAQVERTARDLLARVGLADRADYYPAHLSGGQQQRVAIARALAMEPKLMLFDEPTSALDPELVGEVLDVMKALAKEGMTMIVVTHEMGFAREVADSLVFMDAGVVVESGLPSEVLANPRHARTQAFLSKVL",
    "product": ""
   },
   {
    "start": 18548,
    "end": 18925,
    "strand": -1,
    "locus_tag": "ctg36_20",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,548 - 18,925,\n (total: 378 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_20 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13564.9 (DoxX-like family): [6:112](score: 86.6, e-value: 1.1e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_20\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_20\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACATCGCCATCTGGATCATCACCGGTCTGCTCGCCCTCGCCTTCATCGGTGCCGGGATCATGAAGGTGGCCCAGCCGCGCGCCAAGCTCGCCGCGAGCGGCATGGCCTGGACCAACGACTTCTCGGATACGGGCGTCAAGCTCGTCGGCCTCGCCGAACTGCTCGGCGGGCTCGGGCTGATCCTTCCCGCGGTCACCGGCACAGCGCCCATCCTCGTGCCCATCGCCGCGGCCGCCCTCACCGTGATCATGATCGGCGCGGTCGTCTGGCACGTGCGCGCCGGCGACGGCGCCAAGGAGACCATGCCCAGCGTGATCCTCGGCATCCTGTCTCTCGTCGTGGCCATCACCCGCTTCGGCCCCTGGGCGTTCTAG",
    "translation": "MNIAIWIITGLLALAFIGAGIMKVAQPRAKLAASGMAWTNDFSDTGVKLVGLAELLGGLGLILPAVTGTAPILVPIAAAALTVIMIGAVVWHVRAGDGAKETMPSVILGILSLVVAITRFGPWAF",
    "product": ""
   },
   {
    "start": 19047,
    "end": 19523,
    "strand": 1,
    "locus_tag": "ctg36_21",
    "type": "regulatory",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,047 - 19,523,\n (total: 477 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1135:MarR family transcriptional regulator (Score: 78.3; E-value: 7.1e-24)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_21 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01047.25 (MarR family): [40:99](score: 46.7, e-value: 2.4e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_21 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01047.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity<br>\n  \n   PF01047.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_21\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_21_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_21\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGAACCGGAGTGGCTGACCCCCGTGGAGCACGACGCCTGGATGGCCCTGGCGGAGGTGTTGTTCCTGCTGCCGGCCAGGCTCGAGTCGCAGTTGCAGCGGGACGATGGGCTCGCGATGGCGGACTACATGGTGCTGGTGATGCTCTCCGAACGGGACGACCACAGCATGCGCATGAGCGACCTGGCGACCTCGGCGAGCACGTCGCAGTCGCGGCTGTCACGCATCGTGGCCCGGCTCGAGGCCGCGGGGTATGTGACCCGGGAGATGGCACCGGATGATCGCCGTGCGGTGATCGCGACCCTCACCGAGCCGGGCCTGGCCAAGTTAGTCGCCGCGGCGCCGGGCCACGTCGCCCAGGTGCGCCGCCTGGTCTTCGATCGCCTCACGCCCGCCCAGGTTCTCTCGCTCACCGAGGTCGCCCGCGCCCTCGCGCACCCCGACGACCCCGCCGCCTGCGACGGGGCTCCCTAG",
    "translation": "MAEPEWLTPVEHDAWMALAEVLFLLPARLESQLQRDDGLAMADYMVLVMLSERDDHSMRMSDLATSASTSQSRLSRIVARLEAAGYVTREMAPDDRRAVIATLTEPGLAKLVAAAPGHVAQVRRLVFDRLTPAQVLSLTEVARALAHPDDPAACDGAP",
    "product": ""
   },
   {
    "start": 19793,
    "end": 23869,
    "strand": -1,
    "locus_tag": "ctg36_22",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,793 - 23,869,\n (total: 4077 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_22 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13245.9 (AAA domain): [25:138](score: 25.4, e-value: 1.4e-05)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [229:361](score: 40.5, e-value: 3.2e-10)<br>\n \n  PF04408.26 (Helicase associated domain (HA2)): [487:547](score: 40.8, e-value: 2.3e-10)<br>\n \n  PF07717.19 (Oligonucleotide/oligosaccharide-binding (OB)-fold): [625:702](score: 67.0, e-value: 1.5e-18)<br>\n \n  PF11898.11 (Domain of unknown function (DUF3418)): [715:1357](score: 674.6, e-value: 1.4e-202)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_22 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04408.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004386' target='_blank'>GO:0004386</a>: helicase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_22\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_22_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_22\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTCCCGTGAAAATCACCTTCCCGCCCGAGTTGCCGATCAGCCAGCGCCGCGACGACATCGCGCGCGCCATCCGCGACAACCAGGTCGTGATCGTGGCCGGGTCCACCGGTTCGGGCAAGACCACGCAGCTGCCCAAGATCTGCCTGGAGCTCGGCCGGGAGTCGATCGGGCACACCCAGCCACGCCGGCTCGCCGCGCGCACCATCGCCGAGCGCATCGCCGAGGAACTCGGCCAGGAGGTGGGCGAACTCGTCGGCTACCAGGTGCGCTTCACCGACCGCGTCGGCGCCGACACCCGCATCAAGCTGATGACCGACGGCATCCTGCTCAACGAGATCCACCGCGACCGGATGCTGCGCAAGTACGACACCATCATCATCGACGAGGCGCACGAGCGCAGCCTCAACATCGACTTCCTGCTCGGCTACCTGCAGCAGCTGCTCCCCCAACGGCCCGACCTCAAGCTGATCATCACGTCGGCCACCATCGACCCGGCCAGCTTCGCGAAGCACTTCGCGGCCGCCGACGGCACCCCGGCGCCCATCATCGAGGTCTCCGGCCGCACCTACCCGGTCGAGATCCGCTACCGCCCGCTCGTGGCCGAGGCCGCGATCGACGACGATGACGAGATCTCGGATGCCGCGCCCAGCGTCGACCGCGACTACATCGAGGGCATCTCCGCCGCGCTCGACGAGCTCGAGCGGGAGTCCAACGGCGACGTGCTCGTGTTCCTCTCCGGCGAGACCGAGATCCGAGACGCCGCCGACGCGCTGCAGGGCAAGTTCTCCGGCGGCGGCAACACCAGCCCCACCGAGGTGCTGCCGCTCTACGGCCGGCTCTCCTCCGCCGACCAGCACAAGGTGTTCCAGCCTTCCACCGTGCCCGGGGTGCGCCGCCGCATCGTGCTGGCCACCAACGTGGCCGAGACCAGCCTCACCGTTCCGGGCATCCGTTACGTCATCGACGCCGGCACCGCCCGCATCAGCCGCTACAGCGTGCGCTCGAAGGTGCAGCGGCTGCCCATCGAGGCCATCGCGCAGGCCTCCGCCAACCAGCGCTCGGGCCGGTCCGGCCGCACCAGCGACGGCGTCGCCATCCGCCTGTACAGCGAAGAGGACTTCACCCGCCGGCCCGAGTACACCGAGCCGGAGATCCTGCGCACCAACCTGGCCGCGGTCATCCTGCAGATGATCTCCCTGGGCCTGGGCGACATCGCCCAGTTCCCGTTCCTCACGCCGCCGGACTCGCGCAACATCAAGGACGGCCTCGACCTGCTCACCGAGCTCGGCGCGGTCAAGGCCGTCGTGGCTCCCACCGGCACGCCCACCGAAGACCCGAGTCAGGCCGGTGCTCGCGAGAACGGCCGCTCCGGTCGCGATGGCGGGCGTGGCCGCGGCGGCCGTGACGGCCGTGAGGGCAACCGTGGCGGCGGGCGGATGACCGTGACGGCCGGCACGCACAGCCTCACCCGGGTGGGCCAGCAGCTTGCCCAGCTGCCCATCGATCCCCGGTTCGGCCGCATGGTGATCGAGTCGAAGACGCAGGGCACCAGCCGGGAGGTGATGGCCATCGTGGCCGGCCTCACCATCCAGGACGTGCGCGAGCGTCCGCTCGAGCGCCGCGGTTCCGCCGACGAGAAGCACGCCCGGTTCGCCGACCCCACCAGCGATTTCCTCTCGCTGCTCAACCTCTGGAACTACCTCGAGACGCAACAGAAGGAACTCGGCTCCAGCGCTTTCCGGCGCCTGTGCAAGAACGAGTACCTCAATTACCTGCGGGTGCGCGAGTGGCAGGACGTCTACAAGCAGCTCCGCCAGTTGGCCAAGCCGCTCGGACTGCACATCGGCGACCCGAGCGTGAACCCCGACGGCATCCACCGGTCGATGCTCTCCGGCCTGCTCTCCCACATCGGTCTGAAGGACGTGGCGAAGAAGGACTACATCGGCGCCCGGCAACAGCGCTTCGTGCTGTTCCCCGGCTCGGCGCTGGCCAAGAAGCAGCCCAACGCCGTGATGAGCGCCGAGCTGGTGGAGACCAGCCGGCTGTTCGCCCGGATGAACGCCGTCGTCGACCCGGCCTGGGCCGAACAGCTCGCCGGCGACCTCTGCAAGCGCAGCTACTCCGAGCCGCACTGGGAGAAGAAGCAGGGCGCCGTGGTCGCCTACGAGCGGGTCACCCTCTACGGGGTGCCGATCGTGCCGCGCCGCCGGGTGCAGTTCTCCCGGGTGGATCCAGCCTATGCGCGCGAGCTGTTCATCCGGCACGCCCTCGTCGACGGCGAGTGGGACCTCGACCGGGTCGACCAGCGGGTCACCGCGTTCGACCGGGCCAACACGGCGCTCCGCAAGGAGCTCGCCGAGCTGGAGGAGCGCACCCGGCGCCGCGACATCCTCTTCGACGACGAGGCCGTCTTCGAGTTCTACCACCGCCGCATCCCCGCCGAGGTGCACAGCACCCGCACCTTCGAGACCTGGTGGCGGGTCGCCCGCGCGAAGACGCCCGACCTGCTCACCATGACCGCCGAGGCGCTCGTGCCCGAGGATGCGCCGGAGATCGACGAGTCGCTGTTCCCGCCGTCCTGGCAGCAGCGCGACCAGCGCTTCGCGCTGAGCTACCGGTTCGAGCCCGGTGCGGAGGACGACGGCGTCACCGTGCAGGTGCCTCTCGCCCTGCTTGCGCGGGTCTCCCCCACCGGTTTCGACTGGCAGGTGCCGGGCCTCCGCGCAGACCTCGTCACCTCGCTGATCAAGTCGCTGCCCAAGGCCATCCGCCGCAACGTGGTGCCCGCCGCAGACTGGGCCGTGCGCCTGCTCGCCGAGCTGCCGCCCGCCCCCGGTGTGGTGCGTTCGTCGGTCGAGCCTGTCGAGACCTCGCGAGGTGCCTCGAATCGCGCCCACTCGTCGGTCGAGCCTGTCGAGACCTCGCGGGGTGCCTCGAATCGCTCCAACGCTCACGGGGACTCGGCCGACCCCTCCTTCGCCGAAACCCTCGCCGCCCTCATCCAGCGCCTCACCTACGTGCCCGTCACCGTGCGCGACTTCGACCTCTCCCGGGTCCCCGCGCACCTGCGCATGACCTTCCGGGTCGTCGACGAGCACGGCAAGAGCGTCGCCAGCGGCAAGGACCTCGGCGACCTGCAGCGGCGCCTCGGCAACAAGGTGCGCGAGTCCGTCGCCAAGGCCTCCGCCGCCGTGCCCACGAACGCCATCGAGCGCAGCGGCCTCACCACCTGGGACTTCGTCGAGCTGCCCCGCTTCATCGACACCAAGCAGGGTGACAACACCATCCGCGGTTACCCCACGCTGATCGACGACGGCGCCTCGGTGAGCATCCGCCTGATGAGCACCGCCGAGGAACAGGCCCGCACCCTGCCCCACGGGGTGCGCCGGCTGCTGCTGCTCGCGACCCCGTCGCCCGTGGCCTATGTGCAGCAGCACCTCACGGGCGGCGAGAAGCTCTCGCTGGCCACGAGCCCGTACCGGTCCACCCAGGCCCTGTTCGACGACTGTCTCGCCGCCGCCGTCGATGACGTGCTCTACCGGGTGCGCCCCGACGGCCAGGTGTTCATGAAGGCCGAGTTCGACACCATCCGCGACCGGGTCTCGGGCGTGGTGATGGACTCGATGTTCGAGACCGTCGGCCTCGTCGCCCGCATCCTCACCGCGTCGCGCGCGGCCGACAAGGCGCTCAAGGCCTCCACCAGCATGGCCCTGCTGGCCGCTCTCACGGATGCCCGCGAGCAGCTGAACGGGCTGGTCCACCCGGGTTTCGTCAGCGCCACCGGCCTCGCCCAGCTGCGGCACCTGCCGCGCTACCTCGGCGGCATCACGGCCCGCATCGACAAGCTCCTCGACAACCCCAACCGCGACCGGGTGTGGATGAACGAGGTGCAGTCCGCCACGGCGAAGTTCACCGACGCCGGTGGGCGCATCCCGCTGCCGGCGGATGCGGCGGCGAACCTGGTGCGCGCCCGCTGGATGATCGAGGAGCTGCGCATCAGCCTCTTCGCCCAGGAGCTGCGCGCCGCCGAGTCCGTCTCCCTCCAGCGCATCCAGAAGGTCCTCGCCTCCTAG",
    "translation": "MIPVKITFPPELPISQRRDDIARAIRDNQVVIVAGSTGSGKTTQLPKICLELGRESIGHTQPRRLAARTIAERIAEELGQEVGELVGYQVRFTDRVGADTRIKLMTDGILLNEIHRDRMLRKYDTIIIDEAHERSLNIDFLLGYLQQLLPQRPDLKLIITSATIDPASFAKHFAAADGTPAPIIEVSGRTYPVEIRYRPLVAEAAIDDDDEISDAAPSVDRDYIEGISAALDELERESNGDVLVFLSGETEIRDAADALQGKFSGGGNTSPTEVLPLYGRLSSADQHKVFQPSTVPGVRRRIVLATNVAETSLTVPGIRYVIDAGTARISRYSVRSKVQRLPIEAIAQASANQRSGRSGRTSDGVAIRLYSEEDFTRRPEYTEPEILRTNLAAVILQMISLGLGDIAQFPFLTPPDSRNIKDGLDLLTELGAVKAVVAPTGTPTEDPSQAGARENGRSGRDGGRGRGGRDGREGNRGGGRMTVTAGTHSLTRVGQQLAQLPIDPRFGRMVIESKTQGTSREVMAIVAGLTIQDVRERPLERRGSADEKHARFADPTSDFLSLLNLWNYLETQQKELGSSAFRRLCKNEYLNYLRVREWQDVYKQLRQLAKPLGLHIGDPSVNPDGIHRSMLSGLLSHIGLKDVAKKDYIGARQQRFVLFPGSALAKKQPNAVMSAELVETSRLFARMNAVVDPAWAEQLAGDLCKRSYSEPHWEKKQGAVVAYERVTLYGVPIVPRRRVQFSRVDPAYARELFIRHALVDGEWDLDRVDQRVTAFDRANTALRKELAELEERTRRRDILFDDEAVFEFYHRRIPAEVHSTRTFETWWRVARAKTPDLLTMTAEALVPEDAPEIDESLFPPSWQQRDQRFALSYRFEPGAEDDGVTVQVPLALLARVSPTGFDWQVPGLRADLVTSLIKSLPKAIRRNVVPAADWAVRLLAELPPAPGVVRSSVEPVETSRGASNRAHSSVEPVETSRGASNRSNAHGDSADPSFAETLAALIQRLTYVPVTVRDFDLSRVPAHLRMTFRVVDEHGKSVASGKDLGDLQRRLGNKVRESVAKASAAVPTNAIERSGLTTWDFVELPRFIDTKQGDNTIRGYPTLIDDGASVSIRLMSTAEEQARTLPHGVRRLLLLATPSPVAYVQQHLTGGEKLSLATSPYRSTQALFDDCLAAAVDDVLYRVRPDGQVFMKAEFDTIRDRVSGVVMDSMFETVGLVARILTASRAADKALKASTSMALLAALTDAREQLNGLVHPGFVSATGLAQLRHLPRYLGGITARIDKLLDNPNRDRVWMNEVQSATAKFTDAGGRIPLPADAAANLVRARWMIEELRISLFAQELRAAESVSLQRIQKVLAS",
    "product": ""
   },
   {
    "start": 23956,
    "end": 24612,
    "strand": 1,
    "locus_tag": "ctg36_23",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,956 - 24,612,\n (total: 657 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_23\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_23\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGATGACCTCAGAACCCCCGCCACAGACCTCGACGAGCCCCTGGGTGACCCGCGCGAGATGCTCGCACTGCTCGAAAAGCAGCAGCGCCAGGTGACGGATGCGCAGATCGCGCCCGTCGTCTGGCTCTACTTCATCTGGGGCATCGCCTGGTTCGTGGGCTTCCTCGCCCTCTGGTCGGGCGACGCCGACGGCAACCCCTGGTTCGCGATTCCGGCCGGGGTGGCGACACCGCTGTTCGTCGTGCTGCTGGTCATCTCGATCGTGTCCTCCGCCGTGATCGGTATGCGGATCAACCGGGGGGTGCGCGGAATCTCCAGCTTCTCCGGCGCCGTCTACGGGTTGTCCTGGTCGGTCTGCGGAACCGCGTTCGCGATGCTCGGGGTCGGCCTTATTCGCCAGGGTCTCTCCCCAGAACTGGCCAACCTCTACTTCCCGTCCGGCTATGCGCTGATGTGCGGAACCATCTACCTCGGCGGCGCGGCCCTCTGGCGCGACAAATCCCAGCTCATCCTCGGCCTGATCATGCTCACCGTCGGTGCGGCCGCCCCGTTCGCCGGTTCGCCTGGCAACGACCTGGTCTTCGCCCTCGCCGGCGGTGGTGCCTTCCTGGTTACCTCCGCCGTCATGGCCGTGCGGCTGCGCCGGAACCGCTGA",
    "translation": "MDDLRTPATDLDEPLGDPREMLALLEKQQRQVTDAQIAPVVWLYFIWGIAWFVGFLALWSGDADGNPWFAIPAGVATPLFVVLLVISIVSSAVIGMRINRGVRGISSFSGAVYGLSWSVCGTAFAMLGVGLIRQGLSPELANLYFPSGYALMCGTIYLGGAALWRDKSQLILGLIMLTVGAAAPFAGSPGNDLVFALAGGGAFLVTSAVMAVRLRRNR",
    "product": ""
   },
   {
    "start": 24612,
    "end": 24908,
    "strand": 1,
    "locus_tag": "ctg36_24",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,612 - 24,908,\n (total: 297 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_24 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13601.9 (Winged helix DNA-binding domain): [12:94](score: 76.7, e-value: 1.2e-21)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_24\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_24_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_24\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACGAACTCGACCCGGTGATCCACGCATCCGCGCGGCTCAAGATCACTGCTACGTTGGCCACGCTGCCGGTGGGCGACCAGATCGCCTTTCCCCGCCTCCAGGAACTGCTCGGCATGACCGCCGGCAACCTGTCTACACATCTGCGCAAGCTCGAAGACGCCGGCTATGTCGACGTCGTGAAGTCGCACCAGGGCCGCACCCCGGCCACGTACCTCGCGCTGTCCCGTTCGGGCCGACGCGCCTTCGAGGACTATCTGGAAGCCCTCCGTGCACTGTTGGGAGAATCCGCATGA",
    "translation": "MDELDPVIHASARLKITATLATLPVGDQIAFPRLQELLGMTAGNLSTHLRKLEDAGYVDVVKSHQGRTPATYLALSRSGRRAFEDYLEALRALLGESA",
    "product": ""
   },
   {
    "start": 24905,
    "end": 25912,
    "strand": 1,
    "locus_tag": "ctg36_25",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,905 - 25,912,\n (total: 1008 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 181.7; E-value: 2.9e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_25 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00005.30 (ABC transporter): [20:156](score: 97.9, e-value: 7.5e-28)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_25 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00005.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_25\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_25_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMTVLARLDHVSRRFGEVLAVDDVTLDIHSGSILGLLGPNGAGKSTVLTMLQGLRKPSSGTVSLFGGSPGDYRMRQKLGGTPQETALPPTLRVGEVIDFVGRHFEEPLTTAAVAEEFGLEELLKRQTGALSGGQKRRLSVALAFVGQPSLVLLDEPTTGLDVDARRTLWDAVRRQHDRGATVVVTSHYLEEIEALAERVVVMGHGRVIADDTVAAVINQVSLRQVRLVTDQPDRVSGLPGVVGRDRGDDGSTTFYANDSDRLIVELVRSGIPFTDLTVRGATLEEAFLTLTGATDAATGQPARPPHDAEPLETADVRTRTGSAPSAVPAVQKEMNR\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_25\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGTTCTGGCCCGGCTCGATCACGTCAGCCGCCGCTTCGGCGAGGTGCTCGCCGTCGACGATGTCACCCTCGACATCCACTCCGGCAGCATCCTGGGCCTGCTCGGGCCCAACGGTGCCGGCAAGTCCACCGTGCTCACCATGTTGCAGGGGCTGCGGAAGCCGAGCTCCGGCACGGTCTCGCTGTTCGGCGGGTCGCCCGGCGACTACCGGATGCGCCAGAAGCTCGGCGGCACCCCGCAGGAGACGGCCCTGCCGCCCACCCTGCGCGTGGGCGAGGTCATCGACTTCGTCGGCCGGCACTTCGAGGAGCCGCTGACCACCGCGGCCGTGGCGGAGGAATTCGGGCTGGAGGAGCTGCTCAAGCGGCAGACCGGCGCGCTCTCCGGCGGCCAGAAGCGCCGGCTCAGCGTGGCGCTCGCGTTCGTCGGCCAGCCCAGCCTGGTGCTGCTCGACGAGCCCACCACCGGGCTCGACGTGGATGCCCGCCGCACCCTGTGGGACGCCGTGCGCCGGCAGCACGACCGCGGCGCCACCGTGGTGGTGACCAGCCACTACCTCGAGGAGATCGAGGCGCTGGCCGAACGTGTCGTGGTGATGGGGCACGGGCGGGTGATCGCCGACGACACTGTCGCGGCGGTGATCAACCAGGTCTCACTGCGCCAGGTGCGCCTGGTCACCGACCAGCCCGACCGGGTGAGCGGGCTGCCCGGCGTGGTCGGCCGCGACCGGGGCGACGACGGCAGCACGACCTTCTACGCCAACGACAGCGACCGGCTGATCGTCGAGCTGGTGCGCTCGGGCATCCCGTTCACCGACCTCACCGTGCGCGGCGCCACCCTCGAAGAGGCGTTCCTCACCCTCACCGGGGCGACGGATGCGGCCACCGGGCAACCGGCGCGGCCCCCGCACGATGCCGAACCACTCGAGACCGCCGACGTGCGAACCCGCACCGGCTCGGCCCCGTCTGCTGTGCCCGCCGTCCAGAAGGAGATGAACCGATGA",
    "translation": "MTVLARLDHVSRRFGEVLAVDDVTLDIHSGSILGLLGPNGAGKSTVLTMLQGLRKPSSGTVSLFGGSPGDYRMRQKLGGTPQETALPPTLRVGEVIDFVGRHFEEPLTTAAVAEEFGLEELLKRQTGALSGGQKRRLSVALAFVGQPSLVLLDEPTTGLDVDARRTLWDAVRRQHDRGATVVVTSHYLEEIEALAERVVVMGHGRVIADDTVAAVINQVSLRQVRLVTDQPDRVSGLPGVVGRDRGDDGSTTFYANDSDRLIVELVRSGIPFTDLTVRGATLEEAFLTLTGATDAATGQPARPPHDAEPLETADVRTRTGSAPSAVPAVQKEMNR",
    "product": ""
   },
   {
    "start": 25909,
    "end": 26736,
    "strand": 1,
    "locus_tag": "ctg36_26",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_26</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_26</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,909 - 26,736,\n (total: 828 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_26 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01061.27 (ABC-2 type transporter): [38:232](score: 28.8, e-value: 8.3e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_26 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01061.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0140359' target='_blank'>GO:0140359</a>: ABC-type transporter activity<br>\n  \n   PF01061.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_26\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_26\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCACCCTCACCCCCACCCCGGCCGGCACCGCCCCCGGAACCGGGAGCCGCGTCCCGGCTCTCGGCGGGAGGACGGGCATCCTCGCCCTCACCTTCGTGCACGCCCGCATCAACCTCGTCGAGACGTTCCGCATCCCGGCCGCCCTGATCGGGTCGCTCGTCTTTCCCGGGCTGTCGCTGCTGTTCTTCGTGGTGCCGCAGCGCACCGTGGCCGACAACCCGGAGTTCGCCACCCAGGCGGTGATCGCGTTGAGCGTGTTCGCGCTGATGTCGAACTCGCTGTTCAGCTTCGGCCTGAACATCTCCGCCAACCGCGAGCAGCCCTGGGACCCGTACCTGCGCACCCTGCCGGTACCGGGCGTCTCCCGGGTGCTCGGCCAGATCTTCTCGACCGGCCTGATGGGGCTGGTCTCGATCCTGCCGGTGATCGCGATCGGTGCCCTGTTCACGGCGGCAGAGGCATCCGTTCTCGGTGTTCTCGGCGGGCTGGTGGCGCTGGGCATCTCGGCGCTGCCGTTCATGTTCATCGGCATCTCGATCGGCTACTCGATGTCGTCCAAGGCGGCGATCGCGGTGGTGCAGATCGTGATGTTCGCCCTGGCGTTCGCGGGCGGGCTGTTCCTGCCGCCGTACCTCTTCGCCGACTGGCTCGACACGCTGTCGAAGTTCCTGCCCTCCCGGCAGGCTCGGGAGTTCGTGATCTGGGCCGTGCAGGGCGGCGAGCTCGAGCCGTGGGTGTGGATCGGCATTCTGGTCTGGACCGCGGTGACCTTCGCCCTGGCCTTGCGGCTCTTCCGCCGCGACGAGGGCCGACGGTACCACTAG",
    "translation": "MSTLTPTPAGTAPGTGSRVPALGGRTGILALTFVHARINLVETFRIPAALIGSLVFPGLSLLFFVVPQRTVADNPEFATQAVIALSVFALMSNSLFSFGLNISANREQPWDPYLRTLPVPGVSRVLGQIFSTGLMGLVSILPVIAIGALFTAAEASVLGVLGGLVALGISALPFMFIGISIGYSMSSKAAIAVVQIVMFALAFAGGLFLPPYLFADWLDTLSKFLPSRQAREFVIWAVQGGELEPWVWIGILVWTAVTFALALRLFRRDEGRRYH",
    "product": ""
   },
   {
    "start": 26914,
    "end": 27747,
    "strand": 1,
    "locus_tag": "ctg36_27",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_27</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_27</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,914 - 27,747,\n (total: 834 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1039:aldo/keto reductase family oxidoreductase (Score: 227.4; E-value: 3.7e-69)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_27 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00248.24 (Aldo/keto reductase family): [24:264](score: 163.2, e-value: 7.5e-48)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_27\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_27_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_27\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGAATTCTGTACCCCTCATCACCCTGAACGACGGCCACACCATCCCGCAGCTCGGCTTCGGTGTCTTCCAGGTCGACCCGACCGAGACCACTCGCATCGTGACCGACGCGCTCGAGGTGGGCTACCGCCACATCGACACCGCTGCCATCTACGGCAACGAAGAGGGTGTGGGCCAGGCACTGGCCTCCTCCGGCATCGACCGTTCCGAGCTCTTCATCACGACGAAGCTCTGGAACGACAAGCAGGGCACGCAGTCGGCGCTGGATGCGTTCGACGTGAGCCTGGAGAAGCTCGGCCTGGACTACGTCGACCTCTACCTCATCCACTGGCCGGCGCCCGCGAACGACAAGTTCGTGGAGAGCTGGAAGACCCTCGAGAAGATCCGCGAGTCGGGCCGTGCCCGCTCCATCGGCGTCTCGAACTTCCTGGTGCCCCAGTTGGAGCGTCTGCTCGCCGAGACCGACGTCGTGCCCGCGGTCAACCAGATCGAGCTGCACCCCGCCCTCCAGCAGACCGAGCTGACCACCTTCGCGCGCGAGCAGGGCATCCACATCGAGGCCTGGGGACCGCTCGGCCAGGGCAAGTACCCGCTGCTCGAGGAGGACGTCGTGCTCGCCGCCGCCGAAGCACACGGCAAGACCCCCGCGCAGGTGGTCATCCGCTGGCACCTGCAGAGCGGCAACATCGTCTTCCCCAAGTCGAACCGCCGCGAGCGGATGGCCGAGAACTTCGACGTTCTCGACTTCGAGCTCAGCCACACCGAACTCGCCACGATCACGGCGCTCGAGCGCGGCGGCCGGGTCGGCTCGCACCCCAACGACGTCAACTAG",
    "translation": "MTNSVPLITLNDGHTIPQLGFGVFQVDPTETTRIVTDALEVGYRHIDTAAIYGNEEGVGQALASSGIDRSELFITTKLWNDKQGTQSALDAFDVSLEKLGLDYVDLYLIHWPAPANDKFVESWKTLEKIRESGRARSIGVSNFLVPQLERLLAETDVVPAVNQIELHPALQQTELTTFAREQGIHIEAWGPLGQGKYPLLEEDVVLAAAEAHGKTPAQVVIRWHLQSGNIVFPKSNRRERMAENFDVLDFELSHTELATITALERGGRVGSHPNDVN",
    "product": ""
   },
   {
    "start": 28080,
    "end": 28661,
    "strand": 1,
    "locus_tag": "ctg36_28",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_28</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_28</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,080 - 28,661,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_28 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03358.18 (NADPH-dependent FMN reductase): [5:149](score: 100.4, e-value: 8.5e-29)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_28 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03358.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_28\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_28_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_28\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCGTACACCCTGAACGTCGTCGCCGTCTCCGGCAGCCTGCACGCGCCCTCGAAAACCACCGCGCTGGTGCGGGCGATCCTCGCCGCGCTCGAGCGCGAACTGTCGATCGATGTGCACCTGATCGAGCTCAGCCAGGTGGGCCGGGAGTTCTCCGGGGCGCTGCGCCGGGACGAGCTGTCCGCCGCGGCCGAGGCCGACCTCAAGCGCATCGAGGGCGCCGACCTGCTCATCGTGGCGTCGCCCGTCTACCGGGCCTCGTTCACGGGCCTGTTCAAGCACGTCTTCGACTTCGTCGACCAGTACTCGCTCGTCGACAAGCCCGTGCTGCTGGCCGCGACCGGGGGCAGCGACCGGCACGCCCTCATTCTCGAGCACCAGTTCCGGCCGCTGTTCAGCTTCTTCCAGGCGCTCACCCTGCCCATCGGTGTGTACGCCAAGGACGCCGACTTCACGAACTACGTGGTGACCAGCGACGAGCTGAACGACCGCATCGACCAGGCCATCCGCCGCGGCCTGCCGCTCGTGCGGGCGAGCCTGCCGGCGGTGCTCTCCGCGGACTCCGCCGCGATCGTCTGGTGA",
    "translation": "MSYTLNVVAVSGSLHAPSKTTALVRAILAALERELSIDVHLIELSQVGREFSGALRRDELSAAAEADLKRIEGADLLIVASPVYRASFTGLFKHVFDFVDQYSLVDKPVLLAATGGSDRHALILEHQFRPLFSFFQALTLPIGVYAKDADFTNYVVTSDELNDRIDQAIRRGLPLVRASLPAVLSADSAAIVW",
    "product": ""
   },
   {
    "start": 28713,
    "end": 29411,
    "strand": 1,
    "locus_tag": "ctg36_29",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_29</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_29</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,713 - 29,411,\n (total: 699 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_29 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04973.15 (Nicotinamide mononucleotide transporter): [30:218](score: 169.2, e-value: 9.3e-50)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_29 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04973.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0034257' target='_blank'>GO:0034257</a>: nicotinamide riboside transmembrane transporter activity<br>\n  \n   PF04973.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0034258' target='_blank'>GO:0034258</a>: nicotinamide riboside transport<br>\n  \n   PF04973.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_29\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_29\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGAACCATCCGGGAGAGAAGTATCGCTGTGTCCCTGATCACCTGGTTGTTCGACGCCCAACTCCACATCGGCACCCAGACCATCCTCTGGCGGGAGATCATCGGCAACGTCTTCGGCATCGCAAGCGCCGTCGGCGGGATGCGCCGCAAGCTCTGGGCCTGGCCCGTGGGCATCATCGGCAACGCGCTGCTCTTCACGGTGTTCCTCGGCGCCGTCTTCGGCACCCCCAACCCGGTGAACCTGCTCGGCCAGGCCGGGCGCCAAATCATGTTCATCGTGGTGTCCATCTACGGCTGGGTGCAGTGGTCGCGCAGCCGCTCCACCGGCGCGGTCGCCGTGGCCCCGCACTGGGCGGGCACCCGCGCGCGCATCGGCCTCGGTGTGGGCCTGATCGCCGGCACCCTCGTGCTCACGCCGATCTTCCGGGCGCTCGGTTCGTTCGAACCGGTCTGGGCGGATGCCTGGATCTTCACCGGATCGCTGCTGGCCACCTACGGCATGGCCCGGGGTTGGACCGAATTCTGGCTGATCTGGGTGGCCGTCGACATCGTGGGGGTGCCTCTGCTGATCAGCGCCGGCTACTACGCCTCGGCCGTCCTCTACCTCTTCTACGGCGCGTTCACTATCACCGGGTTCGTGATCTGGGCCCGCGTGCAACGCCGCCGGCAGCTCCTCCCCGAGGGTGCGGCGGTCTGA",
    "translation": "MRTIRERSIAVSLITWLFDAQLHIGTQTILWREIIGNVFGIASAVGGMRRKLWAWPVGIIGNALLFTVFLGAVFGTPNPVNLLGQAGRQIMFIVVSIYGWVQWSRSRSTGAVAVAPHWAGTRARIGLGVGLIAGTLVLTPIFRALGSFEPVWADAWIFTGSLLATYGMARGWTEFWLIWVAVDIVGVPLLISAGYYASAVLYLFYGAFTITGFVIWARVQRRRQLLPEGAAV",
    "product": ""
   },
   {
    "start": 29511,
    "end": 30218,
    "strand": -1,
    "locus_tag": "ctg36_30",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_30</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_30</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,511 - 30,218,\n (total: 708 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_30\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_30\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATGACCCTCGCCGAAGCCGCGGCCTTGCTCGAGGTCGCGGTCGATGCGCATCCCGAGCAGGTCGAACGCGCCTACCGCTACCAGGCCCAGCGATCGCACCCGGACCGGATGACCTCGGCCAGTCCGGCGGAGCTCGCCGCCGCCGCTGCCCGGTTCGACAGGTTCACCCAGGCGCGCGCGCTGCTGCGCGAGGCCGACGCCGAGCGGATGCGCCCCGCCGCCGACGCATCGCCGGGGCACCCTGCCGCGTCGGGCGCATCCGCTGCACCGGGCCGGCGGCCGGCCGACAGCTCCGCCTGGGCGGATCCGAACTGGGCGGCCGACGAGCCCTACGAACCTGCGCTACCGGCCGGGCCGTGGCTGTTCTGGGTGTGGACGGGCCTGTTCGTGCTCGCGGCCGGGATCTCGTACCTCGGCGGGCCGCTGCCGCAATCGGCGGCGGACCTGTGGCTGCGGGTAGTGCCGCTCGGGCTGGCCAGCGTGGCCTTCGCCCGCACGGGCCGGCCGGTGTTCCTCGCTGGAGTCCTGGTGTTCGGGGCGGCGACGGCGGTGCTCACCGTGCTGTTCGCGTCGTTCGGTCCGCTCGTGACGCTGCAGTTGCTCATCGCGCCCGTGCTGGGGCTCGTGGCGCTCGGCCGGCCCAAGCAGCTGCGCCGCCGCCTCGGCCCGGTCGCGCCGGCTCCCCCGCCGCGTCCCGCCGCCTGA",
    "translation": "MMTLAEAAALLEVAVDAHPEQVERAYRYQAQRSHPDRMTSASPAELAAAAARFDRFTQARALLREADAERMRPAADASPGHPAASGASAAPGRRPADSSAWADPNWAADEPYEPALPAGPWLFWVWTGLFVLAAGISYLGGPLPQSAADLWLRVVPLGLASVAFARTGRPVFLAGVLVFGAATAVLTVLFASFGPLVTLQLLIAPVLGLVALGRPKQLRRRLGPVAPAPPPRPAA",
    "product": ""
   },
   {
    "start": 30215,
    "end": 30307,
    "strand": -1,
    "locus_tag": "ctg36_31",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_31</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_31</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,215 - 30,307,\n (total: 93 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_31\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_31\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGAGCTGGGCACTGGTTCCGGGCAGCCGCACGACTTCCGAGGCGCACTCCCGGCACGGCGCGGCCGGCCGGATCGAGCGCCGTCGATGA",
    "translation": "MKSWALVPGSRTTSEAHSRHGAAGRIERRR",
    "product": ""
   },
   {
    "start": 30538,
    "end": 32424,
    "strand": 1,
    "locus_tag": "ctg36_32",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_32</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_32</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,538 - 32,424,\n (total: 1887 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_32 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03190.18 (Protein of unknown function, DUF255): [1:163](score: 222.3, e-value: 3.4e-66)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_32\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_32_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_32\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGAATCGCCTCGCCGACGCCATCAGCCCGTACCTGCGCTCGCACGCCGAAAACCCGGTGGACTGGCAGCCCTGGGGCGCGGCCGCGTTCGACGAGGCCCGCGCCCGCGACGTGCCGGTGCTGGTGTCGATCGGCTACTCCACCTGCCACTGGTGCCACGTCATGGCCCGCGAGAGTTTCAGTGATCCTGCGATCGCCGCCTACCTCAACGAGCACTTCGTGAGCATCAAGGTGGACCGCGAGGAGCACCCCGACGTCGATGCCAGCTACCTCGCCGCCGCCGGAGCCTTCACGCAGAACCTCGGCTGGCCGCTCAACGTGTTCGTCACCCCGGCCGGCCGGCCGTTCTACGCCGGCACCTATTCCCCGCCCGCGCCGCTGCCCGGGCATCCGGCGTTTCGCGAGGTGCTCGCCGCCGTGACGGATGCCTGGACCACCCGCCGCGACGCCGTGGAGGACAGCGCCGCCGGGCTGGCCGAGGCCCTCGCCCAGGCCGCGCCCGCCGCGGGGGCCGGGGAGCTGCCCGGCCAGGACCGGCTCGCCGAGACCGTGGACCTGCTCGCGACCGCCGAAGACCCGGTCTACGGGGGTTTCGGCACCGCCCCCAAGTTTCCGGCCTCACCCACCCTGGCGCTGCTGCTCGACCGTGCCGACGGACGCGACCTGGCCCTGCGCACCCTCAAACGGCTGGGCGCGACGCCGCTCCGCGACCCCGTCGAGGGCGGGTTCTTCCGGTACGCCGTCAACCGGGACTGGAGCGAACCGCACTACGAGCGGATGCTCTACGACAACGCCCAGCTGCTCGAGCTGTACACCCGGGCGTGGATGCTCACCGGCGAAGCCTGGGCCCGGCTGGTGAGCGAGGGGCTGGTGCGGTTCCTCGGCGCGGTGCTGCAGCTGCCGGACGGCGGATTCGCCAGCGCCCAGGACTCGGAGAGCACCGTGGACGGGGTGCGTGTGGAGGGCGGCTACTACGCCCTCGACGAGGACAGCCGCCATGACCAGGTGCCGCCGGCCCTGGACACCAAGATGCTCACCGGCTGGAACGGTCTTGCGATCGGCGCCCTCGCGCTCGCCGGGTCGGCCTTCGGCGACGACACCGCGCTCAGCCTGGCCCGCCGGGCGGCGGACCGGCTGCTGCAGCTGCACCGGCGGGACGACGGCGCCCTGGTGCGCGCCTCCATCGACGGCCGGCTCTCGACCGCCGTGGCCACGCTCGAGGACTACGGGATGTTCGCCGGCGGTCTGCTCGACCTTGCGACCGCCACCGGCGAGGTGCGCTACGCCGTCGCGGCGCGCGACCTCGTCGACCGCACCCTGCCCGGCCCGGCACCGGCCGGTTTCGCCGCGCCGGAGGGCGCCGATCCGGTGCTCACCGGCCACGGCCTCGACCTGGCGACCGACCCGTCCGAGGGCGCCTATCCCTCCGGGCTCAGCGCCATCGCCGCCGCGGCCTGGCGGCTCTACCTGCTCACCGGCAGCACCCGGTACCGGGAGGCGGCGACGGCGGCCATGGTGCGGCTGGTCGGAACCGGAACGCTCAACCCACTCGCGTTCGGCGCCGCCCTGCGCCTGGTGGACGCGCTCACCTCGCCGGTTCGGCAGCTCGTGGCGGTCACCCCGGAGACGCCGGCGGGCACCCGCGCCGGCGAACCCGAGAGCGGTGGCACGCCATCCGCCGCCTCGCCCGGCAGCCTGGTCGGCGCCGCCCGGCGCCGGAGCGGCCTCGTGGCCGTCGTCACCGAAGACCAGGGCCGCGCCTGGGCGGCGGCCGGCTTCGACCTCTTCGCCGACCGCGGCGTGCGCGACGGCCGGCCCACCGCCTACCAGTGCCGGGATTTCGTCTGCCGGCTGCCCGTCACGGAGCCCGCAGACCTGGCCTGA",
    "translation": "MTNRLADAISPYLRSHAENPVDWQPWGAAAFDEARARDVPVLVSIGYSTCHWCHVMARESFSDPAIAAYLNEHFVSIKVDREEHPDVDASYLAAAGAFTQNLGWPLNVFVTPAGRPFYAGTYSPPAPLPGHPAFREVLAAVTDAWTTRRDAVEDSAAGLAEALAQAAPAAGAGELPGQDRLAETVDLLATAEDPVYGGFGTAPKFPASPTLALLLDRADGRDLALRTLKRLGATPLRDPVEGGFFRYAVNRDWSEPHYERMLYDNAQLLELYTRAWMLTGEAWARLVSEGLVRFLGAVLQLPDGGFASAQDSESTVDGVRVEGGYYALDEDSRHDQVPPALDTKMLTGWNGLAIGALALAGSAFGDDTALSLARRAADRLLQLHRRDDGALVRASIDGRLSTAVATLEDYGMFAGGLLDLATATGEVRYAVAARDLVDRTLPGPAPAGFAAPEGADPVLTGHGLDLATDPSEGAYPSGLSAIAAAAWRLYLLTGSTRYREAATAAMVRLVGTGTLNPLAFGAALRLVDALTSPVRQLVAVTPETPAGTRAGEPESGGTPSAASPGSLVGAARRRSGLVAVVTEDQGRAWAAAGFDLFADRGVRDGRPTAYQCRDFVCRLPVTEPADLA",
    "product": ""
   },
   {
    "start": 32819,
    "end": 34534,
    "strand": 1,
    "locus_tag": "ctg36_33",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_33</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_33</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,819 - 34,534,\n (total: 1716 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_33 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17101.8 (Stealth protein CR1, conserved region 1): [209:237](score: 35.5, e-value: 6.4e-09)<br>\n \n  PF11380.11 (Stealth protein CR2, conserved region 2): [247:352](score: 131.6, e-value: 1.3e-38)<br>\n \n  PF17102.8 (Stealth protein CR3, conserved region 3): [397:444](score: 65.0, e-value: 4.7e-18)<br>\n \n  PF17103.8 (Stealth protein CR4, conserved region 4): [473:521](score: 52.9, e-value: 2.8e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_33 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF11380.11: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016772' target='_blank'>GO:0016772</a>: transferase activity, transferring phosphorus-containing groups<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_33\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_33_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_33\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCCATCCTCTCGCTGAGCAGCGAACCCGAACCGGTGCTGCTCTCCCTCGACGAGCGCACCCGCCGTTTCGACCGCGACGACGTCGTCGTGCGCAAGGGCGAGATCGCCTTGATCAACGGGCACTTCACCCCGCACGAGTCCATGGTCAGCGACCTGCTCGCCCTGAGCGCCGCGCTCGACAACGCCGGCATCGAGTACTTGCTCGTGCGCGGCGACCACGACCGCCCGGTCATCGCGGTCAACCGCAAACGGCGCAAGCAGATCAGCAAGATCCTGAGCAGCGCCTTCTCCGACACCCCGTTCTACATCAAGCCGCTCGACAACGACGAGGCCCGGGCCGGCCTGCTCGCCGACGGCGCCCTCGCCCAACTGCGCAAGTCCGATGTCTTCCGCGCATACCAGCCGCGCATCGAACCCATCGGCCGGCTCCGCTACGGCGCCGAGACCGCCTTCCAGCTCGAGCTGTGGACCTTCGGCGAAGACGAGATCATCGCCCCCGTCGAGAACGTGCTGATGCGCAAGCGCCTGCCCCGCTCCGAGGCGCGGGAGACCACGGTGGAGCTGTTCGGCCGCAGCTGGCGCACCCTGCAGAACATGTTCGACGACCTGGTCAGCGACATCAGCTTCGACATCGACCTGGTCTTCTCCTGGGTCGACGGGTCCTCCACCGACTTCCAGAAGGCCCGCGCCGCCCGCATGAAGTCCTACGTGGTGGGCGAGGGCGACGACTCGGATGCCCGTTTCCGGCAGATCGACGAACTCAAGTACGCCCTGCGCAGCGTGTACATGTTCGCGCCGTGGGTGCGACGCATCTTCATCGCCACCGACTCGCCGGCCCCCGAATGGCTGGTCGAGCACCCCCGGGTGACCATCATGAACAGCGAAGACTTCTTCCCCGACACCAGCGGGCTGCCCACCCACAACTCGCACGCCGTGGAGAGCCAGCTGCACCACATCCCGGGGCTCGCGGAGCACTTCATCTACTCCAACGACGACATGTTCTTCGGCCGCCCGGTGGGCCCGGAGCTGTTCTACTCGCCCGGCGGCATCACCAAGTTCATCGAGGCGGCGACCCGCATCGGCCTGGGCGACAACGACCCCAGCCGCAGCGGGTTCGAGAACGCCGCCCGGGTCAACCGGGCCCTGCTGCGCGAGCGGTTCGGCAAGGTGACCACCCGGCACCTCGAGCACACCCCTGCGCCCCTGCGCAAGAGCGTCATGCAGGAGATGGAGGCGGAGTTCCCCGAGGACTTCACCCGCACCATGAAGAGCCGGTTCCGCTCCGCCACCGACATCTCGGTGACGAACTCGCTGTACCACTACTACGCCCTGGCCACCGGCCGGGCGGTGGAGCAGACCCAGGCGCGGTCGCTCTACGTGGAGACCACCCTCAAGCTGGCGCTGCGCCAGATGAGCAAGCTGCTCAAGCGCCGCGACCAGGACATGTTCTGCCTCAACGACGGCAGCTTCCCCGAGATCTCCGACGAGGTGCGCACCGAGGCCGTCACTGACTTCCTCGAGCGCTACTTCCCGATCGTGGCTCCGTGGGAACGCGAAAGCGTCATCGCGGAGAGCCAGCACGGCGAGGACACCCTCATCGAGAGCGTCCTCGGCACCGGCTCCGCCGCGATGGCGGCCGACGTCAGCGCAGAACCGGGATCGGCCTGGTCATTGGGGGCTCGCGGTACGCGGGCAGAGACCCAGCAGGCATGA",
    "translation": "MPILSLSSEPEPVLLSLDERTRRFDRDDVVVRKGEIALINGHFTPHESMVSDLLALSAALDNAGIEYLLVRGDHDRPVIAVNRKRRKQISKILSSAFSDTPFYIKPLDNDEARAGLLADGALAQLRKSDVFRAYQPRIEPIGRLRYGAETAFQLELWTFGEDEIIAPVENVLMRKRLPRSEARETTVELFGRSWRTLQNMFDDLVSDISFDIDLVFSWVDGSSTDFQKARAARMKSYVVGEGDDSDARFRQIDELKYALRSVYMFAPWVRRIFIATDSPAPEWLVEHPRVTIMNSEDFFPDTSGLPTHNSHAVESQLHHIPGLAEHFIYSNDDMFFGRPVGPELFYSPGGITKFIEAATRIGLGDNDPSRSGFENAARVNRALLRERFGKVTTRHLEHTPAPLRKSVMQEMEAEFPEDFTRTMKSRFRSATDISVTNSLYHYYALATGRAVEQTQARSLYVETTLKLALRQMSKLLKRRDQDMFCLNDGSFPEISDEVRTEAVTDFLERYFPIVAPWERESVIAESQHGEDTLIESVLGTGSAAMAADVSAEPGSAWSLGARGTRAETQQA",
    "product": ""
   },
   {
    "start": 34464,
    "end": 35402,
    "strand": -1,
    "locus_tag": "ctg36_34",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_34</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_34</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,464 - 35,402,\n (total: 939 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Metallophos_2<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_34 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00149.31 (Calcineurin-like phosphoesterase): [15:209](score: 63.1, e-value: 5.6e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_34 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00149.31: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_34\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_34\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGCATTCGAACGGCCGAATACCCCAGGCCGGATTATTTCCTTCTCCACCTCAGTGACACGCACCTGCTCGCAGACGGTAACCGTCTGTACGGCAGCGTCGACAGTGCCGCACACGTGCAACGGTTGTTTGCGGATGTGGAGGCGTCGGGCAGCAGGCCGGACGCCATCATCATCACCGGCGACCTGGCCGACAAGGGCGAACCACATGCCTACGCGCAGCTGCGCGACATCGTGGAACCCGCGGCCGCACGCATCGGCGCCAAGGTGCTCTGGGTGATGGGCAACCACGACAACCGGGCGAACTTCCGCACCGAGTTGCTCGGCCAGGAGCCCAGCCTCGCCCCGATCGACCACGTCGACTATGTCGGCGGGCTGCGCATCATCACCTTCGACACCACCGTTCCGGGCAGCCACTACGGTGAGATCTCCGATCGCCAGCTCGAATGGCTCAGCGAGCAGCTGAGCTTCCCGGCGCCGGACGGCACCATTCTGGCCATGCACCACCCGCCCGTGCCGAGCATGCTCGACCTGTCGGTGGCGGTGGAGCTGCGCGACCAGGCCAGCCTCGCGCAGGTGCTGCGCGGCACGGATGTGCGCAGCATCCTGGCCGGGCACCTGCACTACTCGTCCACCGCGACCTTCGCCGGCATCCCCGTGTCCGTGGCCTCGGCCACCTGCTACACGCAGGACCTCAACGTTCCCGTCGGGGGCACCCGGGGCCGCGACGGCGCCCGGGCGTTCAACCTCGTGCACGTCTACGCGGACACCGTGCTGCACTCGGTGGTGCCGCTGGGCGAATACGAGGCGCTGGACTACATCGACGCGGCCGAAAGCGCCCGCCGCTTGGCCGCATCCGGCATCGAGATCATGCCTGCTGGGTCTCTGCCCGCGTACCGCGAGCCCCCAATGACCAGGCCGATCCCGGTTCTGCGCTGA",
    "translation": "MSIRTAEYPRPDYFLLHLSDTHLLADGNRLYGSVDSAAHVQRLFADVEASGSRPDAIIITGDLADKGEPHAYAQLRDIVEPAAARIGAKVLWVMGNHDNRANFRTELLGQEPSLAPIDHVDYVGGLRIITFDTTVPGSHYGEISDRQLEWLSEQLSFPAPDGTILAMHHPPVPSMLDLSVAVELRDQASLAQVLRGTDVRSILAGHLHYSSTATFAGIPVSVASATCYTQDLNVPVGGTRGRDGARAFNLVHVYADTVLHSVVPLGEYEALDYIDAAESARRLAASGIEIMPAGSLPAYREPPMTRPIPVLR",
    "product": ""
   },
   {
    "start": 35571,
    "end": 36023,
    "strand": -1,
    "locus_tag": "ctg36_35",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_35</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_35</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,571 - 36,023,\n (total: 453 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_35 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00011.24 (Hsp20/alpha crystallin family): [33:129](score: 78.0, e-value: 5.4e-22)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_35\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_35_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_35\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTATGAACTACGATCCCTTCCGCGAACTGGATCGCGTCGCCGGTGCCCTGATGGATGTGCGCGGGCCGCGCGTGATGCCCATGGACCTGTACCGGTCCGGCGACGTGTACGTGCTCGACGCCGATATGCCCGGCATCGACCCCGGCTCGGTCGACATCGATGTGGACGGTCAACTGCTCACGATCCGGGGCGAGCGCACCCTGGCCAGCCACGACAACGTGAAGTGGCTCACCCGGGAGCGCACGGCGGGGTCGTTCCTCCGCCAGCTGAACCTCGGGCAGGGCATCGACCTCGACAACATCAGCGCCAAGTACGCCAACGGCGTGCTCTCGGTGACGATCCCGGTGAGCGAGGCGGCCAAGCCGCGCAAGATCGAGGTGAGCACCGAAAACGCCGACCGGCAGGAGACCCTGACGGTCAAGGAAGGCGAGAAGCACCTGGAGAAGTAG",
    "translation": "MAMNYDPFRELDRVAGALMDVRGPRVMPMDLYRSGDVYVLDADMPGIDPGSVDIDVDGQLLTIRGERTLASHDNVKWLTRERTAGSFLRQLNLGQGIDLDNISAKYANGVLSVTIPVSEAAKPRKIEVSTENADRQETLTVKEGEKHLEK",
    "product": ""
   },
   {
    "start": 36259,
    "end": 36486,
    "strand": -1,
    "locus_tag": "ctg36_36",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_36</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_36</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,259 - 36,486,\n (total: 228 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_36\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_36\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCACTAAGAAGACGAAGCAGGCACGTGCCGACCGCGCGGCCGAGCGACGTCGGGAGCCCGATGACCCCCGCGATCGCGGCGGCTTTCCCGGGCTCGAGGGCGACTTCGAGTCCGAGCGCCGCCGCGCGGTGAGCGCCAGCCACGAACATGCCGAGCCCTACGAGCACGGCGAGGGCGAGACCCCGGTTCTGCCCTCCACGACACCGGGCCTCACCCACCCCTGA",
    "translation": "MSTKKTKQARADRAAERRREPDDPRDRGGFPGLEGDFESERRRAVSASHEHAEPYEHGEGETPVLPSTTPGLTHP",
    "product": ""
   },
   {
    "start": 36614,
    "end": 37450,
    "strand": 1,
    "locus_tag": "ctg36_37",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_37</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_37</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,614 - 37,450,\n (total: 837 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_37 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01569.24 (PAP2 superfamily): [97:191](score: 34.3, e-value: 2e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_37\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_37\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGTCTTCGTCTTCCCGCCTCACGCCCGCCCGTTATGTGGGCGCCGCCGTGCTCTGCGCCGCCGCGTTCCTGGTGCTGTACCTGTTCTTCGTCCGTGACGAGACCGGGCAGGCCATCGACCAACTGGCATTCAACGGCGCCGAGAACGAGACCACGGGCACCCAGGTCACGCTGAGCCTGCTCGACCTGATCCCCTCGGTGATGGTCGGCGTCGGCGCGATCGTGAGCCTGGCCATCGCCGCCGTGCGGCGCGCCTGGTTCCCTCTTCTCGTGGCGGTCGGCAGTGCGATGGCCGCCGTCGTCACCACCCAATTGCTCAAGAACATCGTGCTCACCCGCCCGGATCTCGGGGTGGAGGGCTACGTGTCCAACTCCTTCCCGTCCGGGCATACGACCGTCGCTGCGGCATCCGCCCTCGTCGTGTTCCTGGTGGCCAGCCCGCACACGCGCTGGCTGGCCGGCACGATCGGCGCCGCCTTCGCCGTGGCCGCCGGGGTGTCCACGCTGGTCAGCCTCTGGCACCGGCCCAGCGACGTGATCGCCGCCCTGCTCGTGGTCTCCTTCTGGGGCTGCGTGGGCGGCGCCGTGCTCACCCGGTCCGGCGGTCGCCAGCGCACCGCACGCACGCCCACCCCGGCGCGAGTGGGGCTGCGCCTGCAGACCTGGATCGCCGTGCTCGCCGCGATCGTGACCGCCGTGGCCGTGGGGATCGGCGCCACCGGGGCGTTCGGCACCTCCGCCGCCCCCGCCGCGTACCTCGGCGCGGTCACCGCCATCGTGGCCGTGGGATTCGCGCTCGCCATCACCGCGACCCGGCTGTTCGACCGGCTGCCGTAA",
    "translation": "MSSSSRLTPARYVGAAVLCAAAFLVLYLFFVRDETGQAIDQLAFNGAENETTGTQVTLSLLDLIPSVMVGVGAIVSLAIAAVRRAWFPLLVAVGSAMAAVVTTQLLKNIVLTRPDLGVEGYVSNSFPSGHTTVAAASALVVFLVASPHTRWLAGTIGAAFAVAAGVSTLVSLWHRPSDVIAALLVVSFWGCVGGAVLTRSGGRQRTARTPTPARVGLRLQTWIAVLAAIVTAVAVGIGATGAFGTSAAPAAYLGAVTAIVAVGFALAITATRLFDRLP",
    "product": ""
   },
   {
    "start": 37644,
    "end": 38798,
    "strand": 1,
    "locus_tag": "ctg36_38",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_38</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_38</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 37,644 - 38,798,\n (total: 1155 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T3PKS: Chal_sti_synt_N<br>\n \n  biosynthetic (rule-based-clusters) T3PKS: Chal_sti_synt_C<br>\n \n  biosynthetic-additional (smcogs) SMCOG1024:chalcone and stilbene synthase domain protein (Score: 365.7; E-value: 3.1e-111)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_38 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00195.22 (Chalcone and stilbene synthases, N-terminal domain): [45:183](score: 96.7, e-value: 1.4e-27)<br>\n \n  PF02797.18 (Chalcone and stilbene synthases, C-terminal domain): [300:380](score: 69.5, e-value: 3.3e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_38\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_38_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_38\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGGCGCAGCGGTTGGTGACGGCATCCTTCAATCTGTCCGGCATCGACACCCGGCATACCGTGATCGAGGAACTCACCCTCGATTCCACCGTGGCCGAGCCGCAGTTCTTCGACGCCGCCACCCAGCGGCTGCTCGTTCCCGGCACCAAGGTGCGCAACGAGCTCTACATCGAGCAGGCCACGAAGCTGTTCGTGGAGGCCGGCCGGCGCGCCATCGCCGCCTGCCCGGGGCTGGAGGCCGCGGACATCACCCACGTCGTGACCGTCTCGTGCACCGGGTTCTACGCGCCCGGACCCGACTACATGCTCGTGCGCGAGCTGGGCCTGTCCCCGTCGACGCAGCGGTACCACCTGGGCTTCATGGGCTGTTACGCGGCGATGCCGGCCCTCCGCACCGCCAAGCAGTTCGTGGAGGCCGACCCGAACGCCGTCGTGCTCGTCGTCAGTGCCGAGCTGTGCTCGCTGCACCTGCGCACCTCGAGCGACCCCGACACCATCGTGGCCTCCTCCCTCTTCTCGGATGGCGCGGCCGCGGGCATCGTGAGCAGCCGCCGGCCGTCCGCCGGCGAGAACGCCCTCAACCTCGACCACTTCGAGACCGTGATCACCCCCGTGGGCGAGGGCGACATGGCCTGGAAGATCGGCGACGAGGGGTTCGAGATGATCCTCAGCTCATACGTGCCGCACATCATCGACGAGCACATCGAGTCGGCCCTGGCGCCGCTCTTCGGCCGCGACGACGCGCTGACCCGGGCCCTCGCGGCTGGCGTGCTCGCCGAGGCCGGCGCCGTGACGGCGCAGGCACAGGACGACGGGGCGGATGCCGCCTCCGCCGCTGCCGAACCCGGCCAGGTGCTCACCGCCGCGGCACCCGGCTCCCCGCTGAGCACGGCGATCGCGCACTGGGCGATCCATCCGGGCGGGCGCAGCATCCTCGACAAGACCGAGACCAAGCTCGGGCTCACCGAGGCGCAGCTGGTTCCCTCCCGGGAGACCCTGCGCACGAACGGCAACATGTCCAGCGCCACCATCCTCTTCGTCATGAAGGCGATTCTCGAACAGGAGAACGCCGCGGACGGGGACCGGGTCTGCGCCATGGCGTTCGGGCCGGGGTTGACCGTGGAGTCGAGCCTGATGACCGTGCTGCGCGGCTGA",
    "translation": "MAQRLVTASFNLSGIDTRHTVIEELTLDSTVAEPQFFDAATQRLLVPGTKVRNELYIEQATKLFVEAGRRAIAACPGLEAADITHVVTVSCTGFYAPGPDYMLVRELGLSPSTQRYHLGFMGCYAAMPALRTAKQFVEADPNAVVLVVSAELCSLHLRTSSDPDTIVASSLFSDGAAAGIVSSRRPSAGENALNLDHFETVITPVGEGDMAWKIGDEGFEMILSSYVPHIIDEHIESALAPLFGRDDALTRALAAGVLAEAGAVTAQAQDDGADAASAAAEPGQVLTAAAPGSPLSTAIAHWAIHPGGRSILDKTETKLGLTEAQLVPSRETLRTNGNMSSATILFVMKAILEQENAADGDRVCAMAFGPGLTVESSLMTVLRG",
    "product": ""
   },
   {
    "start": 38830,
    "end": 39543,
    "strand": 1,
    "locus_tag": "ctg36_39",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_39</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_39</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38,830 - 39,543,\n (total: 714 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1269:hypothetical protein (Score: 223.1; E-value: 5.3e-68)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_39 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08241.15 (Methyltransferase domain): [54:146](score: 40.3, e-value: 4e-10)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_39 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF08241.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008757' target='_blank'>GO:0008757</a>: S-adenosylmethionine-dependent methyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_39\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_39\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGACGCCGTCGAGATCATGGACGATCCGGACTGCGACCCCGACAAGCTCCGCCGCACCTACGCGAACTTCCGGTATGTCAACGCCGTCGTGTCCGGCCTCCGGCACACCTACCGGCACGATATCCGGCCGTTGCTCTCGCCCGACGTGCCGCGCACGCTGCTCGACATCGGCTCGGGCGGCGGCGATGTGGCCCGGTCGCTGGCACGCTGGGCGGCCAGGGACGGACTGCGCCTGACCGTGACGGGCATCGACCCGGACGCCCGCGCCCACGACTACGCCACCAGCCTGCCGCCGCTGGCCGGGCTCACCTTCCGCCGGGCATTGAGCAGCGACCTCGTCGCGGCGGGGGAGCGATTCGACGTCGTGCTGTCCAACCATGTGCTGCACCACCTCGCCGCCGCGGACCTCGGCGCGCTGCTGGTCGACTCCGAACGGCTCAGCCGTGCCCTGGTGCTCCACGGCGACATCGAACGGGCCCCGTTGGCGTACCTCGGCTTCGGGCTGGGCACGTGGCCGTTCTTCCGGCGCTCGTTCATCCGCGCCGACGGACTCACCTCGATCCGGCGCAGCTTCACCCGCGCGGAGCTGGCCGCGGCGGTGCCGCCGGGCTGGACCGTGCACCGGGAGGTGCCGTACCGGCTGATGTTGCGCTGGAGCGCGCCACCGGTGGCACCGACCTCGGCACGACAGGCGAGCCGGGCCCATGCGTGA",
    "translation": "MDAVEIMDDPDCDPDKLRRTYANFRYVNAVVSGLRHTYRHDIRPLLSPDVPRTLLDIGSGGGDVARSLARWAARDGLRLTVTGIDPDARAHDYATSLPPLAGLTFRRALSSDLVAAGERFDVVLSNHVLHHLAAADLGALLVDSERLSRALVLHGDIERAPLAYLGFGLGTWPFFRRSFIRADGLTSIRRSFTRAELAAAVPPGWTVHREVPYRLMLRWSAPPVAPTSARQASRAHA",
    "product": ""
   },
   {
    "start": 39536,
    "end": 40699,
    "strand": 1,
    "locus_tag": "ctg36_40",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_40</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_40</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 39,536 - 40,699,\n (total: 1164 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1050:monooxygenase FAD-binding (Score: 284.5; E-value: 2.9e-86)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_40 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01494.22 (FAD binding domain): [2:342](score: 163.6, e-value: 7.7e-48)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_40 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0071949' target='_blank'>GO:0071949</a>: FAD binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_40\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_40_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_40\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGTGACGTGATCGTGGTGGGCGGCGGGCCCGTGGGCATCCTGCTGGGGTGTCTGCTGGCCGAACGCGGGGTGGATGTGGAGGTGCTCGAACGGCGCACCGAGCCGTCGATGCACGCCAAGGCCATCGGCATCCACCCGCCGTCGATGCGGGTGTTGCGGCAGGCCGGGGTGGCCGACGAGGTGTTGTCCCGGGCGGTGCGCATCGTGACCGGCAGCGTGCAGAGTGGCGGGCGCACCCTGGGCCGGCTCTCGTTCTCCCAGGTCACCGGCCGGTTCCCGTTCGTGGTGACGCTGCCGCAGCACGAGACCGAGGCTGTGCTTCGGGAGCGGTTCGCGGCCCTCCGGCCCGACGGCCTGCGCTCCGGCGTGGGCGTGGGCATGCTGCAGGACCGCGGCGACCACGTGGACGTGCTCGCGGAGTCCGGTGCGGCTGAGGCCGAATCCGGTGACGGCGGCCGGGAGATCGTGGCTCAGGCCCGGTATGTGGTCGTCGCCGACGGGGCCCGAGGGCTGTTGCGTGACGCCGTGGGCATCGAATCCCGCGAGCTGGGCGGTGCGGGCACCTACCTGATGGCCGACTACCCCGACACCGGCGAGCACGGCGAGGAGGCGGTGTTGTTCTTCGAGGAGGGCGGTGTCGTCGAGTCGTTCCCGCTGCCGGGCGGCCGACGCCGGTGGGTGGCGGCGACGCCCACCCTGGTGACGGATGCGTCCATCGACGCCCTGGCGGCGCTCATCCTGCAACGCACGGGCGTGCGGTTGCCGCCCTCGGCGGCGGTGCCCAGCTCGTTCACGGTGCGGCAACGGCTCGCGTCGACCATGGTGCGCGGGCGGGTGCTGCTGGCGGGGGATGCGGCGCACGAGATCAGCCCGATCGGCGGGCAGGGCATGAATCTGGGCTGGCTCGACGCCGTGGCGCTCGCTCCGGCCCTCAAACACGCGCTGGCGCAGCCCATCGAGGCGGCGGTGACGCTGGCCGGGTACGACCGGCGCCGGCGCCGCAGCGCTCGCATGGCGGCCCGGCAGGCCGGGTTCAACATGGCGATGGGCCGGCCGGTGCGCGGGCTGCGCCTGCGGATGCGGAACGTCCTCGTGCGCGCCCTGGCGCTGCCGCCCCTGAACGCGCTCCTCTCCCGCGCGTTCACCATGCGCTGGCTCTAG",
    "translation": "MRDVIVVGGGPVGILLGCLLAERGVDVEVLERRTEPSMHAKAIGIHPPSMRVLRQAGVADEVLSRAVRIVTGSVQSGGRTLGRLSFSQVTGRFPFVVTLPQHETEAVLRERFAALRPDGLRSGVGVGMLQDRGDHVDVLAESGAAEAESGDGGREIVAQARYVVVADGARGLLRDAVGIESRELGGAGTYLMADYPDTGEHGEEAVLFFEEGGVVESFPLPGGRRRWVAATPTLVTDASIDALAALILQRTGVRLPPSAAVPSSFTVRQRLASTMVRGRVLLAGDAAHEISPIGGQGMNLGWLDAVALAPALKHALAQPIEAAVTLAGYDRRRRRSARMAARQAGFNMAMGRPVRGLRLRMRNVLVRALALPPLNALLSRAFTMRWL",
    "product": ""
   },
   {
    "start": 41623,
    "end": 43287,
    "strand": 1,
    "locus_tag": "ctg36_41",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_41</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_41</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 41,623 - 43,287,\n (total: 1665 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_41 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05175.17 (Methyltransferase small domain): [173:299](score: 54.8, e-value: 9.5e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_41 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05175.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008168' target='_blank'>GO:0008168</a>: methyltransferase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_41\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_41_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_41\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCAGTTGAATGGAGGGGTGACTGCACCCCTGATCGACCAGCTCCGCGCCGACCTGACCGCCGCCAACTTCTCGGTGACGGCCCTGACCGGCCTGTGGGGCATCGACGCCGATGCGGCCCTGCACCGCAACCAGCGGGTGCCGGCCCTTCGGGCGCTCGCCCGGCTGCGCGGCTCCCTCATCGTGCTCGAACCGAATGTAGTGCTCGCCCAGCTCTTCGTGCTCGGCCTGCCCGTGGAGCGGGACGAGCTGGACACCGCCCTGCCCACCCTCGGTGCGGCCGGCGCCGAGCTCCTCGGCCTGGTCACCGCGCACCACGCGCACGCCGGAACCGACGAGAACCCCACCGTGGACACCGGTCCCCGTCAGGTGGAACCGCTGGTGGACCTGCGCCCGTACAGCTTCGTCGACGCGCACGGGGCCGGCAGTTGGTGGATCACCTCGGACCTGGGCGAACTGGCCCTCGGGCATCCGCTCGGCGAGAACCACGTGCTCGGCGTCGGCGGTGCCTCCCTCACGCTCAGCGCCCTGATGATCCCCGCCCCGGTCGACAGCGCGCTCGACCTGGGCACCGGCTGCGGCATCCAGGCGCTGCACGCCTCCCGGCACGCCGCCCGGGTGGTGGCCACCGACATCTCCGAGCGGGCCCTCGAGCTCGCGGCCCTGAACGCCCGGCTGAACCAGGTCGAGAACATCGAGTTCCGGCTCGGCAGCCTGTTCGAGCCCGTCGCCGGGGAGCGCTTCGACCACATCATCTCCAACCCGCCGTTCGTGATCACCCCGCGCGTCGAGGGCGTGCCCAGCTATGAGTACCGGGACGGCGGCCTGGTCGGCGACGCCCTCGTCGAGGCCGTGGTGCGCGGCGCATCCGCCCACCTCAGGCCCGGCGGGATCGCGCAGTTGCTCGGCAACTGGGAGTACCACGACGAGGCCGACGCCTTCGCCCGGCTCACCGGCTGGATCGACGCCCCGTACCCCGACGCCGATGCGGGCGACGCGGCATCCGCCCCGCTGGACGCCTGGATCATCGAGCGTGAGGTGCAGGCGCCCACCGGCTACGCCGAAACCTGGATCCGCGACGGCGGCACCCGCCCGGAGACCCCCGACTTCGACAGGCTCTACGGCGCCTGGCTCGACGACTTCGAGGCCCGCGGGGTGCGGCAGGTGGGCTTCGGTTACATGCTGCTGCGCCGTCCGGCCACGGATGCGGCGGGCCGCCGCTCCGAGCGCGTGCGGCCCCGCCTGCTGCGGCTCGAACGGCTGCCCGAGGCCCTCGGACACAACGCGGCCGGCATCGGCAGCCACCTCGCCGAGTGCCTCGCCGCCCACGACTGGCAGGCCGGGCTCGACGACGACGCGCTCTCCCGCAGCACCCTCACGGTGGGCTCGGACGTCACCGAAGAACGGCATTTCTGGCCCGGCCAGGAGGATCCGACGCTGATGACCCTGCACCAGGGCGGCGGCTTCGGCCGCTCGGTGCCGCTGGACACCGCCCAGGCCGCCCTGATCGGCGCCTGCGACGGTGAACTGCCGGTGGGCGCGATCATCGACGCGATCGCGCAGTTGCTCGACGCCGACGCCACCGCCCTCCGCGCCGAGCTGCTCCCGCGCGTGCGGGTCCTGCTCGACGACGGCTTCCTCGAGCCGCCCGCCTCCGGCGCCTGA",
    "translation": "MQLNGGVTAPLIDQLRADLTAANFSVTALTGLWGIDADAALHRNQRVPALRALARLRGSLIVLEPNVVLAQLFVLGLPVERDELDTALPTLGAAGAELLGLVTAHHAHAGTDENPTVDTGPRQVEPLVDLRPYSFVDAHGAGSWWITSDLGELALGHPLGENHVLGVGGASLTLSALMIPAPVDSALDLGTGCGIQALHASRHAARVVATDISERALELAALNARLNQVENIEFRLGSLFEPVAGERFDHIISNPPFVITPRVEGVPSYEYRDGGLVGDALVEAVVRGASAHLRPGGIAQLLGNWEYHDEADAFARLTGWIDAPYPDADAGDAASAPLDAWIIEREVQAPTGYAETWIRDGGTRPETPDFDRLYGAWLDDFEARGVRQVGFGYMLLRRPATDAAGRRSERVRPRLLRLERLPEALGHNAAGIGSHLAECLAAHDWQAGLDDDALSRSTLTVGSDVTEERHFWPGQEDPTLMTLHQGGGFGRSVPLDTAQAALIGACDGELPVGAIIDAIAQLLDADATALRAELLPRVRVLLDDGFLEPPASGA",
    "product": ""
   },
   {
    "start": 43573,
    "end": 45021,
    "strand": 1,
    "locus_tag": "ctg36_42",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_42</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_42</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 43,573 - 45,021,\n (total: 1449 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) DAO<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_42 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01593.27 (Flavin containing amine oxidoreductase): [41:116](score: 65.0, e-value: 8.4e-18)<br>\n \n  PF01593.27 (Flavin containing amine oxidoreductase): [134:468](score: 137.0, e-value: 1.2e-39)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg36_42 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01593.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_42\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg36_42_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_42\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAACGTCGGACCTTCTTGCTCAGTTCCCTCACCGGACTCTCGTTGCTCGCGCTCAGCGGATGCGTGCCGCCCAAGCCCACCCCCACGGGGACGCCCAGTCCCTCGGCCACACCGGCGCCGTCCCTCGTGCCGCAACCGGCGGGCATGCTCCGCACCTCCTGGTCGGAGGATCCGTTCGCCCGCGGTTCCTACAGCTTCGCCACGGTGTCGTCGACGCCCCAGCAGCGCGATGACCTCGCCGAACCCGTCCTCGACCGGCTTTTCTTCGCCGGCGAAGCGGTCTCTGCCGATGCGCCGGGCACCGTGCAGGGCGCCCGGGCTTCCGGCCAGCGTGCCGCCCGACTGCTGCAGGCCGCCGCGGAGCCGGCGGAGCGGGTGGCCGTGATCGGCGCCGGCGCCGCCGGACTCGCCGCCGCCCGCCAGCTCGCCGCCGCCGGGTTCTCGGTGATGGTGATCGAGGCGCGCGACCGGTTGGGCGGCCGCATCGACACCGTCACGGACGACGCCTGGCCCATCCCGGTGGAGCTCGGTCCGTCATTCATCGTGGGCTCCGACGGCAGCTCCCTCGACGAGGAACTCACCGGCCTCGAGATCTCCCACGCGCCGTTCCCGCTCACGCCGGAGGCGCGCACCTCGGCCGGCACGGTGACCGAGGTGTCCACGGTCGGTGCCGACTCCGTCACGGCCGCGCTCACCTGGGCCGCCGCCCAGGCGCAGGACACCTCCCTGGCCAAGGCCCTGGTCGCAACCGGCTCGGCCACGCTCTCCCAAACGGATGGCGACACCGGCGTCTCCGACGCCGACTGGCTGGACTACCAGCTCGCGACCTCCACCACCCTGGAGTCCGGCGCTCCCACCGACGAGATGTCCGGCTGGTACACCGCCACCCCCGCGGCCAGCGCCGGCGCCGACGTGCGCATCGTGCTGGGCGGCTACGGCGGCCTGATCAAGGACGATTCGACCGACCTCGACGTGCTCTACTCCAGTGTGGTGACCCGGGTGGCGTACACCGACGCATCCGTCAGTTTGCGCCTGGGCACCGGCGAATCGCTCACCGTGGACCGCGCCATCGTGACCGTGCCGCTCGGTGTGCTGCAGGGCGACGTGATCGAATTCGACCCGGCGCTGCCGTTCGCGCATCGCGGGGCGATCGCCGCGCTGGGCATGGGCACGCTCGACAAGATCTGGTTGCGCTTCGACGAGCCGTTCTGGGACACCGACGCCGCCCTGTGGACCACAGTGGGCGACGACACCCTCGATTTCAGGGTCTGGGTGAATATGATGCCGCTTACGAATGAGCCGATCCTGGTGGGTTTCGTCAGCGGCGATCACGCCCTCAAGCTGGCGAAATCCGGTAATACCGAGTTCACCGACGCCGCGTTGCGCAGCCTCGAGCCGTTCGCGGCCCTGCCCACAGACAGTGCCAGCCCGAGCCCTGCGGCCTGA",
    "translation": "MERRTFLLSSLTGLSLLALSGCVPPKPTPTGTPSPSATPAPSLVPQPAGMLRTSWSEDPFARGSYSFATVSSTPQQRDDLAEPVLDRLFFAGEAVSADAPGTVQGARASGQRAARLLQAAAEPAERVAVIGAGAAGLAAARQLAAAGFSVMVIEARDRLGGRIDTVTDDAWPIPVELGPSFIVGSDGSSLDEELTGLEISHAPFPLTPEARTSAGTVTEVSTVGADSVTAALTWAAAQAQDTSLAKALVATGSATLSQTDGDTGVSDADWLDYQLATSTTLESGAPTDEMSGWYTATPAASAGADVRIVLGGYGGLIKDDSTDLDVLYSSVVTRVAYTDASVSLRLGTGESLTVDRAIVTVPLGVLQGDVIEFDPALPFAHRGAIAALGMGTLDKIWLRFDEPFWDTDAALWTTVGDDTLDFRVWVNMMPLTNEPILVGFVSGDHALKLAKSGNTEFTDAALRSLEPFAALPTDSASPSPAA",
    "product": ""
   },
   {
    "start": 45209,
    "end": 45529,
    "strand": -1,
    "locus_tag": "ctg36_43",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,209 - 45,529,\n (total: 321 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_43\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_43\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCCGAGACCCGGGGCGAGCACTGGATCACCTTGGGGCCGCAGCACGGGGAGATCACCATGAAGGCGCCCGGCTCGGCCGCGGCGTGTCCGCTCAGGCTGCGGTGGTGGTGGCTGCCCTCGCAGGGCAGGTTGGTGTCGAAGTCGAGTAACGACATCGCATCGAGATTTGTCAGGATATACATGGTTCTCACGGTCAATCAGGAGAGGCACTGGCCGCGGTGCAAGAGGACGTCGGGATCGCGACCACACCCGACGGCCGACGGCGGAAGGCACTGCGTCCGCGAAACCGGGCTTGTCGGACCGGCACCGCTGAACTGA",
    "translation": "MAETRGEHWITLGPQHGEITMKAPGSAAACPLRLRWWWLPSQGRLVSKSSNDIASRFVRIYMVLTVNQERHWPRCKRTSGSRPHPTADGGRHCVRETGLVGPAPLN",
    "product": ""
   },
   {
    "start": 45731,
    "end": 46459,
    "strand": -1,
    "locus_tag": "ctg36_44",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,731 - 46,459,\n (total: 729 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_44\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_44\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCGCGACTCCCCCGATACCCGGGCGGATCCAACAGCGCGCAAGCCGTTGCGCGCGCCCCGACGCCTCACCCTGCGCGCCGGCTACGGCTACGGCCGGCTGGTCCTGGCCGCCGCGGGCATCGTCGGGCTGGTCGGCAACTACGAGTACGTGCTGCTGTTTCCGACCTTCGCCGCGTACAACGTGTTCACCTACTTCACGGTGCAGAGCGCCATTGCCGCGGTCGTCGCGTTCATCCTCGGCGCCGTCGTCGCGTTCCGGCACGAGAAGGACCCGCAATGGCTCGACACGTTCCGGGCCCTCGTCACGACGTACATCATCGTGTCGGGCATCGTGTTCCTCACCATCGTCATCCAGTCGTCGTCTCGCGACTACACGATCGAGGTGCCCTGGCCGAGCCAGGTGCTGCACTTCTACATCCCCACGATCGCGCTGCTGGACTGGCTGACGGACACCGGGAAGGCCCGGTTGTCCTGGCGCTTCCTGCGCTGGATCCTGCCGTACCCGTTCGCCTGGGGCATCTTCACACTCGTGCGCGGGTCGTTCGTGGGCTGGTACCCGTACTTCTTCCTCGACCCCGCCCAGGTCAGCGGCCCGCTCGAGACGGTGCTCTACTGCCTGATCGCGGTGGCCCTGTTCCTCGGCATCGCCTCGGTACTCGTGGCCACGTCCCGGCTCAGCTGGCGGCCGCGCACGCGCGGCGACCGCAGTTCGTCGGTCCCCAACTAG",
    "translation": "MRDSPDTRADPTARKPLRAPRRLTLRAGYGYGRLVLAAAGIVGLVGNYEYVLLFPTFAAYNVFTYFTVQSAIAAVVAFILGAVVAFRHEKDPQWLDTFRALVTTYIIVSGIVFLTIVIQSSSRDYTIEVPWPSQVLHFYIPTIALLDWLTDTGKARLSWRFLRWILPYPFAWGIFTLVRGSFVGWYPYFFLDPAQVSGPLETVLYCLIAVALFLGIASVLVATSRLSWRPRTRGDRSSSVPN",
    "product": ""
   },
   {
    "start": 46614,
    "end": 46868,
    "strand": -1,
    "locus_tag": "ctg36_45",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg36_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg36_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 46,614 - 46,868,\n (total: 255 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg36_45 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00708.21 (Acylphosphatase): [1:82](score: 92.5, e-value: 1.7e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg36_45\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg36_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg36_45\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGATCGTCAACGGGATGGTGCAGGGCGTGGGCTTCCGGTACTACACCGAGGCTCAGGCCAGTTCCCTCGGCCTGGGCGGGTACGTGCGCAACCGATCCGACGGGGCCGTGGAGACCGAGATCGAGGGCGACGACGAGGCCGTCGAGCGGATGCTCACCTGGCTGCACCAAGGACCCCGCTCGGCGAGCGTGGAGTCGGTGCAGGTGACCGACCTGGCCGAGCACGGCGAGGCGGGTTTCAGCATCCGCATCTGA",
    "translation": "MIVNGMVQGVGFRYYTEAQASSLGLGGYVRNRSDGAVETEIEGDDEAVERMLTWLHQGPRSASVESVQVTDLAEHGEAGFSIRI",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 37643,
    "end": 38798,
    "tool": "rule-based-clusters",
    "neighbouring_start": 17643,
    "neighbouring_end": 46916,
    "product": "T3PKS",
    "category": "PKS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [
    {
     "start": 19377,
     "end": 19379,
     "strand": 1,
     "containedBy": [
      "ctg36_21"
     ]
    }
   ],
   "bindingSites": []
  },
  "type": "T3PKS",
  "products": [
   "T3PKS"
  ],
  "product_categories": [
   "PKS"
  ],
  "cssClass": "PKS T3PKS",
  "anchor": "r36c1"
 },
 "r55c1": {
  "start": 1,
  "end": 19200,
  "idx": 1,
  "orfs": [
   {
    "start": 3,
    "end": 167,
    "strand": 1,
    "locus_tag": "ctg55_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 167,\n (total: 165 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTATGCGCATCGCCGGGCGGGATGGGGCGGGGTGGGAGGACAATGTGCCTGTGTGACGCGCGTTCACCCGCCGGTTACCTGATCGCCCTAGGGTGGCCGCGTCGCGGTTTGTCGCGAAAGCCGGACAGGAGCGTGCGTGACCTCGAACCATCCAGAGCCCGATAA",
    "translation": "MCASPGGMGRGGRTMCLCDARSPAGYLIALGWPRRGLSRKPDRSVRDLEPSRAR",
    "product": ""
   },
   {
    "start": 139,
    "end": 4200,
    "strand": 1,
    "locus_tag": "ctg55_2",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 139 - 4,200,\n (total: 4062 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NAPAA: TIGR02353<br>\n \n  biosynthetic (rule-based-clusters) NAPAA: AMP-binding<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 249; E-value: 1.3e-75)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_2 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [62:452](score: 219.0, e-value: 9.2e-65)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [572:634](score: 44.3, e-value: 1.8e-11)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg55_2_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACCTCGAACCATCCAGAGCCCGATAAGCGCTCGGCCGACTCACTCGCCAGCACCGTTTCCATGCCGGCCACCACCTCGGCTCCCAGCAGCACGGTCTCAAGCCCGTACACGCAGGCGCACGACCAGCGCGTGCTGGATGCCGGTCATCTGGTGCACCCGGAGCGCACCCTCGTCGACATCCTGCGGGCCAGCGCCGAGGAAGACCCCACCGCTCTCGCGCTCGAAGACGCCGCCGGGGCCCTGAGCTACCGCCGCCTGCTGCGGCTGGTCAACGACCAGGCCGTGCAGCTGAGCCGCGCGGGTGTGCGCCGCGGCGACACTGTCGGCATCCGCATCCCGTCGGGCACCCGGGAGCTGTACCTGTCGATCCTCGCGACCCTCAGCGTGGGCGCCGCCTACGTGCCGGTGGACGCCGACGACCCCGAGGAGCGGGCCCGGCTGGTGTTCGGTGAGGCCCACGTCGTGGGCGTGATCGGCGCCGGGGGCCGGTTCGCGGTGCGTGACGGCCTCGACGCCGGTGTGCTCACCGAGCGGCCCGTTCCGGCCGGGGAGGATCCGTCGCTGGCGCACTGGGGCGAGCCGATGCCGGGCCCCGACGACGACGCCTGGATCATCTTCACCTCCGGCTCCACCGGCGTGCCCAAGGGTGTCGCCGTGACGCACCGGTCCGCCGCGGCTTTCGTCGACGCCGAGGCCGGCCTGTTCCTCAGCGCCGACCCGATCGCGCCGGGCGACCGGGTGCTGGCTGGCCTCTCGGTGGCGTTCGATGCCTCCTGCGAGGAGATGTGGCTGGCCTGGCGGAACGGCGCGTGCCTGGTGCCGGCCCCGCGCTCCCTCGTGCGCAGCGGCGCCGACCTCGGCCCCTGGTTGATCGCCCACGGCATCACCGTGGTCTCCACCGTGCCCACCCTCGCCGCGCTCTGGCCCGAGGAGGCGCTGGAGAACGTGCGCCTGGTGATCTTCGGCGGCGAGGCGTGCCCACCCGAACTGGCCGCCCGCATCAGCGGCCGCGGCCGCGAGGTCTGGAACACGTACGGCCCCACCGAGGCCACCGTCGTGGCCTGCGGCGCCCTGCTCGACGGCAGCGACCCCGTGCGCATCGGCCTGCCGCTGGACGGCTGGAGCCTCGCCGTGGTCGACGCCGACGGCGCTCGGGTGCCCGCCGGCGGCACCGGTGAGCTGATCATCGGCGGCGTGGGCCTGGCCCGCTACCTCGACGCCGCGCAGGATGCCGTGAAATACGCCCCGCACGCCGGCCTCGGCTGGGACCGCGCCTACCGCAGCGGCGACCTGGTGCGCTTCGACCCCGAGGGGCTGGTCTTCGTGGGCCGCGCCGACGACCAGATCAAGCTCGGCGGCCGCCGCATCGAGCTCGGCGAGATCGACGCCGCCCTCCAGGCGCTGCCCGGCGTCGCCGGCGCCGCCGCGGTGGTGCAGACCACCCCGGCCGGCAACCAGGTTCTGGTCGGCTACCTCTCCCTCGTCGAGCCGGCGCCGGTCGGTAGCGACCCGGTCACGTCGCCCTTCGACCTCCCCGCCGCCACCGAGGCCCTGCGCATCGCCCTGCCGGCCGCCCTCGTGCCGCTCCTCGCCGTGGTCGACACGATCCCCACCCGCACCTCCGGCAAAGTCGACCGGGCCGCGCTGCCCTGGCCGCTGCCCAGCCTGGCCGGCGGCAGCACCGACACGGATGCGCTCAGCCCCACCGCCGCCTGGCTCGCCGAACACTGGGCCGCGATCCTCGGGCTGCCCGTGACCGACGCCGACAGCGACTTCTTCGCCTACGGCGGGGGCTCCCTCTCGGCCGCCCAGTTCGTCTCCGCGATCCGGGAACGCTACCCCGACACCCGCGTCAGCGACATCTACGACCACCCGCGCATCGGCGCCCTGGCCGCCGAACTCGACGGCCGCACCCCGCCGGCGGCCCGCCGCAGCCGCACGGTGCTGCCCACCCCCGCACGCAGCGGTCTGCTGCAGAGCCTGCTCGGCATCCCCCTGCACCTGCTCGTGGGCGCCAAATGGCTGGTCTACCTGGCCGCGGCCAACAACGTGCTCGCCGCCGCCGGCGCATCCTTCGCCCCCACCGTGTCGTGGTGGTGGGTCCTAGCCGGGTTCCTCCTGCTCGTCACCCCGCTGGGCAAGATGGGCATCTCGGTGGTCGCGGCCCGGCTGCTGCTCCGGGGCCTGAAACCGGGCGCCTACCCGCGCGGCGGCTCGGTGCACCTGCGGCTCTGGCTGGCCGAGCAGGTGGCCCAGTTCGTCGACGCCGCCAGCCTGGCCGGGGCGCCGTGGATCAGCTACTACGCCCGCCTGCTCGGCGCCCGCATCGAACCGGGCGTGGACCTGCACTCGGTGCCCCCGGTCACCGGGATGCTCAGCATCGGGGCACGCGCCGCGATCGAACCCGAGGTGGACCTGGCCGGCTACTGGCTCGACGGCGACACCCTGCGCCTGGGCCAGGTGCGCATCGGCGAGGAGGCCGTGGTCGGTTCCCGCAGCACCCTGCTCGGCGGCGCGAAGATCGGCGCCGGCGCCGAGATCGAGCCGGGCTCCGCGGTCTCCGGCCGCGTCCCGGCCGGCGAACGCTGGGCCGGTTCACCCGCGACCCGGGTCGGGTCGGCCCGCCACACCTGGCCGGCCGAACGTCCGCCGAGCGCCCGCCGTTGGCTGCTCGCCTACGGCGCCGGCTCCGTCGGCCTCACCGCCATCCCCACCGTCGCCGTGCTGCTCGGCGTGCTCATCGTCGGGCTGTTCGTGGGGGAGGCCGGCAGTCTCGGCACCGCCGTCGGCCGGGCCGCCCTGGCCGTGCCGCTGGCCGTGCTCGCCGCCGGCCTGCTCTACGCGGGCGCCGTGATCGGCGCGGTGCGCCTCCTCGGCCTGGGCCTGACCGAGGGGCACCATCCGGTGCGCAGCCGCGTGGGCTGGCAGGTCTGGATGACCGAACGCCTGCTCGACGGCGCCCGCACCCTGCTCTTCCCGGTCTACGCGAGCCTGATCACGCCAGTCTGGCTGCGGTTGCTCGGTGCGAAGGTCGGCTCCGGCGTGGAGGCCTCCACCGTGCTGCTCGTGCCCGCACTCACCACCATCGCGCCGGGCGCATTCCTCGCCGACGACACCATGGTCGCCTGTTACGAGCTCGGCGGCGGCTGGATGCGCATCGACCGGGCCAAGATCGGCCGCCGGGCGTTCCTGGGCAACAGCGGCATCGCCGGCCCCGGCCGCACCGTGCCGCGGGACGGCCTCGTGGCCGTGCTCTCCTCCACCCCGCGGAAGGCCAAACGCGGGTCCTCCTGGCTGGGCAACCCGCCGGCGCGGCTGCGCCGCCGGGTCACCGACATCGACGAGGCCCGCACCTTCCACCCGCACGCCCGGCTGCGCCTGGCCCGGTCGCTCTGGGAACTCCTCCGCCTGGTGCCGGTGTTCGTCTCCGCCTGGATCGCGCTCGGCGTCCTCGCCGCCCTCGAGGCGCTCTGGCTCACCGCCGGGCCCGGCTGGGCGCTGCTGCTCTCCGGGTTCGTGCTCATCGGCGCGGGAGTGATCGCGGCAGCGGTCAGCACGGCCGCAAAATGGCTGCTGGTGGGCCGCATCCGCGCCACCGAGCATCCGCTCTGGTCGTCGTTCATCTGGCGCAACGAGGTGTCGGACACCTTTGTGGAGATGGTGGCGCGGCCGTGGTTCGCGCAGAACGCGTCGGGCACGCCGGCCCTGGCGCTGTGGCTGCGCTCGCTCGGCGCCCGGATCGGCCGGGGCGTGTGGTGCGAGTCGTACTGGCTCCCAGAGGCCGACCTGGTCACCCTCGCCGCCGGCAGCAGCGTCAACCGCGGCTGCGTGGTGCAGACCCACCTGTTCCACGACCGGATCATGCAGCTGGACACCGTGCACATCGGCGCCGGCGGCACCCTGGGGCCCAACAGCGTGATCCTGCCCGCGGCGCGGATCGACGACCACGCCACCGTCGGGCCGGGCTCCCTGGTGATGCGCGGCGAGCGGGTGCCCACCGATTCGCTGTGGGCCGGCAACCCGATTGCGCCCTGGCACCGCCCGCCATGGAAGACTTGA",
    "translation": "MTSNHPEPDKRSADSLASTVSMPATTSAPSSTVSSPYTQAHDQRVLDAGHLVHPERTLVDILRASAEEDPTALALEDAAGALSYRRLLRLVNDQAVQLSRAGVRRGDTVGIRIPSGTRELYLSILATLSVGAAYVPVDADDPEERARLVFGEAHVVGVIGAGGRFAVRDGLDAGVLTERPVPAGEDPSLAHWGEPMPGPDDDAWIIFTSGSTGVPKGVAVTHRSAAAFVDAEAGLFLSADPIAPGDRVLAGLSVAFDASCEEMWLAWRNGACLVPAPRSLVRSGADLGPWLIAHGITVVSTVPTLAALWPEEALENVRLVIFGGEACPPELAARISGRGREVWNTYGPTEATVVACGALLDGSDPVRIGLPLDGWSLAVVDADGARVPAGGTGELIIGGVGLARYLDAAQDAVKYAPHAGLGWDRAYRSGDLVRFDPEGLVFVGRADDQIKLGGRRIELGEIDAALQALPGVAGAAAVVQTTPAGNQVLVGYLSLVEPAPVGSDPVTSPFDLPAATEALRIALPAALVPLLAVVDTIPTRTSGKVDRAALPWPLPSLAGGSTDTDALSPTAAWLAEHWAAILGLPVTDADSDFFAYGGGSLSAAQFVSAIRERYPDTRVSDIYDHPRIGALAAELDGRTPPAARRSRTVLPTPARSGLLQSLLGIPLHLLVGAKWLVYLAAANNVLAAAGASFAPTVSWWWVLAGFLLLVTPLGKMGISVVAARLLLRGLKPGAYPRGGSVHLRLWLAEQVAQFVDAASLAGAPWISYYARLLGARIEPGVDLHSVPPVTGMLSIGARAAIEPEVDLAGYWLDGDTLRLGQVRIGEEAVVGSRSTLLGGAKIGAGAEIEPGSAVSGRVPAGERWAGSPATRVGSARHTWPAERPPSARRWLLAYGAGSVGLTAIPTVAVLLGVLIVGLFVGEAGSLGTAVGRAALAVPLAVLAAGLLYAGAVIGAVRLLGLGLTEGHHPVRSRVGWQVWMTERLLDGARTLLFPVYASLITPVWLRLLGAKVGSGVEASTVLLVPALTTIAPGAFLADDTMVACYELGGGWMRIDRAKIGRRAFLGNSGIAGPGRTVPRDGLVAVLSSTPRKAKRGSSWLGNPPARLRRRVTDIDEARTFHPHARLRLARSLWELLRLVPVFVSAWIALGVLAALEALWLTAGPGWALLLSGFVLIGAGVIAAAVSTAAKWLLVGRIRATEHPLWSSFIWRNEVSDTFVEMVARPWFAQNASGTPALALWLRSLGARIGRGVWCESYWLPEADLVTLAAGSSVNRGCVVQTHLFHDRIMQLDTVHIGAGGTLGPNSVILPAARIDDHATVGPGSLVMRGERVPTDSLWAGNPIAPWHRPPWKT",
    "product": ""
   },
   {
    "start": 4208,
    "end": 5542,
    "strand": 1,
    "locus_tag": "ctg55_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,208 - 5,542,\n (total: 1335 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_3 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17900.4 (Peptidase M1 N-terminal domain): [29:201](score: 60.0, e-value: 3.7e-16)<br>\n \n  PF01433.23 (Peptidase family M1 domain): [291:433](score: 95.7, e-value: 3.1e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg55_3 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01433.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008237' target='_blank'>GO:0008237</a>: metallopeptidase activity<br>\n  \n   PF01433.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg55_3_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCGTCACCCACGCCTCCGATCCTCGGCTCCGCATCCGCGGGCGACCCCTACCTGCCGGCGAGTGGGAACGGCGGCTACCAGGTCGAGCACTACGACCTGGTGCTGGACTACCGGGTCTCCTCCAACCGGCTGAGCGCCACCGCCACGATCACCGCGCGCGCCCTCACCCGGCTCGACCGGTTCAGCCTCGACCTGGCCGGCCTCAGCGTCGACAAGGTCACCGTGGCCGGGCGGATGCCCACCAAGACCACGCACACCGCCCGCAAGCTGGTGCTCACTCCGGCCGTGCCGCTGCAGGCCGGCGAGCGGTTCGACGTCGTCGTGGCCTACCGCGGCGCACCGCGCCCGGTGCGCAGCCACTGGGGCGAGGTGGGCTGGGAAGAGCTCACCGACGGCGTGCTCGTCGCCGGACAGCCCAGCGGCGCCCCGTCCTGGTTTCCCTGCAACGACCACCCGAGCGACAAGGCCACCTTCCGCATCCAGCTCAGCTGCGAGGCCCCGTACACGGTCGTGAGCAACGGCCCGCTCGTGGCCAAGAGCAGCCGGTCCGGCCGCACCACCTGGACCTTCGAGGTGCGCGAGCCCATGGCCGCGTACCTGGCCAGCGTGCAGATCGGCCGGTACCGCCGGCAGGACGTGACGGCCACCCCGGTGGCGTACAGCCTGTTCTACCCGCCTGCCCTGGCGCGGCCGGTGGCGGTGGACTTCGCCCGGCTGGGCGACATGATCGCCGTGTTCGGCGAGGCTTTCGGCCCCTACCCGTTCCCGGCGTTCTCGGTGATCGTGACGGCCGACGAGCTGGAGATCCCGCTCGAGGCGCACGGGCTGGCCGTCTTCGGCCGCAATCACGTGGACGGGCTGCACGGCAGCGACCGGCTCATCGCCCACGAGTTGGCGCACCAGTGGTTCGGCAACAGCCTCACCCTCACCCGGTGGCAAGACATTTGGCTGCACGAGGGCTTCGCCTGCTACGCCGAGTGGATCTGGGCGGAGGCCAGCGGCGGCCTCACCGCGCACGAGAGCGCCGTGCTGCACCGGGCCGAGGTGGACCTGCTGCCCAAGAACATCGTGGTGGGCGACCCCGGACCACCGGACATGTTCGACGACCGGGTCTACAAGCGCGGCGCCCTGGCCCTGCACGCCGTGCGCCAGGCCATCGGCGACGAGGCCTTCTTCACGGCGCTCCGCGCGTACACCCGCACCCACCGGCACGGCAGCGTCACCACCGACGACCTGCTCGGCTGCTTCGATGCGGCCTCCGGCACGCGGGCCGCCGACAAGATCATCGCCCGCTGGGTGTCAGGCAAGAGCCTGCCGCCGCTGGTCGCCTAG",
    "translation": "MSSPTPPILGSASAGDPYLPASGNGGYQVEHYDLVLDYRVSSNRLSATATITARALTRLDRFSLDLAGLSVDKVTVAGRMPTKTTHTARKLVLTPAVPLQAGERFDVVVAYRGAPRPVRSHWGEVGWEELTDGVLVAGQPSGAPSWFPCNDHPSDKATFRIQLSCEAPYTVVSNGPLVAKSSRSGRTTWTFEVREPMAAYLASVQIGRYRRQDVTATPVAYSLFYPPALARPVAVDFARLGDMIAVFGEAFGPYPFPAFSVIVTADELEIPLEAHGLAVFGRNHVDGLHGSDRLIAHELAHQWFGNSLTLTRWQDIWLHEGFACYAEWIWAEASGGLTAHESAVLHRAEVDLLPKNIVVGDPGPPDMFDDRVYKRGALALHAVRQAIGDEAFFTALRAYTRTHRHGSVTTDDLLGCFDAASGTRAADKIIARWVSGKSLPPLVA",
    "product": ""
   },
   {
    "start": 6280,
    "end": 6678,
    "strand": -1,
    "locus_tag": "ctg55_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,280 - 6,678,\n (total: 399 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGCCGCCATGGATACAAACCGCTCCACCGCGCCCGCCCCGGCGGAGGTGCAGGACTGCATCGACGCCTGCACCGAGCTGGAGCGGGCGAGCGAGGATTGCGCGGAGGCGTGCCTGCGGCTGGGCGGCGACGGCGACGTCACGGACTGCTTCCTGGCCGACCTGGACTGCACAGAGGTCTGCGCGGCGACCAACCGTCTGCTCGGGTGGCGCTCCCGCACCGACGGGCCCACGACCCAAGCGATGCTGCTGGCCTGCCGGGAGGCCGCGTCCGTTTCGATCGCGGCCTGTGAACGGATGCGGCCGGGCCGCCCGAACTGGACCTCCTGCGCGCCCGCCGCCCACCGGGCCATCGCGGCCTGCACGGCACTCCTCGAGGCGTACGAGCCGAACGGCTAG",
    "translation": "MAAMDTNRSTAPAPAEVQDCIDACTELERASEDCAEACLRLGGDGDVTDCFLADLDCTEVCAATNRLLGWRSRTDGPTTQAMLLACREAASVSIAACERMRPGRPNWTSCAPAAHRAIAACTALLEAYEPNG",
    "product": ""
   },
   {
    "start": 6722,
    "end": 7411,
    "strand": -1,
    "locus_tag": "ctg55_5",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,722 - 7,411,\n (total: 690 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1012:4&#39;-phosphopantetheinyl transferase (Score: 70; E-value: 2.8e-21)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_5 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01648.23 (4&#39;-phosphopantetheinyl transferase superfamily): [100:185](score: 40.5, e-value: 2.8e-10)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg55_5 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01648.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000287' target='_blank'>GO:0000287</a>: magnesium ion binding<br>\n  \n   PF01648.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008897' target='_blank'>GO:0008897</a>: holo-[acyl-carrier-protein] synthase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg55_5_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGTCCGGCCTGCCGGGCAGCAGCTCGTCGGCAGTCGACCTGTCGCGCACCGTGGTCGTCGCGATCGGTCACCGGGCGGAGACCAAGGCCGGGGACCATGCCCTGCTCGCCCGCCTCGTGGCCCGGCTGACCGGGGTGGGCGCCGCATCCGTCGCCCTGACCCAGCGCTGCCCCCAGTGCGGTGCGCCCGGTCACGGCCCGCTGCGGGTGGTCATCGACGGGTCCGGCACGGGCACCCCTCGGGTGAGCCTGGCCCGGGCGGGCGGACTGCTGGCCGTCGCGGTCACCGCGGCCGGCCCGATGGGCATCGATCTGGAGTCCCGCGCCGACCTAGCCCGCGCTCCGCTGAACGATGTGGCGCTCTCCCCCGCCGAGGCCGCGACCCTCGCCACGCTGCGTCCGGCCGATGCGGCCGCGGCGCTGGCCGCCCTGTGGACCTCGAAGGAGGCCGTGCTCAAGGCGGCCGAGGTCGGTCTCCGCGTGGACCCGTCCGAGCTCACGGTGACCCTCGACGCGGCCGGCCCGCCCGCATCCGCCAGGCACCGGATGCTCACCGACTGGCCCCAGGCCCCGTTCGCCCTGGGCGAGCTGCACCTGTTCCCCGTCGCCGGCCGCGCCGGCTTCACCTCTGCTCTCGCCGTCATCAGCTCCCGACGCCCGATGCTGCGGTTCCTCCCCCTCGACGACTAG",
    "translation": "MSGLPGSSSSAVDLSRTVVVAIGHRAETKAGDHALLARLVARLTGVGAASVALTQRCPQCGAPGHGPLRVVIDGSGTGTPRVSLARAGGLLAVAVTAAGPMGIDLESRADLARAPLNDVALSPAEAATLATLRPADAAAALAALWTSKEAVLKAAEVGLRVDPSELTVTLDAAGPPASARHRMLTDWPQAPFALGELHLFPVAGRAGFTSALAVISSRRPMLRFLPLDD",
    "product": ""
   },
   {
    "start": 7634,
    "end": 8251,
    "strand": 1,
    "locus_tag": "ctg55_6",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,634 - 8,251,\n (total: 618 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAAGCGGTTCGAAGGTCTGGCCAGGCCATCCACACTCGCCGCCGGGGCGGTCTTCCTGATCGGCGGCCTCCTCGACCAGGCCTTGCGCCTCACCGGCGACCCGGCGAGCAACCTTGTCCAGACTCCGCTCTACGCCGTGCGCTCCATCGCCCTGCTCGGCGGGGCGCTGCTGCTGATCCTGTCTCTCGTGTCGATCTACGAGCGGCACGCCAAGCAGATCGGCCCGTTCGGGTTCTCCGCGGCGATCGTCGCCGGAACCGGCACCATCCTGATCAGCGGCCAGTTCTGGGCCGAGTCCTTCCTGTATCCGACCCTGGGCCGTGTGGCCCCTGGCCTGCTCGACGGCACCGACCGGCCCGGCTCCTACGCGTTCGGGCTGCTGCTCACCGCGGCGGTGTTCGGGGTGGGCTGGCTGCTGCTCGGCAGCGCCATCCTGCGCGCACGGGTCTACCGGGTGCTTCCCGCCGTCGTGATCCTGGCCGGCGGAGCGGTGTCACTACTCCCCGGCAACGCGCTCGGCCAGGCGGTGCTAGGCGCCGGCCTGGTGCTGCTCTCCTTCAGCCCCACCTACCGCAAGCACGAGGGCCCCCAGCGGCAGGCCAGCCCGGCTCGCTGA",
    "translation": "MKRFEGLARPSTLAAGAVFLIGGLLDQALRLTGDPASNLVQTPLYAVRSIALLGGALLLILSLVSIYERHAKQIGPFGFSAAIVAGTGTILISGQFWAESFLYPTLGRVAPGLLDGTDRPGSYAFGLLLTAAVFGVGWLLLGSAILRARVYRVLPAVVILAGGAVSLLPGNALGQAVLGAGLVLLSFSPTYRKHEGPQRQASPAR",
    "product": ""
   },
   {
    "start": 8315,
    "end": 9331,
    "strand": 1,
    "locus_tag": "ctg55_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,315 - 9,331,\n (total: 1017 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_7 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01544.21 (CorA-like Mg2+ transporter protein): [31:334](score: 208.4, e-value: 1.5e-61)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg55_7 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046873' target='_blank'>GO:0046873</a>: metal ion transmembrane transporter activity<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030001' target='_blank'>GO:0030001</a>: metal ion transport<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGGCGCTGATAGATGACGCGATCTACGTAGATGGCCGTCGGGTGGCAACCCCGGAAACGTTGCAGGACGTGTTCGAGGTACTCAAAGAGAAGGACGGCTTCGCCTGGATCGGACTGTACCGGCCGACCGACGACGAGATCAGGTCGGTGGCGGACGAGTTCACGCTGCACCACCTCGCGATCGAGGACGCCCTCAAGGGGCACCAGCGCGCCAAGATCGAACGCTACTCCGACACCCTGTTCCTCGTACTCCGCCCGGCCCGGTACCTCGACTCCGAGGAACGCGTCGAGTTCGGTGAGCTGCACGTCTTCGTGGGCCCCGATTTTGTCGTGACCATCCGGCACGCGGAATCACCCGACCTCGCCTCGGTGCGGCACCGGCTGGAAAGCACCCCCAAACTCCTCGCCTTCGGCCCCCAGGCGGTGCTGTACGCGATCCTCGACCAGGTGATCGACGAGTACGCGCCCGTCGTGGCCGGCCTGGAGAACGACATCGACGAGATCGAGGACCAACTCTTCGACGGCGATCAGGCGGTGTCCCGGCGCATCTACGCGCTCTCCCGGGAGGTCATCGAGTTCCAGCGCGCCACCCAGCCGCTGATCGGCATGCTCGAATCCCTGCAGGAGGGGTTCGAGAAGCACAACGTGGATGTGGAGCTGCACCGGCACCTGCGCGACGTGCTCGACCACACCATCCGGGTCGTCGAGCGGGGGGATGCGTTCCGCCAGCTGCTGCAGAACGCCCTCACTGTGCACAGCACCCTCGTGGCGCAGAGGCAGAACGACGAGACCCGCCGGCTCTCCGAGACGGGCCTGGCGCAAAGCGAAGAGGTCAAGAAAATCTCCAGTTGGGCGGCGATTTTGTTCGCCCCCACCCTGGTCGGCACCATCTACGGCATGAATTTCACCCATATGCCGGAGCTAAAATGGCAGTTCGGCTATCCGTTCGCGATCACTCTGATGATCGCCATGGGGTTCGGGCTCTACGCCGTCTTCAAGCGCAAGAACTGGCTGTAG",
    "translation": "MALIDDAIYVDGRRVATPETLQDVFEVLKEKDGFAWIGLYRPTDDEIRSVADEFTLHHLAIEDALKGHQRAKIERYSDTLFLVLRPARYLDSEERVEFGELHVFVGPDFVVTIRHAESPDLASVRHRLESTPKLLAFGPQAVLYAILDQVIDEYAPVVAGLENDIDEIEDQLFDGDQAVSRRIYALSREVIEFQRATQPLIGMLESLQEGFEKHNVDVELHRHLRDVLDHTIRVVERGDAFRQLLQNALTVHSTLVAQRQNDETRRLSETGLAQSEEVKKISSWAAILFAPTLVGTIYGMNFTHMPELKWQFGYPFAITLMIAMGFGLYAVFKRKNWL",
    "product": ""
   },
   {
    "start": 9488,
    "end": 13180,
    "strand": 1,
    "locus_tag": "ctg55_8",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,488 - 13,180,\n (total: 3693 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGTCCTCGCCCGGCTCGCGTCAAGCGACCTCCCCGGACTCGGTGAGCCTGGGGGACCCGTCGCTGGTCGCCGGGAACATCGCCGAACCCACCTGGCAACGCTGGCGGGACGAACTCGCCCTGGTCGGCGGGCACTCCCCGCTGCTGCACTTCGGTGACAGCCCGCGCTCCCGCATCGAGCTCTCCGCCACCCACCCGGGCGGACTGCCGCAGTTCATCACCGGCAAGACCACTCTGCTGTCCAACCTGATCCGCGACGAACTGGCGCTTCGCAACGCCCGCCTGGCCGCCAACGAGATCACCCAGAAGGGCATCGAACTGCGCTCCATGCGCGGCATCGAGTCGGTGCACCTGGCCATCGGCCTGGCCCAGTGGCGTCACGGCGACGTGGAGTTCACCGCGCCGGTGCTGCTGCGGCCCCTCGCCATCCGCCGTTACGGCCGGGACTTCGAACTCAAGCTCAAGGGCCAGCCGTTCCTCAACCCCGAACTGGCCCGCGCCCTGCACGACCAGTTCCAGATCACCCTCGACGCCGACGCGTTCGTGGCCCTCGCCGTGACCAACGGCGCGTTCAAGCCGCAACCCGTCATCGACCGCCTGCGCGGCCTCACCTCGCACCTGCCCTGGTTCAACGTGGTACCCCGCCTGGTCGCGTCCTCCTTCGCCGACGTCGGCCGCGCCATGGCCGTCGACGCGCAGAAGCTCACGCATCCGGTGCTCGACGCCGTCGCCGGCAACCCCACCGCCCGCCGCGCCATCGAAATGGCGTACAACCCGGTGCTACCGATCGGCCAGGACGTGCGCCCGCCCGGCACCGACACGCTGCTGCTGGATGCCGACGCCGAGCAGGAGAACGTCGTCGCGCAGATCAGCGCCGGCAACTCCCTCGTCGTGAAGACCCTGCCCGGAACGGGCGGCACCCAGACCATCGTGAACGCCATCGGCTCGCTCGTCGCCCAGCACAAGCGCGTGCTCGTGGTCAGCGCCCGGCGGTCCAGCCTCGACGGCATCGCGCACCGGCTCGTGCAGGTGGGCCTGCCCGGCGTGGCCGTCACCCCGCGCACGCTGCGCCGCGACCTGATCCAGTCGATCACCCGCAACGAGAAGGCCGCCCAGCCGCGCGTCGGCGACGTCGACGACGCTCTCGTGCGCCTCCGCAAGGTACTGCTCGACTACCGCTCCGCCCTCACCCGCAAGGACGCCGCCCTCGGCGTCTCGGTGCTCGACGCGCTCGGCGAACTCGCCCGCCTCGCCCAGCTGCCGGCGCCGCCGTCGACCACCGCCCGGCTCGACCGGGTGGCCCTCGAACGCCTCGCCCACGACCGGGCCAGCGCCGCCGCGATCCTGATCAAGGCCGCCGTCCTCGGCCAGTTCCGCTACGGCCCGGGCGACTCGCCCTGGTACGGGGCCTCCTTCGCCTCCACGGCGGATGCCGGCGCCTCGCACGAACTCGCCAAGCGGCTCAGCCAGACCGACGTGCCCCGGCTGCTCGAGCGCGCCGGCCACCTGGTCGGCCAGACCCGGCTGCGCCCGTTCGAGACGGTGCACGAGTTGGGCATCTACCTGCGCCTGCTCCTGGACATCCGCGAGACCCTGGACAAATTCCAGCCCGCCGTGTTCGACCGCTCACTGACCGAACTCATCGCCGCCACCTCGGCCCGCCGCGACTCGCCCGAGATGACCTCGAGCAACCGTCGCCGGCTCCGCAAACTCGCCGACGAGTACCTGCGACCCGGCGTGCACGTGAGCGACATGAACGAGAGCCTGCGGCGCATCCAGCAGCAGCGCACCCTGTGGCAGCGGTACGCCGCCGCGGGCGTCACCCCCGAGGTCCCGGTGGGCATCAACGATGTGCACGTGGCCTTCCAGCGGGTCTCCGAAGACCTCGGCAAGCTCGATGTGCCGCTGGGCAACGCCGGCACCCCGCGCCAGCTGGTCTCCCGGCCGGTGAAGGAACTGCTGCGCACCCTGGCCGGCCTCGCCGCCGACAGCGAGGTGCTCGCCAACCTGCACGAGCGCACCGCCCTGCTCGCCACCCTGCGCGAGCACAACCTCGACCCGCTGATGACCGACCTGTCCCAGCGACACGTGTCGGAAGAGAACGTGGCCGCCGAACTCGAACTCGCCTGGTGGCAGTCCGTGCTCGAGGTCATGCTCAGCGGTGACCGGGCCCTGCTCAACGCCAACACCCAGGTACTCGACCGGCTCGAGGCCGACTTCAAGCTCGTCGACGAGGCGCACGCCTCCACCACCGGGCAGATCCTGGCCTGGCTGCTCGCCGAGACCTGGAAGATCGGCGTGGTCGACTGGCCCGACGAAGCCGACCAGCTGCGCCGGCTGCTGCGCGCCGACCGGGCCACCCCCTCCCGCATCAACGAGGTCGCCCCGCACCTGGGTCGTGTGCTCGCCCCGGTCTGGCTGGCCTCGCCGTACGAGGTCGCCGGACTCGACGACAAGATGACCTTCGACGCTGTGCTGCTCGTCGACGCCGGGGCCACCACCCTGGCCGAGAACGTCGGTGCGATCCGCCGCGCCAAGCAGGTCGTGGCCTTCGGTGACCCGGTCACCCAGACGCCCTCGGGCTTCGAGACCGGCATCGTGGAGCCGGCCGATGTGCCCCGCCCGCAGGAGACCAACGTCGACGCGTTGCACGCCGACTCGGCGCTGGCACGCCTGGGCGAGCTGCTGCCCACCCTCACTCTCACCCGCAGCTACCGGGCCGGCGGCGAGGACCTCGCCGAGCTGGTCAACCACCGCTTCTACGGCGGCCGGATCGACTCGCTGCCCTGGGCGGGCAGCTTCCTCGGCCACGGCAGCCTCACCCTCAACTACGTCAAGGGCGGCCACGGCATGCCCGACGTCGACAGCGGCGCCGTCGAGAGCGTCGATGCCGAGGTATCCAAGGTCGTCGACCTGGTCATGGACCACGCCGTCAAGCGCCCCCGCGAGTCGCTCATGGTGATCACCGCCAGCGCCCGGCACGCCGTGCGCGTGCACCAGGCCGTGCTCGCCGCGTTCGCCAAGCGCACCGACCTGAGCGACTTCATCCTCAAGGACCGTGCCGAACCGTTCACGGTGCTCACCCTCGAGCAGGCCGTCGCGCAGAGCCGCGACCGGGTGATCTTCTCCATCGGCTACGGCCGCACCCCGCACGGCCGGCTGCTGAGCAACTTCGGTTCGCTCGGCGAACCCGGCGGCGAACGCCTGCTCGCGATCGGCATGACCCGCGCCCGCCGCGCCATGGACATCGTCTCCTGCTTCCGCCCCATCGACATCGACGCCGACCGCCAGCGGCACGGCATCCTGGCCCTGTCGCAGGTGCTCACCGAGACCGAGGCGCGCCGCAACGAGGTGGCGGTGCCGGATGCGCGCGAGGCCATGCTCGTCGACCTCGCCCGCCGTCTGGAACGCCAGGGCCTCACCGTCTCGCTCGGGCACCGCGGCAAGCTCGCGCTGGCCGCCTCCCACGCCGGCCGCGCCGTCGTGGTGGAGACCGACGCCGTGGTCAACCGGGCGAGCCTGCGCGAATCGCTGCGCCTCCGCCCCGAAGTGCTGCGCCGCCTCGGCTGGCACTACCTGCGGGTGCACAGCTTCGAGCTGTTCAGCAACCCGGATGCCGTCGCCGCCCGCGTCGCCGCCCTCGCGGGCGTCGTCCCGGCCGAAGGGTCTGGCGGTCCGGCGCACCGTGCCTGA",
    "translation": "MSSPGSRQATSPDSVSLGDPSLVAGNIAEPTWQRWRDELALVGGHSPLLHFGDSPRSRIELSATHPGGLPQFITGKTTLLSNLIRDELALRNARLAANEITQKGIELRSMRGIESVHLAIGLAQWRHGDVEFTAPVLLRPLAIRRYGRDFELKLKGQPFLNPELARALHDQFQITLDADAFVALAVTNGAFKPQPVIDRLRGLTSHLPWFNVVPRLVASSFADVGRAMAVDAQKLTHPVLDAVAGNPTARRAIEMAYNPVLPIGQDVRPPGTDTLLLDADAEQENVVAQISAGNSLVVKTLPGTGGTQTIVNAIGSLVAQHKRVLVVSARRSSLDGIAHRLVQVGLPGVAVTPRTLRRDLIQSITRNEKAAQPRVGDVDDALVRLRKVLLDYRSALTRKDAALGVSVLDALGELARLAQLPAPPSTTARLDRVALERLAHDRASAAAILIKAAVLGQFRYGPGDSPWYGASFASTADAGASHELAKRLSQTDVPRLLERAGHLVGQTRLRPFETVHELGIYLRLLLDIRETLDKFQPAVFDRSLTELIAATSARRDSPEMTSSNRRRLRKLADEYLRPGVHVSDMNESLRRIQQQRTLWQRYAAAGVTPEVPVGINDVHVAFQRVSEDLGKLDVPLGNAGTPRQLVSRPVKELLRTLAGLAADSEVLANLHERTALLATLREHNLDPLMTDLSQRHVSEENVAAELELAWWQSVLEVMLSGDRALLNANTQVLDRLEADFKLVDEAHASTTGQILAWLLAETWKIGVVDWPDEADQLRRLLRADRATPSRINEVAPHLGRVLAPVWLASPYEVAGLDDKMTFDAVLLVDAGATTLAENVGAIRRAKQVVAFGDPVTQTPSGFETGIVEPADVPRPQETNVDALHADSALARLGELLPTLTLTRSYRAGGEDLAELVNHRFYGGRIDSLPWAGSFLGHGSLTLNYVKGGHGMPDVDSGAVESVDAEVSKVVDLVMDHAVKRPRESLMVITASARHAVRVHQAVLAAFAKRTDLSDFILKDRAEPFTVLTLEQAVAQSRDRVIFSIGYGRTPHGRLLSNFGSLGEPGGERLLAIGMTRARRAMDIVSCFRPIDIDADRQRHGILALSQVLTETEARRNEVAVPDAREAMLVDLARRLERQGLTVSLGHRGKLALAASHAGRAVVVETDAVVNRASLRESLRLRPEVLRRLGWHYLRVHSFELFSNPDAVAARVAALAGVVPAEGSGGPAHRA",
    "product": ""
   },
   {
    "start": 13752,
    "end": 14009,
    "strand": 1,
    "locus_tag": "ctg55_9",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,752 - 14,009,\n (total: 258 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCGCAAGTCGGCACGACGCAACTCGGCGAGATGCAGCAAAGTGCCCCCTCCGGCGCCCTGAAAGGTGCTTCTGCGGCAAGTCGGCGACGTGAGAGTCTTTGCGTCTTTGCGTCTTTGCGTCTTTGCGTCTTTGCGTCTTTGCGTCTATGCAGCGGATGCAGCGGATGCAGCGGATGCAGCAGATGCAGCGGATGCAGCGAGGGGTGCCGGGAGGCGCTGCTGCGGGTGCGACGGGGGGAGAGGCGTGACGGCTAG",
    "translation": "MPQVGTTQLGEMQQSAPSGALKGASAASRRRESLCVFASLRLCVFASLRLCSGCSGCSGCSRCSGCSEGCREALLRVRRGERRDG",
    "product": ""
   },
   {
    "start": 14006,
    "end": 14890,
    "strand": -1,
    "locus_tag": "ctg55_10",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,006 - 14,890,\n (total: 885 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_10 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01741.21 (Large-conductance mechanosensitive channel, MscL): [130:259](score: 118.5, e-value: 2.2e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGCCCCACCTGCGGCGGCAAGCTGCGCAAGGTCTACTCGTCGATCGGGGTGAGCTTCACCGGCTCGGGCTTCTACCGCAACGACTCGCGCGCCGAGTCGAGCGGCAAGTCATCGCTGTCCGCGGAGAAGAGCGCGGCCAAGTCCGACAGCAAGTCCGACTCCGCCCCGGCCGCGAAAACGGCCGAGAAGTCCGGCGCCGCCGCATCGACGTCGTCGAGCGGGTCGTCGTCAGGCGGATCGTCCTCGTCGTCCTCTTCTTCCTCGTCCTCGAGCTCGTCGCCGACTCCGGCGCCGAAGTCATCCTGACCCTGCCAGGCGCCTCCGCACAACCGCGCACACGCACCGCAGCACAACCGCACCGCAGCACCTCAAGGAGTAATCGAATGGGCATGATCAACGGCTTCAAAGAATTCATCATGCGCGGCAACGTCATCGAACTCGCCGTCGCCGTCGTCATCGGGGCAGCATTCACCGGGGTCGTCAAGGCCATCGTCGACGGCATCTTCAACCCGCTGATCGGGGCGATCTTCAACGCCGAGTCGCTCAACGACTCCATGAACGTGACGCTCGGCGCCAGCACCATCTCGTTCGGACTCGTCCTGGCCGCGCTGATCCAGTTCCTCCTCGTGGCCGCGGTCGTGTACTTCGCCTTCGTGATGCCGCTCAACACGCTCAAGGAACACCAGGCCCGTCGCCGCCAGGCCGGCGAGCCGCTGGACCCGAAGAAGAACCCGATCACCGACCTCGACCTGCTCACCGAGATCCGCGACCTGCTCGCCGCCCAGAACGGTGCCGTCACGCCCTCCGCCGCCACGGATGCCCCCGCTCCGTACACCGCAGGCACCTCGCCCAGTGGGCCCGACGGCGCCAAGCACACCCTCTAG",
    "translation": "MPHLRRQAAQGLLVDRGELHRLGLLPQRLARRVERQVIAVRGEERGQVRQQVRLRPGRENGREVRRRRIDVVERVVVRRIVLVVLFFLVLELVADSGAEVILTLPGASAQPRTRTAAQPHRSTSRSNRMGMINGFKEFIMRGNVIELAVAVVIGAAFTGVVKAIVDGIFNPLIGAIFNAESLNDSMNVTLGASTISFGLVLAALIQFLLVAAVVYFAFVMPLNTLKEHQARRRQAGEPLDPKKNPITDLDLLTEIRDLLAAQNGAVTPSAATDAPAPYTAGTSPSGPDGAKHTL",
    "product": ""
   },
   {
    "start": 15040,
    "end": 15681,
    "strand": -1,
    "locus_tag": "ctg55_11",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,040 - 15,681,\n (total: 642 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_11 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01812.23 (5-formyltetrahydrofolate cyclo-ligase family): [29:207](score: 109.9, e-value: 1.4e-31)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGTAACCATGGCATTAGGTTAGCGGGAACCCGAATGGCTTACGCACCTAGGATGACTTGTATGGATTCTGACATCGAGCACCGAAAGCGGGCGCTCCGCGCAGAGCTGCGGGAGCGACGGCACACCATGACGGCGGCAGAACGCGACGCGGCCACCGCCGGGTTCACCGAAAACCTGCAAAGCATCGTGCTCGACCTGTCCGCCCGGTCGATTTCCTGCTACCTCTCCAGCCCCACCGAGCCCAACACGCGCCCGTTCGTGAACTGGGCCGAGGCCCGCGGCATCCGGGTGCTCTTCCCCGTATCGCGGGATGACGGCCTGCTGGACTGGACCGTCGGCGAGGAGGAAACCGAGGTTCAGGGTCTCTCCGGCGCCCCGGAGCCCCAGGGCGAACTGCTCGGCCCGATCGCCATCAACGATGTCGACCTCATCATCGTTCCCGCCGCGGCCATCGACCACACCGGTCTGCGGATGGGCTGGGGGCGCGGGTATTTCGACAAGACCCTCGGATCGATGGAGAAATGCCCGCCGGTGTACGCCGTCGTCTACGACAATGAGTATGTGGACGAAGTGCCGCGCGAGGTGCACGACCAGCCGGTGAACGGTCTCGTCACGCCCACCCGCATCGTCGTCTTCTAA",
    "translation": "MSNHGIRLAGTRMAYAPRMTCMDSDIEHRKRALRAELRERRHTMTAAERDAATAGFTENLQSIVLDLSARSISCYLSSPTEPNTRPFVNWAEARGIRVLFPVSRDDGLLDWTVGEEETEVQGLSGAPEPQGELLGPIAINDVDLIIVPAAAIDHTGLRMGWGRGYFDKTLGSMEKCPPVYAVVYDNEYVDEVPREVHDQPVNGLVTPTRIVVF",
    "product": ""
   },
   {
    "start": 15745,
    "end": 16563,
    "strand": 1,
    "locus_tag": "ctg55_12",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,745 - 16,563,\n (total: 819 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1064:glucose-1-phosphate adenylyl/thymidylyltransferase (Score: 177.3; E-value: 6.4e-54)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_12 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00483.26 (Nucleotidyl transferase): [1:246](score: 64.3, e-value: 1.4e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg55_12 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00483.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg55_12_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCCAAAGAGATGTTGCCGGTGGTGGACAAGCCCGCCATCCAGTACGTCGTCGAGGAGGCCGTCGCCGCCGGACTGACCGACGTGCTCATGATCACGGGCCGCAACAAGAACGCACTGGAGAACCATTTCGACCGCGTCACCGAGCTCGAGGCGGTGCTCATCCAGAAGGGTGACCGCGATCGTCTCGCCAAGGTGAACGAGTCGACCGACCTTGCCGACATGCACTACGTGCGTCAGGGTGACCCGCTGGGCCTGGGGCACGCCGTGCTCCGCGCCAAGATGCACGTGGGCAACGAGCCCTTCGCCGTGCTCCTCGGTGACGACATCATCGACGCCCGCGACCCGCTGCTCGACAAGATGCTCGCCGAGCAGATCGGCCGCAACACTAGCGTCGTCGCGCTCCTCGAGGTCGACCCGTCGCAGATCCACCTCTACGGCGCCGCCGCGATCGAGAAGACCGACGACCCCGACGTGGTGCGCATCACCGGCCTGGTCGAGAAGCCGTCGGCAGCGGATGCCCCGTCGAACCTGGCCATCATCGGCCGCTACGTGCTGCGCCCCGAGGTGTTCGACGTGCTCGAGCACACCGCGCCGGGCAAGGGCAACGAGATCCAGCTCACCGACGCCCTGCAGGAGATGGCGGTCAACCCGGAGACCACGGGCGGCGTCTACGGCGTCATCTTCCGCGGCCGTCGCTACGACACCGGGGACCGGTTGGACTACATCAAGGCCATCATCCAGCTCGCCGTGGACCGGGACGACCTCGGCACCGAGCTGCGCCCCTGGCTCAAGGAGTTCACCGCCACTCTCGACTAG",
    "translation": "MPKEMLPVVDKPAIQYVVEEAVAAGLTDVLMITGRNKNALENHFDRVTELEAVLIQKGDRDRLAKVNESTDLADMHYVRQGDPLGLGHAVLRAKMHVGNEPFAVLLGDDIIDARDPLLDKMLAEQIGRNTSVVALLEVDPSQIHLYGAAAIEKTDDPDVVRITGLVEKPSAADAPSNLAIIGRYVLRPEVFDVLEHTAPGKGNEIQLTDALQEMAVNPETTGGVYGVIFRGRRYDTGDRLDYIKAIIQLAVDRDDLGTELRPWLKEFTATLD",
    "product": ""
   },
   {
    "start": 16663,
    "end": 17286,
    "strand": 1,
    "locus_tag": "ctg55_13",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,663 - 17,286,\n (total: 624 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1111:GCN5-related N-acetyltransferase (Score: 102.3; E-value: 4.8e-31)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-ctg55_13 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13302.10 (Acetyltransferase (GNAT) domain): [1:142](score: 70.0, e-value: 3.4e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-ctg55_13 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF13302.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016747' target='_blank'>GO:0016747</a>: acyltransferase activity, transferring groups other than amino-acyl groups<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ctg55_13_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACCCTGCGCCCGATCCGCCTGCGCGACGCCCGCGCCCTGGAGCGCGAGCTGATGGCCAACCGTTCCTGGCTGCGCACCTGGGAGGCCACCAGTCCCTACGCGCCCATGTCCTTCGATACCCGGGCGAGCATCCGCAGCCTGCTCGCCCACTCGCGCACGGGCAGCGGGCTGCCGTTCCTGATCGAGTACAACGGGGAACTCGCCGGCCAGCTCAACGTGTCGTCGATCACCTGGGGATCGCTCTCCAGCGCGTCGATCGGCTACTGGGTGGGCGAGGAGTTCGCCGGCCGGTCGATCACCCCCACCGCGGTGGCCCTGGCCACCGACTACTGCTTCGCCCAGTTGGGCCTGCACCGCATGGAAATCTGCATCCGCCCGGAGAACGGGCCGTCGTTGCGGGTCGTGGAGAAGCTGGGGTTCCGCTACGAGGGGCTGCGCCGCCGGTTCATCCACATCAACGGCGCCTGGCGTGACCACTTCGCCTTCGGCCTCGTGGCCGAGGAGGTGCGCACCGGGGTGCTGCGACGCTGGCAGGACGGTCTCGTACCGCCCGGGAACGCCACCGTGAACGAGTACGACCGGGCCGCCTCGCAGCATCCGTTGCCGGTGGCCGACAAGTGA",
    "translation": "MTLRPIRLRDARALERELMANRSWLRTWEATSPYAPMSFDTRASIRSLLAHSRTGSGLPFLIEYNGELAGQLNVSSITWGSLSSASIGYWVGEEFAGRSITPTAVALATDYCFAQLGLHRMEICIRPENGPSLRVVEKLGFRYEGLRRRFIHINGAWRDHFAFGLVAEEVRTGVLRRWQDGLVPPGNATVNEYDRAASQHPLPVADK",
    "product": ""
   },
   {
    "start": 17461,
    "end": 18330,
    "strand": 1,
    "locus_tag": "ctg55_14",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,461 - 18,330,\n (total: 870 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGGCTGCAGCAGACCCTGCGCATCCTCGCCGAGACGTCGGAGATTCCCCAGGAGGTACGCGTGGAGACCAACGCGCGCGGTGTGTCCGCCCAACGTAAGCTGCTCGCCCAGGCCGAAGAAGACGCCCGGATCGCCTCCAAGGCCGCCGGAGACGCCGCCACGGCCGCTCGACGTGCCGCGGTGCTGCGCGCCGCCGCCGCCCGCCCCCAGGCGCTCACCCCGGCCGGCAAGGCCAAGCGCCTGCGCGCCATGCGGGCCCTCTCGACCCTGCTGCTGCTCATCGGCCTGGTCAGCGCCGTCGCCGGTCTCACCCTGCTCTCCACCGGCCTGTGGACGTTGCTGGTCGGCGGACTCGTCGCCGCCGGTACCGCGCTCGCCGCGCTCGGTCGTCTCGCCAGCGTGAGCCGGTCGGCCCGTGCGCCGCGCCAGGCAACGGATGCCGAGGCCACCGACACCGCTCGCCGCGTGCCGGCCGGCAGCCGCGGCCAGCGCTTCGAACCCGTGCACTTCGAGGAGGCGCCCGTGGCGGCGCCCACCCCCTGGACGCCGCAGCCGTTGCCCAAGCCCCTGCACCTCTCGCCGGGCTCGATCGCCCAGGCGGCCATGGCGTCGGTGGACGCCGCCGCGCAGCTGCGCCAGGCGGCCGCCGAAGCCGAGCTGCAGCGCCGGGCGCAGGCCCTGGCCGAGGCCATCGCGCCGTCGGAGGTCACCCCGATCACCCGCCCCGTGGCCGCCAGGGCTGCGGCCGCCAAGGCGTCGCCGCAGGCCGCGCCGAGCCGGTTCGCCAGCATGGGCATCGTCGGCGACACCGAACCCGGCATGACCGACCTCGACGATGTGCTGCGCCGCCGCCGGGCCGTCGGCTGA",
    "translation": "MRLQQTLRILAETSEIPQEVRVETNARGVSAQRKLLAQAEEDARIASKAAGDAATAARRAAVLRAAAARPQALTPAGKAKRLRAMRALSTLLLLIGLVSAVAGLTLLSTGLWTLLVGGLVAAGTALAALGRLASVSRSARAPRQATDAEATDTARRVPAGSRGQRFEPVHFEEAPVAAPTPWTPQPLPKPLHLSPGSIAQAAMASVDAAAQLRQAAAEAELQRRAQALAEAIAPSEVTPITRPVAARAAAAKASPQAAPSRFASMGIVGDTEPGMTDLDDVLRRRRAVG",
    "product": ""
   },
   {
    "start": 18392,
    "end": 18481,
    "strand": 1,
    "locus_tag": "ctg55_15",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,392 - 18,481,\n (total: 90 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGCAGTTGGTAGCGCGTCTCGTTCGCAATGAGAAGGTCAGGAGTTCGAATCTCCTTAGCTCCACCACTGATGCAGAAGGACCGTAG",
    "translation": "MAQLVARLVRNEKVRSSNLLSSTTDAEGP",
    "product": ""
   },
   {
    "start": 18596,
    "end": 18898,
    "strand": -1,
    "locus_tag": "ctg55_16",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,596 - 18,898,\n (total: 303 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCGCACCGTGACGCCCTCCACGCCCTCTCCGAGTGGGATGTCCGGCAGGTAGGTGCCCACCGGCGCATCGACATCCAGCAGCCCGTCATCGGCTGCGATCCCGATCGCAAGAACGCAGACGCCCTTGGCAACCGAGTGAACGTCCCGGCGATCATCGGCGCCCCAGTGATGCTCGGCGCTGTCGTCGTCAATGAGGACGTGCACGGAGTGCGCGCTGAAGCCGTCCTCTTCGATGATGCCGACAAGGCGGTCTACGATCGTCTGCGCTCTGCTCATCCCACCATTCTGTCGCGCGAGTAG",
    "translation": "MPHRDALHALSEWDVRQVGAHRRIDIQQPVIGCDPDRKNADALGNRVNVPAIIGAPVMLGAVVVNEDVHGVRAEAVLFDDADKAVYDRLRSAHPTILSRE",
    "product": ""
   },
   {
    "start": 18844,
    "end": 19035,
    "strand": -1,
    "locus_tag": "ctg55_17",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg55_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg55_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,844 - 19,035,\n (total: 192 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg55_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg55_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg55_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGTACGTGCTCGCGTTGGAGTACTGGAAGACCCGTCCGCGTGATGGACGGCCGAGAAACTCAGCCGCGAGGTCGGGCCAGTCCGTCGTCATCGTCTCCGACCACGGAAGGTCGATACCGCTCGTCATCGTGAGCAGATGCCGCACCGTGACGCCCTCCACGCCCTCTCCGAGTGGGATGTCCGGCAGGTAG",
    "translation": "MYVLALEYWKTRPRDGRPRNSAARSGQSVVIVSDHGRSIPLVIVSRCRTVTPSTPSPSGMSGR",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 138,
    "end": 4200,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 19200,
    "product": "NAPAA",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [
    {
     "start": 3,
     "end": 5,
     "strand": 1,
     "containedBy": [
      "ctg55_1"
     ]
    },
    {
     "start": 15658,
     "end": 15660,
     "strand": -1,
     "containedBy": [
      "ctg55_11"
     ]
    }
   ],
   "bindingSites": []
  },
  "type": "NAPAA",
  "products": [
   "NAPAA"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NAPAA",
  "anchor": "r55c1"
 }
};
var details_data = {
 "nrpspks": {
  "r36c1": {
   "id": "r36c1",
   "orfs": []
  },
  "r55c1": {
   "id": "r55c1",
   "orfs": [
    {
     "id": "ctg55_2",
     "sequence": "MTSNHPEPDKRSADSLASTVSMPATTSAPSSTVSSPYTQAHDQRVLDAGHLVHPERTLVDILRASAEEDPTALALEDAAGALSYRRLLRLVNDQAVQLSRAGVRRGDTVGIRIPSGTRELYLSILATLSVGAAYVPVDADDPEERARLVFGEAHVVGVIGAGGRFAVRDGLDAGVLTERPVPAGEDPSLAHWGEPMPGPDDDAWIIFTSGSTGVPKGVAVTHRSAAAFVDAEAGLFLSADPIAPGDRVLAGLSVAFDASCEEMWLAWRNGACLVPAPRSLVRSGADLGPWLIAHGITVVSTVPTLAALWPEEALENVRLVIFGGEACPPELAARISGRGREVWNTYGPTEATVVACGALLDGSDPVRIGLPLDGWSLAVVDADGARVPAGGTGELIIGGVGLARYLDAAQDAVKYAPHAGLGWDRAYRSGDLVRFDPEGLVFVGRADDQIKLGGRRIELGEIDAALQALPGVAGAAAVVQTTPAGNQVLVGYLSLVEPAPVGSDPVTSPFDLPAATEALRIALPAALVPLLAVVDTIPTRTSGKVDRAALPWPLPSLAGGSTDTDALSPTAAWLAEHWAAILGLPVTDADSDFFAYGGGSLSAAQFVSAIRERYPDTRVSDIYDHPRIGALAAELDGRTPPAARRSRTVLPTPARSGLLQSLLGIPLHLLVGAKWLVYLAAANNVLAAAGASFAPTVSWWWVLAGFLLLVTPLGKMGISVVAARLLLRGLKPGAYPRGGSVHLRLWLAEQVAQFVDAASLAGAPWISYYARLLGARIEPGVDLHSVPPVTGMLSIGARAAIEPEVDLAGYWLDGDTLRLGQVRIGEEAVVGSRSTLLGGAKIGAGAEIEPGSAVSGRVPAGERWAGSPATRVGSARHTWPAERPPSARRWLLAYGAGSVGLTAIPTVAVLLGVLIVGLFVGEAGSLGTAVGRAALAVPLAVLAAGLLYAGAVIGAVRLLGLGLTEGHHPVRSRVGWQVWMTERLLDGARTLLFPVYASLITPVWLRLLGAKVGSGVEASTVLLVPALTTIAPGAFLADDTMVACYELGGGWMRIDRAKIGRRAFLGNSGIAGPGRTVPRDGLVAVLSSTPRKAKRGSSWLGNPPARLRRRVTDIDEARTFHPHARLRLARSLWELLRLVPVFVSAWIALGVLAALEALWLTAGPGWALLLSGFVLIGAGVIAAAVSTAAKWLLVGRIRATEHPLWSSFIWRNEVSDTFVEMVARPWFAQNASGTPALALWLRSLGARIGRGVWCESYWLPEADLVTLAAGSSVNRGCVVQTHLFHDRIMQLDTVHIGAGGTLGPNSVILPAARIDDHATVGPGSLVMRGERVPTDSLWAGNPIAPWHRPPWKT",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 62,
       "end": 453,
       "predictions": [
        [
         "substrate consensus",
         "X"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "RASAEEDPTALALEDAAGALSYRRLLRLVNDQAVQLSRAGVRRGDTVGIRIPSGTRELYLSILATLSVGAAYVPVDADDPEERARLVFGEAHVVGVIGAGGRFAVRDGLDAGVLTERPVPAGEDPSLAHWGEPMPGPDDDAWIIFTSGSTGVPKGVAVTHRSAAAFVDAEAGLFLSADPIAPGDRVLAGLSVAFDASCEEMWLAWRNGACLVPAPRSLVRSGADLGPWLIAHGITVVSTVPTLAALWPEEALENVRLVIFGGEACPPELAARISGRGREVWNTYGPTEATVVACGALLDGSDPVRIGLPLDGWSLAVVDADGARVPAGGTGELIIGGVGLARYLDAAQDAVKYAPHAGLGWDRAYRSGDLVRFDPEGLVFVGRADDQIKLG",
       "dna_sequence": "CGGGCCAGCGCCGAGGAAGACCCCACCGCTCTCGCGCTCGAAGACGCCGCCGGGGCCCTGAGCTACCGCCGCCTGCTGCGGCTGGTCAACGACCAGGCCGTGCAGCTGAGCCGCGCGGGTGTGCGCCGCGGCGACACTGTCGGCATCCGCATCCCGTCGGGCACCCGGGAGCTGTACCTGTCGATCCTCGCGACCCTCAGCGTGGGCGCCGCCTACGTGCCGGTGGACGCCGACGACCCCGAGGAGCGGGCCCGGCTGGTGTTCGGTGAGGCCCACGTCGTGGGCGTGATCGGCGCCGGGGGCCGGTTCGCGGTGCGTGACGGCCTCGACGCCGGTGTGCTCACCGAGCGGCCCGTTCCGGCCGGGGAGGATCCGTCGCTGGCGCACTGGGGCGAGCCGATGCCGGGCCCCGACGACGACGCCTGGATCATCTTCACCTCCGGCTCCACCGGCGTGCCCAAGGGTGTCGCCGTGACGCACCGGTCCGCCGCGGCTTTCGTCGACGCCGAGGCCGGCCTGTTCCTCAGCGCCGACCCGATCGCGCCGGGCGACCGGGTGCTGGCTGGCCTCTCGGTGGCGTTCGATGCCTCCTGCGAGGAGATGTGGCTGGCCTGGCGGAACGGCGCGTGCCTGGTGCCGGCCCCGCGCTCCCTCGTGCGCAGCGGCGCCGACCTCGGCCCCTGGTTGATCGCCCACGGCATCACCGTGGTCTCCACCGTGCCCACCCTCGCCGCGCTCTGGCCCGAGGAGGCGCTGGAGAACGTGCGCCTGGTGATCTTCGGCGGCGAGGCGTGCCCACCCGAACTGGCCGCCCGCATCAGCGGCCGCGGCCGCGAGGTCTGGAACACGTACGGCCCCACCGAGGCCACCGTCGTGGCCTGCGGCGCCCTGCTCGACGGCAGCGACCCCGTGCGCATCGGCCTGCCGCTGGACGGCTGGAGCCTCGCCGTGGTCGACGCCGACGGCGCTCGGGTGCCCGCCGGCGGCACCGGTGAGCTGATCATCGGCGGCGTGGGCCTGGCCCGCTACCTCGACGCCGCGCAGGATGCCGTGAAATACGCCCCGCACGCCGGCCTCGGCTGGGACCGCGCCTACCGCAGCGGCGACCTGGTGCGCTTCGACCCCGAGGGGCTGGTCTTCGTGGGCCGCGCCGACGACCAGATCAAGCTCGGC",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PCP",
       "start": 573,
       "end": 637,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LAEHWAAILGLPVTDADSDFFAYGGGSLSAAQFVSAIRERYPDTRVSDIYDHPRIGALAAELDG",
       "dna_sequence": "CTCGCCGAACACTGGGCCGCGATCCTCGGGCTGCCCGTGACCGACGCCGACAGCGACTTCTTCGCCTACGGCGGGGGCTCCCTCTCGGCCGCCCAGTTCGTCTCCGCGATCCGGGAACGCTACCCCGACACCCGCGTCAGCGACATCTACGACCACCCGCGCATCGGCGCCCTGGCCGCCGAACTCGACGGC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "TIGR02353",
       "start": 658,
       "end": 1343,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LQSLLGIPLHLLVGAKWLVYLAAANNVLAAAGASFAPTVSWWWVLAGFLLLVTPLGKMGISVVAARLLLRGLKPGAYPRGGSVHLRLWLAEQVAQFVDAASLAGAPWISYYARLLGARIEPGVDLHSVPPVTGMLSIGARAAIEPEVDLAGYWLDGDTLRLGQVRIGEEAVVGSRSTLLGGAKIGAGAEIEPGSAVSGRVPAGERWAGSPATRVGSARHTWPAERPPSARRWLLAYGAGSVGLTAIPTVAVLLGVLIVGLFVGEAGSLGTAVGRAALAVPLAVLAAGLLYAGAVIGAVRLLGLGLTEGHHPVRSRVGWQVWMTERLLDGARTLLFPVYASLITPVWLRLLGAKVGSGVEASTVLLVPALTTIAPGAFLADDTMVACYELGGGWMRIDRAKIGRRAFLGNSGIAGPGRTVPRDGLVAVLSSTPRKAKRGSSWLGNPPARLRRRVTDIDEARTFHPHARLRLARSLWELLRLVPVFVSAWIALGVLAALEALWLTAGPGWALLLSGFVLIGAGVIAAAVSTAAKWLLVGRIRATEHPLWSSFIWRNEVSDTFVEMVARPWFAQNASGTPALALWLRSLGARIGRGVWCESYWLPEADLVTLAAGSSVNRGCVVQTHLFHDRIMQLDTVHIGAGGTLGPNSVILPAARIDDHATVGPGSLVMRGERVPTDSLWAGNPI",
       "dna_sequence": "CTGCAGAGCCTGCTCGGCATCCCCCTGCACCTGCTCGTGGGCGCCAAATGGCTGGTCTACCTGGCCGCGGCCAACAACGTGCTCGCCGCCGCCGGCGCATCCTTCGCCCCCACCGTGTCGTGGTGGTGGGTCCTAGCCGGGTTCCTCCTGCTCGTCACCCCGCTGGGCAAGATGGGCATCTCGGTGGTCGCGGCCCGGCTGCTGCTCCGGGGCCTGAAACCGGGCGCCTACCCGCGCGGCGGCTCGGTGCACCTGCGGCTCTGGCTGGCCGAGCAGGTGGCCCAGTTCGTCGACGCCGCCAGCCTGGCCGGGGCGCCGTGGATCAGCTACTACGCCCGCCTGCTCGGCGCCCGCATCGAACCGGGCGTGGACCTGCACTCGGTGCCCCCGGTCACCGGGATGCTCAGCATCGGGGCACGCGCCGCGATCGAACCCGAGGTGGACCTGGCCGGCTACTGGCTCGACGGCGACACCCTGCGCCTGGGCCAGGTGCGCATCGGCGAGGAGGCCGTGGTCGGTTCCCGCAGCACCCTGCTCGGCGGCGCGAAGATCGGCGCCGGCGCCGAGATCGAGCCGGGCTCCGCGGTCTCCGGCCGCGTCCCGGCCGGCGAACGCTGGGCCGGTTCACCCGCGACCCGGGTCGGGTCGGCCCGCCACACCTGGCCGGCCGAACGTCCGCCGAGCGCCCGCCGTTGGCTGCTCGCCTACGGCGCCGGCTCCGTCGGCCTCACCGCCATCCCCACCGTCGCCGTGCTGCTCGGCGTGCTCATCGTCGGGCTGTTCGTGGGGGAGGCCGGCAGTCTCGGCACCGCCGTCGGCCGGGCCGCCCTGGCCGTGCCGCTGGCCGTGCTCGCCGCCGGCCTGCTCTACGCGGGCGCCGTGATCGGCGCGGTGCGCCTCCTCGGCCTGGGCCTGACCGAGGGGCACCATCCGGTGCGCAGCCGCGTGGGCTGGCAGGTCTGGATGACCGAACGCCTGCTCGACGGCGCCCGCACCCTGCTCTTCCCGGTCTACGCGAGCCTGATCACGCCAGTCTGGCTGCGGTTGCTCGGTGCGAAGGTCGGCTCCGGCGTGGAGGCCTCCACCGTGCTGCTCGTGCCCGCACTCACCACCATCGCGCCGGGCGCATTCCTCGCCGACGACACCATGGTCGCCTGTTACGAGCTCGGCGGCGGCTGGATGCGCATCGACCGGGCCAAGATCGGCCGCCGGGCGTTCCTGGGCAACAGCGGCATCGCCGGCCCCGGCCGCACCGTGCCGCGGGACGGCCTCGTGGCCGTGCTCTCCTCCACCCCGCGGAAGGCCAAACGCGGGTCCTCCTGGCTGGGCAACCCGCCGGCGCGGCTGCGCCGCCGGGTCACCGACATCGACGAGGCCCGCACCTTCCACCCGCACGCCCGGCTGCGCCTGGCCCGGTCGCTCTGGGAACTCCTCCGCCTGGTGCCGGTGTTCGTCTCCGCCTGGATCGCGCTCGGCGTCCTCGCCGCCCTCGAGGCGCTCTGGCTCACCGCCGGGCCCGGCTGGGCGCTGCTGCTCTCCGGGTTCGTGCTCATCGGCGCGGGAGTGATCGCGGCAGCGGTCAGCACGGCCGCAAAATGGCTGCTGGTGGGCCGCATCCGCGCCACCGAGCATCCGCTCTGGTCGTCGTTCATCTGGCGCAACGAGGTGTCGGACACCTTTGTGGAGATGGTGGCGCGGCCGTGGTTCGCGCAGAACGCGTCGGGCACGCCGGCCCTGGCGCTGTGGCTGCGCTCGCTCGGCGCCCGGATCGGCCGGGGCGTGTGGTGCGAGTCGTACTGGCTCCCAGAGGCCGACCTGGTCACCCTCGCCGCCGGCAGCAGCGTCAACCGCGGCTGCGTGGTGCAGACCCACCTGTTCCACGACCGGATCATGCAGCTGGACACCGTGCACATCGGCGCCGGCGGCACCCTGGGGCCCAACAGCGTGATCCTGCCCGCGGCGCGGATCGACGACCACGCCACCGTCGGGCCGGGCTCCCTGGTGATGCGCGGCGAGCGGGTGCCCACCGATTCGCTGTGGGCCGGCAACCCGATT",
       "abbreviation": "",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": [
      {
       "start": 62,
       "end": 1343,
       "complete": true,
       "iterative": false,
       "monomer": "?",
       "multi_cds": null,
       "match_id": null
      }
     ]
    },
    {
     "id": "ctg55_5",
     "sequence": "MSGLPGSSSSAVDLSRTVVVAIGHRAETKAGDHALLARLVARLTGVGAASVALTQRCPQCGAPGHGPLRVVIDGSGTGTPRVSLARAGGLLAVAVTAAGPMGIDLESRADLARAPLNDVALSPAEAATLATLRPADAAAALAALWTSKEAVLKAAEVGLRVDPSELTVTLDAAGPPASARHRMLTDWPQAPFALGELHLFPVAGRAGFTSALAVISSRRPMLRFLPLDD",
     "domains": [
      {
       "type": "ACPS",
       "start": 101,
       "end": 161,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "GIDLESRADLARAPLNDVALSPAEAATLATLRPADAAAALAALWTSKEAVLKAAEVGLRV",
       "dna_sequence": "GGCATCGATCTGGAGTCCCGCGCCGACCTAGCCCGCGCTCCGCTGAACGATGTGGCGCTCTCCCCCGCCGAGGCCGCGACCCTCGCCACGCTGCGTCCGGCCGATGCGGCCGCGGCGCTGGCCGCCCTGTGGACCTCGAAGGAGGCCGTGCTCAAGGCGGCCGAGGTCGGTCTCCGCGTG",
       "abbreviation": "",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": []
    }
   ]
  }
 }
};
var resultsData = {
 "r8c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001289: 16-10643": {
       "start": 16,
       "end": 10643,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "penT",
         "query_loc": 63588,
         "subject_loc": 4728
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ALR96374.1",
         "start": 9042,
         "end": 9336,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ALR96375.1",
         "start": 9407,
         "end": 9725,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ALR96376.1",
         "start": 9833,
         "end": 10643,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "penA1",
         "start": 16,
         "end": 211,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "penA2",
         "start": 292,
         "end": 484,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "penB",
         "start": 670,
         "end": 3793,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "penC",
         "start": 5701,
         "end": 7066,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "penD",
         "start": 7146,
         "end": 8832,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "penT",
         "start": 3789,
         "end": 5667,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        }
       ]
      },
      "BGC0002576: 0-3141": {
       "start": 0,
       "end": 3141,
       "links": [
        {
         "query": "ctg8_57",
         "subject": "UBK24780.1",
         "query_loc": 65485,
         "subject_loc": 1570
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "UBK24780.1",
         "start": 0,
         "end": 3141,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg8_57"
         }
        }
       ]
      },
      "BGC0000560: 1037-9106": {
       "start": 1037,
       "end": 9106,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "subT",
         "query_loc": 63588,
         "subject_loc": 8227
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "subA",
         "start": 1037,
         "end": 1208,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "subB",
         "start": 2270,
         "end": 5381,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "subC",
         "start": 5405,
         "end": 6728,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "subI",
         "start": 6740,
         "end": 7331,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "subP",
         "start": 1295,
         "end": 2270,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "subT",
         "start": 7348,
         "end": 9106,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        }
       ]
      },
      "BGC0000543: 87-7506": {
       "start": 87,
       "end": 7506,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "pepT",
         "query_loc": 63588,
         "subject_loc": 945
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "pepA",
         "start": 2321,
         "end": 2504,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "pepB",
         "start": 3409,
         "end": 6313,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "pepC",
         "start": 6309,
         "end": 7506,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "pepI",
         "start": 2027,
         "end": 2237,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "pepP",
         "start": 2565,
         "end": 3423,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "pepT",
         "start": 87,
         "end": 1803,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        }
       ]
      },
      "BGC0000542: 0-9130": {
       "start": 0,
       "end": 9130,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "pabT",
         "query_loc": 63588,
         "subject_loc": 6809
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "pabA",
         "start": 0,
         "end": 177,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "pabB",
         "start": 2679,
         "end": 5871,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "pabC",
         "start": 7747,
         "end": 9130,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "pabE",
         "start": 1071,
         "end": 1872,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "pabF",
         "start": 346,
         "end": 1075,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "pabG",
         "start": 1884,
         "end": 2652,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "pabT",
         "start": 5867,
         "end": 7751,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        }
       ]
      },
      "BGC0000538: 238-7610": {
       "start": 238,
       "end": 7610,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "nisT",
         "query_loc": 63588,
         "subject_loc": 4412
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "nisB",
         "start": 519,
         "end": 3501,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "nisC",
         "start": 5294,
         "end": 6551,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "nisI",
         "start": 6547,
         "end": 7285,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "nisP",
         "start": 7286,
         "end": 7610,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "nisT",
         "start": 3511,
         "end": 5314,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        },
        {
         "locus_tag": "nisin",
         "start": 238,
         "end": 412,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000541: 0-9113": {
       "start": 0,
       "end": 9113,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "paeT",
         "query_loc": 63588,
         "subject_loc": 6790
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "paeA",
         "start": 0,
         "end": 177,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "paeB",
         "start": 2678,
         "end": 5855,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paeC",
         "start": 7730,
         "end": 9113,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paeE",
         "start": 1070,
         "end": 1871,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paeF",
         "start": 345,
         "end": 1074,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "paeG",
         "start": 1883,
         "end": 2651,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paeT",
         "start": 5851,
         "end": 7729,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        }
       ]
      },
      "BGC0000528: 0-8183": {
       "start": 0,
       "end": 8183,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "CMM_1964",
         "query_loc": 63588,
         "subject_loc": 1951
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "CMM_1962",
         "start": 0,
         "end": 747,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CMM_1963",
         "start": 752,
         "end": 1505,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CMM_1964",
         "start": 1501,
         "end": 2401,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        },
        {
         "locus_tag": "CMM_1965",
         "start": 2554,
         "end": 3229,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "CMM_1966",
         "start": 3225,
         "end": 4362,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "CMM_1967",
         "start": 4723,
         "end": 4930,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CMM_1968",
         "start": 5021,
         "end": 8183,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001364: 3-17587": {
       "start": 3,
       "end": 17587,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "G339_RS40375",
         "query_loc": 63588,
         "subject_loc": 10104
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "G339_RS0111955",
         "start": 3,
         "end": 417,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0111965",
         "start": 998,
         "end": 2231,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0111970",
         "start": 2316,
         "end": 2985,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0111975",
         "start": 3176,
         "end": 3605,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0111980",
         "start": 3597,
         "end": 3969,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0111985",
         "start": 4174,
         "end": 4516,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0111990",
         "start": 4533,
         "end": 5367,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112000",
         "start": 6319,
         "end": 6532,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112005",
         "start": 6617,
         "end": 7631,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112010",
         "start": 7967,
         "end": 9017,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112020",
         "start": 11101,
         "end": 12010,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112025",
         "start": 12026,
         "end": 15248,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112030",
         "start": 15389,
         "end": 15629,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112035",
         "start": 15660,
         "end": 16032,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112040",
         "start": 16576,
         "end": 17587,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS33370",
         "start": 446,
         "end": 827,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS40365",
         "start": 5460,
         "end": 5871,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS40370",
         "start": 5774,
         "end": 6323,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS40375",
         "start": 9104,
         "end": 11105,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        }
       ]
      },
      "BGC0000255: 796-9440": {
       "start": 796,
       "end": 9440,
       "links": [
        {
         "query": "ctg8_68",
         "subject": "AAW33976.1",
         "query_loc": 77227,
         "subject_loc": 8047
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AAW33970.1",
         "start": 796,
         "end": 1609,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAW33971.1",
         "start": 2400,
         "end": 3156,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAW33972.1",
         "start": 3257,
         "end": 4589,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AAW33973.1",
         "start": 4578,
         "end": 4821,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAW33974.1",
         "start": 5044,
         "end": 6052,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAW33975.1",
         "start": 6282,
         "end": 7575,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AAW33976.1",
         "start": 7575,
         "end": 8520,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg8_68"
         }
        },
        {
         "locus_tag": "AAW33977.1",
         "start": 8546,
         "end": 9440,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001289: 16-10643": {
       "start": 16,
       "end": 10643,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "penT",
         "query_loc": 63588,
         "subject_loc": 4728
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ALR96374.1",
         "start": 9042,
         "end": 9336,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ALR96375.1",
         "start": 9407,
         "end": 9725,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ALR96376.1",
         "start": 9833,
         "end": 10643,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "penA1",
         "start": 16,
         "end": 211,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "penA2",
         "start": 292,
         "end": 484,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "penB",
         "start": 670,
         "end": 3793,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "penC",
         "start": 5701,
         "end": 7066,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "penD",
         "start": 7146,
         "end": 8832,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "penT",
         "start": 3789,
         "end": 5667,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        }
       ]
      },
      "BGC0002576: 0-3141": {
       "start": 0,
       "end": 3141,
       "links": [
        {
         "query": "ctg8_57",
         "subject": "UBK24780.1",
         "query_loc": 65485,
         "subject_loc": 1570
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "UBK24780.1",
         "start": 0,
         "end": 3141,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg8_57"
         }
        }
       ]
      },
      "BGC0000560: 1037-9106": {
       "start": 1037,
       "end": 9106,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "subT",
         "query_loc": 63588,
         "subject_loc": 8227
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "subA",
         "start": 1037,
         "end": 1208,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "subB",
         "start": 2270,
         "end": 5381,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "subC",
         "start": 5405,
         "end": 6728,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "subI",
         "start": 6740,
         "end": 7331,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "subP",
         "start": 1295,
         "end": 2270,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "subT",
         "start": 7348,
         "end": 9106,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        }
       ]
      },
      "BGC0000543: 87-7506": {
       "start": 87,
       "end": 7506,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "pepT",
         "query_loc": 63588,
         "subject_loc": 945
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "pepA",
         "start": 2321,
         "end": 2504,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "pepB",
         "start": 3409,
         "end": 6313,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "pepC",
         "start": 6309,
         "end": 7506,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "pepI",
         "start": 2027,
         "end": 2237,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "pepP",
         "start": 2565,
         "end": 3423,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "pepT",
         "start": 87,
         "end": 1803,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        }
       ]
      },
      "BGC0000542: 0-9130": {
       "start": 0,
       "end": 9130,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "pabT",
         "query_loc": 63588,
         "subject_loc": 6809
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "pabA",
         "start": 0,
         "end": 177,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "pabB",
         "start": 2679,
         "end": 5871,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "pabC",
         "start": 7747,
         "end": 9130,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "pabE",
         "start": 1071,
         "end": 1872,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "pabF",
         "start": 346,
         "end": 1075,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "pabG",
         "start": 1884,
         "end": 2652,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "pabT",
         "start": 5867,
         "end": 7751,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        }
       ]
      },
      "BGC0000538: 238-7610": {
       "start": 238,
       "end": 7610,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "nisT",
         "query_loc": 63588,
         "subject_loc": 4412
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "nisB",
         "start": 519,
         "end": 3501,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "nisC",
         "start": 5294,
         "end": 6551,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "nisI",
         "start": 6547,
         "end": 7285,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "nisP",
         "start": 7286,
         "end": 7610,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "nisT",
         "start": 3511,
         "end": 5314,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        },
        {
         "locus_tag": "nisin",
         "start": 238,
         "end": 412,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000541: 0-9113": {
       "start": 0,
       "end": 9113,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "paeT",
         "query_loc": 63588,
         "subject_loc": 6790
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "paeA",
         "start": 0,
         "end": 177,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "paeB",
         "start": 2678,
         "end": 5855,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paeC",
         "start": 7730,
         "end": 9113,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paeE",
         "start": 1070,
         "end": 1871,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paeF",
         "start": 345,
         "end": 1074,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "paeG",
         "start": 1883,
         "end": 2651,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paeT",
         "start": 5851,
         "end": 7729,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        }
       ]
      },
      "BGC0000528: 0-8183": {
       "start": 0,
       "end": 8183,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "CMM_1964",
         "query_loc": 63588,
         "subject_loc": 1951
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "CMM_1962",
         "start": 0,
         "end": 747,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CMM_1963",
         "start": 752,
         "end": 1505,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CMM_1964",
         "start": 1501,
         "end": 2401,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        },
        {
         "locus_tag": "CMM_1965",
         "start": 2554,
         "end": 3229,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "CMM_1966",
         "start": 3225,
         "end": 4362,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "CMM_1967",
         "start": 4723,
         "end": 4930,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CMM_1968",
         "start": 5021,
         "end": 8183,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001364: 3-17587": {
       "start": 3,
       "end": 17587,
       "links": [
        {
         "query": "ctg8_56",
         "subject": "G339_RS40375",
         "query_loc": 63588,
         "subject_loc": 10104
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "G339_RS0111955",
         "start": 3,
         "end": 417,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0111965",
         "start": 998,
         "end": 2231,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0111970",
         "start": 2316,
         "end": 2985,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0111975",
         "start": 3176,
         "end": 3605,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0111980",
         "start": 3597,
         "end": 3969,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0111985",
         "start": 4174,
         "end": 4516,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0111990",
         "start": 4533,
         "end": 5367,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112000",
         "start": 6319,
         "end": 6532,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112005",
         "start": 6617,
         "end": 7631,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112010",
         "start": 7967,
         "end": 9017,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112020",
         "start": 11101,
         "end": 12010,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112025",
         "start": 12026,
         "end": 15248,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112030",
         "start": 15389,
         "end": 15629,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112035",
         "start": 15660,
         "end": 16032,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS0112040",
         "start": 16576,
         "end": 17587,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS33370",
         "start": 446,
         "end": 827,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS40365",
         "start": 5460,
         "end": 5871,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS40370",
         "start": 5774,
         "end": 6323,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G339_RS40375",
         "start": 9104,
         "end": 11105,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "ctg8_56"
         }
        }
       ]
      },
      "BGC0000255: 796-9440": {
       "start": 796,
       "end": 9440,
       "links": [
        {
         "query": "ctg8_68",
         "subject": "AAW33976.1",
         "query_loc": 77227,
         "subject_loc": 8047
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AAW33970.1",
         "start": 796,
         "end": 1609,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAW33971.1",
         "start": 2400,
         "end": 3156,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAW33972.1",
         "start": 3257,
         "end": 4589,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AAW33973.1",
         "start": 4578,
         "end": 4821,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAW33974.1",
         "start": 5044,
         "end": 6052,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAW33975.1",
         "start": 6282,
         "end": 7575,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AAW33976.1",
         "start": 7575,
         "end": 8520,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg8_68"
         }
        },
        {
         "locus_tag": "AAW33977.1",
         "start": 8546,
         "end": 9440,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg8_50": {
     "functions": []
    },
    "ctg8_51": {
     "functions": []
    },
    "ctg8_52": {
     "functions": []
    },
    "ctg8_53": {
     "functions": []
    },
    "ctg8_54": {
     "functions": []
    },
    "ctg8_55": {
     "functions": [
      {
       "description": "SMCOG1083:oxidoreductase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg8_56": {
     "functions": [
      {
       "description": "SMCOG1000:ABC transporter ATP-binding protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg8_57": {
     "functions": [
      {
       "description": "Lant_dehydr_C",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Lant_dehydr_N",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1155:Lantibiotic dehydratase domain protein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg8_58": {
     "functions": [
      {
       "description": "LANC_like",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1140:Lanthionine synthetase C family protein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg8_59": {
     "functions": []
    },
    "ctg8_60": {
     "functions": [
      {
       "description": "SMCOG1057:TetR family transcriptional regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg8_61": {
     "functions": [
      {
       "description": "SMCOG1001:short-chain dehydrogenase/reductase SDR ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg8_62": {
     "functions": [
      {
       "description": "PF07366",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg8_63": {
     "functions": []
    },
    "ctg8_64": {
     "functions": []
    },
    "ctg8_65": {
     "functions": [
      {
       "description": "SMCOG1260:AraC family transcriptional regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg8_66": {
     "functions": []
    },
    "ctg8_67": {
     "functions": []
    },
    "ctg8_68": {
     "functions": [
      {
       "description": "PF00561",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Abhydrolase_6",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1036:alpha/beta hydrolase fold protein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg8_69": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "ctg8_51",
      "seqLength": 1033,
      "domains": [
       {
        "start": 29,
        "end": 220,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004519' target='_blank'>GO:0004519</a>: endonuclease activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006304' target='_blank'>GO:0006304</a>: DNA modification"
        ],
        "html_class": "generic-type-other",
        "name": "HSDR_N",
        "accession": "PF04313",
        "description": "Type I restriction enzyme R protein N terminus (HSDR_N)",
        "evalue": "1.6e-55",
        "score": "188.2"
       },
       {
        "start": 275,
        "end": 493,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "SWI2_SNF2",
        "accession": "PF18766",
        "description": "SWI2/SNF2 ATPase",
        "evalue": "4.5e-50",
        "score": "170.5"
       },
       {
        "start": 722,
        "end": 1026,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "EcoR124_C",
        "accession": "PF12008",
        "description": "Type I restriction and modification enzyme - subunit R C terminal",
        "evalue": "1.6e-67",
        "score": "228.0"
       }
      ]
     },
     {
      "id": "ctg8_54",
      "seqLength": 189,
      "domains": [
       {
        "start": 5,
        "end": 177,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008703' target='_blank'>GO:0008703</a>: 5-amino-6-(5-phosphoribosylamino)uracil reductase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009231' target='_blank'>GO:0009231</a>: riboflavin biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "RibD_C",
        "accession": "PF01872",
        "description": "RibD C-terminal domain",
        "evalue": "1.2e-12",
        "score": "48.2"
       }
      ]
     },
     {
      "id": "ctg8_55",
      "seqLength": 328,
      "domains": [
       {
        "start": 30,
        "end": 285,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Bac_luciferase",
        "accession": "PF00296",
        "description": "Luciferase-like monooxygenase",
        "evalue": "6.1e-19",
        "score": "68.7"
       }
      ]
     },
     {
      "id": "ctg8_56",
      "seqLength": 608,
      "domains": [
       {
        "start": 376,
        "end": 530,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-transport",
        "name": "ABC_tran",
        "accession": "PF00005",
        "description": "ABC transporter",
        "evalue": "5.2e-31",
        "score": "108.1"
       }
      ]
     },
     {
      "id": "ctg8_57",
      "seqLength": 681,
      "domains": [
       {
        "start": 13,
        "end": 351,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Lant_dehydr_N",
        "accession": "PF04738",
        "description": "Lantibiotic dehydratase, N terminus",
        "evalue": "4.5e-63",
        "score": "213.4"
       },
       {
        "start": 423,
        "end": 664,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Lant_dehydr_C",
        "accession": "PF14028",
        "description": "Lantibiotic biosynthesis dehydratase C-term",
        "evalue": "5e-32",
        "score": "111.9"
       }
      ]
     },
     {
      "id": "ctg8_58",
      "seqLength": 465,
      "domains": [
       {
        "start": 82,
        "end": 452,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0031179' target='_blank'>GO:0031179</a>: peptide modification"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "LANC_like",
        "accession": "PF05147",
        "description": "Lanthionine synthetase C-like protein",
        "evalue": "6e-35",
        "score": "120.6"
       }
      ]
     },
     {
      "id": "ctg8_59",
      "seqLength": 329,
      "domains": [
       {
        "start": 15,
        "end": 307,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "SLAC1",
        "accession": "PF03595",
        "description": "Voltage-dependent anion channel",
        "evalue": "5.7e-19",
        "score": "68.7"
       }
      ]
     },
     {
      "id": "ctg8_60",
      "seqLength": 185,
      "domains": [
       {
        "start": 11,
        "end": 58,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding"
        ],
        "html_class": "generic-type-regulatory",
        "name": "TetR_N",
        "accession": "PF00440",
        "description": "Bacterial regulatory proteins, tetR family",
        "evalue": "1.8e-14",
        "score": "53.4"
       },
       {
        "start": 75,
        "end": 173,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "TetR_C_21",
        "accession": "PF17926",
        "description": "Tetracyclin repressor-like, C-terminal domain",
        "evalue": "2.2e-13",
        "score": "50.4"
       }
      ]
     },
     {
      "id": "ctg8_61",
      "seqLength": 281,
      "domains": [
       {
        "start": 3,
        "end": 186,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "adh_short",
        "accession": "PF00106",
        "description": "short chain dehydrogenase",
        "evalue": "3.1e-44",
        "score": "150.9"
       }
      ]
     },
     {
      "id": "ctg8_62",
      "seqLength": 134,
      "domains": [
       {
        "start": 8,
        "end": 132,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030638' target='_blank'>GO:0030638</a>: polyketide metabolic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SnoaL",
        "accession": "PF07366",
        "description": "SnoaL-like polyketide cyclase",
        "evalue": "6.8e-26",
        "score": "90.7"
       }
      ]
     },
     {
      "id": "ctg8_63",
      "seqLength": 145,
      "domains": [
       {
        "start": 13,
        "end": 136,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "SnoaL_4",
        "accession": "PF13577",
        "description": "SnoaL-like domain",
        "evalue": "2.6e-13",
        "score": "50.2"
       }
      ]
     },
     {
      "id": "ctg8_64",
      "seqLength": 212,
      "domains": [
       {
        "start": 31,
        "end": 118,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "HD",
        "accession": "PF01966",
        "description": "HD domain",
        "evalue": "8.7e-09",
        "score": "35.8"
       }
      ]
     },
     {
      "id": "ctg8_65",
      "seqLength": 311,
      "domains": [
       {
        "start": 1,
        "end": 160,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DJ-1_PfpI",
        "accession": "PF01965",
        "description": "DJ-1/PfpI family",
        "evalue": "1.9e-26",
        "score": "93.0"
       },
       {
        "start": 220,
        "end": 299,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043565' target='_blank'>GO:0043565</a>: sequence-specific DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "HTH_18",
        "accession": "PF12833",
        "description": "Helix-turn-helix domain",
        "evalue": "5e-22",
        "score": "78.1"
       }
      ]
     },
     {
      "id": "ctg8_66",
      "seqLength": 170,
      "domains": [
       {
        "start": 28,
        "end": 163,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008199' target='_blank'>GO:0008199</a>: ferric iron binding"
        ],
        "html_class": "generic-type-other",
        "name": "Ferritin",
        "accession": "PF00210",
        "description": "Ferritin-like domain",
        "evalue": "5.8e-19",
        "score": "68.6"
       }
      ]
     },
     {
      "id": "ctg8_67",
      "seqLength": 182,
      "domains": [
       {
        "start": 55,
        "end": 110,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051920' target='_blank'>GO:0051920</a>: peroxiredoxin activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "CMD",
        "accession": "PF02627",
        "description": "Carboxymuconolactone decarboxylase family",
        "evalue": "4.3e-09",
        "score": "36.5"
       }
      ]
     },
     {
      "id": "ctg8_68",
      "seqLength": 323,
      "domains": [
       {
        "start": 68,
        "end": 304,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Abhydrolase_1",
        "accession": "PF00561",
        "description": "alpha/beta hydrolase fold",
        "evalue": "3.5e-27",
        "score": "95.8"
       }
      ]
     },
     {
      "id": "ctg8_69",
      "seqLength": 131,
      "domains": [
       {
        "start": 35,
        "end": 97,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DUF302",
        "accession": "PF03625",
        "description": "Domain of unknown function DUF302",
        "evalue": "6e-16",
        "score": "58.2"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   }
  ]
 },
 "r14c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000644: 97-6276": {
       "start": 97,
       "end": 6276,
       "links": [
        {
         "query": "ctg14_26",
         "subject": "crtI",
         "query_loc": 23234,
         "subject_loc": 2966
        },
        {
         "query": "ctg14_24",
         "subject": "lbtBC",
         "query_loc": 21916,
         "subject_loc": 4828
        },
        {
         "query": "ctg14_27",
         "subject": "crtB",
         "query_loc": 24494,
         "subject_loc": 1683
        },
        {
         "query": "ctg14_25",
         "subject": "lbtA",
         "query_loc": 22258,
         "subject_loc": 3995
        },
        {
         "query": "ctg14_28",
         "subject": "crtE",
         "query_loc": 25468,
         "subject_loc": 671
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 1242,
         "end": 2124,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg14_27"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 97,
         "end": 1246,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_28"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 2120,
         "end": 3812,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_26"
         }
        },
        {
         "locus_tag": "crtX",
         "start": 5544,
         "end": 6276,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "lbtA",
         "start": 3808,
         "end": 4183,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "ctg14_25"
         }
        },
        {
         "locus_tag": "lbtBC",
         "start": 4179,
         "end": 5478,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_24"
         }
        }
       ]
      },
      "BGC0000648: 1057-11443": {
       "start": 1057,
       "end": 11443,
       "links": [
        {
         "query": "ctg14_52",
         "subject": "ORF1",
         "query_loc": 52749,
         "subject_loc": 1600
        },
        {
         "query": "ctg14_26",
         "subject": "ORF2",
         "query_loc": 23234,
         "subject_loc": 2927
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ORF1",
         "start": 1057,
         "end": 2143,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_52"
         }
        },
        {
         "locus_tag": "ORF2",
         "start": 2150,
         "end": 3704,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_26"
         }
        },
        {
         "locus_tag": "ORF3",
         "start": 3700,
         "end": 4711,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ORF4",
         "start": 4771,
         "end": 6229,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ORF5",
         "start": 6225,
         "end": 7152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF6",
         "start": 7148,
         "end": 8261,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF7",
         "start": 8257,
         "end": 8644,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF8",
         "start": 8640,
         "end": 8991,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ORF9",
         "start": 8987,
         "end": 9665,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "carA",
         "start": 9661,
         "end": 10528,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "carH",
         "start": 10543,
         "end": 11443,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000664: 0-8391": {
       "start": 0,
       "end": 8391,
       "links": [
        {
         "query": "ctg14_52",
         "subject": "SGR_6830",
         "query_loc": 52749,
         "subject_loc": 7752
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "SGR_6824",
         "start": 0,
         "end": 1242,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6825",
         "start": 1238,
         "end": 1967,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6826",
         "start": 1963,
         "end": 3520,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6827",
         "start": 3555,
         "end": 4572,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6828",
         "start": 4568,
         "end": 5597,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6829",
         "start": 5593,
         "end": 7117,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6830",
         "start": 7113,
         "end": 8391,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_52"
         }
        }
       ]
      },
      "BGC0000633: 0-14284": {
       "start": 0,
       "end": 14284,
       "links": [
        {
         "query": "ctg14_52",
         "subject": "crtE",
         "query_loc": 52749,
         "subject_loc": 5630
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "BAB69138.1",
         "start": 0,
         "end": 363,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAB69139.1",
         "start": 418,
         "end": 967,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAB69147.1",
         "start": 10059,
         "end": 12159,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAB69148.1",
         "start": 12241,
         "end": 14284,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtE",
         "start": 5060,
         "end": 6200,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_52"
         }
        },
        {
         "locus_tag": "crtI-1",
         "start": 6196,
         "end": 7738,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI-2",
         "start": 7734,
         "end": 8763,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtT",
         "start": 2677,
         "end": 3409,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtU",
         "start": 1121,
         "end": 2624,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtV",
         "start": 8759,
         "end": 9839,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 3452,
         "end": 4799,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000637: 540-9054": {
       "start": 540,
       "end": 9054,
       "links": [
        {
         "query": "ctg14_26",
         "subject": "crtI",
         "query_loc": 23234,
         "subject_loc": 5649
        },
        {
         "query": "ctg14_23",
         "subject": "crtEb",
         "query_loc": 21290,
         "subject_loc": 7750
        },
        {
         "query": "ctg14_27",
         "subject": "crtB",
         "query_loc": 24494,
         "subject_loc": 4370
        },
        {
         "query": "ctg14_28",
         "subject": "crtE",
         "query_loc": 25468,
         "subject_loc": 1114
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AAK64297.1",
         "start": 1724,
         "end": 3917,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAK64303.1",
         "start": 8190,
         "end": 9054,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 3913,
         "end": 4828,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg14_27"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 540,
         "end": 1689,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_28"
         }
        },
        {
         "locus_tag": "crtEb",
         "start": 7318,
         "end": 8182,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_23"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 4824,
         "end": 6474,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_26"
         }
        },
        {
         "locus_tag": "crtYe",
         "start": 6477,
         "end": 6927,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtYf",
         "start": 6923,
         "end": 7316,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001456: 0-9777": {
       "start": 0,
       "end": 9777,
       "links": [
        {
         "query": "ctg14_52",
         "subject": "crtaE",
         "query_loc": 52749,
         "subject_loc": 4278
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtaB",
         "start": 1013,
         "end": 2045,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtaE",
         "start": 3582,
         "end": 4974,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_52"
         }
        },
        {
         "locus_tag": "crtaI",
         "start": 2041,
         "end": 3586,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtaQ",
         "start": 5309,
         "end": 5930,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "crtaT",
         "start": 7417,
         "end": 8152,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtaU",
         "start": 8148,
         "end": 9777,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtaV",
         "start": 0,
         "end": 1017,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtaY",
         "start": 6171,
         "end": 7362,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001227: 0-12144": {
       "start": 0,
       "end": 12144,
       "links": [
        {
         "query": "ctg14_52",
         "subject": "B446_02735",
         "query_loc": 52749,
         "subject_loc": 4200
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "B446_02720",
         "start": 0,
         "end": 1020,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02725",
         "start": 1016,
         "end": 2033,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "B446_02730",
         "start": 2029,
         "end": 3532,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "B446_02735",
         "start": 3564,
         "end": 4836,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_52"
         }
        },
        {
         "locus_tag": "B446_02740",
         "start": 5082,
         "end": 6279,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "B446_02745",
         "start": 6490,
         "end": 7225,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "B446_02750",
         "start": 7221,
         "end": 8856,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "B446_02755",
         "start": 8896,
         "end": 9736,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02760",
         "start": 9842,
         "end": 10559,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02765",
         "start": 10585,
         "end": 11170,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02770",
         "start": 11073,
         "end": 12144,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000649: 148-10747": {
       "start": 148,
       "end": 10747,
       "links": [
        {
         "query": "ctg14_52",
         "subject": "crtE",
         "query_loc": 52749,
         "subject_loc": 2981
        },
        {
         "query": "ctg14_27",
         "subject": "crtB",
         "query_loc": 24494,
         "subject_loc": 5650
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 5136,
         "end": 6165,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg14_27"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 2342,
         "end": 3620,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_52"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 3616,
         "end": 5140,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtT",
         "start": 8780,
         "end": 9509,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtU",
         "start": 7227,
         "end": 8781,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtV",
         "start": 6161,
         "end": 7178,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 9505,
         "end": 10747,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "fadD",
         "start": 148,
         "end": 1771,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002309: 0-2466": {
       "start": 0,
       "end": 2466,
       "links": [
        {
         "query": "ctg14_52",
         "subject": "SCAT_0460",
         "query_loc": 52749,
         "subject_loc": 552
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "SCAT_0460",
         "start": 0,
         "end": 1104,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_52"
         }
        },
        {
         "locus_tag": "SCAT_0461",
         "start": 1100,
         "end": 1397,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCAT_0462",
         "start": 1321,
         "end": 1852,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SCAT_0463",
         "start": 1731,
         "end": 2466,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001911: 591-10299": {
       "start": 591,
       "end": 10299,
       "links": [
        {
         "query": "ctg14_52",
         "subject": "rmnA",
         "query_loc": 52749,
         "subject_loc": 5372
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "BAR97459.1",
         "start": 3373,
         "end": 4684,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "BAR97464.1",
         "start": 9870,
         "end": 10299,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cvnA",
         "start": 591,
         "end": 1992,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cvnB",
         "start": 1988,
         "end": 2408,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cvnC",
         "start": 2404,
         "end": 2785,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cvnD",
         "start": 2756,
         "end": 3377,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "rmnA",
         "start": 4831,
         "end": 5914,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_52"
         }
        },
        {
         "locus_tag": "rmnB",
         "start": 5910,
         "end": 7560,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "rmnC",
         "start": 7569,
         "end": 8928,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "rmnD",
         "start": 8924,
         "end": 9893,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000644: 97-6276": {
       "start": 97,
       "end": 6276,
       "links": [
        {
         "query": "ctg14_26",
         "subject": "crtI",
         "query_loc": 23234,
         "subject_loc": 2966
        },
        {
         "query": "ctg14_24",
         "subject": "lbtBC",
         "query_loc": 21916,
         "subject_loc": 4828
        },
        {
         "query": "ctg14_27",
         "subject": "crtB",
         "query_loc": 24494,
         "subject_loc": 1683
        },
        {
         "query": "ctg14_25",
         "subject": "lbtA",
         "query_loc": 22258,
         "subject_loc": 3995
        },
        {
         "query": "ctg14_28",
         "subject": "crtE",
         "query_loc": 25468,
         "subject_loc": 671
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "crtB",
         "start": 1242,
         "end": 2124,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg14_27"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 97,
         "end": 1246,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_28"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 2120,
         "end": 3812,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_26"
         }
        },
        {
         "locus_tag": "crtX",
         "start": 5544,
         "end": 6276,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "lbtA",
         "start": 3808,
         "end": 4183,
         "strand": 1,
         "function": "other",
         "linked": {
          "1": "ctg14_25"
         }
        },
        {
         "locus_tag": "lbtBC",
         "start": 4179,
         "end": 5478,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_24"
         }
        }
       ]
      },
      "BGC0001137: 0-18476": {
       "start": 0,
       "end": 18476,
       "links": [
        {
         "query": "ctg14_45",
         "subject": "AGL76720.1",
         "query_loc": 43856,
         "subject_loc": 12636
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AGL76713.1",
         "start": 0,
         "end": 3744,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGL76714.1",
         "start": 3890,
         "end": 5612,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76715.1",
         "start": 5847,
         "end": 6327,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76716.1",
         "start": 6323,
         "end": 7064,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76717.1",
         "start": 7244,
         "end": 8774,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGL76718.1",
         "start": 8826,
         "end": 10764,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGL76719.1",
         "start": 10841,
         "end": 11543,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "AGL76720.1",
         "start": 11892,
         "end": 13380,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_45"
         }
        },
        {
         "locus_tag": "AGL76721.1",
         "start": 13463,
         "end": 14408,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76722.1",
         "start": 14461,
         "end": 16114,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGL76723.1",
         "start": 16360,
         "end": 17242,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76724.1",
         "start": 17238,
         "end": 17892,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGL76725.1",
         "start": 17927,
         "end": 18476,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        }
       ]
      },
      "BGC0000633: 0-14284": {
       "start": 0,
       "end": 14284,
       "links": [
        {
         "query": "ctg14_52",
         "subject": "crtE",
         "query_loc": 52749,
         "subject_loc": 5630
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "BAB69138.1",
         "start": 0,
         "end": 363,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAB69139.1",
         "start": 418,
         "end": 967,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAB69147.1",
         "start": 10059,
         "end": 12159,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAB69148.1",
         "start": 12241,
         "end": 14284,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtE",
         "start": 5060,
         "end": 6200,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_52"
         }
        },
        {
         "locus_tag": "crtI-1",
         "start": 6196,
         "end": 7738,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtI-2",
         "start": 7734,
         "end": 8763,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtT",
         "start": 2677,
         "end": 3409,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtU",
         "start": 1121,
         "end": 2624,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtV",
         "start": 8759,
         "end": 9839,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtY",
         "start": 3452,
         "end": 4799,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001456: 0-9777": {
       "start": 0,
       "end": 9777,
       "links": [
        {
         "query": "ctg14_52",
         "subject": "crtaE",
         "query_loc": 52749,
         "subject_loc": 4278
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "crtaB",
         "start": 1013,
         "end": 2045,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "crtaE",
         "start": 3582,
         "end": 4974,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_52"
         }
        },
        {
         "locus_tag": "crtaI",
         "start": 2041,
         "end": 3586,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtaQ",
         "start": 5309,
         "end": 5930,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "crtaT",
         "start": 7417,
         "end": 8152,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtaU",
         "start": 8148,
         "end": 9777,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "crtaV",
         "start": 0,
         "end": 1017,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtaY",
         "start": 6171,
         "end": 7362,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000664: 0-8391": {
       "start": 0,
       "end": 8391,
       "links": [
        {
         "query": "ctg14_52",
         "subject": "SGR_6830",
         "query_loc": 52749,
         "subject_loc": 7752
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "SGR_6824",
         "start": 0,
         "end": 1242,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6825",
         "start": 1238,
         "end": 1967,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6826",
         "start": 1963,
         "end": 3520,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6827",
         "start": 3555,
         "end": 4572,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6828",
         "start": 4568,
         "end": 5597,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6829",
         "start": 5593,
         "end": 7117,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SGR_6830",
         "start": 7113,
         "end": 8391,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_52"
         }
        }
       ]
      },
      "BGC0002284: 0-17900": {
       "start": 0,
       "end": 17900,
       "links": [
        {
         "query": "ctg14_42",
         "subject": "CPI83_20020",
         "query_loc": 39145,
         "subject_loc": 4898
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "CPI83_19995",
         "start": 0,
         "end": 627,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20000",
         "start": 647,
         "end": 1403,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20005",
         "start": 1406,
         "end": 2234,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20010",
         "start": 2230,
         "end": 2719,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20015",
         "start": 2715,
         "end": 3879,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20020",
         "start": 3878,
         "end": 5918,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_42"
         }
        },
        {
         "locus_tag": "CPI83_20025",
         "start": 5923,
         "end": 7513,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20030",
         "start": 7611,
         "end": 8211,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20035",
         "start": 8259,
         "end": 9006,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20040",
         "start": 9163,
         "end": 9424,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20045",
         "start": 9612,
         "end": 11019,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20050",
         "start": 10996,
         "end": 12361,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20055",
         "start": 12357,
         "end": 13797,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20060",
         "start": 13980,
         "end": 16227,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "CPI83_20065",
         "start": 16451,
         "end": 17900,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001227: 0-12144": {
       "start": 0,
       "end": 12144,
       "links": [
        {
         "query": "ctg14_52",
         "subject": "B446_02735",
         "query_loc": 52749,
         "subject_loc": 4200
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "B446_02720",
         "start": 0,
         "end": 1020,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02725",
         "start": 1016,
         "end": 2033,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "B446_02730",
         "start": 2029,
         "end": 3532,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "B446_02735",
         "start": 3564,
         "end": 4836,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_52"
         }
        },
        {
         "locus_tag": "B446_02740",
         "start": 5082,
         "end": 6279,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "B446_02745",
         "start": 6490,
         "end": 7225,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "B446_02750",
         "start": 7221,
         "end": 8856,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "B446_02755",
         "start": 8896,
         "end": 9736,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02760",
         "start": 9842,
         "end": 10559,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02765",
         "start": 10585,
         "end": 11170,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "B446_02770",
         "start": 11073,
         "end": 12144,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000650: 28-7720": {
       "start": 28,
       "end": 7720,
       "links": [
        {
         "query": "ctg14_27",
         "subject": "crtB",
         "query_loc": 24494,
         "subject_loc": 2591
        },
        {
         "query": "ctg14_26",
         "subject": "crtI",
         "query_loc": 23234,
         "subject_loc": 1284
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ABB88947.1",
         "start": 28,
         "end": 541,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ABB88953.1",
         "start": 5263,
         "end": 7720,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 2170,
         "end": 3013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg14_27"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 545,
         "end": 2024,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_26"
         }
        },
        {
         "locus_tag": "crtW",
         "start": 4532,
         "end": 5303,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtYcd",
         "start": 3015,
         "end": 3726,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ispH",
         "start": 3729,
         "end": 4575,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000637: 540-9054": {
       "start": 540,
       "end": 9054,
       "links": [
        {
         "query": "ctg14_26",
         "subject": "crtI",
         "query_loc": 23234,
         "subject_loc": 5649
        },
        {
         "query": "ctg14_23",
         "subject": "crtEb",
         "query_loc": 21290,
         "subject_loc": 7750
        },
        {
         "query": "ctg14_27",
         "subject": "crtB",
         "query_loc": 24494,
         "subject_loc": 4370
        },
        {
         "query": "ctg14_28",
         "subject": "crtE",
         "query_loc": 25468,
         "subject_loc": 1114
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AAK64297.1",
         "start": 1724,
         "end": 3917,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAK64303.1",
         "start": 8190,
         "end": 9054,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtB",
         "start": 3913,
         "end": 4828,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg14_27"
         }
        },
        {
         "locus_tag": "crtE",
         "start": 540,
         "end": 1689,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_28"
         }
        },
        {
         "locus_tag": "crtEb",
         "start": 7318,
         "end": 8182,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_23"
         }
        },
        {
         "locus_tag": "crtI",
         "start": 4824,
         "end": 6474,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg14_26"
         }
        },
        {
         "locus_tag": "crtYe",
         "start": 6477,
         "end": 6927,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "crtYf",
         "start": 6923,
         "end": 7316,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001521: 1747-26349": {
       "start": 1747,
       "end": 26349,
       "links": [
        {
         "query": "ctg14_49",
         "subject": "Haur_0023",
         "query_loc": 49185,
         "subject_loc": 2867
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "Haur_0023",
         "start": 1747,
         "end": 3988,
         "strand": 1,
         "function": "regulatory",
         "linked": {
          "1": "ctg14_49"
         }
        },
        {
         "locus_tag": "Haur_0024",
         "start": 4049,
         "end": 4949,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0025",
         "start": 5183,
         "end": 5900,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0026",
         "start": 6059,
         "end": 6287,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0027",
         "start": 6367,
         "end": 7222,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0028",
         "start": 7276,
         "end": 9745,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0029",
         "start": 9824,
         "end": 10829,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0030",
         "start": 11134,
         "end": 11596,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0031",
         "start": 11606,
         "end": 12611,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0032",
         "start": 13016,
         "end": 14474,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0033",
         "start": 14654,
         "end": 15563,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0034",
         "start": 15756,
         "end": 16422,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0035",
         "start": 16523,
         "end": 16940,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0036",
         "start": 17184,
         "end": 17763,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0037",
         "start": 18469,
         "end": 20305,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0038",
         "start": 20308,
         "end": 21355,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0039",
         "start": 21895,
         "end": 22354,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0040",
         "start": 22387,
         "end": 23803,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0041",
         "start": 23824,
         "end": 24418,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0042",
         "start": 24403,
         "end": 25504,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Haur_0043",
         "start": 25500,
         "end": 26349,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg14_17": {
     "functions": [
      {
       "description": "SMCOG1069:putative ABC transporter permease protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_18": {
     "functions": [
      {
       "description": "SMCOG1067:putative ABC transporter permease protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_19": {
     "functions": [
      {
       "description": "SMCOG1143:sugar-binding lipoprotein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_20": {
     "functions": [
      {
       "description": "SMCOG1078:LacI family transcription regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_21": {
     "functions": []
    },
    "ctg14_22": {
     "functions": []
    },
    "ctg14_23": {
     "functions": [
      {
       "description": "ubiA",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg14_24": {
     "functions": []
    },
    "ctg14_25": {
     "functions": []
    },
    "ctg14_26": {
     "functions": [
      {
       "description": "DAO",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1222:dehydrogenase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_27": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg14_28": {
     "functions": [
      {
       "description": "SMCOG1182:Polyprenyl synthetase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_29": {
     "functions": []
    },
    "ctg14_30": {
     "functions": []
    },
    "ctg14_31": {
     "functions": []
    },
    "ctg14_32": {
     "functions": []
    },
    "ctg14_33": {
     "functions": []
    },
    "ctg14_34": {
     "functions": []
    },
    "ctg14_35": {
     "functions": []
    },
    "ctg14_36": {
     "functions": []
    },
    "ctg14_37": {
     "functions": []
    },
    "ctg14_38": {
     "functions": []
    },
    "ctg14_39": {
     "functions": []
    },
    "ctg14_40": {
     "functions": []
    },
    "ctg14_41": {
     "functions": [
      {
       "description": "SMCOG1157:hypothetical protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_42": {
     "functions": [
      {
       "description": "HMGL-like",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Dala_Dala_lig_C",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "ATP-grasp",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1090:acetyl-CoA carboxylase biotin carboxylase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_43": {
     "functions": [
      {
       "description": "SMCOG1157:hypothetical protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_44": {
     "functions": [
      {
       "description": "SMCOG1275:peptide deformylase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_45": {
     "functions": [
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_46": {
     "functions": [
      {
       "description": "SMCOG1108:ROK family protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_47": {
     "functions": [
      {
       "description": "SMCOG1141:acyltransferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_48": {
     "functions": []
    },
    "ctg14_49": {
     "functions": [
      {
       "description": "Pkinase",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1030:serine/threonine protein kinase ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_50": {
     "functions": []
    },
    "ctg14_51": {
     "functions": []
    },
    "ctg14_52": {
     "functions": [
      {
       "description": "SMCOG1182:Polyprenyl synthetase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg14_53": {
     "functions": []
    },
    "ctg14_54": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "ctg14_17",
      "seqLength": 298,
      "domains": [
       {
        "start": 106,
        "end": 287,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-transport",
        "name": "BPD_transp_1",
        "accession": "PF00528",
        "description": "Binding-protein-dependent transport system inner membrane component",
        "evalue": "6.6e-18",
        "score": "65.2"
       }
      ]
     },
     {
      "id": "ctg14_18",
      "seqLength": 319,
      "domains": [
       {
        "start": 113,
        "end": 311,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-transport",
        "name": "BPD_transp_1",
        "accession": "PF00528",
        "description": "Binding-protein-dependent transport system inner membrane component",
        "evalue": "1e-15",
        "score": "58.1"
       }
      ]
     },
     {
      "id": "ctg14_19",
      "seqLength": 444,
      "domains": [
       {
        "start": 69,
        "end": 385,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "SBP_bac_8",
        "accession": "PF13416",
        "description": "Bacterial extracellular solute-binding protein",
        "evalue": "7.1e-35",
        "score": "121.3"
       }
      ]
     },
     {
      "id": "ctg14_20",
      "seqLength": 356,
      "domains": [
       {
        "start": 21,
        "end": 67,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "LacI",
        "accession": "PF00356",
        "description": "Bacterial regulatory proteins, lacI family",
        "evalue": "3.8e-11",
        "score": "42.7"
       },
       {
        "start": 191,
        "end": 349,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Peripla_BP_3",
        "accession": "PF13377",
        "description": "Periplasmic binding protein-like domain",
        "evalue": "9.3e-34",
        "score": "117.2"
       }
      ]
     },
     {
      "id": "ctg14_21",
      "seqLength": 488,
      "domains": [
       {
        "start": 120,
        "end": 274,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051604' target='_blank'>GO:0051604</a>: protein maturation"
        ],
        "html_class": "generic-type-other",
        "name": "LMF1",
        "accession": "PF06762",
        "description": "Lipase maturation factor",
        "evalue": "2.6e-57",
        "score": "195.0"
       },
       {
        "start": 300,
        "end": 476,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051604' target='_blank'>GO:0051604</a>: protein maturation"
        ],
        "html_class": "generic-type-other",
        "name": "LMF1",
        "accession": "PF06762",
        "description": "Lipase maturation factor",
        "evalue": "4.7e-59",
        "score": "200.8"
       }
      ]
     },
     {
      "id": "ctg14_22",
      "seqLength": 122,
      "domains": [
       {
        "start": 6,
        "end": 52,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding"
        ],
        "html_class": "generic-type-other",
        "name": "S4",
        "accession": "PF01479",
        "description": "S4 domain",
        "evalue": "4.6e-12",
        "score": "45.6"
       }
      ]
     },
     {
      "id": "ctg14_23",
      "seqLength": 301,
      "domains": [
       {
        "start": 32,
        "end": 283,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016765' target='_blank'>GO:0016765</a>: transferase activity, transferring alkyl or aryl (other than methyl) groups",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "UbiA",
        "accession": "PF01040",
        "description": "UbiA prenyltransferase family",
        "evalue": "2.1e-34",
        "score": "119.1"
       }
      ]
     },
     {
      "id": "ctg14_24",
      "seqLength": 117,
      "domains": [
       {
        "start": 1,
        "end": 89,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016872' target='_blank'>GO:0016872</a>: intramolecular lyase activity"
        ],
        "html_class": "generic-type-other",
        "name": "Lycopene_cyc",
        "accession": "PF18916",
        "description": "Lycopene cyclase",
        "evalue": "1.8e-07",
        "score": "31.7"
       }
      ]
     },
     {
      "id": "ctg14_26",
      "seqLength": 539,
      "domains": [
       {
        "start": 16,
        "end": 509,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Amino_oxidase",
        "accession": "PF01593",
        "description": "Flavin containing amine oxidoreductase",
        "evalue": "5.9e-26",
        "score": "91.9"
       }
      ]
     },
     {
      "id": "ctg14_27",
      "seqLength": 302,
      "domains": [
       {
        "start": 33,
        "end": 281,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "1.3e-32",
        "score": "113.5"
       }
      ]
     },
     {
      "id": "ctg14_28",
      "seqLength": 348,
      "domains": [
       {
        "start": 39,
        "end": 271,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "polyprenyl_synt",
        "accession": "PF00348",
        "description": "Polyprenyl synthetase",
        "evalue": "1.1e-48",
        "score": "165.8"
       }
      ]
     },
     {
      "id": "ctg14_29",
      "seqLength": 176,
      "domains": [
       {
        "start": 32,
        "end": 149,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "NUDIX",
        "accession": "PF00293",
        "description": "NUDIX domain",
        "evalue": "4.2e-18",
        "score": "65.8"
       }
      ]
     },
     {
      "id": "ctg14_30",
      "seqLength": 246,
      "domains": [
       {
        "start": 108,
        "end": 149,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "MarR",
        "accession": "PF01047",
        "description": "MarR family",
        "evalue": "6.9e-08",
        "score": "32.4"
       }
      ]
     },
     {
      "id": "ctg14_31",
      "seqLength": 175,
      "domains": [
       {
        "start": 39,
        "end": 153,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Pribosyltran",
        "accession": "PF00156",
        "description": "Phosphoribosyl transferase domain",
        "evalue": "1.3e-14",
        "score": "54.0"
       }
      ]
     },
     {
      "id": "ctg14_32",
      "seqLength": 237,
      "domains": [
       {
        "start": 17,
        "end": 216,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016829' target='_blank'>GO:0016829</a>: lyase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "DeoC",
        "accession": "PF01791",
        "description": "DeoC/LacD family aldolase",
        "evalue": "8.3e-18",
        "score": "65.0"
       }
      ]
     },
     {
      "id": "ctg14_33",
      "seqLength": 154,
      "domains": [
       {
        "start": 27,
        "end": 138,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "NUDIX",
        "accession": "PF00293",
        "description": "NUDIX domain",
        "evalue": "2.5e-14",
        "score": "53.5"
       }
      ]
     },
     {
      "id": "ctg14_34",
      "seqLength": 288,
      "domains": [
       {
        "start": 23,
        "end": 259,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "DUF1295",
        "accession": "PF06966",
        "description": "Protein of unknown function (DUF1295)",
        "evalue": "5.8e-47",
        "score": "160.3"
       }
      ]
     },
     {
      "id": "ctg14_35",
      "seqLength": 863,
      "domains": [
       {
        "start": 347,
        "end": 438,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "LigD_N",
        "accession": "PF13298",
        "description": "DNA polymerase Ligase (LigD)",
        "evalue": "5.9e-33",
        "score": "113.4"
       },
       {
        "start": 503,
        "end": 700,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003910' target='_blank'>GO:0003910</a>: DNA ligase (ATP) activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006281' target='_blank'>GO:0006281</a>: DNA repair",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006310' target='_blank'>GO:0006310</a>: DNA recombination"
        ],
        "html_class": "generic-type-other",
        "name": "DNA_ligase_A_M",
        "accession": "PF01068",
        "description": "ATP dependent DNA ligase domain",
        "evalue": "1.2e-35",
        "score": "123.1"
       },
       {
        "start": 719,
        "end": 825,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003910' target='_blank'>GO:0003910</a>: DNA ligase (ATP) activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006281' target='_blank'>GO:0006281</a>: DNA repair",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006310' target='_blank'>GO:0006310</a>: DNA recombination"
        ],
        "html_class": "generic-type-other",
        "name": "DNA_ligase_A_C",
        "accession": "PF04679",
        "description": "ATP dependent DNA ligase C terminal region",
        "evalue": "6e-21",
        "score": "75.0"
       }
      ]
     },
     {
      "id": "ctg14_36",
      "seqLength": 329,
      "domains": [
       {
        "start": 10,
        "end": 188,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006303' target='_blank'>GO:0006303</a>: double-strand break repair via nonhomologous end joining"
        ],
        "html_class": "generic-type-other",
        "name": "Ku",
        "accession": "PF02735",
        "description": "Ku70/Ku80 beta-barrel domain",
        "evalue": "2.3e-34",
        "score": "119.0"
       }
      ]
     },
     {
      "id": "ctg14_37",
      "seqLength": 185,
      "domains": [
       {
        "start": 7,
        "end": 162,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016780' target='_blank'>GO:0016780</a>: phosphotransferase activity, for other substituted phosphate groups",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008654' target='_blank'>GO:0008654</a>: phospholipid biosynthetic process",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "CDP-OH_P_transf",
        "accession": "PF01066",
        "description": "CDP-alcohol phosphatidyltransferase",
        "evalue": "3.5e-35",
        "score": "121.9"
       }
      ]
     },
     {
      "id": "ctg14_38",
      "seqLength": 169,
      "domains": [
       {
        "start": 86,
        "end": 150,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "FHA",
        "accession": "PF00498",
        "description": "FHA domain",
        "evalue": "8.7e-17",
        "score": "61.4"
       }
      ]
     },
     {
      "id": "ctg14_39",
      "seqLength": 232,
      "domains": [
       {
        "start": 32,
        "end": 89,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "MerR_1",
        "accession": "PF13411",
        "description": "MerR HTH family regulatory protein",
        "evalue": "1.2e-09",
        "score": "38.2"
       }
      ]
     },
     {
      "id": "ctg14_40",
      "seqLength": 183,
      "domains": [
       {
        "start": 34,
        "end": 103,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "MerR_1",
        "accession": "PF13411",
        "description": "MerR HTH family regulatory protein",
        "evalue": "1.2e-14",
        "score": "54.2"
       }
      ]
     },
     {
      "id": "ctg14_41",
      "seqLength": 236,
      "domains": [
       {
        "start": 0,
        "end": 146,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "AAA_31",
        "accession": "PF13614",
        "description": "AAA domain",
        "evalue": "4.6e-17",
        "score": "62.6"
       }
      ]
     },
     {
      "id": "ctg14_42",
      "seqLength": 1134,
      "domains": [
       {
        "start": 0,
        "end": 111,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Biotin_carb_N",
        "accession": "PF00289",
        "description": "Biotin carboxylase, N-terminal domain",
        "evalue": "2e-38",
        "score": "131.5"
       },
       {
        "start": 116,
        "end": 326,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "CPSase_L_D2",
        "accession": "PF02786",
        "description": "Carbamoyl-phosphate synthase L chain, ATP binding domain",
        "evalue": "7e-68",
        "score": "228.4"
       },
       {
        "start": 342,
        "end": 451,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Biotin_carb_C",
        "accession": "PF02785",
        "description": "Biotin carboxylase C-terminal domain",
        "evalue": "9.3e-36",
        "score": "122.3"
       },
       {
        "start": 528,
        "end": 801,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "HMGL-like",
        "accession": "PF00682",
        "description": "HMGL-like",
        "evalue": "6.1e-29",
        "score": "101.5"
       },
       {
        "start": 824,
        "end": 1013,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PYC_OADA",
        "accession": "PF02436",
        "description": "Conserved carboxylase domain",
        "evalue": "3.8e-49",
        "score": "167.3"
       },
       {
        "start": 1072,
        "end": 1130,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Biotin_lipoyl",
        "accession": "PF00364",
        "description": "Biotin-requiring enzyme",
        "evalue": "1.6e-14",
        "score": "53.6"
       }
      ]
     },
     {
      "id": "ctg14_43",
      "seqLength": 435,
      "domains": [
       {
        "start": 191,
        "end": 349,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "CbiA",
        "accession": "PF01656",
        "description": "CobQ/CobB/MinD/ParA nucleotide binding domain",
        "evalue": "6e-08",
        "score": "32.9"
       }
      ]
     },
     {
      "id": "ctg14_44",
      "seqLength": 163,
      "domains": [
       {
        "start": 3,
        "end": 150,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0042586' target='_blank'>GO:0042586</a>: peptide deformylase activity"
        ],
        "html_class": "generic-type-other",
        "name": "Pep_deformylase",
        "accession": "PF01327",
        "description": "Polypeptide deformylase",
        "evalue": "2.5e-33",
        "score": "115.1"
       }
      ]
     },
     {
      "id": "ctg14_45",
      "seqLength": 614,
      "domains": [
       {
        "start": 36,
        "end": 467,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "2.8e-90",
        "score": "303.1"
       }
      ]
     },
     {
      "id": "ctg14_46",
      "seqLength": 315,
      "domains": [
       {
        "start": 3,
        "end": 310,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "ROK",
        "accession": "PF00480",
        "description": "ROK family",
        "evalue": "1e-78",
        "score": "264.9"
       }
      ]
     },
     {
      "id": "ctg14_47",
      "seqLength": 229,
      "domains": [
       {
        "start": 22,
        "end": 151,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016746' target='_blank'>GO:0016746</a>: acyltransferase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Acyltransferase",
        "accession": "PF01553",
        "description": "Acyltransferase",
        "evalue": "7.3e-25",
        "score": "87.3"
       }
      ]
     },
     {
      "id": "ctg14_48",
      "seqLength": 447,
      "domains": [
       {
        "start": 10,
        "end": 441,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003849' target='_blank'>GO:0003849</a>: 3-deoxy-7-phosphoheptulonate synthase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009073' target='_blank'>GO:0009073</a>: aromatic amino acid family biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "DAHP_synth_2",
        "accession": "PF01474",
        "description": "Class-II DAHP synthetase family",
        "evalue": "3.7e-195",
        "score": "648.7"
       }
      ]
     },
     {
      "id": "ctg14_49",
      "seqLength": 640,
      "domains": [
       {
        "start": 9,
        "end": 281,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004672' target='_blank'>GO:0004672</a>: protein kinase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006468' target='_blank'>GO:0006468</a>: protein phosphorylation"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Pkinase",
        "accession": "PF00069",
        "description": "Protein kinase domain",
        "evalue": "4.1e-51",
        "score": "174.0"
       },
       {
        "start": 369,
        "end": 430,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PASTA",
        "accession": "PF03793",
        "description": "PASTA domain",
        "evalue": "4.6e-13",
        "score": "48.9"
       },
       {
        "start": 508,
        "end": 569,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PASTA",
        "accession": "PF03793",
        "description": "PASTA domain",
        "evalue": "2.6e-12",
        "score": "46.5"
       },
       {
        "start": 574,
        "end": 633,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PASTA",
        "accession": "PF03793",
        "description": "PASTA domain",
        "evalue": "4.1e-10",
        "score": "39.5"
       }
      ]
     },
     {
      "id": "ctg14_50",
      "seqLength": 452,
      "domains": [
       {
        "start": 108,
        "end": 151,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "LysM",
        "accession": "PF01476",
        "description": "LysM domain",
        "evalue": "2.7e-09",
        "score": "37.0"
       },
       {
        "start": 171,
        "end": 215,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "LysM",
        "accession": "PF01476",
        "description": "LysM domain",
        "evalue": "6e-11",
        "score": "42.4"
       },
       {
        "start": 241,
        "end": 285,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "LysM",
        "accession": "PF01476",
        "description": "LysM domain",
        "evalue": "2.2e-09",
        "score": "37.4"
       }
      ]
     },
     {
      "id": "ctg14_51",
      "seqLength": 122,
      "domains": [
       {
        "start": 68,
        "end": 122,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Rv2175c_C",
        "accession": "PF18367",
        "description": "Rv2175c C-terminal domain of unknown function",
        "evalue": "4.4e-21",
        "score": "74.9"
       }
      ]
     },
     {
      "id": "ctg14_52",
      "seqLength": 335,
      "domains": [
       {
        "start": 5,
        "end": 283,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "polyprenyl_synt",
        "accession": "PF00348",
        "description": "Polyprenyl synthetase",
        "evalue": "2e-46",
        "score": "158.3"
       }
      ]
     },
     {
      "id": "ctg14_53",
      "seqLength": 126,
      "domains": [
       {
        "start": 0,
        "end": 79,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "DUF3040",
        "accession": "PF11239",
        "description": "Protein of unknown function (DUF3040)",
        "evalue": "3.7e-25",
        "score": "88.1"
       }
      ]
     },
     {
      "id": "ctg14_54",
      "seqLength": 143,
      "domains": [
       {
        "start": 0,
        "end": 69,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MraZ",
        "accession": "PF02381",
        "description": "MraZ protein, putative antitoxin-like",
        "evalue": "1.4e-16",
        "score": "60.4"
       },
       {
        "start": 71,
        "end": 137,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MraZ",
        "accession": "PF02381",
        "description": "MraZ protein, putative antitoxin-like",
        "evalue": "2.9e-18",
        "score": "65.7"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   }
  ]
 },
 "r36c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001962: 0-7027": {
       "start": 0,
       "end": 7027,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "QBC65480.1",
         "query_loc": 38220,
         "subject_loc": 4403
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "QBC65474.1",
         "start": 0,
         "end": 879,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QBC65475.1",
         "start": 875,
         "end": 1661,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QBC65476.1",
         "start": 4956,
         "end": 5553,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QBC65477.1",
         "start": 5488,
         "end": 7027,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QBC65478.1",
         "start": 1849,
         "end": 2650,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QBC65479.1",
         "start": 2823,
         "end": 3840,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QBC65480.1",
         "start": 3836,
         "end": 4970,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        }
       ]
      },
      "BGC0001938: 0-1819": {
       "start": 0,
       "end": 1819,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "cepA",
         "query_loc": 38220,
         "subject_loc": 1265
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "cepA",
         "start": 712,
         "end": 1819,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        },
        {
         "locus_tag": "cepB",
         "start": 0,
         "end": 711,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000282: 0-2613": {
       "start": 0,
       "end": 2613,
       "links": [
        {
         "query": "ctg36_40",
         "subject": "SGR_470",
         "query_loc": 40117,
         "subject_loc": 508
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "SGR_470",
         "start": 0,
         "end": 1017,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg36_40"
         }
        },
        {
         "locus_tag": "SGR_471",
         "start": 1013,
         "end": 1547,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SGR_472",
         "start": 1560,
         "end": 2613,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000902: 0-3903": {
       "start": 0,
       "end": 3903,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "SACE_1243",
         "query_loc": 38220,
         "subject_loc": 2329
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "SACE_1241",
         "start": 0,
         "end": 540,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SACE_1242",
         "start": 575,
         "end": 1781,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SACE_1243",
         "start": 1777,
         "end": 2881,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        },
        {
         "locus_tag": "SACE_1244",
         "start": 3234,
         "end": 3903,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        }
       ]
      },
      "BGC0002332: 137-13618": {
       "start": 137,
       "end": 13618,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "QEO32865.1",
         "query_loc": 38220,
         "subject_loc": 10900
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "QEO32858.1",
         "start": 137,
         "end": 1160,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32859.1",
         "start": 866,
         "end": 1160,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32860.1",
         "start": 2215,
         "end": 3238,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QEO32861.1",
         "start": 3351,
         "end": 5640,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QEO32862.1",
         "start": 5789,
         "end": 7610,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32863.1",
         "start": 7783,
         "end": 8206,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32864.1",
         "start": 8241,
         "end": 9663,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32865.1",
         "start": 10338,
         "end": 11463,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        },
        {
         "locus_tag": "QEO32866.1",
         "start": 11658,
         "end": 12189,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32867.1",
         "start": 12185,
         "end": 12815,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32868.1",
         "start": 13031,
         "end": 13618,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001310: 0-2705": {
       "start": 0,
       "end": 2705,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "SCLAV_5492",
         "query_loc": 38220,
         "subject_loc": 2177
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "SCLAV_5491",
         "start": 0,
         "end": 1365,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SCLAV_5492",
         "start": 1649,
         "end": 2705,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        }
       ]
      },
      "BGC0002127: 147-3013": {
       "start": 147,
       "end": 3013,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "SCO1206",
         "query_loc": 38220,
         "subject_loc": 709
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "SCO1206",
         "start": 147,
         "end": 1272,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        },
        {
         "locus_tag": "SCO1207",
         "start": 1268,
         "end": 2483,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SCO1208",
         "start": 2479,
         "end": 3013,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002403: 0-129425": {
       "start": 0,
       "end": 129425,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "MLOC_59804",
         "query_loc": 38220,
         "subject_loc": 128789
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AK373499",
         "start": 78824,
         "end": 81639,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Hv_66C06_HlyIII",
         "start": 0,
         "end": 1014,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MLOC_13397",
         "start": 28358,
         "end": 29591,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "MLOC_59804",
         "start": 128154,
         "end": 129425,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        }
       ]
      },
      "BGC0000285: 2-11002": {
       "start": 2,
       "end": 11002,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "rppA",
         "query_loc": 38220,
         "subject_loc": 3662
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AAL78049.1",
         "start": 2,
         "end": 179,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAL78050.1",
         "start": 175,
         "end": 1405,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AAL78051.1",
         "start": 1496,
         "end": 2021,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAL78052.1",
         "start": 2088,
         "end": 2757,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "AAL78055.1",
         "start": 5451,
         "end": 5991,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAL78056.1",
         "start": 6671,
         "end": 7298,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "AAL78057.1",
         "start": 8155,
         "end": 11002,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "rppA",
         "start": 3110,
         "end": 4214,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        },
        {
         "locus_tag": "rppB",
         "start": 4210,
         "end": 5416,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001077: 0-6550": {
       "start": 0,
       "end": 6550,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "AMIS_77560",
         "query_loc": 38220,
         "subject_loc": 978
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AMIS_77550",
         "start": 0,
         "end": 453,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AMIS_77560",
         "start": 449,
         "end": 1508,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        },
        {
         "locus_tag": "AMIS_77570",
         "start": 1501,
         "end": 2656,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AMIS_77580",
         "start": 2645,
         "end": 3353,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AMIS_77590",
         "start": 3418,
         "end": 4216,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AMIS_77600",
         "start": 4318,
         "end": 5089,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AMIS_77610",
         "start": 5125,
         "end": 6550,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001962: 0-7027": {
       "start": 0,
       "end": 7027,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "QBC65480.1",
         "query_loc": 38220,
         "subject_loc": 4403
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "QBC65474.1",
         "start": 0,
         "end": 879,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QBC65475.1",
         "start": 875,
         "end": 1661,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QBC65476.1",
         "start": 4956,
         "end": 5553,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QBC65477.1",
         "start": 5488,
         "end": 7027,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QBC65478.1",
         "start": 1849,
         "end": 2650,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QBC65479.1",
         "start": 2823,
         "end": 3840,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QBC65480.1",
         "start": 3836,
         "end": 4970,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        }
       ]
      },
      "BGC0001938: 0-1819": {
       "start": 0,
       "end": 1819,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "cepA",
         "query_loc": 38220,
         "subject_loc": 1265
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "cepA",
         "start": 712,
         "end": 1819,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        },
        {
         "locus_tag": "cepB",
         "start": 0,
         "end": 711,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000282: 0-2613": {
       "start": 0,
       "end": 2613,
       "links": [
        {
         "query": "ctg36_40",
         "subject": "SGR_470",
         "query_loc": 40117,
         "subject_loc": 508
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "SGR_470",
         "start": 0,
         "end": 1017,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg36_40"
         }
        },
        {
         "locus_tag": "SGR_471",
         "start": 1013,
         "end": 1547,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SGR_472",
         "start": 1560,
         "end": 2613,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000902: 0-3903": {
       "start": 0,
       "end": 3903,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "SACE_1243",
         "query_loc": 38220,
         "subject_loc": 2329
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "SACE_1241",
         "start": 0,
         "end": 540,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "SACE_1242",
         "start": 575,
         "end": 1781,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SACE_1243",
         "start": 1777,
         "end": 2881,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        },
        {
         "locus_tag": "SACE_1244",
         "start": 3234,
         "end": 3903,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        }
       ]
      },
      "BGC0002332: 137-13618": {
       "start": 137,
       "end": 13618,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "QEO32865.1",
         "query_loc": 38220,
         "subject_loc": 10900
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "QEO32858.1",
         "start": 137,
         "end": 1160,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32859.1",
         "start": 866,
         "end": 1160,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32860.1",
         "start": 2215,
         "end": 3238,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QEO32861.1",
         "start": 3351,
         "end": 5640,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QEO32862.1",
         "start": 5789,
         "end": 7610,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32863.1",
         "start": 7783,
         "end": 8206,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32864.1",
         "start": 8241,
         "end": 9663,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32865.1",
         "start": 10338,
         "end": 11463,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        },
        {
         "locus_tag": "QEO32866.1",
         "start": 11658,
         "end": 12189,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32867.1",
         "start": 12185,
         "end": 12815,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QEO32868.1",
         "start": 13031,
         "end": 13618,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001310: 0-2705": {
       "start": 0,
       "end": 2705,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "SCLAV_5492",
         "query_loc": 38220,
         "subject_loc": 2177
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "SCLAV_5491",
         "start": 0,
         "end": 1365,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SCLAV_5492",
         "start": 1649,
         "end": 2705,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        }
       ]
      },
      "BGC0002127: 147-3013": {
       "start": 147,
       "end": 3013,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "SCO1206",
         "query_loc": 38220,
         "subject_loc": 709
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "SCO1206",
         "start": 147,
         "end": 1272,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        },
        {
         "locus_tag": "SCO1207",
         "start": 1268,
         "end": 2483,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "SCO1208",
         "start": 2479,
         "end": 3013,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002403: 0-129425": {
       "start": 0,
       "end": 129425,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "MLOC_59804",
         "query_loc": 38220,
         "subject_loc": 128789
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AK373499",
         "start": 78824,
         "end": 81639,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Hv_66C06_HlyIII",
         "start": 0,
         "end": 1014,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MLOC_13397",
         "start": 28358,
         "end": 29591,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "MLOC_59804",
         "start": 128154,
         "end": 129425,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        }
       ]
      },
      "BGC0000285: 2-11002": {
       "start": 2,
       "end": 11002,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "rppA",
         "query_loc": 38220,
         "subject_loc": 3662
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AAL78049.1",
         "start": 2,
         "end": 179,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAL78050.1",
         "start": 175,
         "end": 1405,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AAL78051.1",
         "start": 1496,
         "end": 2021,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAL78052.1",
         "start": 2088,
         "end": 2757,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "AAL78055.1",
         "start": 5451,
         "end": 5991,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAL78056.1",
         "start": 6671,
         "end": 7298,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "AAL78057.1",
         "start": 8155,
         "end": 11002,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "rppA",
         "start": 3110,
         "end": 4214,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        },
        {
         "locus_tag": "rppB",
         "start": 4210,
         "end": 5416,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001077: 0-6550": {
       "start": 0,
       "end": 6550,
       "links": [
        {
         "query": "ctg36_38",
         "subject": "AMIS_77560",
         "query_loc": 38220,
         "subject_loc": 978
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AMIS_77550",
         "start": 0,
         "end": 453,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AMIS_77560",
         "start": 449,
         "end": 1508,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg36_38"
         }
        },
        {
         "locus_tag": "AMIS_77570",
         "start": 1501,
         "end": 2656,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AMIS_77580",
         "start": 2645,
         "end": 3353,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AMIS_77590",
         "start": 3418,
         "end": 4216,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AMIS_77600",
         "start": 4318,
         "end": 5089,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AMIS_77610",
         "start": 5125,
         "end": 6550,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg36_19": {
     "functions": [
      {
       "description": "SMCOG1000:ABC transporter ATP-binding protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg36_20": {
     "functions": []
    },
    "ctg36_21": {
     "functions": [
      {
       "description": "SMCOG1135:MarR family transcriptional regulator ",
       "function": "regulatory",
       "tool": "smcogs"
      }
     ]
    },
    "ctg36_22": {
     "functions": []
    },
    "ctg36_23": {
     "functions": []
    },
    "ctg36_24": {
     "functions": []
    },
    "ctg36_25": {
     "functions": [
      {
       "description": "SMCOG1000:ABC transporter ATP-binding protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "ctg36_26": {
     "functions": []
    },
    "ctg36_27": {
     "functions": [
      {
       "description": "SMCOG1039:aldo/keto reductase family oxidoreductase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg36_28": {
     "functions": []
    },
    "ctg36_29": {
     "functions": []
    },
    "ctg36_30": {
     "functions": []
    },
    "ctg36_31": {
     "functions": []
    },
    "ctg36_32": {
     "functions": []
    },
    "ctg36_33": {
     "functions": []
    },
    "ctg36_34": {
     "functions": [
      {
       "description": "Metallophos_2",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg36_35": {
     "functions": []
    },
    "ctg36_36": {
     "functions": []
    },
    "ctg36_37": {
     "functions": []
    },
    "ctg36_38": {
     "functions": [
      {
       "description": "Chal_sti_synt_N",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Chal_sti_synt_C",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1024:chalcone and stilbene synthase domain protein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg36_39": {
     "functions": [
      {
       "description": "SMCOG1269:hypothetical protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "ctg36_40": {
     "functions": [
      {
       "description": "SMCOG1050:monooxygenase FAD-binding ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg36_41": {
     "functions": []
    },
    "ctg36_42": {
     "functions": [
      {
       "description": "DAO",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg36_43": {
     "functions": []
    },
    "ctg36_44": {
     "functions": []
    },
    "ctg36_45": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "ctg36_19",
      "seqLength": 264,
      "domains": [
       {
        "start": 30,
        "end": 189,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-transport",
        "name": "ABC_tran",
        "accession": "PF00005",
        "description": "ABC transporter",
        "evalue": "6.7e-33",
        "score": "114.2"
       }
      ]
     },
     {
      "id": "ctg36_20",
      "seqLength": 125,
      "domains": [
       {
        "start": 6,
        "end": 112,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DoxX_2",
        "accession": "PF13564",
        "description": "DoxX-like family",
        "evalue": "1.1e-24",
        "score": "86.6"
       }
      ]
     },
     {
      "id": "ctg36_21",
      "seqLength": 158,
      "domains": [
       {
        "start": 40,
        "end": 99,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "MarR",
        "accession": "PF01047",
        "description": "MarR family",
        "evalue": "2.4e-12",
        "score": "46.7"
       }
      ]
     },
     {
      "id": "ctg36_22",
      "seqLength": 1358,
      "domains": [
       {
        "start": 25,
        "end": 138,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "AAA_19",
        "accession": "PF13245",
        "description": "AAA domain",
        "evalue": "1.4e-05",
        "score": "25.4"
       },
       {
        "start": 229,
        "end": 361,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Helicase_C",
        "accession": "PF00271",
        "description": "Helicase conserved C-terminal domain",
        "evalue": "3.2e-10",
        "score": "40.5"
       },
       {
        "start": 487,
        "end": 547,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004386' target='_blank'>GO:0004386</a>: helicase activity"
        ],
        "html_class": "generic-type-other",
        "name": "HA2",
        "accession": "PF04408",
        "description": "Helicase associated domain (HA2)",
        "evalue": "2.3e-10",
        "score": "40.8"
       },
       {
        "start": 625,
        "end": 702,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "OB_NTP_bind",
        "accession": "PF07717",
        "description": "Oligonucleotide/oligosaccharide-binding (OB)-fold",
        "evalue": "1.5e-18",
        "score": "67.0"
       },
       {
        "start": 715,
        "end": 1357,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "DUF3418",
        "accession": "PF11898",
        "description": "Domain of unknown function (DUF3418)",
        "evalue": "1.4e-202",
        "score": "674.6"
       }
      ]
     },
     {
      "id": "ctg36_24",
      "seqLength": 98,
      "domains": [
       {
        "start": 12,
        "end": 94,
        "go_terms": [],
        "html_class": "generic-type-regulatory",
        "name": "HTH_34",
        "accession": "PF13601",
        "description": "Winged helix DNA-binding domain",
        "evalue": "1.2e-21",
        "score": "76.7"
       }
      ]
     },
     {
      "id": "ctg36_25",
      "seqLength": 335,
      "domains": [
       {
        "start": 20,
        "end": 156,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-transport",
        "name": "ABC_tran",
        "accession": "PF00005",
        "description": "ABC transporter",
        "evalue": "7.5e-28",
        "score": "97.9"
       }
      ]
     },
     {
      "id": "ctg36_26",
      "seqLength": 275,
      "domains": [
       {
        "start": 38,
        "end": 232,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0140359' target='_blank'>GO:0140359</a>: ABC-type transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-transport",
        "name": "ABC2_membrane",
        "accession": "PF01061",
        "description": "ABC-2 type transporter",
        "evalue": "8.3e-07",
        "score": "28.8"
       }
      ]
     },
     {
      "id": "ctg36_27",
      "seqLength": 277,
      "domains": [
       {
        "start": 24,
        "end": 264,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Aldo_ket_red",
        "accession": "PF00248",
        "description": "Aldo/keto reductase family",
        "evalue": "7.5e-48",
        "score": "163.2"
       }
      ]
     },
     {
      "id": "ctg36_28",
      "seqLength": 193,
      "domains": [
       {
        "start": 5,
        "end": 149,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "FMN_red",
        "accession": "PF03358",
        "description": "NADPH-dependent FMN reductase",
        "evalue": "8.5e-29",
        "score": "100.4"
       }
      ]
     },
     {
      "id": "ctg36_29",
      "seqLength": 232,
      "domains": [
       {
        "start": 30,
        "end": 218,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0034257' target='_blank'>GO:0034257</a>: nicotinamide riboside transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0034258' target='_blank'>GO:0034258</a>: nicotinamide riboside transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "NMN_transporter",
        "accession": "PF04973",
        "description": "Nicotinamide mononucleotide transporter",
        "evalue": "9.3e-50",
        "score": "169.2"
       }
      ]
     },
     {
      "id": "ctg36_32",
      "seqLength": 628,
      "domains": [
       {
        "start": 1,
        "end": 163,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Thioredox_DsbH",
        "accession": "PF03190",
        "description": "Protein of unknown function, DUF255",
        "evalue": "3.4e-66",
        "score": "222.3"
       }
      ]
     },
     {
      "id": "ctg36_33",
      "seqLength": 571,
      "domains": [
       {
        "start": 209,
        "end": 237,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Stealth_CR1",
        "accession": "PF17101",
        "description": "Stealth protein CR1, conserved region 1",
        "evalue": "6.4e-09",
        "score": "35.5"
       },
       {
        "start": 247,
        "end": 352,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016772' target='_blank'>GO:0016772</a>: transferase activity, transferring phosphorus-containing groups"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Stealth_CR2",
        "accession": "PF11380",
        "description": "Stealth protein CR2, conserved region 2",
        "evalue": "1.3e-38",
        "score": "131.6"
       },
       {
        "start": 397,
        "end": 444,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Stealth_CR3",
        "accession": "PF17102",
        "description": "Stealth protein CR3, conserved region 3",
        "evalue": "4.7e-18",
        "score": "65.0"
       },
       {
        "start": 473,
        "end": 521,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Stealth_CR4",
        "accession": "PF17103",
        "description": "Stealth protein CR4, conserved region 4",
        "evalue": "2.8e-14",
        "score": "52.9"
       }
      ]
     },
     {
      "id": "ctg36_34",
      "seqLength": 312,
      "domains": [
       {
        "start": 15,
        "end": 209,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Metallophos",
        "accession": "PF00149",
        "description": "Calcineurin-like phosphoesterase",
        "evalue": "5.6e-17",
        "score": "63.1"
       }
      ]
     },
     {
      "id": "ctg36_35",
      "seqLength": 150,
      "domains": [
       {
        "start": 33,
        "end": 129,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "HSP20",
        "accession": "PF00011",
        "description": "Hsp20/alpha crystallin family",
        "evalue": "5.4e-22",
        "score": "78.0"
       }
      ]
     },
     {
      "id": "ctg36_37",
      "seqLength": 278,
      "domains": [
       {
        "start": 97,
        "end": 191,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PAP2",
        "accession": "PF01569",
        "description": "PAP2 superfamily",
        "evalue": "2e-08",
        "score": "34.3"
       }
      ]
     },
     {
      "id": "ctg36_38",
      "seqLength": 384,
      "domains": [
       {
        "start": 45,
        "end": 183,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Chal_sti_synt_N",
        "accession": "PF00195",
        "description": "Chalcone and stilbene synthases, N-terminal domain",
        "evalue": "1.4e-27",
        "score": "96.7"
       },
       {
        "start": 300,
        "end": 380,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Chal_sti_synt_C",
        "accession": "PF02797",
        "description": "Chalcone and stilbene synthases, C-terminal domain",
        "evalue": "3.3e-19",
        "score": "69.5"
       }
      ]
     },
     {
      "id": "ctg36_39",
      "seqLength": 237,
      "domains": [
       {
        "start": 54,
        "end": 146,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008757' target='_blank'>GO:0008757</a>: S-adenosylmethionine-dependent methyltransferase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Methyltransf_11",
        "accession": "PF08241",
        "description": "Methyltransferase domain",
        "evalue": "4e-10",
        "score": "40.3"
       }
      ]
     },
     {
      "id": "ctg36_40",
      "seqLength": 387,
      "domains": [
       {
        "start": 2,
        "end": 342,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0071949' target='_blank'>GO:0071949</a>: FAD binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "FAD_binding_3",
        "accession": "PF01494",
        "description": "FAD binding domain",
        "evalue": "7.7e-48",
        "score": "163.6"
       }
      ]
     },
     {
      "id": "ctg36_41",
      "seqLength": 554,
      "domains": [
       {
        "start": 173,
        "end": 299,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008168' target='_blank'>GO:0008168</a>: methyltransferase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "MTS",
        "accession": "PF05175",
        "description": "Methyltransferase small domain",
        "evalue": "9.5e-15",
        "score": "54.8"
       }
      ]
     },
     {
      "id": "ctg36_42",
      "seqLength": 482,
      "domains": [
       {
        "start": 41,
        "end": 116,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Amino_oxidase",
        "accession": "PF01593",
        "description": "Flavin containing amine oxidoreductase",
        "evalue": "8.4e-18",
        "score": "65.0"
       },
       {
        "start": 134,
        "end": 468,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Amino_oxidase",
        "accession": "PF01593",
        "description": "Flavin containing amine oxidoreductase",
        "evalue": "1.2e-39",
        "score": "137.0"
       }
      ]
     },
     {
      "id": "ctg36_45",
      "seqLength": 84,
      "domains": [
       {
        "start": 1,
        "end": 82,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Acylphosphatase",
        "accession": "PF00708",
        "description": "Acylphosphatase",
        "evalue": "1.7e-26",
        "score": "92.5"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   }
  ]
 },
 "r55c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002174: 0-3894": {
       "start": 0,
       "end": 3894,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "epls",
         "query_loc": 2169,
         "subject_loc": 1947
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "epls",
         "start": 0,
         "end": 3894,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      },
      "BGC0002535: 1708-15164": {
       "start": 1708,
       "end": 15164,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "pldA",
         "query_loc": 2169,
         "subject_loc": 3733
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BCD58485.1",
         "start": 8993,
         "end": 10082,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BCD58486.1",
         "start": 10381,
         "end": 11329,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BCD58487.1",
         "start": 11412,
         "end": 12867,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "BCD58488.1",
         "start": 13264,
         "end": 14113,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BCD58489.1",
         "start": 14465,
         "end": 15164,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "pldA",
         "start": 1708,
         "end": 5758,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        },
        {
         "locus_tag": "pldB",
         "start": 5845,
         "end": 7246,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "pldC",
         "start": 7398,
         "end": 8661,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000343: 1-6208": {
       "start": 1,
       "end": 6208,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "ACY02015.1",
         "query_loc": 2169,
         "subject_loc": 4943
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACY02012.1",
         "start": 1,
         "end": 1174,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACY02013.1",
         "start": 1170,
         "end": 2796,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACY02014.1",
         "start": 2809,
         "end": 3682,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACY02015.1",
         "start": 3678,
         "end": 6208,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      },
      "BGC0000933: 0-5189": {
       "start": 0,
       "end": 5189,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "AGY49247.1",
         "query_loc": 2169,
         "subject_loc": 781
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AGY49245.1",
         "start": 2794,
         "end": 3385,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGY49246.1",
         "start": 3393,
         "end": 4815,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGY49247.1",
         "start": 0,
         "end": 1563,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg55_2"
         }
        },
        {
         "locus_tag": "AGY49248.1",
         "start": 1787,
         "end": 2729,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGY49249.1",
         "start": 4814,
         "end": 5189,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000375: 0-9457": {
       "start": 0,
       "end": 9457,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "indC",
         "query_loc": 2169,
         "subject_loc": 3696
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AFV27433.1",
         "start": 0,
         "end": 1266,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AFV27437.1",
         "start": 8740,
         "end": 9457,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "indA",
         "start": 5797,
         "end": 6751,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "indB",
         "start": 6834,
         "end": 8679,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "indC",
         "start": 1629,
         "end": 5763,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      },
      "BGC0002295: 0-9315": {
       "start": 0,
       "end": 9315,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "minA",
         "query_loc": 2169,
         "subject_loc": 3634
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "minA",
         "start": 1564,
         "end": 5704,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        },
        {
         "locus_tag": "minB",
         "start": 5735,
         "end": 6689,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "minC",
         "start": 6724,
         "end": 8566,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "minD",
         "start": 8592,
         "end": 9315,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "minT",
         "start": 0,
         "end": 1260,
         "strand": 1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0001833: 14964-30015": {
       "start": 14964,
       "end": 30015,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "icoS",
         "query_loc": 2169,
         "subject_loc": 22489
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "icoS",
         "start": 14964,
         "end": 30015,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      },
      "BGC0002518: 0-10561": {
       "start": 0,
       "end": 10561,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "GE543_00950",
         "query_loc": 2169,
         "subject_loc": 5812
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "GE543_00945",
         "start": 0,
         "end": 774,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "GE543_00950",
         "start": 1063,
         "end": 10561,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      },
      "BGC0001135: 0-16848": {
       "start": 0,
       "end": 16848,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "nrpS",
         "query_loc": 2169,
         "subject_loc": 8424
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "nrpS",
         "start": 0,
         "end": 16848,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      },
      "BGC0002075: 0-3894": {
       "start": 0,
       "end": 3894,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "A8O26_RS14270",
         "query_loc": 2169,
         "subject_loc": 1947
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "A8O26_RS14270",
         "start": 0,
         "end": 3894,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002174: 0-3894": {
       "start": 0,
       "end": 3894,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "epls",
         "query_loc": 2169,
         "subject_loc": 1947
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "epls",
         "start": 0,
         "end": 3894,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      },
      "BGC0002535: 1708-15164": {
       "start": 1708,
       "end": 15164,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "pldA",
         "query_loc": 2169,
         "subject_loc": 3733
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BCD58485.1",
         "start": 8993,
         "end": 10082,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BCD58486.1",
         "start": 10381,
         "end": 11329,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BCD58487.1",
         "start": 11412,
         "end": 12867,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "BCD58488.1",
         "start": 13264,
         "end": 14113,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BCD58489.1",
         "start": 14465,
         "end": 15164,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "pldA",
         "start": 1708,
         "end": 5758,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        },
        {
         "locus_tag": "pldB",
         "start": 5845,
         "end": 7246,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "pldC",
         "start": 7398,
         "end": 8661,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000343: 1-6208": {
       "start": 1,
       "end": 6208,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "ACY02015.1",
         "query_loc": 2169,
         "subject_loc": 4943
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACY02012.1",
         "start": 1,
         "end": 1174,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACY02013.1",
         "start": 1170,
         "end": 2796,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACY02014.1",
         "start": 2809,
         "end": 3682,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACY02015.1",
         "start": 3678,
         "end": 6208,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      },
      "BGC0000933: 0-5189": {
       "start": 0,
       "end": 5189,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "AGY49247.1",
         "query_loc": 2169,
         "subject_loc": 781
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AGY49245.1",
         "start": 2794,
         "end": 3385,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGY49246.1",
         "start": 3393,
         "end": 4815,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGY49247.1",
         "start": 0,
         "end": 1563,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "ctg55_2"
         }
        },
        {
         "locus_tag": "AGY49248.1",
         "start": 1787,
         "end": 2729,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGY49249.1",
         "start": 4814,
         "end": 5189,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000375: 0-9457": {
       "start": 0,
       "end": 9457,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "indC",
         "query_loc": 2169,
         "subject_loc": 3696
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AFV27433.1",
         "start": 0,
         "end": 1266,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AFV27437.1",
         "start": 8740,
         "end": 9457,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "indA",
         "start": 5797,
         "end": 6751,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "indB",
         "start": 6834,
         "end": 8679,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "indC",
         "start": 1629,
         "end": 5763,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      },
      "BGC0002295: 0-9315": {
       "start": 0,
       "end": 9315,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "minA",
         "query_loc": 2169,
         "subject_loc": 3634
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "minA",
         "start": 1564,
         "end": 5704,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        },
        {
         "locus_tag": "minB",
         "start": 5735,
         "end": 6689,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "minC",
         "start": 6724,
         "end": 8566,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "minD",
         "start": 8592,
         "end": 9315,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "minT",
         "start": 0,
         "end": 1260,
         "strand": 1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0001833: 14964-30015": {
       "start": 14964,
       "end": 30015,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "icoS",
         "query_loc": 2169,
         "subject_loc": 22489
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "icoS",
         "start": 14964,
         "end": 30015,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      },
      "BGC0002518: 0-10561": {
       "start": 0,
       "end": 10561,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "GE543_00950",
         "query_loc": 2169,
         "subject_loc": 5812
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "GE543_00945",
         "start": 0,
         "end": 774,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "GE543_00950",
         "start": 1063,
         "end": 10561,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      },
      "BGC0001135: 0-16848": {
       "start": 0,
       "end": 16848,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "nrpS",
         "query_loc": 2169,
         "subject_loc": 8424
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "nrpS",
         "start": 0,
         "end": 16848,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      },
      "BGC0002075: 0-3894": {
       "start": 0,
       "end": 3894,
       "links": [
        {
         "query": "ctg55_2",
         "subject": "A8O26_RS14270",
         "query_loc": 2169,
         "subject_loc": 1947
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "A8O26_RS14270",
         "start": 0,
         "end": 3894,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "ctg55_2"
         }
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "ctg55_2",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 62,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PCP",
        "modifier": false,
        "special": false,
        "cds": "ctg55_2",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 573,
        "terminalDocking": ""
       },
       {
        "name": "",
        "description": "TIGR02353",
        "modifier": false,
        "special": false,
        "cds": "ctg55_2",
        "css": "jsdomain-other",
        "inactive": false,
        "start": 658,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "X"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg55_1": {
     "functions": []
    },
    "ctg55_2": {
     "functions": [
      {
       "description": "TIGR02353",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg55_3": {
     "functions": []
    },
    "ctg55_4": {
     "functions": []
    },
    "ctg55_5": {
     "functions": [
      {
       "description": "SMCOG1012:4'-phosphopantetheinyl transferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg55_6": {
     "functions": []
    },
    "ctg55_7": {
     "functions": []
    },
    "ctg55_8": {
     "functions": []
    },
    "ctg55_9": {
     "functions": []
    },
    "ctg55_10": {
     "functions": []
    },
    "ctg55_11": {
     "functions": []
    },
    "ctg55_12": {
     "functions": [
      {
       "description": "SMCOG1064:glucose-1-phosphate adenylyl/thymidylyltransferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg55_13": {
     "functions": [
      {
       "description": "SMCOG1111:GCN5-related N-acetyltransferase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg55_14": {
     "functions": []
    },
    "ctg55_15": {
     "functions": []
    },
    "ctg55_16": {
     "functions": []
    },
    "ctg55_17": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "ctg55_2",
      "seqLength": 1353,
      "domains": [
       {
        "start": 62,
        "end": 452,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "9.2e-65",
        "score": "219.0"
       },
       {
        "start": 572,
        "end": 634,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "1.8e-11",
        "score": "44.3"
       }
      ]
     },
     {
      "id": "ctg55_3",
      "seqLength": 444,
      "domains": [
       {
        "start": 29,
        "end": 201,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Peptidase_M1_N",
        "accession": "PF17900",
        "description": "Peptidase M1 N-terminal domain",
        "evalue": "3.7e-16",
        "score": "60.0"
       },
       {
        "start": 291,
        "end": 433,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008237' target='_blank'>GO:0008237</a>: metallopeptidase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding"
        ],
        "html_class": "generic-type-other",
        "name": "Peptidase_M1",
        "accession": "PF01433",
        "description": "Peptidase family M1 domain",
        "evalue": "3.1e-27",
        "score": "95.7"
       }
      ]
     },
     {
      "id": "ctg55_5",
      "seqLength": 229,
      "domains": [
       {
        "start": 100,
        "end": 185,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000287' target='_blank'>GO:0000287</a>: magnesium ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008897' target='_blank'>GO:0008897</a>: holo-[acyl-carrier-protein] synthase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "ACPS",
        "accession": "PF01648",
        "description": "4'-phosphopantetheinyl transferase superfamily",
        "evalue": "2.8e-10",
        "score": "40.5"
       }
      ]
     },
     {
      "id": "ctg55_7",
      "seqLength": 338,
      "domains": [
       {
        "start": 31,
        "end": 334,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046873' target='_blank'>GO:0046873</a>: metal ion transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030001' target='_blank'>GO:0030001</a>: metal ion transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "CorA",
        "accession": "PF01544",
        "description": "CorA-like Mg2+ transporter protein",
        "evalue": "1.5e-61",
        "score": "208.4"
       }
      ]
     },
     {
      "id": "ctg55_10",
      "seqLength": 294,
      "domains": [
       {
        "start": 130,
        "end": 259,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MscL",
        "accession": "PF01741",
        "description": "Large-conductance mechanosensitive channel, MscL",
        "evalue": "2.2e-34",
        "score": "118.5"
       }
      ]
     },
     {
      "id": "ctg55_11",
      "seqLength": 213,
      "domains": [
       {
        "start": 29,
        "end": 207,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "5-FTHF_cyc-lig",
        "accession": "PF01812",
        "description": "5-formyltetrahydrofolate cyclo-ligase family",
        "evalue": "1.4e-31",
        "score": "109.9"
       }
      ]
     },
     {
      "id": "ctg55_12",
      "seqLength": 272,
      "domains": [
       {
        "start": 1,
        "end": 246,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "NTP_transferase",
        "accession": "PF00483",
        "description": "Nucleotidyl transferase",
        "evalue": "1.4e-17",
        "score": "64.3"
       }
      ]
     },
     {
      "id": "ctg55_13",
      "seqLength": 207,
      "domains": [
       {
        "start": 1,
        "end": 142,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016747' target='_blank'>GO:0016747</a>: acyltransferase activity, transferring groups other than amino-acyl groups"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Acetyltransf_3",
        "accession": "PF13302",
        "description": "Acetyltransferase (GNAT) domain",
        "evalue": "3.4e-19",
        "score": "70.0"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   }
  ]
 }
};
